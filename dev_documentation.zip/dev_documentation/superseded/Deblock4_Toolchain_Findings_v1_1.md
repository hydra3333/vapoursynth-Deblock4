# Deblock4 - Toolchain Findings

**Version:** 1.1
**Date:** 2026-07-28
**Status:** Informative knowledge record; not controlling. Durable capture of
empirically established Zig/linker toolchain facts, so they are not re-derived.
**Encoding:** US-ASCII only
**Provenance:** Each finding records how it was established (build test, source
read, or inference) per the project's verify-cold discipline.

---

# F1. Zig 0.16 omits an unreferenced non-exported function entirely

**Status: established by build test (W3X Debug build, Stage 1B.1) plus dumpbin
/SYMBOLS on the resulting cache objects. Conclusive.**

Context: Stage 1B.1 needed the SSE4.1/AVX2 backend marker functions to be
present and linked in the DLL but NOT exported (charter G6) and NOT called
(charter G5). The first attempt declared them as ordinary non-exported
functions and tried to retain them with Zig's forceUndefinedSymbol (which emits
a COFF /INCLUDE-class linker requirement):

```zig
pub fn deblock4_backend_probe_sse41_marker() callconv(.c) u32 { return ...; }
```

with, in build.zig:

```zig
dll.forceUndefinedSymbol("deblock4_backend_probe_sse41_marker");
```

Result: the DLL link FAILED with "undefined symbol". dumpbin /SYMBOLS on the
gated cache objects showed:

- `.text` section length ZERO;
- no marker symbol present at all - not under the requested name, not mangled;
- only static build-metadata symbols (builtin.cpu, Target.x86.cpu.x86_64,
  anonymous constants) and the source filename in debug metadata.

Conclusion: **a top-level `pub fn ... callconv(.c)` that is never semantically
referenced (never called, never address-taken) and not declared `export` is
NOT EMITTED by Zig 0.16.** Zig's lazy analysis/codegen omits it. Therefore
forceUndefinedSymbol has nothing to retain - it correctly requests a symbol that
was never generated.

Consequences / rules of thumb:
- `callconv(.c)` sets the calling convention; it does NOT force emission and
  does NOT guarantee an unmangled external COFF symbol name.
- `export` DOES force emission and an external name - but also creates a PE
  export-table entry, which G6 forbids for gated code. So `export` is not a
  usable retention mechanism for non-exported code.
- forceUndefinedSymbol / COFF /INCLUDE can only retain a symbol that actually
  exists in an input object. It cannot cause emission.

# F2. Cross-compilation references do NOT force emission (anchor falsified)

**Status: FALSIFIED by build test (W3X Debug build of the v1.5 delivery) plus
dumpbin /SYMBOLS. Superseded by F4/F5. Retained as a recorded dead end.**

The v1.5 attempt placed an address-taking anchor in the DLL root module which
@import-ed the gated modules and took the address of each marker. Result: both
standalone gated objects STILL had .text length 0 and no marker symbol.

Root cause: each Zig compile step analyses its own module graph independently.
Reusing the same std.Build.Module in two compile steps (the DLL compilation and
a standalone addObject compilation) creates two INDEPENDENT compilations; a
semantic reference in one does not force emission in the other. An @import in
the DLL graph may compile ANOTHER INSTANCE of the gated source inside the DLL
compilation (under murky per-module-target semantics) - it does not create an
inbound reference to the standalone object. Per-module targets are themselves
slated for possible removal (ziglang/zig issue 22285), and mixing targets
across one compilation graph is unsupported territory (issue 3521).

Rule of thumb: emission is decided per compilation unit. To force emission in a
given object, the semantic root must be IN that object's own compilation:
export fn, or a reference from that unit's own graph. Cross-object references
are a LINKER-level matter and require export/@extern pairs (see F4/F5).

The original design principle below is retained for context (it remains the
right shape - address-taken, never called, internal pointers - but the
reference must be @extern at the linker level, not @import across compilations):

To make a gated function present (emitted + linker-retained) while non-exported
and non-executed, give it a genuine SEMANTIC reference that is an ADDRESS
reference, taken by retained baseline code:

```text
- baseline (generic-target) code takes the address of each gated marker and
  stores it into an internal, non-exported pointer or pointer table;
- taking the address forces Zig to EMIT the function (it is now referenced);
- the address reference puts the function in the linker reachability graph, so
  /OPT:REF RETAINS it;
- the address is TAKEN, never CALLED - so no execution path exists (G5 holds);
- nothing is declared export, and the pointer table is internal - so nothing
  enters the PE export table (G6 holds, structurally).
```

The G5-critical distinction: ADDRESS-TAKEN retains code without creating an
execution path; a CALL would create one and is forbidden until the Stage 1B.3
capability guard exists. The anchor must achieve emission + retention +
non-export + non-execution simultaneously.

This is also the shape of the eventual real dispatch mechanism (a
capability-populated function-pointer table, the FFmpeg/dav1d idiom identified
in the retention/export research), so the anchor is a step toward the real
architecture, not a throwaway.

Verification the anchor works (contrast with F1's failure):
- DLL links successfully;
- dumpbin /SYMBOLS on the gated objects shows each marker present with
  NON-ZERO .text;
- dumpbin /EXPORTS on the DLL shows NEITHER gated marker.

# F3. Windows binary inspection tooling

**Status: established by environment inspection (W3X machine).**

- Zig 0.16 ships only a flagless objdump passthrough (lib/compiler/objdump.zig);
  no standalone llvm-objdump or llvm-nm is bundled. `zig objdump --help` shows
  only -h/--help. Inadequate for targeted symbol/export inspection.
- The usable inspector is MSVC `dumpbin`, present in the VS 2026 install under
  `C:\Program Files\Microsoft Visual Studio\18\Community\VC\Tools\MSVC\<ver>\
  bin\Hostx64\x64\dumpbin.exe` (VS product year 2026 = internal version 18;
  two toolsets seen, 14.44.x and 14.51.x).
- dumpbin is reached WITHOUT hard-coding the MSVC version by calling VsDevCmd to
  set the environment, then relying on PATH:
  `CALL "C:\Program Files\Microsoft Visual Studio\18\Community\Common7\Tools\VsDevCmd.bat" -arch=amd64 -host_arch=amd64`
  (note: VsDevCmd changes directory, so restore the working directory after).
- Commands in use: `dumpbin /EXPORTS <dll>` (export-table check),
  `dumpbin /SYMBOLS <obj>` (symbol/emission check),
  `dumpbin /DISASM <dll>` (supplementary only - shows instructions PRESENT, not
  whether any path REACHES them, so never the load-bearing non-execution proof).

# F4. export fn in an addObject-ed object does NOT enter the PE export table

**Status: established by build test (W3X Debug build of the v1.5 delivery) plus
dumpbin /EXPORTS on the built DLL and /LINKERMEMBER on the import library.
Conclusive.**

Evidence: the generic and scalar markers are declared `export fn` in their own
separately compiled objects, added to the DLL with addObject. The built
Deblock4.dll exported ONLY the root-graph export (deblock4_build_probe_value);
neither addObject-ed export fn appeared in the export table or in Deblock4.lib.

Conclusion: on Zig 0.16 + lld-link (COFF/PE), `export` in an OBJECT-mode
compilation grants EMISSION and EXTERNAL LINKAGE but does NOT by itself create
PE export candidacy. A symbol enters .edata only via a dllexport-class directive
from the DLL compilation itself. Three separate properties, three controls:

```text
EMISSION   in-unit semantic root (export fn, or in-graph reference)
LINKAGE    export/@export (definition) + extern/@extern (reference)
PE EXPORT  dllexport-class directive from the DLL compilation only
```

Two consequences:
- An export fn that must be REACHABLE FROM OUTSIDE the DLL (e.g. smoke-test
  targets like the generic/scalar markers) must be part of the DLL root
  compilation graph (import its module into the root), or it will not export
  and the consumer will not link.
- An export fn in an addObject-ed unit is exactly "linkable but not
  PE-exported" - the property needed for gated backend code. Its absence from
  .edata is corroborated by the standing dumpbin /EXPORTS gate (charter G6
  tier 3; tier 2 if an explicit export-list mechanism is available).

This finding motivated the charter v1.10 refinement of the G6 corollary: the
ban is on PE-EXPORT of gated code, not on the export keyword, which is Zig's
only linkage mechanism and is required for emission and cross-object reference.

# F5. The proven Zig idiom for multi-feature-level code in one binary

**Status: established community practice (worked showcase, Ziggit
"Dispatching SIMD functions at runtime", Nov 2024; consistent with accepted
Zig proposal 1018 - function multi-versioning - which is NOT yet implemented,
so manual dispatch is required).**

The pattern:
- Compile the feature code as SEPARATE COMPILATION UNITS, one per feature
  level, each with its own target/-mcpu. One target contract per unit.
- Each unit SELF-EMITS its functions: export fn (or @export) under a unique
  linker-visible name, so emission and linkage are rooted in the unit itself.
- Consumers in the baseline unit reference other units' functions via @extern
  BY NAME, resolved at link time - a genuine cross-object reference edge that
  also retains the code and fails the link loudly if a unit is missing.
- Runtime dispatch: detect the CPU (std.zig.system.resolveTargetQuery with
  .cpu_model = .native; std.Target.x86.featureSetHasAll), then populate
  internal function pointers with the @extern addresses. Address-taken at
  init; called only after the capability check passes.
- Do NOT @import feature modules across target boundaries; the seam between
  target contracts is the LINKER (extern/export), not the module graph.

Deblock4 mapping: gated markers/kernels are export fn in their own
single-target addObject units (F4: linkable, not PE-exported); the DLL-root
baseline anchor (and later the 1B.3 dispatch table) references them with
@extern + address-taken-never-called; generic/scalar modules are imported into
the DLL root graph so their exports genuinely PE-export for the smoke test;
duplicate-symbol rule: a given source is either in the root graph OR a linked
object, never both.

---

*This file is informative knowledge capture so hard-won toolchain facts are not
re-derived in a later chat. The charter and README prevail for any controlling
rule.*
