# Deblock4 Stage 1B.3 W3C Delivery

Version: v1.0
Date: 2026-07-31
Scope: Deblock4_Scope_Stage_1B3_Runtime_Capability_Guard_v1_3.md
Source base: the exact tree supplied by W3X as src(37).zip
Status: IMPLEMENTATION DELIVERY - W3X BUILD/RUN AND W3C OUTPUT REVIEW REQUIRED
Encoding: US-ASCII only

## 1. Base and authority

Per the previously agreed Deblock4 workflow, no commit hash is pinned. W3X may
commit documentation between source scopes. The exact implementation base is
the source tree supplied in `src(37).zip`.

Controlling inputs used:

```text
AI_Charter_and_Invariants_Card_v1_17.md
README_Deblock4_Design_Spec_v1_9.md
Deblock4_Scope_Stage_1B3_Runtime_Capability_Guard_v1_3.md
Deblock4_Debug_Module_Inclusion_Pattern_v1_1.md
build_1B2_v5_REDEVELOPED.bat
zig_builtin_x86_64_v1.txt
zig_builtin_x86_64_v2.txt
zig_builtin_x86_64_v3.txt
```

No forbidden existing source file was modified.

## 2. Delivered files

New whole files:

```text
build_1B3_v1.bat
src/cpu_capability_detection.zig
src/deblock4_config.zig
src/deblock4_selftest.zig
src/force_down_debug.zig
src/print_diag_helper_functions.zig
src/print_helper_functions.zig
```

Modified existing files:

```text
build.zig
src/dll_probe.zig
```

Delivery forms:

```text
repo_overlay/   exact whole-file overlay for all nine changed files
*.patch         unified patch containing the same changes
```

## 3. Implementation summary

### 3.1 Capability records and once detection

`src/cpu_capability_detection.zig` provides the pinned public contract:

```text
ResolvedTier
RequestedBackend
FeatureState
ActualCapabilities
EffectiveCapabilities
InstanceInitError

detectActualOnce()
initInstanceCapabilities(instance_name, requested)
```

Actual capability is detected once process-wide through a three-state atomic
protocol:

```text
idle -> running -> complete
```

The detector writes the immutable storage before a release store publishes the
complete state. Later callers use an acquire load and receive the same const
pointer. No per-frame or future hot-path detection is introduced.

### 3.2 Raw CPUID/XGETBV detector

The detector uses raw inline assembly in the pinned detection unit. CPUID
records the complete Set-A contract, with optional-leaf availability guards.
XGETBV is called only inside the OSXSAVE-present branch. The Set-B result is
recorded separately as the XCR0 XMM+YMM state.

Whole-level resolution is exact:

```text
v3 = complete v1 + complete v2 additions + complete v3 additions
     + XCR0 XMM/YMM enabled
v2 = complete v1 + complete v2 additions
v1 = unconditional Windows x64 floor
```

OSFXSR and SCE are not misreported as CPUID observations. They carry the
`policy_assumed_present` provenance required by the scope.

### 3.3 Structural force-down

Effective capability is constructed by explicit intersection:

```text
effective feature = actual feature AND feature permitted by ceiling
```

The effective record carries the masked feature set as well as the resolved
tier. The force-down path has no operation capable of setting an absent actual
feature. Nine actual-tier x ceiling combinations are covered by pure unit tests.

The environment seam is isolated in `src/force_down_debug.zig` and accepts only
exact lower-case `v1` or `v2`. Acquisition uses a fixed UTF-16 stack buffer and
the Win32 `GetEnvironmentVariableW`-class API. Absence is inert; invalid values
are loud and return `InvalidForceDownValue`; other acquisition failures panic.

### 3.4 G10 three-layer debug omission

The two debug facilities are independent modules and independent gates:

```text
enable_force_down          -> src/force_down_debug.zig
enable_verbose_detection   -> src/print_diag_helper_functions.zig
```

Both use the ratified source-visible C-3 conditional import and same-option use
gates. Both modules also contain their own matching inner content gate.

Each has three unique proof surfaces:

```text
force-down:
    DEBLOCK4_FORCE_DOWN_DEBUG_MARKER_FD00D001
    deblock4_force_down_marker_FD00D001
    0xFD00D001

verbose detection:
    DEBLOCK4_VERBOSE_DETECTION_MARKER_DD00D001
    deblock4_verbose_detection_marker_DD00D001
    0xDD00D001
```

`build.zig` rejects either debug option in ReleaseSafe, ReleaseFast or
ReleaseSmall. The options default off.

### 3.5 Diagnostics and forward API

`src/print_helper_functions.zig` is the always-present printing home. It emits
the pinned once-per-instance production summary and deterministic reason.

`src/print_diag_helper_functions.zig` emits the Debug-only per-feature dump,
including provenance and Set-B state.

`src/deblock4_config.zig` is declarations-only and holds the debug gates, tier
names, prefix and initial version string `0.1.0-dev`.

`src/deblock4_selftest.zig` exercises the same public instance API intended for
the future filter stage, including `.auto` and a non-auto requested backend.

### 3.6 Build graph

`build.zig` adds:

```text
-Denable_force_down
-Denable_verbose_detection
selftest
selftest-run
test coverage for cpu_capability_detection.zig
detection-object
```

The standalone detection object is compiled for the explicit baseline named
model and installed at:

```text
zig-out/detection-objects/cpu_capability_detection.obj
```

`src/dll_probe.zig` makes the minimum authorised call into the first-class
instance API so the real DLL graph contains the production detector and the
G10 artifact proof is meaningful. It does not call a gated backend.

## 4. Completed Zig model reconciliation for approval

The implementation exactly re-encodes all three supplied Zig 0.16.0 named-model
captures and compile-fails if any captured set changes.

Approved seed mappings completed with no unresolved classification:

```text
Zig tag   psABI/scope name
--------  ----------------
x87       FPU
cx16      CMPXCHG16B
sahf      LAHF-SAHF
bmi       BMI1
```

Direct architectural members:

```text
v1: cmov cx8 fxsr mmx sse sse2
v2: popcnt sse3 sse4_1 sse4_2 ssse3
v3: avx avx2 bmi2 f16c fma lzcnt movbe
```

Scope-only policy rows, not expected in Zig model sets:

```text
OSFXSR
SCE
```

Exact exclusions proposed for W3X/W3D approval:

```text
64bit
    architecture precondition, not a psABI level-table member

crc32
    Zig feature covered by SSE4.2, not a separate psABI v2 row

xsave
    Zig code-generation feature, not the psABI OSXSAVE membership row

allow_light_256_bit
false_deps_lzcnt_tzcnt
false_deps_popcnt
fast_15bytenop
fast_scalar_fsqrt
fast_shld_rotate
fast_variable_crosslane_shuffle
fast_variable_perlane_shuffle
idivq_to_divl
macrofusion
nopl
slow_3ops_lea
slow_incdec
slow_unaligned_mem_32
vzeroupper
    compiler tuning or code-generation properties, not ISA-level membership
```

No additional entry was silently classified. This complete list requires the
scope-mandated W3X/W3D approval before the implementing commit is accepted.

## 5. Validation runner

Run from the repository root:

```bat
build_1B3_v1.bat
```

The runner is loud-failing and performs:

```text
1. exact Zig 0.16.0 check;
2. full Stage 1B.2 regression batch;
3. ReleaseSafe and ReleaseFast build, test and self-test;
4. release DLL and self-test G10 absence over raw bytes, exports and disassembly;
5. Debug positive-control build with both gates on;
6. absent, v2, v1 and invalid DEBLOCK4_FORCE_DOWN cases;
7. non-auto requested-backend summary rendering;
8. ReleaseSafe/ReleaseFast/ReleaseSmall rejection for each debug option;
9. standalone baseline detection-object symbols and disassembly;
10. CPUID presence, exactly one XGETBV, baseline deny-family scans;
11. source-visible OSXSAVE/XGETBV guard checks;
12. deliberate named-model one-feature perturbation in a temporary copy;
13. one-way first-class dependency audit;
14. git diff --check and final git status.
```

Evidence is retained under:

```text
zig-out/inspection_1B3
```

## 6. Static validation performed by W3C

Passed locally without Zig execution:

```text
exact nine-file changed set
US-ASCII and line-ending check for every changed file
Zig delimiter/lexical balance scan
invalid export/noinline modifier scan
G10 C-3 import-shape scan
config declarations-only scan
one-way dependency textual audit
capability API, guard and atomic-once structure scan
exact equality of all three coded model captures to the supplied files
mapping/exclusion structure scan
batch label/call consistency
batch required-proof component audit
unique-marker audit
newline-escape audit
git diff --check using CR-at-EOL policy for the supplied CRLF source
unified-patch apply check against a clean source-base export
byte-identical comparison of patched files to the overlay
```

The detailed results are included as `STATIC_VALIDATION.txt`.

## 7. Validation not performed here

This environment did not provide an installed Zig 0.16.0 compiler, Windows
execution, or Visual Studio `dumpbin`. The exact compiler could not be
materialized into the working runtime. Therefore W3C has NOT claimed:

```text
Zig compilation PASS
Windows runtime PASS
CPUID/XGETBV runtime correctness on the W3X host
dumpbin instruction-level PASS
G10 artifact absence/presence PASS
Stage 1B.2 regression PASS
```

The delivery remains provisional until W3X runs the supplied batch and W3C
reviews the complete actual output. This is the normal W3X/W3C/W3D process, not
a waiver of any proof obligation.

## 8. Apply sequence

Preferred overlay method:

```text
1. Confirm the working source matches the supplied src(37).zip base.
2. Extract repo_overlay over the repository root, preserving paths.
3. Run: git diff --check
4. Review: git status --short
5. Run: build_1B3_v1.bat
```

Patch alternative:

```bat
git apply --check --whitespace=nowarn Deblock4_Stage_1B3_W3C_Delivery_v1_0.patch
git apply --whitespace=nowarn Deblock4_Stage_1B3_W3C_Delivery_v1_0.patch
git diff --check
git status --short
build_1B3_v1.bat
```

Expected changed-file status is exactly:

```text
M  build.zig
M  src/dll_probe.zig
?? build_1B3_v1.bat
?? src/cpu_capability_detection.zig
?? src/deblock4_config.zig
?? src/deblock4_selftest.zig
?? src/force_down_debug.zig
?? src/print_diag_helper_functions.zig
?? src/print_helper_functions.zig
```

## 9. Evidence to return

Please return:

```text
the complete build_1B3_v1.bat console output
all files under zig-out/inspection_1B3, preferably as one ZIP
git status --short after the run
```

W3C will then review the actual outputs against every section-7 obligation and
issue PASS, corrections, or a focused follow-up patch. W3D review follows the
normal process after W3C output review.
