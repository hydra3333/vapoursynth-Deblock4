const std = @import("std");
const build_options = @import("build_options");

const scenario = build_options.scenario;
const enable = build_options.enable;

// ===========================================================================
// Force-down omission mechanism comparison, Zig 0.16.0, on the real toolchain.
//
// The seam lives in force_down_debug.zig and carries a UNIQUE MARKER STRING.
//
// C-3 is GAIS's primary recommendation: a top-level conditional DECLARATION
//   const fd = if (enable) @import("force_down_debug.zig") else struct {};
// GAIS claims conditional declarations behave identically to conditional
// statements for omission. This test proves or disproves that on the toolchain.
//
// Scenarios:
//   c3_ok      : C-3 decl, reference gated                (correct)   -> expect COMPILE, marker ABSENT (release)
//   c3_leak    : C-3 decl, reference UNGATED in active code(stray)    -> expect COMPILE FAIL (no member in struct{})
//   c3_importonly : C-3 decl present, NEVER referenced               -> expect COMPILE, marker ABSENT
//   c2_ok      : import inside the gate                   (correct)   -> expect COMPILE, marker ABSENT
//   c3_on      : C-3 decl, gated ref, enable=true (sanity)           -> expect COMPILE, marker PRESENT
// ===========================================================================

// ---- C-3: top-level conditional DECLARATION (GAIS primary form) -----------
const fd_c3 = if (enable)
    @import("force_down_debug.zig")
else
    struct {};

fn c3_ok(tier: u8) u8 {
    var t = tier;
    if (enable) {
        t = fd_c3.tools.applyMaskOnly(t);
    }
    return t;
}

fn c3_leak(tier: u8) u8 {
    var t = tier;
    // STRAY: reference fd_c3 member in ACTIVE (ungated) code.
    // In release, fd_c3 is struct {} -> expect: error: no member named 'tools'
    t = fd_c3.tools.applyMaskOnly(t);
    return t;
}

fn c3_importonly(tier: u8) u8 {
    // fd_c3 declared at top but never referenced anywhere.
    // Does the decl alone drag the marker in? (expect no)
    return tier;
}

// ---- C-2: import inside the gate (for comparison) -------------------------
fn c2_ok(tier: u8) u8 {
    var t = tier;
    if (enable) {
        const fd = @import("force_down_debug.zig");
        t = fd.tools.applyMaskOnly(t);
    }
    return t;
}

pub fn main() void {
    const tier: u8 = 3;
    var result: u8 = tier;

    if (std.mem.eql(u8, scenario, "c3_ok")) {
        result = c3_ok(tier);
    } else if (std.mem.eql(u8, scenario, "c3_leak")) {
        result = c3_leak(tier);
    } else if (std.mem.eql(u8, scenario, "c3_importonly")) {
        result = c3_importonly(tier);
    } else if (std.mem.eql(u8, scenario, "c2_ok")) {
        result = c2_ok(tier);
    } else {
        std.debug.print("unknown scenario: {s}\n", .{scenario});
        return;
    }

    std.debug.print("scenario={s} enable={} tier {} -> {}\n", .{ scenario, enable, tier, result });
}
