// Separate module for the force-down seam. Always present on disk. The seam is
// a CONDITIONAL NAMESPACE: 'tools' is a populated struct when enable is true,
// and an EMPTY struct when enable is false. Omission in release therefore rests
// on the comptime-false branch not being analyzed/emitted, and the empty struct
// gives a compile-error boundary against stray references (C-1 shape).
//
// Carries a UNIQUE MARKER STRING so binary inspection can prove presence/absence.

const std = @import("std");
const build_options = @import("build_options");

pub const tools = if (build_options.enable) struct {
    pub const MARKER = "FORCE_DOWN_MODULE_MARKER_0xC0FFEE";

    pub fn applyMaskOnly(tier: u8) u8 {
        std.debug.print("[seam] applyMaskOnly called, marker={s}\n", .{MARKER});
        if (tier > 1) return tier - 1;
        return tier;
    }
} else struct {};
