const std = @import("std");

// Test harness for comparing two force-down omission patterns in Zig 0.16.0:
//   Pattern A: conditional namespace (empty struct in release)
//   Pattern B: separate module imported inside a comptime gate
//
// Build options:
//   -Denable=true|false        the force-down gate (default false)
//   -Dscenario=NAME            which source scenario to compile
//
// Scenarios (set at build time so each is a clean separate compile):
//   a_ok        Pattern A, correct usage (gated reference only)
//   a_leak      Pattern A, ACCIDENTAL reference in active code
//   b_ok        Pattern B, correct usage (import inside gate)
//   b_leak      Pattern B, ACCIDENTAL active import + reference
//
// What we learn:
//   - Does a_ok COMPILE in release? (tests whether comptime-false if skips
//     analysis of the gated body against the empty struct)
//   - Does a_leak FAIL to compile in release? (tests A's structural boundary)
//   - Does b_ok COMPILE and OMIT in release?
//   - Does b_leak COMPILE but LEAK in release? (tests B's silent-leak risk)

pub fn build(b: *std.Build) void {
    const target = b.standardTargetOptions(.{});
    const optimize = b.standardOptimizeOption(.{});

    const enable = b.option(bool, "enable", "enable force-down gate") orelse false;
    const scenario = b.option([]const u8, "scenario", "which scenario to compile") orelse "a_ok";

    const opts = b.addOptions();
    opts.addOption(bool, "enable", enable);
    opts.addOption([]const u8, "scenario", scenario);

    const exe = b.addExecutable(.{
        .name = "gate_test",
        .root_module = b.createModule(.{
            .root_source_file = b.path("src/main.zig"),
            .target = target,
            .optimize = optimize,
        }),
    });
    exe.root_module.addOptions("build_options", opts);
    b.installArtifact(exe);

    const run = b.addRunArtifact(exe);
    const run_step = b.step("run", "run the selected scenario");
    run_step.dependOn(&run.step);
}
