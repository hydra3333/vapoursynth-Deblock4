@echo off
@setlocal ENABLEEXTENSIONS ENABLEDELAYEDEXPANSION

rem ===========================================================================
rem Force-down omission test, Zig 0.16.0. Proves GAIS's primary recommendation
rem (C-3: top-level conditional DECLARATION  const fd = if (enable) @import(...)
rem else struct {}) genuinely omits the seam in release, plus C-2 for compare.
rem
rem Seam module carries marker FORCE_DOWN_MODULE_MARKER. Compiles each scenario
rem in ReleaseFast with the gate OFF (except the sanity ON run) and scans the
rem binary for the marker.
rem
rem Run from the gate_test folder. Requires zig on PATH. Paste whole output.
rem ===========================================================================

set "ZIG=zig"
set "MARK=FORCE_DOWN_MODULE_MARKER"

echo.
echo Zig version:
%ZIG% version

echo.
echo ###########################################################################
echo # T1  c3_ok  ReleaseFast gate OFF   EXPECT compiles, marker ABSENT
echo #   C-3 conditional declaration, reference gated. GAIS core claim.
echo ###########################################################################
call :build_scan c3_ok false ReleaseFast

echo.
echo ###########################################################################
echo # T2  c3_leak  ReleaseFast gate OFF  EXPECT FAILS to compile
echo #   C-3 stray ungated reference; fd is struct{} in release.
echo #   Expected error: no member named 'tools' in 'struct {}'
echo ###########################################################################
call :build_scan c3_leak false ReleaseFast

echo.
echo ###########################################################################
echo # T3  c3_importonly  ReleaseFast gate OFF  EXPECT compiles, marker ABSENT
echo #   C-3 declaration present but never referenced; decl alone must not leak.
echo ###########################################################################
call :build_scan c3_importonly false ReleaseFast

echo.
echo ###########################################################################
echo # T4  c2_ok  ReleaseFast gate OFF   EXPECT compiles, marker ABSENT
echo #   import inside gate, for comparison.
echo ###########################################################################
call :build_scan c2_ok false ReleaseFast

echo.
echo ###########################################################################
echo # T5  c3_ok  ReleaseFast gate ON   EXPECT compiles, marker PRESENT
echo #   sanity: enabled -> seam really included.
echo ###########################################################################
call :build_scan c3_ok true ReleaseFast

echo.
echo ============================================================
echo INTERPRETATION
echo   T1 compiles + ABSENT   C-3 declaration omits in release  (GAIS claim holds)
echo   T2 FAILS to compile    C-3 empty-struct boundary catches stray refs
echo   T3 compiles + ABSENT   bare C-3 decl does not leak the seam
echo   T4 compiles + ABSENT   C-2 omits too
echo   T5 compiles + PRESENT  seam included when enabled
echo Paste the whole output.
echo ============================================================
pause
exit /b 0

:build_scan
rem %1 scenario  %2 enable  %3 optimize
set "sc=%~1"
if exist ".zig-cache" rmdir /s /q ".zig-cache" >nul 2>nul
if exist "zig-out" rmdir /s /q "zig-out" >nul 2>nul
%ZIG% build -Doptimize=%~3 -Dscenario=%~1 -Denable=%~2
if errorlevel 1 (
    echo   RESULT %sc%: DID NOT COMPILE
    exit /b 0
)
echo   RESULT %sc%: COMPILED
set "exe=zig-out\bin\gate_test.exe"
if not exist "!exe!" (
    echo   scan %sc%: no exe at !exe!
    exit /b 0
)
findstr /C:"%MARK%" "!exe!" >nul < nul
if errorlevel 1 (echo   scan %sc%: marker ABSENT) else (echo   scan %sc%: marker PRESENT)
exit /b 0
