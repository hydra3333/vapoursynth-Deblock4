const std = @import("std");
const builtin = @import("builtin");

const expected_generic_marker: u32 = 0x4442_4701;
const expected_scalar_marker: u32 = 0x4442_5301;

comptime {
    if (builtin.cpu.arch != .x86_64 or
        builtin.os.tag != .windows or
        builtin.abi != .msvc)
    {
        @compileError("backend-isolation smoke test requires x86_64-windows-msvc");
    }

    if (std.Target.x86.featureSetHas(builtin.cpu.features, .sse4_1) or
        std.Target.x86.featureSetHas(builtin.cpu.features, .avx) or
        std.Target.x86.featureSetHas(builtin.cpu.features, .avx2) or
        std.Target.x86.featureSetHas(builtin.cpu.features, .fma))
    {
        @compileError("backend-isolation smoke test requires the provisional baseline target");
    }
}

// Only the safe generic and scalar DLL exports are declared here. There is no
// source-level route from this executable to either target-specific marker.
extern fn deblock4_backend_probe_generic_marker() callconv(.c) u32;
extern fn deblock4_backend_probe_scalar_marker() callconv(.c) u32;

pub fn main() !void {
    const generic_marker = deblock4_backend_probe_generic_marker();
    const scalar_marker = deblock4_backend_probe_scalar_marker();

    if (generic_marker != expected_generic_marker)
        return error.UnexpectedGenericBackendMarker;

    if (scalar_marker != expected_scalar_marker)
        return error.UnexpectedScalarBackendMarker;

    std.debug.print(
        "Deblock4 backend isolation smoke test: PASS " ++
            "(generic 0x{x}, scalar 0x{x})\n",
        .{ generic_marker, scalar_marker },
    );
}
