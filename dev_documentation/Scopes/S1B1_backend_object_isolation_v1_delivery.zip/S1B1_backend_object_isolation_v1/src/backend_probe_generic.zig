const std = @import("std");
const builtin = @import("builtin");

pub const marker_value: u32 = 0x4442_4701;

comptime {
    if (builtin.cpu.arch != .x86_64 or
        builtin.os.tag != .windows or
        builtin.abi != .msvc)
    {
        @compileError("generic backend probe requires x86_64-windows-msvc");
    }

    if (std.Target.x86.featureSetHas(builtin.cpu.features, .sse4_1) or
        std.Target.x86.featureSetHas(builtin.cpu.features, .avx) or
        std.Target.x86.featureSetHas(builtin.cpu.features, .avx2) or
        std.Target.x86.featureSetHas(builtin.cpu.features, .fma))
    {
        @compileError("generic backend probe requires the provisional baseline target");
    }
}

// Safe baseline marker. build.zig deliberately exports this function so the
// backend-isolation smoke test can execute it through Deblock4.dll.
export fn deblock4_backend_probe_generic_marker() u32 {
    return marker_value;
}
