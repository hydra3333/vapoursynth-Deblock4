const std = @import("std");
const builtin = @import("builtin");

comptime {
    if (builtin.cpu.arch != .x86_64 or
        builtin.os.tag != .windows or
        builtin.abi != .msvc)
    {
        @compileError("AVX2 backend probe requires x86_64-windows-msvc");
    }

    if (!std.Target.x86.featureSetHas(builtin.cpu.features, .avx) or
        !std.Target.x86.featureSetHas(builtin.cpu.features, .avx2) or
        std.Target.x86.featureSetHas(builtin.cpu.features, .fma))
    {
        @compileError("AVX2 backend probe requires its provisional FMA-free target contract");
    }
}

// Linker-visible retention marker. build.zig suppresses PE export metadata,
// creates no call reference, and retains this function with forceUndefinedSymbol.
export fn deblock4_backend_probe_avx2_marker() u32 {
    return 0x4442_4201;
}
