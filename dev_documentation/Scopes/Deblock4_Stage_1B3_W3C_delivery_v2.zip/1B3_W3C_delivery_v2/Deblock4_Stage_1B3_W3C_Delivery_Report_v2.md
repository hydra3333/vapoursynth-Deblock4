# Deblock4 - Stage 1B.3 W3C Delivery Report

Version: v2  
Date: 2026-07-31  
Status: REPLACEMENT DELIVERY; SOURCE DESIGN STATICALLY SOUND; W3X BUILD/RUN/INSPECTION EVIDENCE PENDING  
Encoding: US-ASCII

## 1. Disposition

This v2 delivery withdraws and replaces `1B3_W3C_delivery_v1`.

Independent successor-W3C review found no verified semantic defect in the nine
Stage 1B.3 implementation files. W3D independently found the source
scope-faithful and without a blocking design defect. The implementation logic is
therefore retained.

The prior delivery form was not suitable for unchanged reissue under charter
v1.18 because it:

1. instructed W3X to bypass the mandatory whitespace-error patch gate with
   `--whitespace=nowarn`;
2. supplied both a patch and a repository overlay for the same existing files,
   rather than one delivery form per file; and
3. delivered new files as CRLF although C-DELIV-06 requires LF unless an
   existing controlling file contract requires otherwise.

This v2 revision repairs those delivery defects without changing program logic:

- `build.zig`, whose authorised additions are dispersed through several build
  regions, is one complete existing-file replacement preserving its established
  CRLF bytes;
- the small `src/dll_probe.zig` edit is the sole unified patch, and that patch is
  US-ASCII/LF;
- each new file is supplied once, complete, under `repo_new_files/`, in
  US-ASCII/LF;
- both mandatory patch checks and the final `git diff --check` pass in an
  isolated exact-base repository.

No Zig compilation, Windows execution, `dumpbin` inspection, stage PASS, commit,
or acceptance is claimed by W3C. Those remain W3X proof obligations.

## 2. Exact base and scope

Scope: `Deblock4_Scope_Stage_1B3_Runtime_Capability_Guard_v1_3.md`  
Objective: implement and prove the runtime whole-level capability guard, shared
configuration/printing skeleton, ACTUAL/EFFECTIVE records, Debug-only force-down
and verbose seams, self-test, named-model drift checks, and standing validation
batch, without calling a gated backend.

Prevailing controlling documents:

- `AI_Charter_and_Invariants_Card_v1_18.md`
- `README_Deblock4_Design_Spec_v1_9.md`

Exact attached-source-tree base:

- package: `vapoursynth-Deblock4_src.zip`
- SHA-256: `9060f5abc12132f75b66dbd60b87d5b15f387b0096d9ed50c6f4c606f81c6a4a`
- project payload: archive root, excluding the embedded
  `1B3_W3C_delivery_v1/` transport directory

The attached source has no `.git` metadata. W3X must report the actual
repository, branch and starting commit before application; this delivery does
not infer them.

## 3. Adds or changes

- Raw baseline-v1 CPUID/XGETBV detection with leaf guards and whole-level
  v1/v2/v3 resolution.
- Process-wide immutable ACTUAL record and per-instance immutable EFFECTIVE
  record.
- Structural force-down-only intersection with no top-tier force value.
- Shared declarations-only config and always-on summary-printing homes.
- G10 C-3 gated diagnostic and force-down modules.
- Comptime named-model membership and exact-capture drift checks.
- First-class capability self-test and baseline detection inspection object.
- Root standing batch for the complete Stage 1B.3 proof matrix and Stage 1B.2
  regression.

## 4. Defers or does not change

- No runtime call into SSE4.1 or AVX2 backend code.
- No dispatch-table execution wiring.
- No VapourSynth plugin entry point, filter construction, frames, planes,
  pixel copying, or deblocking.
- No change to the Stage 1B.1 retention/export mechanism or Stage 1B.2 backend
  objects.
- No claim that Windows runtime, binary inspection, or perturbation proof has
  passed.

## 5. File manifest and delivery form

Existing file, dispersed change - complete replacement:

- `repo_existing_replacements/build.zig`
  - destination: `build.zig`
  - base SHA-256: `5358526d1fc46d9365c7f0d4f8b2873878e4291fffc844cea7948d2ccf884d5d`
  - replacement SHA-256: `1a829141cd09b395d537e849f84d2860e30d8c2e5cf4d4e073f0962fdea7bbd4`
  - encoding/line ending: US-ASCII/CRLF, preserving the existing file contract

Existing file, small localised change - unified patch `Deblock4_Stage_1B3_dll_probe_v2.patch`:

- `src/dll_probe.zig`
  - base SHA-256: `e69987d06ea2c04b8f6899144df76d5b3e3a55dea644d8c5d4c94c6e90d70c03`
  - resulting SHA-256: `1ec9f10457f32ffeaff01f0c6a315aa02cd304910de4cbc6c40276c79e553db3`
  - patch encoding/line ending: US-ASCII/LF
  - resulting file encoding/line ending: US-ASCII/LF

New files, complete whole-file delivery under `repo_new_files/`:

- `build_1B3_v1.bat`
- `src/cpu_capability_detection.zig`
- `src/deblock4_config.zig`
- `src/deblock4_selftest.zig`
- `src/force_down_debug.zig`
- `src/print_diag_helper_functions.zig`
- `src/print_helper_functions.zig`

Permitted changed files are exactly those nine repository paths. Every other
repository path is forbidden.

## 6. Patch anchor

The `src/dll_probe.zig` patch anchors uniquely on:

```zig
const std = @import("std");

pub const dll_probe_value: u32 = 0x4442_3401;
```

The anchor occurs exactly once in the exact attached base. Both mandatory
`git apply --check` gates passed in isolated validation.

## 7. Line-ending contract

| Repository path | Delivered/resulting line endings |
|---|---|
| `build.zig` | CRLF (470 lines) |
| `src/dll_probe.zig` | LF (23 lines) |
| `build_1B3_v1.bat` | LF (685 lines) |
| `src/cpu_capability_detection.zig` | LF (797 lines) |
| `src/deblock4_config.zig` | LF (27 lines) |
| `src/deblock4_selftest.zig` | LF (52 lines) |
| `src/force_down_debug.zig` | LF (119 lines) |
| `src/print_diag_helper_functions.zig` | LF (106 lines) |
| `src/print_helper_functions.zig` | LF (109 lines) |

`build.zig` is the sole delivered source file using CRLF because it is an
existing CRLF file and unrelated line-ending conversion is forbidden. Before
`git diff --check`, the apply sequence explicitly configures Git's local
`cr-at-eol` rule so retained CRLF is not misdiagnosed as trailing whitespace.
This rule does not excuse spaces or tabs at end of line.

## 8. Apply sequence

Extract this delivery outside the repository. From the repository root:

```bat
git status --short
git rev-parse --short HEAD
git apply --check "<delivery-dir>\Deblock4_Stage_1B3_dll_probe_v2.patch"
git apply --check --whitespace=error "<delivery-dir>\Deblock4_Stage_1B3_dll_probe_v2.patch"
git apply "<delivery-dir>\Deblock4_Stage_1B3_dll_probe_v2.patch"
```

Copy the following complete files to their exact repository-relative paths:

```text
<delivery-dir>\repo_existing_replacements\build.zig
    -> build.zig

<delivery-dir>\repo_new_files\build_1B3_v1.bat
    -> build_1B3_v1.bat

<delivery-dir>\repo_new_files\src\cpu_capability_detection.zig
    -> src\cpu_capability_detection.zig
<delivery-dir>\repo_new_files\src\deblock4_config.zig
    -> src\deblock4_config.zig
<delivery-dir>\repo_new_files\src\deblock4_selftest.zig
    -> src\deblock4_selftest.zig
<delivery-dir>\repo_new_files\src\force_down_debug.zig
    -> src\force_down_debug.zig
<delivery-dir>\repo_new_files\src\print_diag_helper_functions.zig
    -> src\print_diag_helper_functions.zig
<delivery-dir>\repo_new_files\src\print_helper_functions.zig
    -> src\print_helper_functions.zig
```

Do not copy the delivery report, patch, manifest, validation record, or delivery
container directory into the repository.

Continue:

```bat
git config --local core.whitespace cr-at-eol
git diff --check
git status --short
```

Expected status is exactly:

```text
 M build.zig
 M src/dll_probe.zig
?? build_1B3_v1.bat
?? src/cpu_capability_detection.zig
?? src/deblock4_config.zig
?? src/deblock4_selftest.zig
?? src/force_down_debug.zig
?? src/print_diag_helper_functions.zig
?? src/print_helper_functions.zig
```

A mismatch means STOP; do not hand-edit the delivery to fit.

## 9. Required W3X validation order

1. Confirm the actual repository, branch, starting commit and clean/expected
   pre-application status.
2. Build the baseline detection object first:

```bat
zig build detection-object -Doptimize=ReleaseFast
```

3. Inspect `zig-out\detection-objects\cpu_capability_detection.obj` with
   `dumpbin /DISASM:BYTES`. Confirm the inline asm compiles, EBX/RBX handling is
   correct, no prohibited v2/v3 instruction family appears, and XGETBV exists
   only on the OSXSAVE-confirmed path.
4. Run the single standing runner:

```bat
build_1B3_v1.bat
```

The batch includes the Stage 1B.2 regression, Debug self-test and force-down
matrix, unit tests, ReleaseSafe/ReleaseFast builds, G10 three-surface absence,
Debug positive controls, non-Debug option rejection, named-model perturbation,
and one-way dependency audit.
5. Return complete console output, generated inspection files, exit code and
   final `git status --short` to W3C/W3D.
6. Obtain explicit W3X/W3D R3 approval of the completed named-model
   mapping/exclusion classification before commit acceptance.

## 10. Expected results

- `zig build detection-object -Doptimize=ReleaseFast`: PASS.
- Detection-object disassembly: baseline-v1 only; guarded XGETBV; no prohibited
  v2/v3 instructions.
- `build_1B3_v1.bat`: exit 0 with every named gate PASS.
- Deliberate named-model perturbation in its temporary copied tree: build FAILS
  with `Zig 0.16 named-model capture drift` and `bmi2`, then the temporary tree
  is removed and repository source remains unchanged.
- ReleaseSafe and ReleaseFast artifacts: both debug modules absent from strings,
  PE exports and disassembly.
- Debug positive control: both module markers present on applicable surfaces.
- Either debug option in a non-Debug build: expected build failure.
- Stage 1B.2 regression: PASS.
- Final changed-file set: exactly the nine paths in section 5.

## 11. Independent static validation performed by successor W3C

PASS:

- exact base archive SHA-256 confirmed;
- complete `build.zig` replacement hash and CRLF contract confirmed;
- patch changes only `src/dll_probe.zig` and is US-ASCII/LF;
- `git apply --check`;
- `git apply --check --whitespace=error`;
- patch application and all complete-file copies;
- `git diff --check` with explicit local `cr-at-eol` policy;
- exact nine-path changed-file set;
- US-ASCII on all nine resulting files;
- byte identity with v1 for both existing modified files;
- content identity with v1 after newline normalisation for every new file;
- declarations-only config check;
- one-way first-class dependency textual audit;
- required G10 markers, build options, self-test/detection steps, perturbation
  routine, disassembly commands and Stage 1B.2 regression invocation present;
- manifest and ZIP integrity.

NOT RUN / NOT CLAIMED:

- Zig 0.16.0 compilation;
- Windows x86_64 execution;
- CPUID/XGETBV runtime behaviour;
- `dumpbin` export/disassembly gates;
- the standing batch;
- project acceptance or PASS.

## 12. Review notes

The implementation remains the source reviewed by W3D in
`Deblock4_Stage_1B3_W3D_Delivery_Review_v1_0.md`. Its inline asm is still the
first compilation-sensitive item to close. The hand-rolled atomic once guard is
unchanged. The stronger exact named-model-set capture check, dual debug markers,
and object-mode semantic root are retained.

This v2 delivery is ready for W3X application and proof, not for commit on static
inspection alone.
