const std = @import("std");

pub fn build(b: *std.Build) void {
    const target = b.standardTargetOptions(.{});
    const optimize = b.standardOptimizeOption(.{});

    const enable =
        b.option(bool, "enable", "enable the test seam") orelse false;
    const scenario =
        b.option([]const u8, "scenario", "scenario compiled by the selected suite") orelse "both_ok";
    const suite =
        b.option([]const u8, "suite", "primary or inner_breach") orelse "primary";

    const root_source_file =
        if (std.mem.eql(u8, suite, "primary"))
            b.path("src/main.zig")
        else if (std.mem.eql(u8, suite, "inner_breach"))
            b.path("src/inner_breach_main.zig")
        else
            @panic("unknown -Dsuite value; expected primary or inner_breach");

    const options = b.addOptions();
    options.addOption(bool, "enable", enable);
    options.addOption([]const u8, "scenario", scenario);

    const library = b.addLibrary(.{
        .name = "gate_test",
        .linkage = .dynamic,
        .root_module = b.createModule(.{
            .root_source_file = root_source_file,
            .target = target,
            .optimize = optimize,
        }),
    });

    library.root_module.addOptions("build_options", options);
    b.installArtifact(library);
}
