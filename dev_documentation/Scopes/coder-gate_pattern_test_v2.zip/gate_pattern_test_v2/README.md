# Deblock4 Stage 1B.3 C-3 Gate Pattern Test v2

Status: standalone empirical test only; no production code authorised
Target toolchain: Windows, Zig 0.16.0, Visual Studio dumpbin

## Purpose

This kit tests the settled source-visible conditional-import pattern:

```zig
const module_name = if (build_options.enable)
    @import("module.zig")
else
    struct {};
```

The primary test has two imports using the same gate:

```text
force_down_inner_gated.zig:
    has an additional internal content gate.

force_down_outer_only.zig:
    has no internal gate and is the isolation control proving the outer import.
```

A separate `inner_breach_main.zig` intentionally imports the internally gated
module unconditionally to test Layer 2 as a breach fallback. That file is a
test-only negative-control arrangement, not the production pattern.

## Running

From this folder:

```bat
run_gate_test.bat
```

The batch expects:

```text
zig on PATH;
Visual Studio 2026 Community at the path configured near the top of the batch,
or dumpbin already available on PATH.
```

Evidence is retained under:

```text
gate-results\
```

Paste the complete console output and zip `gate-results` for W3C review.

## Expected final result

```text
DEBLOCK4 STAGE 1B.3 GATE PATTERN TEST V2: PASS
```

Any build, export, string or disassembly mismatch terminates with a non-zero
exit status.
