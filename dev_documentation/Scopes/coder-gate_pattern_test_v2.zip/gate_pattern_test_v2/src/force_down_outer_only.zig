const std = @import("std");

pub const MARKER =
    "FORCE_DOWN_OUTER_ONLY_MARKER_0xC302";
pub const CODE_MARKER: u32 = 0xC302C302;

// Deliberately NO build-options import and NO internal gate.
// If this module is selected by the outer C-3 import, its marker, export and
// machine-code constant must exist.
pub export fn deblock4_gate_outer_only_probe_C302() callconv(.c) u32 {
    std.debug.print(
        "[outer-only] marker={s}\n",
        .{MARKER},
    );
    return CODE_MARKER;
}
