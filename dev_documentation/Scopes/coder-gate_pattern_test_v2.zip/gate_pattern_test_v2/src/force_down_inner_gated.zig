const std = @import("std");
const build_options = @import("build_options");

pub const tools = if (build_options.enable) struct {
    pub const MARKER =
        "FORCE_DOWN_INNER_GATED_MARKER_0xC301";
    pub const CODE_MARKER: u32 = 0xC301C301;

    pub export fn deblock4_gate_inner_gated_probe_C301() callconv(.c) u32 {
        std.debug.print(
            "[inner-gated] marker={s}\n",
            .{MARKER},
        );
        return CODE_MARKER;
    }
} else struct {};
