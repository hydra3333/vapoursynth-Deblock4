const std = @import("std");
const build_options = @import("build_options");

const enable = build_options.enable;

const Scenario = enum {
    breach_ok,
    breach_leak,
};

const scenario =
    std.meta.stringToEnum(Scenario, build_options.scenario) orelse
    @compileError("unknown inner-breach scenario");

// TEST-ONLY BREACH SIMULATION.
//
// This unconditional import deliberately violates the Layer-1 production rule
// so Layer 2 can be tested independently. The imported module must keep its
// feature absent when enable=false.
const breached_inner_module = @import("force_down_inner_gated.zig");

fn breachOk() u32 {
    var result: u32 = 0;

    if (enable) {
        result = breached_inner_module.tools.deblock4_gate_inner_gated_probe_C301();
    }

    return result;
}

fn breachLeak() u32 {
    // Deliberately ungated reference. With enable=false, tools is struct {} and
    // compilation must fail.
    return breached_inner_module.tools.deblock4_gate_inner_gated_probe_C301();
}

pub export fn gate_test_entry() callconv(.c) u32 {
    return switch (scenario) {
        .breach_ok => breachOk(),
        .breach_leak => breachLeak(),
    };
}
