const std = @import("std");
const build_options = @import("build_options");

const enable = build_options.enable;

const Scenario = enum {
    both_ok,
    import_only,
    plain_leak,
    inner_leak,
};

const scenario =
    std.meta.stringToEnum(Scenario, build_options.scenario) orelse
    @compileError("unknown primary scenario");

// Both modules use the SAME top-level outer gate.
//
// The first module also has an internal content gate and represents the
// intended double-gated production shape.
//
// The second module has no internal gate. Its unconditional contents make it
// the isolation control: when enable is false, its absence can only be caused
// by this outer C-3 conditional import.
const fd_inner_gated = if (enable)
    @import("force_down_inner_gated.zig")
else
    struct {};

const fd_outer_only = if (enable)
    @import("force_down_outer_only.zig")
else
    struct {};

fn bothOk() u32 {
    var result: u32 = 0;

    if (enable) {
        result ^= fd_inner_gated.tools.deblock4_gate_inner_gated_probe_C301();
        result ^= fd_outer_only.deblock4_gate_outer_only_probe_C302();
    }

    return result;
}

fn importOnly() u32 {
    // Both top-level declarations exist, but neither namespace is referenced.
    return 0x1B300004;
}

fn plainLeak() u32 {
    // Deliberately ungated active reference.
    // With enable=false, fd_outer_only is struct {} and compilation must fail.
    return fd_outer_only.deblock4_gate_outer_only_probe_C302();
}

fn innerLeak() u32 {
    // Deliberately ungated active reference.
    // With enable=false, fd_inner_gated is struct {} and compilation must fail.
    return fd_inner_gated.tools.deblock4_gate_inner_gated_probe_C301();
}

pub export fn gate_test_entry() callconv(.c) u32 {
    return switch (scenario) {
        .both_ok => bothOk(),
        .import_only => importOnly(),
        .plain_leak => plainLeak(),
        .inner_leak => innerLeak(),
    };
}
