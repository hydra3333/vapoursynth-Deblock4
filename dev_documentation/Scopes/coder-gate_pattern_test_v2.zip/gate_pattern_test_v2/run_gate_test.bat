@echo off
@setlocal ENABLEEXTENSIONS ENABLEDELAYEDEXPANSION

rem ===========================================================================
rem Deblock4 Stage 1B.3 C-3 gate pattern test v2
rem
rem Primary proof:
rem   main.zig contains TWO imports using the SAME outer conditional gate.
rem   - inner-gated module: also contains its own internal gate.
rem   - outer-only module: contains no internal gate and isolates Layer 1.
rem
rem Secondary proof:
rem   inner_breach_main.zig deliberately imports the inner-gated module
rem   unconditionally, proving the Layer-2 fallback independently.
rem
rem Every expected success, failure, presence and absence is enforced.
rem Evidence is retained under gate-results.
rem ===========================================================================

set "ZIG=zig"
set "VSDEVCMD=C:\Program Files\Microsoft Visual Studio\18\Community\Common7\Tools\VsDevCmd.bat"

set "INNER_STRING=FORCE_DOWN_INNER_GATED_MARKER_0xC301"
set "INNER_EXPORT=deblock4_gate_inner_gated_probe_C301"
set "INNER_CODE=C301C301"

set "OUTER_STRING=FORCE_DOWN_OUTER_ONLY_MARKER_0xC302"
set "OUTER_EXPORT=deblock4_gate_outer_only_probe_C302"
set "OUTER_CODE=C302C302"

cd /d "%~dp0"
if errorlevel 1 goto :fail

where "%ZIG%" >nul 2>nul
if errorlevel 1 (
    echo ERROR zig is not available on PATH
    goto :fail
)

where dumpbin >nul 2>nul
if errorlevel 1 (
    if not exist "%VSDEVCMD%" (
        echo ERROR dumpbin is not on PATH and VsDevCmd was not found
        goto :fail
    )
    call "%VSDEVCMD%" -arch=amd64 -host_arch=amd64
    if errorlevel 1 goto :fail
    cd /d "%~dp0"
    if errorlevel 1 goto :fail
)

where dumpbin >nul 2>nul
if errorlevel 1 (
    echo ERROR dumpbin is not available after VsDevCmd
    goto :fail
)

if exist "gate-results" rmdir /s /q "gate-results"
if errorlevel 1 goto :fail
md "gate-results"
if errorlevel 1 goto :fail

echo.
echo Zig version:
"%ZIG%" version
if errorlevel 1 goto :fail

echo.
echo ========================================================================
echo T01 primary both_ok gate OFF Debug - expect both modules ABSENT
echo ========================================================================
call :expect_primary_absent T01 both_ok Debug
if errorlevel 1 goto :fail

echo.
echo ========================================================================
echo T02 primary both_ok gate OFF ReleaseSafe - expect both modules ABSENT
echo ========================================================================
call :expect_primary_absent T02 both_ok ReleaseSafe
if errorlevel 1 goto :fail

echo.
echo ========================================================================
echo T03 primary both_ok gate OFF ReleaseFast - expect both modules ABSENT
echo ========================================================================
call :expect_primary_absent T03 both_ok ReleaseFast
if errorlevel 1 goto :fail

echo.
echo ========================================================================
echo T04 primary import_only gate OFF ReleaseFast - expect both modules ABSENT
echo ========================================================================
call :expect_primary_absent T04 import_only ReleaseFast
if errorlevel 1 goto :fail

echo.
echo ========================================================================
echo T05 primary plain_leak gate OFF ReleaseFast - expect COMPILE FAILURE
echo ========================================================================
call :expect_compile_failure T05 primary plain_leak false ReleaseFast
if errorlevel 1 goto :fail

echo.
echo ========================================================================
echo T06 primary inner_leak gate OFF ReleaseFast - expect COMPILE FAILURE
echo ========================================================================
call :expect_compile_failure T06 primary inner_leak false ReleaseFast
if errorlevel 1 goto :fail

echo.
echo ========================================================================
echo T07 primary both_ok gate ON ReleaseFast - expect both modules PRESENT
echo ========================================================================
call :expect_primary_present T07 both_ok ReleaseFast
if errorlevel 1 goto :fail

echo.
echo ========================================================================
echo T08 inner breach gate OFF ReleaseFast - expect inner feature ABSENT
echo ========================================================================
call :expect_inner_absent T08 breach_ok ReleaseFast
if errorlevel 1 goto :fail

echo.
echo ========================================================================
echo T09 inner breach leak gate OFF ReleaseFast - expect COMPILE FAILURE
echo ========================================================================
call :expect_compile_failure T09 inner_breach breach_leak false ReleaseFast
if errorlevel 1 goto :fail

echo.
echo ========================================================================
echo T10 inner breach gate ON ReleaseFast - expect inner feature PRESENT
echo ========================================================================
call :expect_inner_present T10 breach_ok ReleaseFast
if errorlevel 1 goto :fail

echo.
echo ================================================================================
echo DEBLOCK4 STAGE 1B.3 GATE PATTERN TEST V2: PASS
echo Evidence retained under gate-results
echo ================================================================================
exit /b 0

:expect_primary_absent
call :build_and_capture %~1 primary %~2 false %~3
if errorlevel 1 exit /b 1
call :assert_absent %~1 INNER_STRING INNER_EXPORT INNER_CODE
if errorlevel 1 exit /b 1
call :assert_absent %~1 OUTER_STRING OUTER_EXPORT OUTER_CODE
if errorlevel 1 exit /b 1
echo %~1 PASS
exit /b 0

:expect_primary_present
call :build_and_capture %~1 primary %~2 true %~3
if errorlevel 1 exit /b 1
call :assert_present %~1 INNER_STRING INNER_EXPORT INNER_CODE
if errorlevel 1 exit /b 1
call :assert_present %~1 OUTER_STRING OUTER_EXPORT OUTER_CODE
if errorlevel 1 exit /b 1
echo %~1 PASS
exit /b 0

:expect_inner_absent
call :build_and_capture %~1 inner_breach %~2 false %~3
if errorlevel 1 exit /b 1
call :assert_absent %~1 INNER_STRING INNER_EXPORT INNER_CODE
if errorlevel 1 exit /b 1
echo %~1 PASS
exit /b 0

:expect_inner_present
call :build_and_capture %~1 inner_breach %~2 true %~3
if errorlevel 1 exit /b 1
call :assert_present %~1 INNER_STRING INNER_EXPORT INNER_CODE
if errorlevel 1 exit /b 1
echo %~1 PASS
exit /b 0

:expect_compile_failure
set "TEST_ID=%~1"
set "SUITE=%~2"
set "SCENARIO=%~3"
set "ENABLE=%~4"
set "OPTIMIZE=%~5"
set "RESULT_DIR=gate-results\%TEST_ID%"
md "%RESULT_DIR%" >nul 2>nul

call :clean_build
if errorlevel 1 exit /b 1

echo zig build -Dsuite=%SUITE% -Dscenario=%SCENARIO% -Denable=%ENABLE% -Doptimize=%OPTIMIZE%
"%ZIG%" build -Dsuite=%SUITE% -Dscenario=%SCENARIO% -Denable=%ENABLE% -Doptimize=%OPTIMIZE% >"%RESULT_DIR%\build_stdout.txt" 2>"%RESULT_DIR%\build_stderr.txt"
set "BUILD_CODE=!ERRORLEVEL!"

type "%RESULT_DIR%\build_stdout.txt"
type "%RESULT_DIR%\build_stderr.txt"

if "!BUILD_CODE!"=="0" (
    echo ERROR %TEST_ID% compiled but compilation failure was required
    exit /b 1
)

echo %TEST_ID% observed expected compile failure with exit code !BUILD_CODE!
exit /b 0

:build_and_capture
set "TEST_ID=%~1"
set "SUITE=%~2"
set "SCENARIO=%~3"
set "ENABLE=%~4"
set "OPTIMIZE=%~5"
set "RESULT_DIR=gate-results\%TEST_ID%"
md "%RESULT_DIR%" >nul 2>nul

call :clean_build
if errorlevel 1 exit /b 1

echo zig build -Dsuite=%SUITE% -Dscenario=%SCENARIO% -Denable=%ENABLE% -Doptimize=%OPTIMIZE%
"%ZIG%" build -Dsuite=%SUITE% -Dscenario=%SCENARIO% -Denable=%ENABLE% -Doptimize=%OPTIMIZE% >"%RESULT_DIR%\build_stdout.txt" 2>"%RESULT_DIR%\build_stderr.txt"
set "BUILD_CODE=!ERRORLEVEL!"

type "%RESULT_DIR%\build_stdout.txt"
type "%RESULT_DIR%\build_stderr.txt"

if not "!BUILD_CODE!"=="0" (
    echo ERROR %TEST_ID% failed to compile with exit code !BUILD_CODE!
    exit /b 1
)

set "DLL=zig-out\bin\gate_test.dll"
if not exist "!DLL!" (
    echo ERROR %TEST_ID% did not produce !DLL!
    exit /b 1
)

copy /y "!DLL!" "%RESULT_DIR%\gate_test.dll" >nul
if errorlevel 1 exit /b 1

dumpbin /NOLOGO /EXPORTS "!DLL!" >"%RESULT_DIR%\exports.txt"
if errorlevel 1 exit /b 1

dumpbin /NOLOGO /SYMBOLS "!DLL!" >"%RESULT_DIR%\symbols.txt"
if errorlevel 1 exit /b 1

dumpbin /NOLOGO /DISASM:BYTES "!DLL!" >"%RESULT_DIR%\disasm.txt"
if errorlevel 1 exit /b 1

exit /b 0

:assert_absent
set "TEST_ID=%~1"
call set "STRING_VALUE=%%%~2%%"
call set "EXPORT_VALUE=%%%~3%%"
call set "CODE_VALUE=%%%~4%%"
set "RESULT_DIR=gate-results\%TEST_ID%"

findstr /I /C:"!STRING_VALUE!" "%RESULT_DIR%\gate_test.dll" >nul <nul
if "!ERRORLEVEL!"=="0" (
    echo ERROR %TEST_ID% raw marker unexpectedly PRESENT: !STRING_VALUE!
    exit /b 1
)

findstr /I /C:"!EXPORT_VALUE!" "%RESULT_DIR%\exports.txt" >nul <nul
if "!ERRORLEVEL!"=="0" (
    echo ERROR %TEST_ID% export unexpectedly PRESENT: !EXPORT_VALUE!
    exit /b 1
)

findstr /I /C:"!CODE_VALUE!" "%RESULT_DIR%\disasm.txt" >nul <nul
if "!ERRORLEVEL!"=="0" (
    echo ERROR %TEST_ID% code marker unexpectedly PRESENT: !CODE_VALUE!
    exit /b 1
)

echo %TEST_ID% confirmed ABSENT: !STRING_VALUE!, !EXPORT_VALUE!, !CODE_VALUE!
exit /b 0

:assert_present
set "TEST_ID=%~1"
call set "STRING_VALUE=%%%~2%%"
call set "EXPORT_VALUE=%%%~3%%"
call set "CODE_VALUE=%%%~4%%"
set "RESULT_DIR=gate-results\%TEST_ID%"

findstr /I /C:"!STRING_VALUE!" "%RESULT_DIR%\gate_test.dll" >nul <nul
if not "!ERRORLEVEL!"=="0" (
    echo ERROR %TEST_ID% raw marker not found: !STRING_VALUE!
    exit /b 1
)

findstr /I /C:"!EXPORT_VALUE!" "%RESULT_DIR%\exports.txt" >nul <nul
if not "!ERRORLEVEL!"=="0" (
    echo ERROR %TEST_ID% export not found: !EXPORT_VALUE!
    exit /b 1
)

findstr /I /C:"!CODE_VALUE!" "%RESULT_DIR%\disasm.txt" >nul <nul
if not "!ERRORLEVEL!"=="0" (
    echo ERROR %TEST_ID% code marker not found: !CODE_VALUE!
    exit /b 1
)

echo %TEST_ID% confirmed PRESENT: !STRING_VALUE!, !EXPORT_VALUE!, !CODE_VALUE!
exit /b 0

:clean_build
if exist ".zig-cache" rmdir /s /q ".zig-cache"
if errorlevel 1 exit /b 1
if exist "zig-out" rmdir /s /q "zig-out"
if errorlevel 1 exit /b 1
exit /b 0

:fail
echo.
echo ================================================================================
echo DEBLOCK4 STAGE 1B.3 GATE PATTERN TEST V2: FAIL
echo ================================================================================
exit /b 1
