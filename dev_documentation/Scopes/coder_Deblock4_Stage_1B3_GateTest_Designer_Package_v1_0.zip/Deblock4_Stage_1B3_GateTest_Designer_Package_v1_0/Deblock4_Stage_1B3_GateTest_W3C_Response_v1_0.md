# Deblock4 Stage 1B.3 Gate-Test Review - W3C Response

Version: v1.0
Date: 2026-07-30
Audience: W3X / W3D
Status: Review response and proposed empirical test kit; no production code authorised
Encoding: US-ASCII only

## 1. Disposition

The standing three-layer pattern is technically sound in principle:

1. Layer 1: top-level C-3 conditional import is the primary omission boundary.
2. Layer 2: per-feature internal gates are defence in depth.
3. Layer 3: absence is proved by artifact inspection.

However, the original test kit did not isolate Layer 1. Its only imported debug
module also contained an identical internal gate. With the option false, marker
absence could therefore be caused by either:

```text
the outer C-3 import gate; or
the module's own inner content gate.
```

That made the original marker-absence result non-discriminating. It could not,
by itself, ratify the claim that the outer conditional import was the reason
the module disappeared.

The revised kit adopts W3X's clarified design exactly:

```zig
const fd_inner_gated = if (enable)
    @import("force_down_inner_gated.zig")
else
    struct {};

const fd_outer_only = if (enable)
    @import("force_down_outer_only.zig")
else
    struct {};
```

Both imports use the same outer gate in the primary root file.

The modules are deliberately different:

```text
force_down_inner_gated.zig:
    contains its own matching internal content gate;
    represents the intended double-gated production shape.

force_down_outer_only.zig:
    contains no internal gate at all;
    its marker, export and machine-code constant are unconditional if the
    module is imported;
    therefore its absence with enable=false can only be attributed to the
    outer C-3 import gate.
```

This resolves the original circularity.

## 2. Answers to the review request

### 2.1 Intent match

The original kit used the correct surface form for C-3, but its only module was
internally gated. It therefore demonstrated that the combined outer-plus-inner
arrangement omitted the marker, not that the outer import independently caused
the omission.

The revised primary test faithfully exercises:

```text
same top-level outer gate;
two distinct imported modules;
one internally gated;
one deliberately plain;
gated references in the correct scenario;
ungated references in negative compile tests;
a bare import-declaration scenario.
```

### 2.2 Omission claim

The C-3 form is consistent with Zig's comptime-known conditional semantics and
lazy analysis. Empirical confirmation on W3X's Zig 0.16.0 toolchain remains
appropriate because this is a safety-relevant project standing rule.

The plain-module control is the load-bearing empirical check:

```text
enable=false
+ outer-only module marker absent
+ outer-only export absent
+ outer-only code marker absent from disassembly
= the outer C-3 branch omitted the module.
```

The internally gated module is then a confirmation that the intended combined
production shape behaves consistently.

### 2.3 Test sufficiency

A raw marker-string scan alone is useful but not sufficient as the only proof.
A string could be optimised away while unrelated module code remained, or a
marker might survive for a reason not tied to executable code.

The revised kit checks three independent artifact surfaces for each module:

```text
raw DLL bytes:
    unique diagnostic string marker;

PE export table:
    unique exported probe function;

DLL disassembly:
    unique immediate machine-code constant.
```

It also captures the COFF symbol table for review.

For disabled builds, all three load-bearing indicators must be absent.
For enabled builds, all three must be present.

### 2.4 Scenario coverage

The revised matrix covers:

```text
Primary exact design:
- gate off in Debug;
- gate off in ReleaseSafe;
- gate off in ReleaseFast;
- bare two-import declarations with no member reference;
- ungated reference to the plain module must fail compilation;
- ungated reference to the internally gated module must fail compilation;
- gate on sanity build must contain both modules.

Layer-2 breach simulation:
- the internally gated module is deliberately imported unconditionally;
- gate off must still omit its feature;
- an ungated member reference must fail compilation;
- gate on sanity build must contain the feature.
```

The Layer-2 breach simulation is in a separate root file and is explicitly not
the production inclusion pattern. Its sole purpose is to prove the standing
rule's defence-in-depth claim independently.

ReleaseSafe and Debug gate-off builds are retained because the omission
guarantee must not depend on ReleaseFast optimisation.

The enabled ReleaseFast cases in this standalone mechanism test do not endorse
enabling the production seam in a release profile. The later Stage 1B.3 scope
must separately enforce the settled production policy for which profiles may
enable it.

### 2.5 Pattern-document correctness

The three-layer model is sound with one clarification:

```text
Layer 2 is redundant for omission only when Layer 1 is known to be intact.
Layer 2 is valuable as a breach fallback, but a test of the combined arrangement
cannot independently prove Layer 1 unless a plain-module control is present.
```

The caveat against treating inner gates as permission for unconditional imports
is correct and should remain prominent.

## 3. Updated test-kit structure

```text
gate_pattern_test_v2\
    build.zig
    run_gate_test.bat
    README.md
    src\
        main.zig
        inner_breach_main.zig
        force_down_inner_gated.zig
        force_down_outer_only.zig
```

### Primary root: `src/main.zig`

Contains the two same-gate imports requested by W3X.

### Inner-gated module

Contains:

```text
unique string: FORCE_DOWN_INNER_GATED_MARKER_0xC301
unique export: deblock4_gate_inner_gated_probe_C301
unique code constant: 0xC301C301
```

### Outer-only plain module

Contains no build-option import and no internal gate. It contains:

```text
unique string: FORCE_DOWN_OUTER_ONLY_MARKER_0xC302
unique export: deblock4_gate_outer_only_probe_C302
unique code constant: 0xC302C302
```

### Batch behaviour

The batch:

```text
requires Zig and dumpbin;
builds each scenario separately;
cleans previous build output before every scenario;
enforces expected compile success or compile failure;
captures EXPORTS, SYMBOLS and DISASM:BYTES;
checks raw strings, exports and disassembly;
fails immediately on any expectation mismatch;
retains per-test evidence under gate-results\;
prints a final PASS only after all tests pass.
```

## 4. Test matrix

| Test | Suite | Scenario | Enable | Optimise | Expected |
|---|---|---|---:|---|---|
| T01 | primary | both_ok | false | Debug | compile; both modules absent |
| T02 | primary | both_ok | false | ReleaseSafe | compile; both modules absent |
| T03 | primary | both_ok | false | ReleaseFast | compile; both modules absent |
| T04 | primary | import_only | false | ReleaseFast | compile; both modules absent |
| T05 | primary | plain_leak | false | ReleaseFast | compile failure |
| T06 | primary | inner_leak | false | ReleaseFast | compile failure |
| T07 | primary | both_ok | true | ReleaseFast | compile; both modules present |
| T08 | inner_breach | breach_ok | false | ReleaseFast | compile; inner feature absent |
| T09 | inner_breach | breach_leak | false | ReleaseFast | compile failure |
| T10 | inner_breach | breach_ok | true | ReleaseFast | compile; inner feature present |

## 5. Static review status

The revised files were produced and statically checked for:

```text
US-ASCII encoding;
CRLF-only line endings;
matching scenario names between build roots and batch;
distinct module markers, export names and code constants;
enforced non-zero failure propagation in the batch;
no production Deblock4 source dependency.
```

W3C could not execute the kit because this environment does not provide the
target Windows Zig 0.16.0 and Visual Studio `dumpbin` toolchain. W3X's real
toolchain run remains the empirical authority.

## 6. Requested designer disposition

Please review the revised kit as the proposed replacement for the original
`gate_pattern_test.zip`.

If the ten enforced tests pass on W3X's machine, the evidence will support:

```text
Layer 1 C-3 outer conditional import: empirically ratified;
Layer 2 inner gate breach fallback: independently confirmed;
Layer 3 multi-surface absence proof: satisfied for this pattern test.
```

No Stage 1B.3 production implementation is authorised by this package.
