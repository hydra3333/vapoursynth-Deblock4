# Package Validation

Static validation only; the Windows Zig 0.16.0 test has not been executed here.

All package text files are US-ASCII and CRLF-only.

| File | Bytes | CRLF lines | SHA-256 |
|---|---:|---:|---|
| `Deblock4_Stage_1B3_GateTest_W3C_Response_v1_0.md` | 8788 | 272 | `8ca21e600d3c8389b6bdac2e9a569959fc0a8f63f10f2a975aa1f8493155efd8` |
| `gate_pattern_test_v2/README.md` | 1431 | 62 | `ec983500b29b09b03a746057cb9919768c128d359069366e6cef4c0307a8b7e0` |
| `gate_pattern_test_v2/build.zig` | 1335 | 38 | `f275be735ff544b8743308cec9711e6e1b3e73db99ab42877341edb0d7fea7a6` |
| `gate_pattern_test_v2/run_gate_test.bat` | 10743 | 320 | `715810896ec8a46f9cce14b88c6abe7368b7b72db5351f5df97462b4d149a7fa` |
| `gate_pattern_test_v2/src/force_down_inner_gated.zig` | 492 | 16 | `d83c3086fc0b400806e18407a246ce2d486594b5410b960586dae85001ebcfa0` |
| `gate_pattern_test_v2/src/force_down_outer_only.zig` | 507 | 16 | `6f05ea1546c4701cadb7dfc90382175797084079b91945912b2d9630add07b49` |
| `gate_pattern_test_v2/src/inner_breach_main.zig` | 1209 | 43 | `c90652c46bbe561d0060c67046aab9326c927cec14e55fb51054141ee5e94ffd` |
| `gate_pattern_test_v2/src/main.zig` | 2008 | 70 | `17599c8e12cb3c1121c2e37876dc3bdd2d05033b9407c4354d4dc66ad9f16570` |

Structural checks:

- Primary root contains two imports using the same outer `enable` gate.
- Inner module contains its own content gate.
- Outer-only module contains no `build_options` import and no internal gate.
- The probe functions use exported C-ABI symbols so PE export inspection is load-bearing.
- Batch contains ten enforced scenarios.
- Batch captures exports, symbols and disassembly.
- Any expectation mismatch propagates a non-zero exit status.
- Zig syntax has been statically reviewed but not compiled in this environment.
