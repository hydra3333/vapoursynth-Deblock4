# Deblock4 - Stage 2C Implementation Delivery Manifest v2.0

**Deliverable:** W3C-2C-IMPLEMENTATION-DELIVERY  
**Version:** 2.0  
**Date:** 2026-08-11  
**Author:** W3C  
**Route:** W3C -> W3X -> W3D  
**Authority:** D4 v1_9 with its released read-together authority set, plus
`Deblock4_Stage_2C_Redelivery_Specification_v1_2.md`.  
**Status:** COMPLETE REDELIVERY OF RECORD. Supersedes Stage 2C implementation
delivery v1.0 and the retired F-1 rider wholesale. W3C has performed package
construction checks and the specifically-ratified K30 authoring evidence audit.
W3C has NOT compiled, linked, loaded VapourSynth, built the HolyWu reference
DLL, run D3/H0 validation, or claimed Stage 2C validation PASS. W3X performs
all validation and supplies execution evidence.  
**Encoding:** US-ASCII; CRLF.

---

# 1. Package shape

```text
Deblock4_Stage_2C_Implementation_Delivery_v2_0/
  Deblock4_Stage_2C_Implementation_Delivery_Manifest_v2_0.md
  apply_to_tree/        21 repository files
  restore_to_base/      10 inert pre-change base copies
```

There is:

```text
NO apply script
NO restore script
NO Stage-2C-authored/shipped .ps1
NO K30 in-tree audit script
NO patch file
```

The one new script authored in this redelivery round is:

```text
tools/holywu_reference/build_holywu_r9_scalar.cmd
```

The package also carries the retained `build_2C_v1.bat` and the minimally
adjusted `tools/holywu_reference/run_stage_2c_holywu_reference.cmd`.

The refined W3X git rule is preserved: no machinery uses `git stash`, performs
automatic staging/committing, or depends for correctness on a particular local
index/staging/HEAD state. The retained runner's non-destructive `git diff
--check` and `git status` reads remain. Manual W3X git operations are outside
delivery machinery.

# 2. Manual W3X application

From the extracted v2.0 delivery, W3X manually copies the **CONTENTS** of:

```text
apply_to_tree/
```

over the repository root.

That one manual copy operation creates the 11 NEW files and overwrites the 10
REPLACES files listed below. No package script applies repository changes.

After the copy, W3X may eyeball:

```text
git status --short --untracked-files=all
```

against section 3. Do not stage or commit before validation/acceptance.

# 3. Complete repository file list

## REPLACES - 10 existing files

```text
REPLACES  build.zig
REPLACES  src/backend_tier_selection.zig
REPLACES  src/classic_ar_all_frames_ready.zig
REPLACES  src/classic_instance_creation.zig
REPLACES  src/classic_instance_data.zig
REPLACES  src/cpu_capability_detection.zig
REPLACES  src/deblock4_config.zig
REPLACES  src/deblock4_selftest.zig
REPLACES  src/deblock4_version.zig
REPLACES  src/print_helper_functions.zig
```

## NEW - 11 files

```text
NEW  build_2C_v1.bat
NEW  src/classic_edge_schedule.zig
NEW  src/classic_scalar_kernel.zig
NEW  src/classic_thresholds.zig
NEW  tests/Deblock4_Stage_2C_D3_v1_10_O_G_to_Test_Crosswalk.md
NEW  tests/stage_2c_classic_obligations.vpy
NEW  tools/holywu_reference/README.md
NEW  tools/holywu_reference/build_holywu_r9_scalar.cmd
NEW  tools/holywu_reference/reference-build-record-schema.json
NEW  tools/holywu_reference/run_stage_2c_holywu_reference.cmd
NEW  tools/holywu_reference/stage_2c_holywu_diff.vpy
```

Total:

```text
10 REPLACES + 11 NEW = 21 apply_to_tree files
```

The v1.2 redelivery prose inherited one stale parenthetical saying `12x del`
in its backout description. The authoritative enumerated 21-file set is
mechanically 10 REPLACES + 11 NEW, so the manual block in section 8 contains
11 `del` commands.

# 4. Byte-identity / bounded-authoring construction record

The v1.2 redelivery specification constrains this round to 16 whole-file
byte-identical apply files and five changed/authored apply files.

## 16 whole-file byte-identical apply files

W3C package construction comparison found these byte-identical to the retained,
W3D-reviewed Stage 2C delivery v1.0 copies:

```text
build.zig
src/backend_tier_selection.zig
src/classic_ar_all_frames_ready.zig
src/classic_instance_creation.zig
src/classic_instance_data.zig
src/cpu_capability_detection.zig
src/deblock4_config.zig
src/deblock4_selftest.zig
src/deblock4_version.zig
src/print_helper_functions.zig
src/classic_scalar_kernel.zig
src/classic_edge_schedule.zig
src/classic_thresholds.zig
tests/stage_2c_classic_obligations.vpy
tools/holywu_reference/stage_2c_holywu_diff.vpy
tools/holywu_reference/reference-build-record-schema.json
```

No per-file base hashes are used or carried.

## Five changed/authored apply files

```text
tests/Deblock4_Stage_2C_D3_v1_10_O_G_to_Test_Crosswalk.md
    Only the K30 row is re-routed from the retired in-tree PS1 gate to:
    W3C delivery-manifest K30 evidence + independent W3D re-verification.

build_2C_v1.bat
    Against the retained reviewed copy:
      - K30 preflight existence-check line removed;
      - K30 execution block removed;
      - batch proof-summary token `K30` removed;
      - crosswalk-completeness ID list still contains `K30`;
      - no other delta.

tools/holywu_reference/build_holywu_r9_scalar.cmd
    New plain-CMD MSVC reference-build driver replacing the retired PS1.

tools/holywu_reference/run_stage_2c_holywu_reference.cmd
    Minimal delta: calls `build_holywu_r9_scalar.cmd` with the same three
    logical inputs and preserves the existing build-log/error flow.

tools/holywu_reference/README.md
    Minimal delta: names the CMD build driver and records K30 delivery-evidence
    routing; the existing H0 usage/guard description is retained.
```

# 5. K30 delivery evidence - W3C authoring audit

K30 is delivery evidence, not an in-tree validation gate.

The canonical retired-identifier set was taken from the Stage 1C S2 audit and
contains these 13 basenames:

```text
build_1B1_v7_3.bat
build_1B2_v5_REDEVELOPED.bat
build_1B3_v5.bat
backend_isolation_smoke_test.zig
backend_probe_avx2.zig
backend_probe_generic.zig
backend_probe_scalar.zig
backend_probe_sse41.zig
backend_retention_anchor.zig
build_probe.zig
dll_probe.zig
dll_smoke_test.zig
vapoursynth_header_probe.zig
```

## K30 part 1 - new first-class modules, build wiring, unit-test names

Domain examined by W3C authoring tooling:

```text
src/classic_scalar_kernel.zig
src/classic_edge_schedule.zig
src/classic_thresholds.zig

the Stage 2C-added build.zig wiring lines for those modules
all 16 `test "..."` names declared by the three modules
the three permanent filenames themselves
```

The three modules contain:

```text
classic_scalar_kernel.zig    4 unit-test names
classic_edge_schedule.zig    8 unit-test names
classic_thresholds.zig       4 unit-test names
                              ------------------
                              16 total
```

The build comparison identifies 31 Stage-2C-added build-wiring lines.

The full new-module/test-name domain and those added wiring lines were searched
case-insensitively for:

```text
stage-number vocabulary
probe vocabulary
smoke vocabulary
all 13 canonical retired S2 basenames
```

Authoring-audit result:

```text
K30 PART 1 RESULT: EMPTY
```

The dependency direction was also inspected:

```text
classic_thresholds.zig
    imports std only

classic_scalar_kernel.zig
    imports std + classic_thresholds.zig

classic_edge_schedule.zig
    imports std + classic_scalar_kernel.zig + classic_thresholds.zig
```

No first-class module imports or references test/tool/scaffolding code.

## K30 part 2 - existing edited modules, added lines only

W3C compared each delivered existing module to the corresponding pre-change
base copy with an exact line-sequence/LCS changes-only comparison:

```text
build.zig                              31 added/replacement lines
src/backend_tier_selection.zig        115
src/classic_ar_all_frames_ready.zig    93
src/classic_instance_creation.zig      85
src/classic_instance_data.zig          15
src/cpu_capability_detection.zig       10
src/deblock4_config.zig                 8
src/deblock4_selftest.zig              37
src/deblock4_version.zig                4
src/print_helper_functions.zig         18
```

Only candidate-added/replacement lines were examined for new scaffolding
references (`probe`, `smoke`, `scaffold/scaffolding`) and for all 13 canonical
retired basenames.

Authoring-audit result:

```text
K30 PART 2 RESULT: EMPTY
```

Accepted Stage 1C regression identifiers are deliberately retained rather than
renamed; for example the delivered selftest still contains
`runStage1CPureContracts` and `stage_1c=PASS`.

W3D independently re-verifies both K30 parts during the v2.0 static review.
`build_2C_v1.bat` does not execute K30 and therefore does not claim K30 in its
batch proof-summary PASS line.

# 6. K31 addressing model retained

The already-reviewed Classic scalar implementation remains byte-identical and
retains K31 model (a), byte-row navigation:

```text
stride is retained in bytes;
row address = base + y * stride_bytes;
no stride division;
one explicit aligned cast to sample type per row/plane view.
```

The existing K31 static and canary/O-8 proof routing in `build_2C_v1.bat`
remains unchanged.

# 7. H0 external HolyWu reference build redelivery

`build_holywu_r9_scalar.cmd` is a plain CMD translation of the reviewed H0
build discipline. It is not part of the Deblock4 production build graph.

It is authored to:

```text
1. require cl.exe, link.exe and certutil.exe;
2. verify deblock.cpp, deblock.h, deblock_sse4.cpp and LICENSE against the
   pinned SHA256SUMS values BEFORE compilation;
3. compile deblock.cpp ONLY, by absolute path, with /O2, without DEBLOCK_X86;
   deblock_sse4.cpp is never a compilation unit;
4. write the DLL/work products only under the W3X inspection/output area;
5. re-verify all four pinned source hashes AFTER compilation;
6. hash VapourSynth4.h, VSHelper4.h and the produced reference DLL;
7. write `reference-build-record.preliminary.json` using the unchanged
   v1 schema and carrying the exact compile/link command;
8. exit nonzero on any failed precondition, hash mismatch, compile failure,
   missing DLL, post-build source drift, hash failure or record-write failure.
```

The CMD driver has not been executed by W3C. W3X generates the actual DLL and
H0 evidence. The unchanged `stage_2c_holywu_diff.vpy` continues to validate the
reference DLL hash, forced scalar metadata, Addendum-A sentinels and the fixed
Addendum-B corpus.

# 8. Manual W3X backout block

Backout is a W3X manual act. No package machinery executes it.

For the 10 REPLACES files, from the repository root:

```text
git restore -- build.zig
git restore -- src/backend_tier_selection.zig
git restore -- src/classic_ar_all_frames_ready.zig
git restore -- src/classic_instance_creation.zig
git restore -- src/classic_instance_data.zig
git restore -- src/cpu_capability_detection.zig
git restore -- src/deblock4_config.zig
git restore -- src/deblock4_selftest.zig
git restore -- src/deblock4_version.zig
git restore -- src/print_helper_functions.zig
```

Equivalent W3X-manual alternative for those ten files: copy the corresponding
files from `restore_to_base/` over the repository copies.

For the 11 NEW files:

```text
del build_2C_v1.bat
del src\classic_edge_schedule.zig
del src\classic_scalar_kernel.zig
del src\classic_thresholds.zig
del tests\Deblock4_Stage_2C_D3_v1_10_O_G_to_Test_Crosswalk.md
del tests\stage_2c_classic_obligations.vpy
del tools\holywu_reference\README.md
del tools\holywu_reference\build_holywu_r9_scalar.cmd
del tools\holywu_reference\reference-build-record-schema.json
del tools\holywu_reference\run_stage_2c_holywu_reference.cmd
del tools\holywu_reference\stage_2c_holywu_diff.vpy
rd tools\holywu_reference
```

Run the final `rd` only if the directory is empty.

`restore_to_base/` has exactly three purposes:

```text
1. delivery record of the exact pre-change base for the 10 REPLACES files;
2. W3D byte-verification input;
3. optional MANUAL W3X backout resource.
```

It is not repository content and is not copied by the normal application.

# 9. W3X validation ownership / next step

W3C makes no project-execution or validation-PASS claim.

After W3D's small static redelivery review and W3X approval, W3X applies the
21-file tree manually and runs the normal Stage 2C validation:

```text
build_2C_v1.bat
```

W3X retains the resulting `zig-out/inspection_2C` evidence and supplies the
console/evidence record for acceptance review.

No staging or commit is performed until the normal post-validation
W3D/W3X acceptance decision.

---

*End of Deblock4 Stage 2C Implementation Delivery Manifest v2.0.*
