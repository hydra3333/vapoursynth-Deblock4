param(
    [string]$CandidateRoot = ".",
    [string]$BaseRoot = ""
)
$ErrorActionPreference = 'Stop'

$newFirstClass = @(
    'src/classic_scalar_kernel.zig',
    'src/classic_edge_schedule.zig',
    'src/classic_thresholds.zig'
)
$newWiring = @('build.zig')
$retired = @(
    'dll_probe.zig','smoke_test.zig','probe_consumer.zig','retention_probe.zig',
    'vapoursynth_bridge_smoke.zig','stage_1a1_probe','stage_1b1_probe'
)
$generic = '(?i)(stage[_ -]?[0-9]|\bprobe\b|\bsmoke\b)'
$failures = New-Object System.Collections.Generic.List[string]

foreach ($rel in $newFirstClass) {
    $path = Join-Path $CandidateRoot $rel
    if (-not (Test-Path -LiteralPath $path)) { $failures.Add("missing new first-class file: $rel"); continue }
    $text = Get-Content -LiteralPath $path -Raw
    if ($text -match $generic) { $failures.Add("new first-class vocabulary violation: $rel") }
    foreach ($token in $retired) {
        if ($text.IndexOf($token, [StringComparison]::OrdinalIgnoreCase) -ge 0) {
            $failures.Add("retired identifier '$token' in $rel")
        }
    }
}

# Build wiring is audited only on the newly added lines. Historical stage-named
# regression wiring elsewhere in build.zig is accepted and is not renamed here.
$buildPath = Join-Path $CandidateRoot 'build.zig'
$build = Get-Content -LiteralPath $buildPath -Raw
foreach ($rel in $newFirstClass) {
    $name = [IO.Path]::GetFileName($rel)
    if ($build.IndexOf($name, [StringComparison]::Ordinal) -lt 0) {
        $failures.Add("build wiring missing first-class module: $name")
    }
    if ($rel -match $generic) {
        $failures.Add("new first-class filename vocabulary violation: $rel")
    }
}

if ($BaseRoot) {
    $baseBuildPath = Join-Path $BaseRoot 'build.zig'
    if (-not (Test-Path -LiteralPath $baseBuildPath)) {
        throw "missing base build wiring input: $baseBuildPath"
    }
    $buildDiff = & git diff --no-index --unified=0 -- $baseBuildPath $buildPath 2>$null
} else {
    # W3X validates after application and before staging/commit, so the index is
    # the accepted base. The final delivery also carries an exact restore base
    # that may be supplied explicitly with -BaseRoot for an index-independent run.
    $buildDiff = & git -C $CandidateRoot diff --unified=0 -- build.zig 2>$null
}
foreach ($line in $buildDiff) {
    if ($line.StartsWith('+') -and -not $line.StartsWith('+++')) {
        if ($line -match $generic) {
            $failures.Add('new build-wiring vocabulary violation: ' + $line)
        }
        foreach ($token in $retired) {
            if ($line.IndexOf($token, [StringComparison]::OrdinalIgnoreCase) -ge 0) {
                $failures.Add("new retired identifier '$token' in build.zig")
            }
        }
    }
}

# Existing edited modules: inspect only added lines against the supplied base.
$existing = @(
    'build.zig','src/backend_tier_selection.zig','src/classic_ar_all_frames_ready.zig',
    'src/classic_instance_creation.zig','src/classic_instance_data.zig',
    'src/cpu_capability_detection.zig','src/deblock4_config.zig',
    'src/deblock4_selftest.zig','src/deblock4_version.zig','src/print_helper_functions.zig'
)
foreach ($rel in $existing) {
    $candidate = Join-Path $CandidateRoot $rel
    if (-not (Test-Path -LiteralPath $candidate)) {
        $failures.Add("missing existing audit input: $rel"); continue
    }
    if ($BaseRoot) {
        $base = Join-Path $BaseRoot $rel
        if (-not (Test-Path -LiteralPath $base)) {
            $failures.Add("missing base audit input: $rel"); continue
        }
        $diff = & git diff --no-index --unified=0 -- $base $candidate 2>$null
    } else {
        $diff = & git -C $CandidateRoot diff --unified=0 -- $rel 2>$null
    }
    foreach ($line in $diff) {
        if ($line.StartsWith('+') -and -not $line.StartsWith('+++')) {
            foreach ($token in $retired) {
                if ($line.IndexOf($token, [StringComparison]::OrdinalIgnoreCase) -ge 0) {
                    $failures.Add("new retired identifier '$token' in $rel")
                }
            }
        }
    }
}

if ($failures.Count -ne 0) {
    $failures | ForEach-Object { Write-Error $_ }
    exit 1
}
Write-Output 'STAGE_2C_K30_FIRST_CLASS_AUDIT_PASS'
exit 0
