param(
    [Parameter(Mandatory=$true)][string]$ReferenceSourceRoot,
    [Parameter(Mandatory=$true)][string]$VapourSynthIncludeRoot,
    [Parameter(Mandatory=$true)][string]$OutputRoot
)
$ErrorActionPreference = 'Stop'

function Sha256([string]$Path) {
    return (Get-FileHash -Algorithm SHA256 -LiteralPath $Path).Hash.ToLowerInvariant()
}
function Require-Tool([string]$Name) {
    $cmd = Get-Command $Name -ErrorAction SilentlyContinue
    if ($null -eq $cmd) { throw "$Name is not on PATH; run from an x64 MSVC developer prompt" }
    return $cmd.Source
}

$cl = Require-Tool 'cl.exe'
$link = Require-Tool 'link.exe'
$required = @('deblock.cpp','deblock.h','deblock_sse4.cpp','LICENSE')
$sumFile = Join-Path $ReferenceSourceRoot 'SHA256SUMS.txt'
if (-not (Test-Path -LiteralPath $sumFile)) { throw "missing SHA256SUMS.txt: $sumFile" }

$expected = @{}
foreach ($line in Get-Content -LiteralPath $sumFile) {
    if ($line -match '^([0-9a-fA-F]{64})\s+\*?(.+)$') {
        $expected[$Matches[2]] = $Matches[1].ToLowerInvariant()
    }
}
$sourceHashes = [ordered]@{}
foreach ($name in $required) {
    $path = Join-Path $ReferenceSourceRoot $name
    if (-not (Test-Path -LiteralPath $path)) { throw "missing pinned source: $path" }
    $actual = Sha256 $path
    if (-not $expected.ContainsKey($name) -or $expected[$name] -ne $actual) {
        throw "pinned source hash mismatch: $name expected=$($expected[$name]) actual=$actual"
    }
    $sourceHashes[$name] = $actual
}

$vs4 = Join-Path $VapourSynthIncludeRoot 'VapourSynth4.h'
$vsh4 = Join-Path $VapourSynthIncludeRoot 'VSHelper4.h'
foreach ($path in @($vs4,$vsh4)) { if (-not (Test-Path -LiteralPath $path)) { throw "missing header: $path" } }

New-Item -ItemType Directory -Force -Path $OutputRoot | Out-Null
$workspace = Join-Path $OutputRoot 'temporary_build_workspace'
if (Test-Path -LiteralPath $workspace) { Remove-Item -LiteralPath $workspace -Recurse -Force }
New-Item -ItemType Directory -Force -Path $workspace | Out-Null
$dll = Join-Path $OutputRoot 'holywu_deblock_r9_scalar.dll'
$obj = Join-Path $workspace 'deblock.obj'
$src = Join-Path $ReferenceSourceRoot 'deblock.cpp'

# The source is compiled in place by absolute path. It is never copied,
# rewritten, EOL-normalised or added to Deblock4's production build graph.
$compileArgs = @(
    '/nologo','/std:c++17','/O2','/EHsc','/MD','/LD','/W3',
    "/I$VapourSynthIncludeRoot",
    "/Fo$obj",
    "/Fd$(Join-Path $workspace 'holywu_compile.pdb')",
    $src,
    '/link','/NOLOGO',"/OUT:$dll",
    "/IMPLIB:$(Join-Path $workspace 'holywu_deblock_r9_scalar.lib')",
    "/PDB:$(Join-Path $workspace 'holywu_deblock_r9_scalar.pdb')"
)
$completeCommand = 'cl.exe ' + (($compileArgs | ForEach-Object { if ($_ -match '\s') { '"' + $_ + '"' } else { $_ } }) -join ' ')
& $cl @compileArgs
if ($LASTEXITCODE -ne 0) { throw "HolyWu scalar reference build failed with exit $LASTEXITCODE" }
if (-not (Test-Path -LiteralPath $dll)) { throw "reference DLL was not produced: $dll" }

$postBuildSourceHashes = [ordered]@{}
foreach ($name in $required) {
    $path = Join-Path $ReferenceSourceRoot $name
    $actual = Sha256 $path
    if ($actual -ne $sourceHashes[$name]) {
        throw "pinned source changed during reference build: $name before=$($sourceHashes[$name]) after=$actual"
    }
    $postBuildSourceHashes[$name] = $actual
}

$clVersion = (& $cl 2>&1 | Out-String).Trim()
$linkVersion = (& $link 2>&1 | Out-String).Trim()
$record = [ordered]@{
    schema = 'deblock4-stage-2c-holywu-reference-build-record-v1'
    completion_state = 'built-awaiting-sentinel-validation'
    os = [Environment]::OSVersion.VersionString
    process_architecture = [Runtime.InteropServices.RuntimeInformation]::ProcessArchitecture.ToString()
    compiler_path = $cl
    compiler_version = $clVersion
    linker_path = $link
    linker_version = $linkVersion
    cpp_language_mode = 'c++17'
    optimisation_flags = @('/O2')
    floating_point_flags = @('MSVC default; integer-only comparison domain')
    preprocessor_definitions = @('DEBLOCK_X86 ABSENT')
    complete_compile_link_command = $completeCommand
    exact_source_files = @('deblock.cpp','deblock.h')
    compilation_units = @('deblock.cpp')
    included_project_headers = @('deblock.h')
    pinned_source_hashes = $sourceHashes
    post_build_source_hashes = $postBuildSourceHashes
    vapoursynth_api_contract = '4.0 (no VS_USE_API_41/42 preprocessor definition)'
    vapoursynth_headers = [ordered]@{
        VapourSynth4_h = [ordered]@{ path = $vs4; sha256 = (Sha256 $vs4) }
        VSHelper4_h = [ordered]@{ path = $vsh4; sha256 = (Sha256 $vsh4) }
    }
    reference_plugin = [ordered]@{
        id = 'com.holywu.deblock'
        namespace = 'deblock'
        version = 'r9 / plugin version 9.0'
        dll_path = $dll
        dll_sha256 = (Sha256 $dll)
    }
    vapoursynth_runtime_version = 'TO_BE_RECORDED_BY_SENTINEL_RUN'
    mxcsr_fp_environment = 'NOT APPLICABLE: Stage 2C H5 comparison domain is integer-only'
    sentinel_observations = @()
}
$recordPath = Join-Path $OutputRoot 'reference-build-record.preliminary.json'
$record | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $recordPath -Encoding ascii
Write-Output "STAGE_2C_HOLYWU_BUILD_PASS dll=$dll record=$recordPath sha256=$($record.reference_plugin.dll_sha256)"
