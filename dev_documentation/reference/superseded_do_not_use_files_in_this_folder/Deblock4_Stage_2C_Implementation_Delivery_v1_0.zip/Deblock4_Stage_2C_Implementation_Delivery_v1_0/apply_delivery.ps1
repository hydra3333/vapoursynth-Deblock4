param(
    [Parameter(Mandatory=$true)][string]$TargetRoot
)
$ErrorActionPreference = 'Stop'

$replacementFiles = @(
    'build.zig',
    'src/backend_tier_selection.zig',
    'src/classic_ar_all_frames_ready.zig',
    'src/classic_instance_creation.zig',
    'src/classic_instance_data.zig',
    'src/cpu_capability_detection.zig',
    'src/deblock4_config.zig',
    'src/deblock4_selftest.zig',
    'src/deblock4_version.zig',
    'src/print_helper_functions.zig'
)
$newFiles = @(
    'build_2C_v1.bat',
    'src/classic_edge_schedule.zig',
    'src/classic_scalar_kernel.zig',
    'src/classic_thresholds.zig',
    'tests/Deblock4_Stage_2C_D3_v1_10_O_G_to_Test_Crosswalk.md',
    'tests/stage_2c_classic_obligations.vpy',
    'tools/audit_stage_2c_k30_first_class.ps1',
    'tools/holywu_reference/README.md',
    'tools/holywu_reference/build_holywu_r9_scalar.ps1',
    'tools/holywu_reference/reference-build-record-schema.json',
    'tools/holywu_reference/run_stage_2c_holywu_reference.cmd',
    'tools/holywu_reference/stage_2c_holywu_diff.vpy'
)

$target = [IO.Path]::GetFullPath($TargetRoot)
$payload = Join-Path $PSScriptRoot 'apply_to_tree'
if (-not (Test-Path -LiteralPath $target -PathType Container)) {
    throw "TargetRoot is not a directory: $target"
}

# Complete preflight before modifying the target. Per-file base hashes are
# intentionally not used; the D4 v1.9 base is the exact attached source tree.
foreach ($rel in $replacementFiles) {
    $source = Join-Path $payload $rel
    $destination = Join-Path $target $rel
    if (-not (Test-Path -LiteralPath $source -PathType Leaf)) {
        throw "delivery replacement payload is missing: $rel"
    }
    if (-not (Test-Path -LiteralPath $destination -PathType Leaf)) {
        throw "replacement target is missing from the attached base tree: $rel"
    }
}
foreach ($rel in $newFiles) {
    $source = Join-Path $payload $rel
    $destination = Join-Path $target $rel
    if (-not (Test-Path -LiteralPath $source -PathType Leaf)) {
        throw "delivery new-file payload is missing: $rel"
    }
    if (Test-Path -LiteralPath $destination) {
        throw "new-file target already exists; stop rather than overwrite: $rel"
    }
}

foreach ($rel in $replacementFiles + $newFiles) {
    $source = Join-Path $payload $rel
    $destination = Join-Path $target $rel
    $parent = Split-Path -Parent $destination
    if (-not (Test-Path -LiteralPath $parent)) {
        New-Item -ItemType Directory -Force -Path $parent | Out-Null
    }
    Copy-Item -LiteralPath $source -Destination $destination -Force
    Write-Output "APPLIED $rel"
}
Write-Output 'DEBLOCK4_STAGE_2C_DELIVERY_APPLIED'
Write-Output 'No validation was run by this apply script. W3X runs build_2C_v1.bat.'
