param(
    [Parameter(Mandatory=$true)][string]$TargetRoot
)
$ErrorActionPreference = 'Stop'

$replacementFiles = @(
    'build.zig',
    'src/backend_tier_selection.zig',
    'src/classic_ar_all_frames_ready.zig',
    'src/classic_instance_creation.zig',
    'src/classic_instance_data.zig',
    'src/cpu_capability_detection.zig',
    'src/deblock4_config.zig',
    'src/deblock4_selftest.zig',
    'src/deblock4_version.zig',
    'src/print_helper_functions.zig'
)
$newFiles = @(
    'build_2C_v1.bat',
    'src/classic_edge_schedule.zig',
    'src/classic_scalar_kernel.zig',
    'src/classic_thresholds.zig',
    'tests/Deblock4_Stage_2C_D3_v1_10_O_G_to_Test_Crosswalk.md',
    'tests/stage_2c_classic_obligations.vpy',
    'tools/audit_stage_2c_k30_first_class.ps1',
    'tools/holywu_reference/README.md',
    'tools/holywu_reference/build_holywu_r9_scalar.ps1',
    'tools/holywu_reference/reference-build-record-schema.json',
    'tools/holywu_reference/run_stage_2c_holywu_reference.cmd',
    'tools/holywu_reference/stage_2c_holywu_diff.vpy'
)

$target = [IO.Path]::GetFullPath($TargetRoot)
$restorePayload = Join-Path $PSScriptRoot 'restore_to_base'
if (-not (Test-Path -LiteralPath $target -PathType Container)) {
    throw "TargetRoot is not a directory: $target"
}
foreach ($rel in $replacementFiles) {
    $source = Join-Path $restorePayload $rel
    if (-not (Test-Path -LiteralPath $source -PathType Leaf)) {
        throw "restore payload is missing: $rel"
    }
}

# Restore only the exact replacement files and remove only the exact new files.
# Generated evidence under zig-out/inspection_2C is deliberately untouched.
foreach ($rel in $replacementFiles) {
    $source = Join-Path $restorePayload $rel
    $destination = Join-Path $target $rel
    $parent = Split-Path -Parent $destination
    if (-not (Test-Path -LiteralPath $parent)) {
        New-Item -ItemType Directory -Force -Path $parent | Out-Null
    }
    Copy-Item -LiteralPath $source -Destination $destination -Force
    Write-Output "RESTORED $rel"
}
foreach ($rel in $newFiles) {
    $destination = Join-Path $target $rel
    if (Test-Path -LiteralPath $destination -PathType Leaf) {
        Remove-Item -LiteralPath $destination -Force
        Write-Output "REMOVED $rel"
    }
}
$holywuDirectory = Join-Path $target 'tools/holywu_reference'
if (Test-Path -LiteralPath $holywuDirectory -PathType Container) {
    $remaining = @(Get-ChildItem -LiteralPath $holywuDirectory -Force)
    if ($remaining.Count -eq 0) {
        Remove-Item -LiteralPath $holywuDirectory -Force
    }
}
Write-Output 'DEBLOCK4_STAGE_2C_BASE_RESTORED'
Write-Output 'W3X-generated zig-out evidence was not inspected or removed.'
