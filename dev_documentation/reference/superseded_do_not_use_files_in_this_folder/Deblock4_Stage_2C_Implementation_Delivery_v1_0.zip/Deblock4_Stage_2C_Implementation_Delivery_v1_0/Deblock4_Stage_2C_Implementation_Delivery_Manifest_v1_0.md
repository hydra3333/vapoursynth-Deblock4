# Deblock4 Stage 2C Implementation Delivery Manifest

**Deliverable:** W3C-STAGE-2C-IMPLEMENTATION-DELIVERY
**Version:** 1.0
**Date:** 2026-08-06
**Author:** W3C
**Status:** Final integrated implementation delivery of record for W3X application and validation. Supersedes implementation increments 1 through 4. No W3C execution or PASS claim.
**Encoding:** US-ASCII; CRLF.

---

# 1. Authority and exact base

Implementation authority:

```text
Deblock4_Scope_Stage_2C_D4_Classic_Scalar_Oracle_v1_9.md
Deblock4_Stage_2C_D0_Preface_and_Binding_Knowledge_Index_v1_11.md
Deblock4_Stage_2C_D2_HolyWu_Real_Schedule_v1_6.md
Deblock4_Stage_2C_D3_Scalar_Obligations_and_Sanity_Gate_v1_10.md
Deblock4_Stage_2C_D4_Addendum_A_K26_Sentinel_Fixtures_v1_2.md
Deblock4_Stage_2C_D4_Addendum_B_Mandatory_Differential_Corpus_v1_2.md
Deblock4_Creation_Error_Message_Table_v1_6.md
D1 HolyWu r9 byte pin and provenance v1.4
```

Exact attached source base, identified by content rather than filename:

```text
Stage 1C + rider 1C.1 accepted tree
build_1C_v1.bat present
effective_invocation_text.zig present
runtime identity 0.1.0-dev+1C
attached archive in this session: src(20260805-120210).zip
archive SHA-256: 2132b44a993e01686aaa5347aba5be9a642ddf565792ea786e663ae62dd066b2
```

No per-file base hashes are imposed. The complete replacement copies under
`restore_to_base/` are the exact bytes from the attached base tree.

# 2. Repository file manifest

Exactly **10 REPLACES** and **12 NEW** repository files are delivered. No file
is removed and no other repository path is changed.

| Form | Repository path | Bounded purpose |
|---|---|---|
| REPLACES | `build.zig` | Wire the three new scalar module unit-test roots into the existing test step. |
| REPLACES | `src/backend_tier_selection.zig` | Apply the filter-neutral implementation ceiling, preserve EFFECTIVE precedence, and become the sole final summary-emission point. |
| REPLACES | `src/classic_ar_all_frames_ready.zig` | Replace Classic writable pass-through with actual per-plane byte-row scalar filtering while retaining copyFrame destination semantics and audit properties. |
| REPLACES | `src/classic_instance_creation.zig` | Add the ratified format refusals/storage validation, resolve thresholds, and use the ceiling-aware selector. |
| REPLACES | `src/classic_instance_data.zig` | Carry immutable sample/storage fields and resolved Classic thresholds. |
| REPLACES | `src/cpu_capability_detection.zig` | Relocate only summary emission and return existing ACTUAL/EFFECTIVE reason data; detection logic remains unchanged. |
| REPLACES | `src/deblock4_config.zig` | Declare filter-neutral implemented-tier ceiling data and the exact intentionally-capped reason token. |
| REPLACES | `src/deblock4_selftest.zig` | Adapt the accepted capability/selection selftest to the relocated summary seam and add pure S5 ceiling checks. |
| REPLACES | `src/deblock4_version.zig` | Advance the single-homed runtime identity from +1C to +2C. |
| REPLACES | `src/print_helper_functions.zig` | Extend the sole shared summary formatter with the intentionally-capped variant. |
| NEW | `build_2C_v1.bat` | Successor proof runner re-executing applicable Stage 1C gates and adding all Stage 2C D3/S5/K30/K31/H0-H6 gates. |
| NEW | `src/classic_edge_schedule.zig` | Exact Schedule-A byte-row traversal, complete-footprint eligibility, guarded schedule obligations, and both-orientation A/B routing. |
| NEW | `src/classic_scalar_kernel.zig` | Single canonical exact u8/u16 scalar edge formula with i32 arithmetic, shifts, clamps, vectors, and range proof. |
| NEW | `src/classic_thresholds.zig` | Pinned HolyWu r9 tables, offset/index derivation, depth scaling, and exhaustive threshold obligations. |
| NEW | `tests/Deblock4_Stage_2C_D3_v1_10_O_G_to_Test_Crosswalk.md` | Mandatory D3 section-7d O/G-to-test and S5/K30/K31/H0 proof routing. |
| NEW | `tests/stage_2c_classic_obligations.vpy` | Creation, production-path, routing, boundary, property, sanity, negative-control, and S5 end-to-end cases. |
| NEW | `tools/audit_stage_2c_k30_first_class.ps1` | Ratified two-part K30 non-cleanup first-class-module audit. |
| NEW | `tools/holywu_reference/README.md` | Operator and evidence-ownership instructions for the isolated reference tooling. |
| NEW | `tools/holywu_reference/build_holywu_r9_scalar.ps1` | Hash-guarded isolated MSVC scalar reference build and auditable preliminary record. |
| NEW | `tools/holywu_reference/reference-build-record-schema.json` | Required H1 reference-build record fields and evidence rules. |
| NEW | `tools/holywu_reference/run_stage_2c_holywu_reference.cmd` | Build/guard/sentinel/corpus orchestration with retained per-step logs. |
| NEW | `tools/holywu_reference/stage_2c_holywu_diff.vpy` | H4 guards, six K26 sentinels, fixed 17-case corpus, byte comparison, and machine-readable first-difference summary. |

Notably unchanged despite being within or adjacent to authorised surfaces:

```text
src/classic_frame_properties.zig
src/deblock4_instance_creation.zig
src/effective_invocation_text.zig
all deblock4.Deblock4 filter-path modules
all G10 debug modules
build_1C_v1.bat
all pinned holywu_r9 files
```

# 3. Application

Extract this delivery outside the repository, then from PowerShell run:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\apply_delivery.ps1 `
  -TargetRoot "X:\path\to\vapoursynth-Deblock4"
```

The script performs a complete preflight before writing:

```text
- every REPLACES target must already exist;
- every NEW target must not exist;
- every delivery payload file must exist;
- unrelated files and directories are not inspected or modified.
```

It copies only the 22 paths in section 2. It does not run validation.

# 4. W3X validation

From an x64 MSVC developer command prompt at the repository root:

```bat
build_2C_v1.bat
```

The successor runner:

```text
- re-executes every still-applicable Stage 1C invariant/regression gate in
  Debug, ReleaseSafe and ReleaseFast against the +2C tree;
- executes all D3 v1.10 pure and production-path obligations;
- checks the mandatory O/G-to-test crosswalk;
- checks T-S5-1a/1b and T-S5-2..5;
- checks K30's two-part audit and K31 byte-row navigation;
- compares ReleaseSafe and ReleaseFast production hashes;
- builds and validates the isolated HolyWu r9 scalar reference under H0-H6;
- retains generated inspection evidence under `zig-out/inspection_2C`.
```

Standard H0 defaults used by `build_2C_v1.bat`:

```text
DEBLOCK4_REFERENCE_SOURCE_ROOT=dev_documentation\reference\holywu_r9
DEBLOCK4_VS_INCLUDE_ROOT=third_party\vapoursynth\include
```

W3X may override those environment variables when the same byte-pinned sources
or headers are stored elsewhere. The reference build and each guard, sentinel,
and corpus invocation retain separate logs under the H0 inspection directory.

Expected final authority result, not observed or claimed by W3C:

```text
OUTER_BATCH_EXIT_CODE=0
all mandatory gates PASS
zero unratified HolyWu plane-byte differences
```

W3X supplies the actual console output and generated evidence before any PASS,
acceptance, commit or push statement.

# 5. H0 evidence ownership

W3C delivers only source tooling and schemas. W3X generates locally:

```text
holywu_deblock_r9_scalar.dll
reference-build-record.preliminary.json
reference-build-record.completed.json
build.log
guard_selftests.log
sentinels.log
corpus.log
stage_2c_holywu_difference_summary.json
outer build/inspection captures
```

These are inspection evidence, not committed source. Neither the apply script
nor the scoped restore script inspects or deletes them.

# 6. Scoped restore-to-base

To restore only this delivery's repository paths:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\restore_to_base.ps1 `
  -TargetRoot "X:\path\to\vapoursynth-Deblock4"
```

The restore script:

```text
- replaces the 10 REPLACES paths with exact attached-base copies;
- removes only the 12 NEW files when present;
- removes tools/holywu_reference only if it becomes empty;
- never performs a global cleanup;
- never touches unrelated W3X work;
- never inspects or deletes zig-out/inspection_2C evidence;
- never reads, moves or deletes superseded folders.
```

# 7. Static authoring checks performed by W3C

These checks examined package/source text only; they did **not** compile, link,
load VapourSynth, run Zig tests, execute PowerShell/batch proof scripts, build
the reference DLL, or compare video output:

```text
- exact changed boundary: 10 REPLACES, 12 NEW, 0 removed;
- every delivered repository artifact US-ASCII and CRLF-only;
- Python/VapourSynth script AST parsing;
- reference-build-record JSON parsing;
- local Zig import-path existence;
- batch/cmd label-reference reachability;
- mandatory crosswalk identifier presence;
- one public canonical filterEdge body and no @Vector/@mulAdd in scalar modules;
- forbidden src/deblock4_instance_creation.zig byte-identical to the base;
- apply/restore payload-list consistency.
```

**C-DELIV-07:** W3C claims no execution and no PASS.

---

*End of Deblock4 Stage 2C implementation delivery manifest.*
