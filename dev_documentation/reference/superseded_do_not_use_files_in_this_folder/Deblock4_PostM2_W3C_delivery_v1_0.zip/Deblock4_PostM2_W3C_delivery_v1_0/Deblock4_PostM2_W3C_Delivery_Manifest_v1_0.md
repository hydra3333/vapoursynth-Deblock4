# Deblock4 - Post-5C Maintenance M2 - W3C Delivery Manifest v1.0

**Scope:** `Deblock4_Scope_PostM2_Identifier_Hygiene_v1_3.md`
**Base:** committed Stage 5C plus accepted M1, identity `0.1.0-dev+5C`
**Delivery:** identifier retirement + historical proof-surface retirement
**Encoding:** repository text remains US-ASCII / CRLF
**Execution ownership:** W3X. W3C has not executed the project proof matrix.

## 1. Repository changes

### REPLACE from `apply_to_tree/`

- `src/deblock4_selftest.zig`
- `build_5C_v1.bat`
- `tests/stage_2c_classic_obligations.vpy`
- `tests/Deblock4_Stage_2C_D3_v1_10_O_G_to_Test_Crosswalk.md`
- `tools/audit_stage_1c_s3_eol.ps1`
- `tools/audit_stage_1c_s2_sweep.ps1`

### DELETE manually after the replacements are copied

- `build_1C_v1.bat`
- `build_2C_v1.bat`
- `build_4C_v1.bat`
- `tools/stage_4c/run_stage_4c_differential.cmd`
- `tools/stage_4c/stage_4c_scalar_v2_diff.py`
- `tests/stage_1c_classic_passthrough.vpy`
- whole directory `tools/holywu_reference`

The HolyWu crosswalk description is replaced BEFORE the directory deletion by
the apply sequence below.

Everything else is byte-frozen.

## 2. Restore material

`restore_to_base/` contains exact pre-M2 copies of:

- all six REPLACE files;
- all six individually deleted files;
- all five files in the deleted `tools/holywu_reference/` directory.

This is sufficient for complete manual backout to the supplied accepted-M1
base without git staging or repository-operating delivery scripts.

## 3. W3X manual base confirmation - BEFORE ANY M2 CHANGE

Extract this package, then from the repository root set its location, e.g.:

```cmd
set "M2=C:\TEMP\Deblock4_PostM2_W3C_delivery_v1_0"
```

Confirm every file that M2 will replace or delete is byte-identical to the
delivery's pre-M2 base copy. Every command below must report no differences.

```cmd
fc /b "src\deblock4_selftest.zig" "%M2%\restore_to_base\src\deblock4_selftest.zig"
fc /b "build_5C_v1.bat" "%M2%\restore_to_base\build_5C_v1.bat"
fc /b "tests\stage_2c_classic_obligations.vpy" "%M2%\restore_to_base\tests\stage_2c_classic_obligations.vpy"
fc /b "tests\Deblock4_Stage_2C_D3_v1_10_O_G_to_Test_Crosswalk.md" "%M2%\restore_to_base\tests\Deblock4_Stage_2C_D3_v1_10_O_G_to_Test_Crosswalk.md"
fc /b "tools\audit_stage_1c_s3_eol.ps1" "%M2%\restore_to_base\tools\audit_stage_1c_s3_eol.ps1"
fc /b "tools\audit_stage_1c_s2_sweep.ps1" "%M2%\restore_to_base\tools\audit_stage_1c_s2_sweep.ps1"

fc /b "build_1C_v1.bat" "%M2%\restore_to_base\build_1C_v1.bat"
fc /b "build_2C_v1.bat" "%M2%\restore_to_base\build_2C_v1.bat"
fc /b "build_4C_v1.bat" "%M2%\restore_to_base\build_4C_v1.bat"
fc /b "tools\stage_4c\run_stage_4c_differential.cmd" "%M2%\restore_to_base\tools\stage_4c\run_stage_4c_differential.cmd"
fc /b "tools\stage_4c\stage_4c_scalar_v2_diff.py" "%M2%\restore_to_base\tools\stage_4c\stage_4c_scalar_v2_diff.py"
fc /b "tests\stage_1c_classic_passthrough.vpy" "%M2%\restore_to_base\tests\stage_1c_classic_passthrough.vpy"
fc /b "tools\holywu_reference\README.md" "%M2%\restore_to_base\tools\holywu_reference\README.md"
fc /b "tools\holywu_reference\build_holywu_r9_scalar.cmd" "%M2%\restore_to_base\tools\holywu_reference\build_holywu_r9_scalar.cmd"
fc /b "tools\holywu_reference\reference-build-record-schema.json" "%M2%\restore_to_base\tools\holywu_reference\reference-build-record-schema.json"
fc /b "tools\holywu_reference\run_stage_2c_holywu_reference.cmd" "%M2%\restore_to_base\tools\holywu_reference\run_stage_2c_holywu_reference.cmd"
fc /b "tools\holywu_reference\stage_2c_holywu_diff.vpy" "%M2%\restore_to_base\tools\holywu_reference\stage_2c_holywu_diff.vpy"
```

If ANY comparison differs, STOP before applying M2 and report the mismatch.

## 4. W3X manual atomic apply sequence

First copy ALL six replacement files. This updates the crosswalk and surviving
proof references before any retirement deletion occurs.

```cmd
copy /y "%M2%\apply_to_tree\src\deblock4_selftest.zig" "src\deblock4_selftest.zig"
copy /y "%M2%\apply_to_tree\build_5C_v1.bat" "build_5C_v1.bat"
copy /y "%M2%\apply_to_tree\tests\stage_2c_classic_obligations.vpy" "tests\stage_2c_classic_obligations.vpy"
copy /y "%M2%\apply_to_tree\tests\Deblock4_Stage_2C_D3_v1_10_O_G_to_Test_Crosswalk.md" "tests\Deblock4_Stage_2C_D3_v1_10_O_G_to_Test_Crosswalk.md"
copy /y "%M2%\apply_to_tree\tools\audit_stage_1c_s3_eol.ps1" "tools\audit_stage_1c_s3_eol.ps1"
copy /y "%M2%\apply_to_tree\tools\audit_stage_1c_s2_sweep.ps1" "tools\audit_stage_1c_s2_sweep.ps1"
```

Then perform the ratified deletions:

```cmd
del /q "build_1C_v1.bat"
del /q "build_2C_v1.bat"
del /q "build_4C_v1.bat"
del /q "tools\stage_4c\run_stage_4c_differential.cmd"
del /q "tools\stage_4c\stage_4c_scalar_v2_diff.py"
del /q "tests\stage_1c_classic_passthrough.vpy"
rmdir /s /q "tools\holywu_reference"
```

Do NOT stage anything.

## 5. Confirm the applied bytes and deletions before validation

All six comparisons must report no differences:

```cmd
fc /b "src\deblock4_selftest.zig" "%M2%\apply_to_tree\src\deblock4_selftest.zig"
fc /b "build_5C_v1.bat" "%M2%\apply_to_tree\build_5C_v1.bat"
fc /b "tests\stage_2c_classic_obligations.vpy" "%M2%\apply_to_tree\tests\stage_2c_classic_obligations.vpy"
fc /b "tests\Deblock4_Stage_2C_D3_v1_10_O_G_to_Test_Crosswalk.md" "%M2%\apply_to_tree\tests\Deblock4_Stage_2C_D3_v1_10_O_G_to_Test_Crosswalk.md"
fc /b "tools\audit_stage_1c_s3_eol.ps1" "%M2%\apply_to_tree\tools\audit_stage_1c_s3_eol.ps1"
fc /b "tools\audit_stage_1c_s2_sweep.ps1" "%M2%\apply_to_tree\tools\audit_stage_1c_s2_sweep.ps1"
```

Confirm every retirement target is absent:

```cmd
if exist "build_1C_v1.bat" echo ERROR: build_1C_v1.bat still exists
if exist "build_2C_v1.bat" echo ERROR: build_2C_v1.bat still exists
if exist "build_4C_v1.bat" echo ERROR: build_4C_v1.bat still exists
if exist "tools\stage_4c\run_stage_4c_differential.cmd" echo ERROR: old Stage 4C runner still exists
if exist "tools\stage_4c\stage_4c_scalar_v2_diff.py" echo ERROR: old Stage 4C Python harness still exists
if exist "tests\stage_1c_classic_passthrough.vpy" echo ERROR: old Stage 1C Classic harness still exists
if exist "tools\holywu_reference" echo ERROR: retired HolyWu directory still exists
```

No `ERROR:` line may be printed.

## 6. M2 static evidence before the full matrix

W3C's prepared static evidence is under `evidence/`. W3D should independently
re-check it against the applied repository.

Useful W3X spot checks:

### 6.1 M2-T1/T2 new token cardinality

```cmd
findstr /n /c:"selection_and_creation_contract=PASS" "src\deblock4_selftest.zig"
findstr /n /c:"selection_and_creation_contract=PASS" "build_5C_v1.bat"
```

Expected visible cardinality:

- selftest: exactly 1 line;
- build_5C: exactly 2 lines.

### 6.2 Old emitted token extinction on the live emitter/assertion surface

```cmd
findstr /n /c:"stage_1c=PASS" "src\deblock4_selftest.zig"
findstr /n /c:"stage_1c=PASS" "build_5C_v1.bat"
```

Both commands should produce no matching line.

### 6.3 M2-T3 human-readable diffs

Retain these transcripts for W3D review:

```cmd
if not exist "zig-out\inspection_M2" mkdir "zig-out\inspection_M2"
fc /n "%M2%\restore_to_base\src\deblock4_selftest.zig" "src\deblock4_selftest.zig" > "zig-out\inspection_M2\selftest_diff.txt"
fc /n "%M2%\restore_to_base\build_5C_v1.bat" "build_5C_v1.bat" > "zig-out\inspection_M2\build5_diff.txt"
fc /n "%M2%\restore_to_base\tests\stage_2c_classic_obligations.vpy" "tests\stage_2c_classic_obligations.vpy" > "zig-out\inspection_M2\stage2_vpy_diff.txt"
fc /n "%M2%\restore_to_base\tests\Deblock4_Stage_2C_D3_v1_10_O_G_to_Test_Crosswalk.md" "tests\Deblock4_Stage_2C_D3_v1_10_O_G_to_Test_Crosswalk.md" > "zig-out\inspection_M2\crosswalk_diff.txt"
fc /n "%M2%\restore_to_base\tools\audit_stage_1c_s3_eol.ps1" "tools\audit_stage_1c_s3_eol.ps1" > "zig-out\inspection_M2\s3_diff.txt"
fc /n "%M2%\restore_to_base\tools\audit_stage_1c_s2_sweep.ps1" "tools\audit_stage_1c_s2_sweep.ps1" > "zig-out\inspection_M2\s2_diff.txt"
```

The expected confinement is documented in
`evidence/M2_W3C_static_preparation_evidence_v1_0.txt`.

## 7. M2-T5 full retained matrix - W3X executes

Use the retained Stage-5C W3D runners:

```cmd
set "DEBLOCK4_STAGE5C_DIFFERENTIAL_RUNNER=%CD%\tools\stage_5c\run_stage_5c_differential.cmd"
set "DEBLOCK4_STAGE5C_BENCHMARK_RUNNER=%CD%\tools\stage_5c\run_stage_5c_benchmark.cmd"
dir "%DEBLOCK4_STAGE5C_DIFFERENTIAL_RUNNER%"
dir "%DEBLOCK4_STAGE5C_BENCHMARK_RUNNER%"
call build_5C_v1.bat
```

The ratified matrix requirement is a green run ending in:

```text
OUTER_BATCH_EXIT_CODE=0
```

W3C does NOT claim this result in advance.

## 8. M2-T6 no-false-success evidence

A terminal exit code alone is insufficient.

After the matrix run, visibly inspect the NEW selftest token in all three
retained mode artifacts:

```cmd
findstr /n /c:"selection_and_creation_contract=PASS" "zig-out\inspection_5C\Debug\selftest.txt"
findstr /n /c:"selection_and_creation_contract=PASS" "zig-out\inspection_5C\ReleaseSafe\selftest.txt"
findstr /n /c:"selection_and_creation_contract=PASS" "zig-out\inspection_5C\ReleaseFast\selftest.txt"
```

Each mode must visibly contain the new token.

Also retain or send W3C the complete matrix console transcript. W3C will audit
the intentional negative-control failures/errors separately from genuine
failures, as required by M2-T6; do not accept the run solely from its final
exit code.

## 9. Manual backout to the exact pre-M2 base

Restore the six modified files:

```cmd
copy /y "%M2%\restore_to_base\src\deblock4_selftest.zig" "src\deblock4_selftest.zig"
copy /y "%M2%\restore_to_base\build_5C_v1.bat" "build_5C_v1.bat"
copy /y "%M2%\restore_to_base\tests\stage_2c_classic_obligations.vpy" "tests\stage_2c_classic_obligations.vpy"
copy /y "%M2%\restore_to_base\tests\Deblock4_Stage_2C_D3_v1_10_O_G_to_Test_Crosswalk.md" "tests\Deblock4_Stage_2C_D3_v1_10_O_G_to_Test_Crosswalk.md"
copy /y "%M2%\restore_to_base\tools\audit_stage_1c_s3_eol.ps1" "tools\audit_stage_1c_s3_eol.ps1"
copy /y "%M2%\restore_to_base\tools\audit_stage_1c_s2_sweep.ps1" "tools\audit_stage_1c_s2_sweep.ps1"
```

Restore the deleted files/directories:

```cmd
copy /y "%M2%\restore_to_base\build_1C_v1.bat" "build_1C_v1.bat"
copy /y "%M2%\restore_to_base\build_2C_v1.bat" "build_2C_v1.bat"
copy /y "%M2%\restore_to_base\build_4C_v1.bat" "build_4C_v1.bat"

if not exist "tools\stage_4c" mkdir "tools\stage_4c"
copy /y "%M2%\restore_to_base\tools\stage_4c\run_stage_4c_differential.cmd" "tools\stage_4c\run_stage_4c_differential.cmd"
copy /y "%M2%\restore_to_base\tools\stage_4c\stage_4c_scalar_v2_diff.py" "tools\stage_4c\stage_4c_scalar_v2_diff.py"

copy /y "%M2%\restore_to_base\tests\stage_1c_classic_passthrough.vpy" "tests\stage_1c_classic_passthrough.vpy"

if not exist "tools\holywu_reference" mkdir "tools\holywu_reference"
copy /y "%M2%\restore_to_base\tools\holywu_reference\README.md" "tools\holywu_reference\README.md"
copy /y "%M2%\restore_to_base\tools\holywu_reference\build_holywu_r9_scalar.cmd" "tools\holywu_reference\build_holywu_r9_scalar.cmd"
copy /y "%M2%\restore_to_base\tools\holywu_reference\reference-build-record-schema.json" "tools\holywu_reference\reference-build-record-schema.json"
copy /y "%M2%\restore_to_base\tools\holywu_reference\run_stage_2c_holywu_reference.cmd" "tools\holywu_reference\run_stage_2c_holywu_reference.cmd"
copy /y "%M2%\restore_to_base\tools\holywu_reference\stage_2c_holywu_diff.vpy" "tools\holywu_reference\stage_2c_holywu_diff.vpy"
```

Do not commit M2 until the W3D artifact review and W3X acceptance are complete.
