# Deblock4 - Post-5C Maintenance M2 - W3C Delivery Note to W3D v1.0

**From:** W3C
**Route:** W3C -> W3X -> W3D
**Date:** 2026-08-16
**Scope:** `Deblock4_Scope_PostM2_Identifier_Hygiene_v1_3.md`
**Base:** committed Stage 5C plus accepted M1, identity `0.1.0-dev+5C`
**Status:** implementation delivery prepared; W3X execution and W3D artifact
review remain required.

## Delivery summary

M2 is implemented as one integrated proof-surface maintenance delivery.

Modified:
- `src/deblock4_selftest.zig`
- `build_5C_v1.bat`
- `tests/stage_2c_classic_obligations.vpy`
- `tests/Deblock4_Stage_2C_D3_v1_10_O_G_to_Test_Crosswalk.md`
- `tools/audit_stage_1c_s3_eol.ps1`
- `tools/audit_stage_1c_s2_sweep.ps1`

Retired:
- historical 1C/2C/4C root proof batches;
- superseded Stage-4C differential tool pair;
- orphaned Stage-1C Classic vpy;
- whole HolyWu reference tooling directory, now historical per K26.

No filter mathematics, dispatch, selection logic, thresholds, vector code,
Classic frozen unit, build.zig, Stage-5C runner, or live Deblock4 Stage-1C vpy
is changed.

## M2 naming

The ratified M2-N1..N9 spellings are applied exactly.

The emitted contract marker is:

    selection_and_creation_contract=PASS

Static candidate cardinality is exactly:
- 1 source emitter;
- 2 live `build_5C_v1.bat` assertions.

The two human gate labels now say "selftest selection and creation contract".

## Discovery-derived proof-surface retirement

The live Stage-2C O/G crosswalk now describes the current Stage-5C proof
surface for T-S5-1a/T-S5-2/T-S5-3/T-S5-4/T-S5-5 and marks H0-H6 as evidence
history. All 45 obligation IDs consumed by the live batch remain present.

The stale n02a/n02b branches are removed from the live Stage-2C vpy and its
caller comments no longer name retired batches.

S3 now audits `build_5C_v1.bat` as the live root proof batch.

S2 now:
- removes the dead build_1C skip;
- enforces the newly retired artifacts through its existing retired-list
  mechanism;
- uses the v1.3-corrected distinctive directory entry
  `tools/holywu_reference`, not generic member basenames such as `README.md`.

## W3C static preparation observations

See `evidence/M2_W3C_static_preparation_evidence_v1_0.txt` and the unified diff.

W3C mechanically observed:
- only the six authorised MOD files differ from base;
- exactly the eleven authorised tracked files are absent in the candidate;
- no unexpected file addition/change/deletion;
- all changed files remain US-ASCII/CRLF;
- old live M2-N1..N9 vocabulary is extinct;
- new token cardinality is exactly 1 emitter + 2 assertions;
- all 45 crosswalk IDs remain;
- no newly retired basename survives in S2's live search domain outside S2's
  own intentional retired-list declarations;
- every non-authorised common file is byte-identical to base.

These are static preparation observations, not project execution/PASS claims.

## Execution still owed by W3X

W3X must apply the package manually and execute the ratified M2-T5 full
`build_5C_v1.bat` matrix.

M2-T6 also requires review beyond the final exit code:
- the new selftest contract marker must be visibly observed in Debug,
  ReleaseSafe and ReleaseFast artifacts;
- the complete console transcript must be reviewed so intentional negative
  controls are distinguished from genuine failure.

W3C has not run Zig, VapourSynth, the audit scripts, differential runner,
benchmark or full matrix.
