# Deblock4 - W3C Review of T1S01a3 Architecture-Summary Ledger

**Deliverable:** T1S01a3_B - W3C REVIEW
**Version:** 1.0
**Date:** 2026-08-18
**Author:** W3C
**Route:** W3C -> W3X -> W3D
**Reviews:** `T1S01a3_A_Ledger_Architecture_Summary_v1_0.md`
**Current review scope used:** `Deblock4_T1_W3C_Review_Scope_v1_8.md`
**Current task register used:** `Deblock4_Standing_Task_Register_T_Series_v1_11.md`
**Current charter used:** `AI_Charter_and_Invariants_Card_v1_31.md`
**Current status record checked:** `Deblock4_Project_Status_v1_30.md`
**Authority adjudicated:** `Deblock4_MPEG2_Deblocking_Investigation_and_Decided_Architecture_v1_05.md`
**Encoding:** US-ASCII; CRLF.

---

# Plain-English summary

The previous range-coverage defect is substantially fixed: this sub-tranche now
states exactly which section-0/header material it takes and assigns the rest to
named later sub-tranches. Most of W3D's substantive conclusion is also right:
the section-0 architecture summary is current and is deliberately duplicating
more detailed material elsewhere in the authority.

I nevertheless found a METHOD defect before the individual verdicts. The
ledger says the proposed designed-summary exception is not yet adopted, but
LED-013 through LED-019 already apply it in PREVAILS by saying the
non-canonical section-0 copy "STAYS as summary". The binding v1.8
CURRENT-DUPLICATE rule presently says the opposite: if this copy is not the
canonical home, it becomes a pointer. New derived reasoning has therefore
leaked into the adjudication before W3X has ratified the rule change.

I also found narrower coverage omissions inside some entries, two incorrect
CURRENT-UNIQUE findings in the header, and one blanket provenance claim whose
truth cannot yet be called current because the body sweep that would establish
it is deliberately unfinished. These corrections do not require stopping
T1S01a4; they do require T1S01a3 to be corrected before it is treated as
closed.

No source was changed. I performed no build, execution, test, patch, delivery
machinery or git operation. The W3X-supplied source snapshot from the current
session remains available, but no entry in this tranche turned on
implementation classification.

---

# DECISIONS/QUESTIONS FOR W3X

## Q1. METHOD: the unratified summary exception is already being applied

The binding v1.8 CURRENT-DUPLICATE rule says:

- identify the canonical home;
- if this copy IS the canonical home, it stays;
- if this copy is NOT the canonical home, it becomes a pointer.

LED-013 through LED-019 identify body sections/registers/Appendix D as their
canonical homes, then say `THIS COPY STAYS as summary`. That outcome is
possible only if W3X first accepts the new exception proposed at LED-024.
LED-024 itself says W3D recommends NOT applying the proposal retroactively to
the entries above, but the entries above already apply it.

Why it matters: this is exactly the corrected-template failure mode in review
scope Q-F - derived reasoning has leaked into PREVAILS, where it reads as an
already-established finding/action.

My recommendation is to ACCEPT THE NEED FOR A NARROW EXCEPTION but NOT W3D's
general `DESIGNED / INCIDENTAL` field as written. The current Task Register T3
already says it strips duplicated knowledge from the OTHER documents into
pointers to the authority; it does not actually instruct T3 to hollow out the
authority's own read-first summary. The minimum safe rule is therefore:

    A CURRENT-DUPLICATE copy that is not the canonical source normally becomes
    a pointer. Exception: an explicitly designated summary/index/orientation
    layer inside the canonical authority may be RETAINED as a subordinate
    summary when its declared function requires a concise restatement. The
    entry must identify the canonical source and must not treat the summary as
    an independent authority or introduce unique normative content.

If W3X wants a visible field, I recommend something narrow such as
`DUPLICATE-ACTION: RETAIN-SUMMARY / POINTER`, not `DESIGNED / INCIDENTAL`.
"Designed" is too broad: stale duplicates are often deliberately designed too.

This is a process criterion applied to W3D's own ledger, so charter I7 applies.
W3D has proposed; this document is W3C's independent verification; W3X decides.

Refs: review scope v1.8 sections 5, 5.2, Q-F; Task Register v1.11 T3;
LED-013..019, LED-024.

## Q2. Coverage is now declared correctly, but several entries still do not cover all propositions they claim to adjudicate

The sub-tranche-level coverage declaration is sound. I do NOT repeat the old
method blocker that a whole range was declared complete while most of it was
missing.

At entry level, however, three places still need correction:

1. LED-013 says it adjudicates section-0 items 1-8, but its CLAIM compresses
   away material propositions inside those items. In particular item 2 also
   says final public token spelling remains D4-Q16, the old
   `mpeg2_field_separated` name is retired in principle, and TFF/BFF is not a
   grid parameter; item 5 also states the plane-relative chroma vertical-edge
   consequence. Those are part of the declared source range and should be
   visibly accounted for.

2. LED-015 says it adjudicates item 11, but its CLAIM omits item 11's required
   horizontal descriptor contents (plane, x bounds, edge row, edge kind,
   pitch/parity where applicable) and the explicit rule that vertical work
   does not gain a fake pitch-2/parity split.

3. LED-019 says it adjudicates all of item 17, but its CLAIM stops after
   processing-order. The source item continues with proper-chroma quality,
   pipeline guidance, side-data interface, final public parameter/property
   surface, scalar oracle and later SIMD backends. Those open items are not
   optional detail: the point of item 17 is to prevent a successor from
   believing unresolved work is settled.

My recommendation is NOT to require seventeen separate entries merely because
there are seventeen numbered items. Bundling propositions that genuinely have
the same disposition is permitted by the atomic rule. But the CLAIM must
visibly account for every material proposition in the declared item, and a
CURRENT-DUPLICATE bundle must map each proposition to its own canonical source.

Refs: review scope v1.8 sections 4.2.1, 5.2, Q-D; authority v1.05 section 0
items 2, 5, 11 and 17; LED-013, LED-015, LED-019.

## Q3. LED-020 and LED-021 are not CURRENT-UNIQUE

LED-020 says the authority-status declaration is unique because other
documents merely "refer" to it rather than "declare" it. That distinction is
not in the binding disposition definition. CURRENT-UNIQUE means this is the
only place the statement is written.

It is not. Current live documents repeat the same proposition, for example:

- coder introduction v1.32 says this W3X-ratified document is the prevailing
  authority and the single source of truth for the named MPEG-2 domains;
- the designer blurb v1.2 calls it the W3X-ratified `PREVAILING SINGLE SOURCE
  OF TRUTH`;
- Project Status v1.30 says it is the prevailing authority and that it
  supersedes the Grid Knowledge document and raw GAIS on MPEG-2 matters.

The source header is the sensible CANONICAL HOME, so the authority-status
proposition is CURRENT-DUPLICATE and this header copy stays.

LED-020 also mixes a second proposition - what v1.05 did as a revision. That
proposition has its natural historical home in Appendix E, which repeats the
ratification-recording / handoff-currency-only nature of v1.05. I recommend
splitting or explicitly mapping the two propositions rather than giving them
one uniqueness judgement and one home.

LED-021 has the same problem. Its single-source boundary is load-bearing and
belongs canonically in the authority header, but its substantive parts are
repeated operationally in current orientation/status documents: the authority
owns MPEG-2 truth, raw GAIS is evidence rather than authority, and non-MPEG-2
global rules remain in their own authorities. Its SWEPT search checked only
the Task Register and old Project Status v1.29, omitting obvious current
orientation documents and current Project Status v1.30. It has therefore not
earned CURRENT-UNIQUE.

My recommendation:
- LED-020 authority-status proposition -> CURRENT-DUPLICATE, canonical home
  authority header;
- LED-020 v1.05 revision-nature proposition -> separately map to Appendix E;
- LED-021 -> CURRENT-DUPLICATE, canonical home authority header.

Refs: review scope v1.8 CURRENT-UNIQUE/CURRENT-DUPLICATE and SWEPT rules;
coder introduction v1.32 section 2.7; designer blurb v1.2 reading list;
Project Status v1.30 current-position section; LED-020, LED-021.

## Q4. LED-023 cannot yet be accepted as CURRENT-UNIQUE because "current" includes truth

The statement `Nothing in this document rests on unverified GAIS testimony`
is probably unique as text. That is only half of CURRENT-UNIQUE. The
definition also says it must be STILL TRUE.

W3D explicitly says it has not verified the truth of this whole-document
claim, because only part of the 1,983-line document has been swept. "No
evidence against it" is not proof that a blanket provenance assertion is true.

I recommend leaving the ledger entry present but the W3C verdict UNSURE and
deferring final disposition until T1S01a5's whole-document check. Do not invent
a sixth temporary disposition. At a5:
- if every relevant factual assertion is supported by the recorded provenance
  discipline, CURRENT-UNIQUE is then justified;
- if not, the live blanket claim must be qualified or dispositioned according
  to what the completed sweep finds.

Refs: review scope v1.8 CURRENT-UNIQUE definition; LED-023.

## Q5. Two live routing records still point the DEC-32 defect at a3 although the current split puts it in a4

The current Task Register v1.11 DEC-35 and the T1S01a3 covering note clearly
put section 23 steps 6-10 in T1S01a4. That is the current routing I used.

Two live records still carry the older route:
- Task Register DEC-32 says the defect is deferred to T1S01a3;
- Project Status v1.30 says T1S01a3 includes section 23 steps 6-10 and likewise
  says the ordering defect is deferred to a3.

This is not a blocker because DEC-35 is the later, more specific split and the
issued batch is unambiguous. It is nevertheless exactly the kind of live
currency drift T1 is meant to expose.

I recommend correcting those pointers on the next natural Task
Register/Project Status refresh. Do not interrupt T1S01a4 merely for this.

Refs: Task Register v1.11 DEC-32/DEC-35; Project Status v1.30 section 0;
T1S01a3 covering note.

---

# Entry-by-entry verdicts

## LED-013 - DISAGREE AS RECORDED; CURRENT-DUPLICATE itself is correct

I independently traced the representative items into the decision register and
body. The substantive outcome is right:

- item 1 -> D4-D01 and section 5;
- item 2 -> D4-D02;
- items 3/4 -> codec findings and D4-D04;
- item 5 -> D4-D05/D4-D12;
- item 6 -> D4-D06;
- item 7 -> D4-D08;
- item 8 -> D4-D09/D4-Q11.

So these are genuine current duplicates.

I disagree with the entry as a complete record for two reasons. First, it
applies the unratified "summary stays" exception in PREVAILS. Second, the
CLAIM does not visibly account for all material subclaims in items 2 and 5 as
described in Q2. Its canonical-home wording also names "the D4-D register and
the body sections" generically; the corrected rule asks for the canonical home
of each proposition, not a cloud of possible homes.

VERDICT: DISAGREE AS RECORDED. Keep CURRENT-DUPLICATE; repair claim coverage,
map canonical source per proposition, and apply whatever summary exception W3X
actually ratifies.

Refs: authority section 0 items 1-8; authority section 22 D4-D01..D4-D09;
LED-013.

## LED-014 - DISAGREE ONLY ON THE UNRATIFIED "STAYS" ACTION; factual adjudication is sound

I checked section 6.2 and section 3.1. The LG table does record
frame_pred_frame_dct=0 for XP/SP/LP/EP and 1 for MLS. Section 6.2 makes the
same precision distinction as section 0: adaptive-capable does not prove an
actual FRAME/FIELD mixture. Section 3.1 explicitly limits MediaInfo to cheap
picture-level triage and says Q14 needs deeper per-macroblock truth.

CURRENT-DUPLICATE is therefore correct and the canonical sources named are
appropriate for the separate measurement and triage propositions.

The only present defect is PREVAILS saying the section-0 copy stays before W3X
has accepted the summary exception.

VERDICT: DISAGREE AS RECORDED; otherwise AGREE.

Refs: authority sections 3.1 and 6.2; LED-014.

## LED-015 - DISAGREE AS RECORDED; CURRENT-DUPLICATE is correct

I checked B2 against sections 10/11 and the SIMD consequences. The topology
table, UNKNOWN behaviour and geometry-homogeneous span concept are genuine
restatements and remain current.

The entry does not visibly cover all of item 11: it omits the minimum
descriptor fields and the explicit no-fake-pitch2/parity rule for vertical
work. Those are implementation-facing architecture requirements, not prose
decoration. They must be accounted for if item 11 is declared adjudicated.

The same unratified "THIS COPY STAYS" issue also applies.

VERDICT: DISAGREE AS RECORDED. Keep CURRENT-DUPLICATE; complete item-11
coverage and reapply PREVAILS after W3X's rule decision.

Refs: authority section 0 item 11, sections 10 and 19; LED-015.

## LED-016 - DISAGREE ONLY ON THE UNRATIFIED "STAYS" ACTION; factual adjudication is sound

Section 11 independently confirms Architecture D's detector-free topology, its
single uncertain internal pitch-1 candidate, the A-derived threshold-scaling
experiment idea, and the known FRAME/FRAME pitch-2 approximation. D4-Q05
independently keeps the threshold-scaling idea open without preserving the old
parameter/name.

CURRENT-DUPLICATE and the substantive reasoning are correct.

VERDICT: DISAGREE AS RECORDED solely because PREVAILS already applies the
unratified retained-summary exception.

Refs: authority section 11, D4-Q05; LED-016.

## LED-017 - DISAGREE ONLY ON THE UNRATIFIED "STAYS" ACTION; factual adjudication is sound

I checked the rejection reasons. Section 12 carries the whole-frame
Architecture-A rejection proof; section 12.5 carries A's local false-activation
application; section 13.1 separately states the general no-implicit-geometry-
classifier principle. Section 9.4 carries the motion-classifier rejection for
Architecture C.

W3D's treatment is consistent with the already-recorded PR-1 correction:
section 0 item 13 is an A-rejection summary, not the unique home of the general
principle.

CURRENT-DUPLICATE is correct. The entry should distinguish the canonical
decision home from supporting proof material instead of calling section 12
and Appendix C jointly "the canonical home", and the retained-summary action
awaits W3X.

VERDICT: DISAGREE AS RECORDED; substantive disposition AGREE.

Refs: authority sections 9.4, 12, 13.1, Appendix C; LED-017.

## LED-018 - DISAGREE ONLY ON THE UNRATIFIED "STAYS" ACTION; factual adjudication is sound

Section 15 confirms the four truth classes, the rule against fabricating
FRAME/FIELD labels for no-DCT macroblocks, the B2/D measurement legs,
predeclared held-out discipline and the no-forced-fallback decision rule.

CURRENT-DUPLICATE with section 15 as the canonical source is correct.

VERDICT: DISAGREE AS RECORDED solely because the noncanonical copy is already
declared retained before the rule allowing that has been ratified.

Refs: authority section 15; LED-018.

## LED-019 - DISAGREE; the entry does not adjudicate all of item 17

Appendix D confirms that item 17 is a current duplicate list of still-open
work. The listed subset in LED-019 is correct.

But item 17 continues after "processing-order Schedule-SA vs Schedule-SB
quality winner". It also includes:

- proper-chroma quality gate;
- pipeline guidance;
- side-data interface;
- final public parameter/property surface;
- scalar oracle;
- later SIMD backends.

LED-019's CLAIM does not account for them even though the coverage declaration
says all of item 17 is adjudicated. This is a Q-D omission inside the entry.

The `THIS COPY STAYS` action is also premature for the reason in Q1.

VERDICT: DISAGREE. Expand CLAIM/ASSERTS so the entire open list is visibly
covered; keep CURRENT-DUPLICATE; then apply the ratified duplicate-action rule.

Refs: authority section 0 item 17, Appendix D; LED-019.

## LED-020 - DISAGREE

The claim is current, but it is not unique.

Current Project Status, coder introduction and designer blurb all restate that
this W3X-ratified document is the prevailing MPEG-2 authority / single source
of truth. The current disposition definition explicitly says not to call a
statement unique merely because this is its correct home while it also appears
elsewhere.

The SWEPT result is therefore wrong on its own evidence: W3D searched the
orientation documents but created a distinction between "declare" and "refer"
that the five disposition definitions do not contain.

The entry also combines authority status with the historical statement about
what v1.05 changed. Those propositions naturally have different canonical
homes: live authority status in the header, revision-nature history in
Appendix E.

VERDICT: DISAGREE. Use CURRENT-DUPLICATE for the authority-status proposition
with the header as canonical home; separately map the revision-history
proposition.

Refs: authority header lines 8-11; coder introduction v1.32 section 2.7;
designer blurb v1.2 reading list; Project Status v1.30; Appendix E; LED-020.

## LED-021 - DISAGREE

The single-source boundary is current and belongs canonically in this header.
It is not unique.

Current orientation/status material repeats the operative propositions that:
the MPEG-2 authority owns the MPEG-2 truth, raw GAIS is evidence rather than
authority, and project-global non-MPEG-2 rules remain governed elsewhere.
Project Status v1.30 also supersedes the v1.29 copy named in SWEPT.

The SWEPT search therefore did not establish uniqueness. It looked in too
narrow a set and omitted obvious current orientation documents where the
boundary is restated operationally.

VERDICT: DISAGREE. CURRENT-DUPLICATE; canonical home is this authority header.
The external copies are T3 candidates.

Refs: authority header lines 13-23; coder introduction v1.32; Project Status
v1.30; designer/coder blurbs; LED-021.

## LED-022 - AGREE

I independently searched the live corpus for the tag definitions. Other live
documents USE tags such as [H.262-VERIFIED], but I found the seven-tag
vocabulary actually DEFINED only in the authority header. That is the
distinction the entry claims.

The definition remains current, and keeping the explicit "no such tag is
sourced from GAIS" qualification is important provenance discipline.

VERDICT: AGREE.

Refs: authority header lines 32-42; live corpus tag-definition search;
LED-022.

## LED-023 - UNSURE

I agree with W3D's own warning and disagree only with closing the question too
early.

The statement is apparently unique as text, but CURRENT-UNIQUE also requires
it to be true. The claim is universal over the entire document. W3D expressly
says the document has not yet been swept far enough to confirm it.

Absence of a discovered counterexample is not evidence sufficient to certify a
blanket provenance claim.

VERDICT: UNSURE. Revisit at the final sub-tranche after the body is swept. If
the provenance claim survives, CURRENT-UNIQUE is then appropriate.

Refs: authority header line 44; review scope CURRENT-UNIQUE; LED-023.

## LED-024 - DISAGREE WITH THE PROPOSED MECHANISM; AGREE THAT THE RULE NEEDS RECONCILIATION

The underlying observation is sound: section 0 is intentionally redundant.
It is a read-first summary, and replacing every sentence with pointers would
make the authority markedly less usable.

The proposed `DESIGNED / INCIDENTAL` field is broader than necessary and can
create a new judgement problem: an obsolete duplicate can have been
deliberately designed. The important fact is not whether an author designed
the duplication; it is whether the duplicate has an approved continuing
document role.

There is also less T3 danger than the derivation states. Task Register T3 says
to strip duplicate knowledge out of the OTHER documents and point them to the
authority. It does not instruct T3 to hollow out the authority itself. The
conflict is chiefly between that T3 wording and review-scope v1.8's generic
"non-canonical copy -> pointer" rule.

I therefore recommend the narrow RETAIN-SUMMARY exception in Q1, optionally
with a `DUPLICATE-ACTION` field. Do not add a sixth disposition.

Two minor document defects in this derived section should be corrected when it
reissues:
- section 1 says "See the derived proposition at LED-025", but the actual
  proposition is LED-024;
- "Ten entries in this sub-tranche alone need that field" is not supported by
  the current entry count/dispositions as written.

VERDICT: DISAGREE with the mechanism; AGREE with the need for a narrow,
ratified summary-retention rule.

Refs: Task Register v1.11 T3; review scope v1.8 CURRENT-DUPLICATE; LED-024.

---

# Coverage check result

The sub-tranche-level coverage declaration PASSES the specific check that
failed in T1S01a2 v1.0:

- the seventeen numbered section-0 items are assigned here;
- the TARGET-DEVICE REALITY block is assigned here;
- the remaining named header statements are assigned here;
- previously adjudicated currency/supersession text is identified rather than
  silently re-adjudicated;
- section 23 tail, Appendix E and the body/appendices are assigned to named
  later sub-tranches.

I therefore do NOT repeat the former whole-range method blocker.

The remaining problem is finer-grained: an entry that says it covers a whole
numbered item must not abbreviate away material propositions inside that item.
Q2 and the LED-013/015/019 verdicts identify the instances I found.

---

# Knowledge-base reliance / current-package findings

I relied on the following current material for this review:

- Task Register v1.11 for current T1 sequencing, DEC-31..DEC-35 and T3;
- T1 W3C Review Scope v1.8 for the atomic-claim, SWEPT and canonical-home
  criteria;
- Charter v1.31 for I7 and controlling-document discipline;
- Project Status v1.30 for current package state;
- MPEG-2 authority v1.05 itself, reading the adjudicated header/section 0 and
  the cited body homes directly;
- T1S00 manifest v1.4 for the frozen search frame;
- coder communication convention v1.0 for this response format.

I did not use the superseded Grid Knowledge document as current MPEG-2
authority.

The package also contains a live-state routing mismatch already noted in Q5:
DEC-35/covering note say the section-23 tail is T1S01a4, while older live
status wording and DEC-32 still say a3. I used the later DEC-35 split.

---

# Review state

T1S01a3 is NOT the final sub-tranche, so whole-document cross-entry
consistency remains deferred to T1S01a5.

I do not recommend stopping preparation/review of T1S01a4 while the T1S01a3
corrections are made. The defects above are identifiable and recoverable, and
incremental review is the standing method. T1S01a3 itself should not be marked
closed until its coverage/uniqueness corrections and the W3X summary-retention
decision are incorporated.
