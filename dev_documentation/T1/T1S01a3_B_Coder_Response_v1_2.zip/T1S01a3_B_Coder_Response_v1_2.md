# Deblock4 - W3C Review of T1S01a3 Replacement Batch v4

**Deliverable:** T1S01a3_B - W3C REVIEW
**Version:** 1.2
**Date:** 2026-08-18
**Author:** W3C
**Route:** W3C -> W3X -> W3D
**Reviews:** `T1S01a3_A_Designer_Batch_v4.zip`
**Encoding:** US-ASCII; CRLF.

---

# Plain-English summary

I checked the replacement T1S01a3 designer batch v4 specifically against the
outstanding findings from `T1S01a3_B_Coder_Response_v1_1.md`.

The outstanding points are now resolved sufficiently to proceed to T1S01a4.
The duplicate-action vocabulary has been repaired with STAY-CANONICAL, LED-020
has been split correctly, the LED-013 D4-Q16 mapping has been tightened, and
the canonical/non-canonical duplicate claims I checked are supported by the
current documentation corpus.

I therefore see no unresolved W3C finding in T1S01a3 that should hold
T1S01a4.

No authority document is ratified or amended by this response. W3X retains the
decision and project-PASS role.

---

# DECISIONS/QUESTIONS FOR W3X

## Q1. Proceed to T1S01a4

I recommend YES - proceed.

The replacement v4 batch resolves the outstanding W3C findings sufficiently
for progression.

Refs: T1S01a3 replacement batch v4; prior W3C response
`T1S01a3_B_Coder_Response_v1_1.md`.

---

# Review findings

## 1. Duplicate-action vocabulary - RESOLVED

Review Scope v1.10 now correctly provides the third action:

```text
STAY-CANONICAL
RETAIN-SUMMARY
POINTER
```

This resolves the inconsistency identified in the previous W3C review.

The distinction is now coherent:

```text
STAY-CANONICAL
    this copy is the canonical home

RETAIN-SUMMARY
    this copy is non-canonical but satisfies the narrow approved-summary
    exception inside the canonical authority

POINTER
    this copy is non-canonical and does not satisfy that exception
```

## 2. LED-020 / LED-020a / LED-021 - RESOLVED

LED-020 is now narrowed to the authority-status proposition and correctly uses:

```text
CURRENT-DUPLICATE
STAY-CANONICAL
```

LED-021 likewise correctly uses:

```text
CURRENT-DUPLICATE
STAY-CANONICAL
```

I checked that the named non-canonical copies genuinely exist in the current
documentation corpus, so these are supported duplicate findings rather than
assertions.

LED-020a correctly separates the v1.05 revision-nature proposition. Its
canonical home is Appendix E, and the header copy is correctly treated as:

```text
CURRENT-DUPLICATE
POINTER
```

The header is not the explicitly designated read-first summary layer, so the
narrow RETAIN-SUMMARY exception does not apply to that proposition.

## 3. LED-013 D4-Q16 mapping - RESOLVED

The retirement-in-principle of `mpeg2_field_separated` is now explicitly
mapped to D4-Q16 as requested.

That correction is sufficient. It does not reopen the substantive
CURRENT-DUPLICATE or RETAIN-SUMMARY findings.

## 4. Appendix E sequencing material - RESOLVED

The replacement ledger correctly recognises that the relevant Appendix E
sequencing sentence was already adjudicated in T1S01a2 and should not be
rediscovered as new T1S01a3 work.

## 5. T1S01a2 v1.1 coverage status

My earlier spot-check remains valid: the T1S01a2 v1.1 reissue genuinely
discharged the original whole-range coverage blocker.

I see no reason to reopen T1S01a2 before the final whole-document consistency
pass.

---

# Current W3C position

```text
T1S01a3
    sufficiently resolved for progression

NEXT
    T1S01a4

W3C HOLD ON A4
    none
```

I am ready to review T1S01a4 when W3X supplies it.

---

*Revision history*

```text
v1.2 (2026-08-18) Reviews the replacement T1S01a3 designer batch v4 against
     the outstanding findings from W3C response v1.1. Confirms the
     STAY-CANONICAL vocabulary repair, LED-020 split/relabel, LED-013 D4-Q16
     mapping correction and related duplicate-home checks. Concludes that
     T1S01a3 is sufficiently resolved to proceed to T1S01a4.
v1.1 (2026-08-18) Focused re-review of reissued T1S01a3 against Review Scope
     v1.9 and Task Register v1.12.
v1.0 (2026-08-18) First W3C review of T1S01a3 v1.0.
```
