# Deblock4 - W3C Final Mechanical Review of T1S01a4 and I7 Review of DEC-51

**Deliverable:** T1S01a4_B - W3C FINAL MECHANICAL REVIEW
**Version:** 1.3
**Date:** 2026-08-18
**Author:** W3C
**Route:** W3C -> W3X -> W3D
**Reviews:** `T1S01a4_A_Designer_Batch_v5.zip`
**Ledger:** `T1S01a4_A_Ledger_Section23_Tail_v1_4.md`
**Covering note:** `T1S01a4_A_Covering_Note_for_W3C_v1_4.md`
**Binding review scope:** `Deblock4_T1_W3C_Review_Scope_v1_11.md`
**Binding work queue:** `Deblock4_Standing_Task_Register_T_Series_v1_19.md`
**Encoding:** US-ASCII; CRLF.

---

# Plain-English summary

The four framing corrections requested by W3C are now clean. The ledger closing
questions describe the corrected population and the narrowed DEC-02/DEC-03
unaffectedness check; the covering note uses the two-role /
two-acceptance-state wording; and DEC-45's live status paragraph now says
explicitly that object identity is not established.

I independently searched the whole current a4 batch for the rejected
two-artifact wording family and obvious semantic variants. I found no LIVE
OPERATIVE stale premise. The literal-wording family produces 15 line hits
across the batch - 8 ledger, 4 covering note, 3 register, 0 scope - and all are
historical/meta descriptions of what an earlier version said or of the search
itself. The operative text consistently states two ROLES and two ACCEPTANCE
STATES and expressly denies a requirement for different object identity.

DEC-51's countermeasure is substantively good, but I recommend a small I7
refinement. "Search the whole document set and enumerate every occurrence" is
too absolute as a universal rule and can become the same sort of ritual as the
first version of DEC-48. The rule should require a DECLARED REPLACEMENT SCOPE,
the search/method appropriate to the rejected proposition, enumeration and
classification of candidate matches, and a semantic check of live framing
where a literal search can miss paraphrases.

With that refinement, I independently verify DEC-51. T1S01a4 itself is clear
from W3C's side and may close; the refined DEC-51 wording should be recorded
before T1S01a5 relies on it.

No source was modified. No build, execution, test, patch, delivery machinery or
git operation was performed.

---

# DECISIONS/QUESTIONS FOR W3X

## Q1. Close T1S01a4

**Recommendation: YES.**

I find no remaining technical, ledger-entry or live-framing defect that should
hold T1S01a4.

The technical conclusions already established remain:

```text
LED-026
    AGREE
    two-senses-of-freeze reading holds
    earlier threshold warning dissolved
    rerun affected comparison and any other dependent quality evidence if a
    step-7 fixed value changes later

LED-029
    AGREE
    ordering conflict is real
    candidate role must precede the SA/SB comparison
    accepted ReleaseSafe-oracle role follows schedule/canonical freeze
    two ROLES / two ACCEPTANCE STATES
    no different-object-identity requirement established

DEC-46
    acceptance gap is real
    remains open
    blocks a future 8a candidate-building scope, not T1
```

The final four framing corrections also pass.

I recommend closing T1S01a4 and proceeding to T1S01a5 after Q2's refined DEC-51
wording is recorded in the binding register.

## Q2. Ratify DEC-51 with the following I7 refinement

**Recommendation: YES.**

I agree with the failure mode:

```text
A rejected proposition can be corrected in its target field while surviving
unchanged in live framing elsewhere. Reporting the replacement "complete"
from memory of the edited field is not evidence.
```

I also agree that enumeration is valuable. The first draft of W3D's own
enumeration being wrong, and the subsequent search finding additional
occurrences, is evidence that the countermeasure is useful.

But the current DEC-51 wording is too rigid as a universal rule:

```text
SEARCH THE WHOLE DOCUMENT SET
and
ENUMERATE every occurrence found
```

That can become ritual in two ways:

1. the natural replacement scope may be smaller or different from an entire
   project document set; and
2. a literal-wording search can miss a semantic paraphrase while producing a
   beautifully complete list of the strings it happened to search.

I recommend this refined wording:

```text
PARTIAL-REPLACEMENT CHECK

After replacing a materially rejected formulation, do not report the
replacement complete from the edited location alone.

1. DECLARE THE REPLACEMENT SCOPE:
   identify the current document, package, authority set, or other bounded
   population in which the rejected proposition could still remain live.

2. SEARCH USING THE METHOD APPROPRIATE TO THE PROPOSITION:
   use the rejected wording and obvious lexical variants where useful, and
   inspect relevant live framing semantically where a paraphrase could preserve
   the rejected proposition without preserving its exact words.

3. ENUMERATE AND CLASSIFY THE CANDIDATE MATCHES:
   record each relevant match/location as LIVE, HISTORICAL/META, or
   FALSE/IRRELEVANT MATCH so an omission or misclassification can be attacked.

4. DO NOT CLAIM EXHAUSTIVENESS BEYOND THE DECLARED SCOPE OR METHOD:
   a literal search proves only what that search can prove. If the completion
   claim is project-wide, the declared scope and search must be correspondingly
   project-wide.

5. A BARE ASSURANCE SUCH AS "the replacement was swept" or "all occurrences
   were fixed" is not evidence.
```

This preserves DEC-51's essential property - a completion claim becomes
falsifiable - while avoiding a new form becoming the evidence.

### I7 provenance

```text
DEC-51 partial-replacement criterion:
    proposer:  W3D, derived from W3C's repeated partial-replacement findings
    verifier:  W3C - ACCEPT IN PRINCIPLE WITH THE REFINEMENT ABOVE
    ratifier:  W3X, if W3X adopts the refined wording
```

I recommend recording that provenance distinctly.

---

# 1. Four requested framing corrections - PASS

## 1.1 Ledger closing question 1 - PASS

The current question now correctly says section 0 names:

```text
every entry in every prior T1 ledger
    T1S01a1
    T1S01a2
    T1S01a3
```

grouped by ledger, with locations/overlap results and boundary exceptions.

It no longer repeats the false "every T1S01a2 entry" formulation.

PASS.

## 1.2 Ledger closing question 2 - PASS

The current question now says LED-025 checks:

```text
DEC-02 and DEC-03
```

because those are the T1/T5/T6 reversal decisions named by REASON.

It also explicitly says no broader "no current register decision changes
D4-Q16" claim is being made.

It no longer asks W3C to verify "every sequencing decision in the register".

PASS.

## 1.3 Covering note provisional-adoption wording - PASS

The live paragraph now says:

```text
TWO-ROLE / TWO-ACCEPTANCE-STATE REPAIR
```

and explicitly says W3C is to attack rather than confirm the provisional
position.

The remaining "two-artifact" occurrence in that paragraph is inside a clearly
historical parenthetical:

```text
CORRECTED at v1.4: this paragraph still called it the TWO-ARTIFACT repair.
```

That is legitimate historical/meta text.

PASS.

## 1.4 DEC-45 live STATUS paragraph - PASS

DEC-45 now states:

```text
the comparison-candidate role and accepted-oracle role have different
acceptance states and must occur at different points in the sequence.

THIS DOES NOT ESTABLISH DIFFERENT OBJECT IDENTITY.
```

That is the requested correction.

The remaining "different artifacts" phrase is in a parenthetical explicitly
describing the rejected earlier wording and pointing to DEC-51.

PASS.

---

# 2. Independent whole-batch rejected-wording search

Because DEC-51 is itself under I7 review, I did not accept the ledger's count.
I independently searched all four current batch documents.

Declared batch population checked:

```text
Deblock4_Standing_Task_Register_T_Series_v1_19.md
Deblock4_T1_W3C_Review_Scope_v1_11.md
T1S01a4_A_Covering_Note_for_W3C_v1_4.md
T1S01a4_A_Ledger_Section23_Tail_v1_4.md
```

Literal family checked included:

```text
two artifact
two-artifact
one artifact
different artifacts
```

Line-hit result:

```text
ledger        8
covering note 4
register      3
review scope  0
TOTAL        15 line hits
```

I also checked obvious semantic variants around:

```text
two implementations
separately implemented codebases
persistent implementation artifacts
object identity
same implementation
two roles
two acceptance states
```

## Result

**No live operative stale two-artifact premise found.**

The current operative statements consistently say:

```text
two ROLES
two ACCEPTANCE STATES
not object identity
same implementation may be reused/refactored/hardened
no requirement for two persistent implementation artifacts
```

The rejected wording remains only where the documents explicitly record:

- what an earlier version said;
- what W3C rejected/corrected; or
- what terms were searched.

That is correct historical/meta retention.

---

# 3. The ledger's own enumeration - correct for the ledger, but not a whole-batch enumeration

The ledger says:

```text
Every occurrence ... in this ledger, classified.
```

I checked that claim. Its count reconciles:

```text
seven semantic occurrences
eight line hits because the enumeration's opening occurrence wraps across two
lines
```

That ledger-local enumeration is accurate.

However, current DEC-51 says to search the **whole document set**, while the
enumeration presented in the ledger explicitly covers **this ledger**.

The current batch also contains historical/meta matches in the covering note
and task register.

Therefore:

```text
ledger-local enumeration: PASS
whole-batch enumeration under DEC-51 as presently worded: not supplied by W3D
```

My independent review above supplies the missing whole-batch check and finds no
live defect, so this does **not** reopen T1S01a4.

It does show why DEC-51 needs the Q2 refinement: the rule should force the
author to declare the replacement scope rather than leave "document set"
implicit.

---

# 4. DEC-51 I7 assessment - ACCEPT WITH REFINEMENT

## What is good

The countermeasure targets a real repeated failure mode.

The key insight is correct:

```text
editing the target field is not evidence that the rejected proposition has
left the live deliverable
```

Enumeration is useful because it lets another reviewer attack:

- population completeness;
- search-term completeness;
- location counts;
- live/historical classification.

The history in this tranche is strong evidence for the method. W3D's
memory-written first enumeration omitted matches; the actual search exposed the
omission before issue.

That is exactly what a useful countermeasure should do.

## What would become ritual if left unrefined

A mandatory "whole document set + literal enumeration" form can become
mechanical compliance:

```text
- search strings chosen too narrowly;
- exhaustive count of those strings;
- semantically equivalent stale proposition survives under different words;
- author reports PASS because the count reconciles.
```

That would reproduce the original failure in a more elaborate format.

The right object of proof is not the string. It is the **rejected proposition
within a declared replacement scope**.

Therefore I independently verify the principle and recommend the refined rule
in Q2.

---

# 5. DEC-50 interaction - no conflict

The refined DEC-51 is consistent with DEC-50 rather than duplicative.

DEC-50 is the general evidence rule:

```text
identify the actual object/population examined and the result/basis in an
independently testable form
```

DEC-51 is the special application for material replacement completion:

```text
declare replacement scope;
search for lexical and semantic remnants;
enumerate/classify candidate matches;
do not claim beyond the scope/method.
```

That is a useful specialization, not a competing process rule.

---

# Consolidated verdict

```text
ledger closing question 1                    PASS
ledger closing question 2                    PASS
covering-note two-role wording               PASS
DEC-45 live STATUS wording                   PASS

ledger-local rejected-wording enumeration    PASS
whole current a4 batch, independent W3C
  rejected-wording/semantic check             PASS
live stale two-artifact premise               NONE FOUND

DEC-51 principle                              AGREE
DEC-51 current universal wording              REFINE
DEC-51 I7 verification                        SUPPLIED BY THIS RESPONSE

T1S01a4 technical result                      CLOSED FROM W3C SIDE
T1S01a4 framing result                        CLOSED FROM W3C SIDE
```

---

# Current W3C position

**T1S01a4 may close.**

I do not request another a4 ledger or covering-note reissue.

Before T1S01a5 relies on DEC-51 as a binding criterion, I recommend W3X ratify
the Q2 wording and W3D record it in the next Task Register generation, with the
I7 provenance shown above.

Subject to that process-record update:

```text
NEXT: T1S01a5
```

T1S01a5 is the final sub-tranche for this authority and can now inherit a clean
T1S01a4 technical result.

---

*Revision history*

```text
v1.3 (2026-08-18) Final mechanical review of designer batch v5 / ledger v1.4.
     Confirms all four framing corrections and independently searches the
     whole current a4 batch for rejected two-artifact wording and semantic
     variants; finds no live operative stale premise. Verifies the ledger's
     local enumeration but notes it is ledger-local while DEC-51 currently
     says whole document set. Independently reviews DEC-51 under charter I7:
     accepts the partial-replacement countermeasure in principle and refines
     it to require a declared replacement scope, appropriate lexical and
     semantic search, enumeration/classification of candidate matches, and no
     completeness claim beyond the declared scope/method. Concludes
     T1S01a4 may close and T1S01a5 may proceed after the refined DEC-51
     process wording is recorded. No source change; no build/test/git.
v1.2 (2026-08-18) Mechanical delta review of designer batch v4 / ledger v1.3.
v1.1 (2026-08-18) Delta review of designer batch v3 / ledger v1.2.
v1.0 (2026-08-18) First W3C review of T1S01a4.
```
