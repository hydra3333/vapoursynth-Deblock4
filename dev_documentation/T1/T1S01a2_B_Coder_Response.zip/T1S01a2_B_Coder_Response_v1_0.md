# Deblock4 - W3C Review of T1S01a2 Orientation/Currency Ledger

**Deliverable:** T1S01a2_B - W3C REVIEW
**Version:** 1.0
**Date:** 2026-08-18
**Author:** W3C
**Route:** W3C -> W3X -> W3D
**Reviews:** `T1S01a2_A_Ledger_Orientation_Layer_v1_0.md`
**Current review scope used:** `Deblock4_T1_W3C_Review_Scope_v1_7.md`
**Current task register used:** `Deblock4_Standing_Task_Register_T_Series_v1_9.md`
**Current charter used:** `AI_Charter_and_Invariants_Card_v1_31.md`
**Encoding:** US-ASCII; CRLF.

---

# Plain-English summary

I reviewed the original authority-document ranges named by W3D in full, not only
the ledger quotations, and checked the live Task Register and the current
charter. The currency problem behind the stale T1/Q14 statements is real, but
this tranche does not yet constitute a complete adjudication of the ranges it
says it covers: substantial registered statements in the header, section 0,
section 23 and Appendix E have no ledger entry. I also found a substantive
ordering error in the point W3D expressly asked me to challenge: steps 8 and 9
of section 23 are not safely "unaffected", because the schedule winner is
specified to become part of the future scalar oracle and the oracle-construction
scope itself requires the schedule as an independent obligation. Of the six
entries, I agree with LED-003 and LED-007; LED-004, LED-005, LED-006 and LED-008
need correction for the reasons below.

No source was changed. I performed no build, execution, test, patch, delivery
machinery or git operation.

---

# DECISIONS/QUESTIONS FOR W3X

## Q1. The tranche says four whole ranges are adjudicated, but they are not yet covered

The ledger header says this sub-tranche adjudicates the authority-document
header, all of section 0, all of section 23 and Appendix E. I read those ranges
in full and also mechanically checked them with the frozen 90-term T1 search
frame. That check finds 151 hit lines across the four declared ranges: 12 in
the header, 97 in section 0, 17 in section 23 and 25 in Appendix E. A hit line
is not the same thing as one ledger entry, so those numbers are a coverage
alarm rather than an expected entry count. The substantive omissions remove
any doubt: section 0's numbered architecture statements 1-17 are not ledgered;
section 23's old 2D/3D/4D/5D shorthand and prerequisite statement are not
ledgered; Appendix E's v1.04-v1.00 MPEG-2-bearing revision records are not
ledgered; and header single-source/provenance statements are not ledgered.

Why it matters: T1 is complete only when every MPEG-2-bearing statement has a
recorded disposition. If a sub-tranche can declare a whole section adjudicated
while logging only selected currency statements, the final ledger cannot prove
coverage.

I recommend treating this as a METHOD BLOCKER, without discarding the useful
six-entry review below. W3D should either add supplemental entries for the
omitted statements now, or reissue the sub-tranche header to identify the exact
subranges/statements actually adjudicated and explicitly assign every omitted
statement to a named later sub-tranche. The four ranges must not be treated as
complete until that accounting exists.

(refs: T1 scope sections 4.2.1, 5, 8 Q-D; T1 manifest v1.4 section 1; T1S01a2
header)

## Q2. One disposition must not cover two clauses that have different statuses

LED-005 marks the whole quoted sentence SUPERSEDED while its own reasoning says
the freeze-before-held-out clause remains binding. LED-006 marks the whole
contrast CONFLICTING while its own reasoning says the no-filtering-implementation
prohibition remains current. The proposed edits are clause-selective, which is
the correct instinct, but the ledger record is not: one disposition is still
being made to stand over text with two different outcomes.

Why it matters: this recreates the first-ledger hybrid-status problem in a
different place. The corrected template says the disposition describes what is
on the page; the surviving clause cannot be smuggled into REASON as a second
unrecorded disposition.

I recommend an atomic-claim rule: narrow CLAIM/ASSERTS to one proposition or
split the source sentence into separate ledger entries whenever its clauses
require different dispositions. LED-005 and LED-006 should be split or narrowed
before they become the model for later batches. If the review-scope wording is
changed to make this explicit, W3D is proposing a process criterion applied to
W3D's own ledger and W3C should be the independent verifier before W3X adopts it.

(refs: charter I7; T1 scope sections 5.1 and 8 Q-F; LED-005, LED-006)

## Q3. The duplicate taxonomy has no clean case for a statement that is already in its canonical home

LED-008 calls the authority header paragraph CURRENT-UNIQUE. It is not unique.
The live Task Register repeats that the Grid Knowledge document is superseded
and separately instructs T3 to strip duplicate MPEG-2 knowledge into pointers;
Project Status also repeats the Grid Knowledge supersession. The authority is
nevertheless the correct canonical home for the MPEG-2 supersession statement.

The present scope definition of CURRENT-DUPLICATE says to replace "this copy"
with a pointer to the real home. That instruction is wrong when the statement
being adjudicated is itself the real home. CURRENT-UNIQUE is factually wrong,
and CURRENT-DUPLICATE as presently worded gives the wrong action.

I recommend clarifying CURRENT-DUPLICATE to mean: identify the canonical home;
retain the canonical statement there; replace or remove the non-canonical
duplicates according to T3. This changes a process criterion used on W3D's
ledger, so W3D should propose the exact wording, W3C should independently
verify it, and W3X should decide it before duplicate-heavy later tranches rely
on the category.

(refs: charter I7; T1 scope section 5 five dispositions; Task Register T2/T3;
LED-008)

## Q4. Do not ratify a new "T1-T3 first" order from LED-004

The current ratified work-queue decision says T1 runs before T5. T2 and T3 are
both blocked by T1, but the supplied register does not separately establish
their order relative to T5/T6/Q14 after T1 completes. W3D's proposed remedy
"place T1-T3 first" therefore adds an order that is not present in the decision
it cites.

Why it matters: an authority cleanup must not create a new development-order
decision while claiming only to reconcile stale wording.

I recommend replacing the mutable head of section 23 with a pointer to the
Standing Task Register rather than spelling a new T1-T3-before-T5 order. If W3X
actually wants T2 and T3 to precede T5 as well, record that as its own explicit
decision first.

(refs: Task Register DEC-02, T2, T3, T5; LED-004)

## Q5. The new charter generation needs the normal scope-compatibility record

The refreshed tree advances the charter from v1.29 to v1.31 while the T1 review
scope remains v1.7. I compared v1.31 against v1.29: the operative change is the
neutral/current README wording in the bootstrap template plus revision history;
v1.31 expressly says there is no rule or invariant change. I find no material
effect on this T1 review scope.

The charter nevertheless requires the usual W3X compatibility decision to be
recorded when a later controlling-document change is unrelated to an existing
scope. I did not find a `scope v1.7 / charter v1.31: compatible` line in Project
Status v1.29.

I recommend recording that one-line compatibility decision; I see no technical
reason to reissue the T1 review scope.

(refs: charter 2.3b; charter v1.31 revision note; T1 review scope v1.7)

---

# Entry-by-entry verdicts

## The paragraph saying T1 is paused - AGREE, with a remedy qualification

The source quotation is accurate. The original paragraph says T1 is paused
while Q14 work is set up, while the later W3X decision recorded in the Task
Register puts T1 before T5. The Task Register is the right place for the live
work queue; the MPEG-2 authority remains the authority for MPEG-2 architecture.
I therefore accept CONFLICTING as a workable disposition while the stale text
still exists in the live authority, and I agree that the work-queue claim
should no longer be restated there.

The proposed pointer remedy is preferable to replacing one hard-coded sequence
with another. One current part of the original paragraph must not be lost,
however: changing work-queue order did not itself reopen or weaken the ratified
MPEG-2 architecture. If the paragraph is replaced wholesale, preserve that
stable authority-boundary point somewhere appropriate rather than deleting it
by accident.

VERDICT: AGREE, subject to preserving the still-current authority-stability
statement.

(refs: LED-003; Task Register DEC-02)

## The numbered development sequence - DISAGREE

I agree with the first half of W3D's finding: the head of the list is stale.
T1 no longer belongs after Q14, and the coordinated T5+T6 packaging permission
is separately obsolete.

I do not agree with two further claims in the entry.

First, "place T1-T3 first" is not established by the cited decision. The
register establishes T1 before T5; it does not establish a complete relative
order for T2/T3 versus T5/T6/Q14 after T1.

Second, steps 6-10 are NOT all safely unaffected. The authority itself says in
section 14.4 that Schedule-SA versus Schedule-SB must be compared in scalar
form and that **the winner becomes part of the future Deblock4 scalar oracle**.
The verification/tiering record says the first Stage-2D oracle-construction
scope is accepted against independently authored obligations including the
**schedule**. Section 23 presently says step 8 builds the ReleaseSafe scalar
oracle and only step 9 performs the Schedule-SA/Schedule-SB quality decision
and freezes the canonical scalar algorithm. An accepted canonical oracle
cannot precede the decision that defines one of its required structural
properties.

There is a second warning in the same tail: step 7 says to "freeze" thresholds
before the later quality-decision step, while the authority's open-quality
records still list final threshold/strength behaviour among unresolved quality
items. That does not prove the exact repaired sequence, but it is enough to
reject W3D's statement that 6-10 can simply be retained unchanged.

The correct repair must be re-derived. Scalar candidate implementations may be
needed to compare schedules, so I am NOT proposing a casual swap of steps 8 and
9. What is established is narrower: the canonical schedule/quality decisions
that define the accepted algorithm must be settled before the final accepted
scalar oracle can serve as the reference for later backends.

VERDICT: DISAGREE.

(refs: LED-004; MPEG-2 authority v1.05 sections 14.4, 21, 23 and Appendix D;
Verification and Tiering Decisions v1.11 section 20.2; Task Register DEC-02)

## The coordinated T5+T6 packaging sentence - DISAGREE as framed

The substantive packaging finding is correct. The permission to use one
coordinated T5+T6 package was withdrawn by W3X's later decision: T5 is issued
and ratified alone, then T6 separately.

But the quoted sentence contains a second proposition: the detector mathematics
must be fixed before held-out experiment judgement. W3D itself correctly says
that this anti-tuning discipline survives. The whole sentence therefore cannot
honestly receive one SUPERSEDED disposition.

Split it:

- the coordinated-package permission -> SUPERSEDED;
- the freeze-before-held-out requirement -> current, with its duplicate/canonical
  home identified under the corrected duplicate rule.

The proposed authority edit - remove the packaging permission and retain the
freeze discipline - is substantively sound once the ledger record is split to
match it.

VERDICT: DISAGREE as framed; the packaging subclaim itself is correct.

(refs: LED-005; Task Register DEC-03)

## The "next substantive artifact" sentence - DISAGREE as framed

W3D correctly identifies the positive next-work claim as stale: Q14 is no
longer the immediately next artifact because T1 runs first, followed by T5 and
T6 before the experiment. The proposed pointer to the Task Register is the
right direction.

The same quoted sentence also says the next thing is **not a filtering
implementation**, and the surrounding section says no pixel-kernel scope is
open. That prohibition remains current. As with LED-005, the ledger should not
give one disposition to a compound statement and then preserve the other
status only in REASON.

Narrow the conflicting entry to the positive "next substantive artifact"
claim, and separately record the current no-kernel/no-filtering prohibition.
The proposed edited prose can then retain the prohibition and point elsewhere
for the mutable work queue.

VERDICT: DISAGREE as framed; the stale next-work subclaim itself is correctly
identified.

(refs: LED-006; Task Register DEC-02; MPEG-2 authority v1.05 section 0)

## The v1.05 revision-history entry - AGREE

W3D is right to attack this in the opposite direction. The revision-history
entry says what v1.05 did on 2026-08-16. It was true that v1.05 reconciled
section 23 to the then-current sequence in which T1 was paused. A later reversal
does not make that historical statement false.

I do not recommend rewriting it or adding a supersession disposition inside
the historical entry. Correct the live section 23 and leave the dated revision
record intact. A successor who reaches Appendix E is explicitly reading
revision history; changing an accurate record to look current would be worse
than leaving it historical.

The `CLASS DERIVED` label is slightly awkward for a documentary record of an
editorial act, but the CLASS field has no fixed five-value vocabulary and this
does not alter the disposition.

VERDICT: AGREE.

(refs: LED-007)

## The header supersession/de-duplication paragraph and structural inference - DISAGREE

The quoted header text is accurate in substance. The MPEG-2 authority does
supersede the old Grid Knowledge document, and the project still owes the T3
work that reduces duplicated MPEG-2 content elsewhere to references.

The disposition CURRENT-UNIQUE is nevertheless wrong. The supersession is
also written in live Project Status and in the Task Register's T2 description.
The de-duplication-to-pointers instruction is also written in the Task
Register's T3 description. This is a duplicate proposition, with this authority
document being the sensible canonical home for the MPEG-2 supersession part.
That exposes the CURRENT-DUPLICATE canonical-home gap raised in Q3.

I also disagree with the derived proposition as presently worded. Section 23
is work-queue material. Section 0 is not: after its short date-stamped status
opening, it is overwhelmingly the read-first architecture summary - whole-frame
input, source modes, chroma/luma geometry, B2, D, rejected A/C, Q14 and open
kernel work. The evidence supports a narrower inference:

- the date-stamped status/next-work lines in section 0 duplicate mutable project
  state and age badly;
- section 23 duplicates the work queue and ages badly;
- section 0's architecture summary belongs in the architecture authority.

W3D's own limit on action is sound. I agree that a structural rewrite should
wait until the authority document's T1 sweep is complete. What should not wait
is correcting the inference: do not carry forward the statement that "sections
0 and 23 are WORK-QUEUE content".

One minor formal point: the derived note says "four conflicts" even though the
ledger itself formally classifies three entries CONFLICTING and one SUPERSEDED.
Because the five disposition words have deliberately strict meanings, use
"four stale status/sequence findings" if a collective description is needed.

VERDICT: DISAGREE.

(refs: LED-008; Task Register T2/T3; Project Status v1.29 section 0)

---

# Missing ledger material found by reading the declared source ranges

These are omission findings under Q-D, not substitute adjudications by W3C. I
am not assigning final dispositions to statements W3D has not yet ledgered.

## Header material is missing

The header contains current statements about the authority's ratified status,
its single-source boundary and its provenance discipline in addition to the
supersession paragraph. Those are within the range this tranche says is
adjudicated and several match the frozen term set. They need ledger coverage or
an explicit later-sub-tranche assignment.

## Most of section 0 is missing

Only the stale "next substantive artifact" sentence is ledgered. The same
section contains seventeen numbered architecture/current-position items:
whole-frame input, three source modes, chroma organisation, per-macroblock luma
DCT geometry, vertical-edge invariance, no hidden temporal state, Deblock4's
own proof chain, B2 topology, Architecture D, rejected A/C, the Q14 gate and
the still-open kernel/quality/API items. These are exactly the kind of
MPEG-2-bearing statements T1 exists to disposition, even where they duplicate
the body of the same authority document.

## The stable tail of section 23 is missing as ledger material

LED-004 reasons about steps 6-10 instead of ledgering them. The old
2D/3D/4D/5D shorthand at lines 1703-1710 and the statement that Q14 plus
architecture/API reconciliation are prerequisites before 2D pixel mathematics
are also unledgered. W3D's incorrect "steps 6-10 remain current" claim shows
why these cannot be silently treated as checked.

## Most of Appendix E is missing

LED-007 covers only the v1.05 revision record. The v1.04 through v1.00 entries
contain substantial MPEG-2-bearing historical statements - architecture
re-decision, LG regime evidence, H.262 provenance, 4:2:2/4:4:4 chroma,
Schedule-SA/SB naming, Q14 held-out discipline and the original investigation.
Historical does not mean outside T1; LED-007 itself correctly demonstrates that
a historical statement still needs an accurate disposition.

(refs: T1 scope Q-D and M5; T1 manifest v1.4 frozen 90-term frame; authority
v1.05 header, section 0, section 23, Appendix E)

---

# Other current-package findings

1. The Standing Task Register v1.9 status-at-a-glance still says T1S01a2 is
   held pending the ledger-template fix. Its own later decision record says the
   template defect is discharged, and W3X has now actually issued T1S01a2.
   This is stale status text. I raised the same point before this review; under
   the T1 rule that silence is not agreement, I am recording it again rather
   than assuming it was accepted or deliberately deferred.

2. W3D's statement that every authority-version-bump remedy here is "charter
   I7 shape" is cautious but broader than I7 itself. I7 is triggered by a
   change to acceptance/review/verification/proof/harness/delivery/process
   criteria that will judge the proposer's own work. A currency edit that merely
   mirrors an already-ratified W3X sequencing decision is not automatically a
   new self-affecting criterion. The T1 three-way process independently reviews
   the remedy anyway. By contrast, changing the ledger's disposition semantics
   or review criteria in Q2/Q3 really is a process-criteria change applied to
   W3D's own ledger, so I7 plainly applies there.

3. The refreshed documentation tree contains charter v1.31, not v1.29. I used
   v1.31 for this review. Its v1.30/v1.31 changes do not alter the technical
   conclusions above.

---

# Review state

This response does NOT accept or ratify any W3D adjudication. It is the W3C
independent review required by the T1 scope. Cross-entry consistency against
future T1S01 sub-tranches is not due yet because W3D expressly says this is not
the final sub-tranche of the authority document.

The six entries reviewed here need not be thrown away. The method/completeness
findings above should be corrected before the authority document is treated as
fully swept, and preferably before the same entry shape is repeated into the
next sub-tranche.
