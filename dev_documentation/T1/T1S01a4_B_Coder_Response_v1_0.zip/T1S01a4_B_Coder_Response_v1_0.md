# Deblock4 - W3C Review of T1S01a4 Section-23 Tail Ledger

**Deliverable:** T1S01a4_B - W3C REVIEW
**Version:** 1.0
**Date:** 2026-08-18
**Author:** W3C
**Route:** W3C -> W3X -> W3D
**Reviews:** `T1S01a4_A_Designer_Batch_v2.zip`
**Ledger:** `T1S01a4_A_Ledger_Section23_Tail_v1_1.md`
**Covering note:** `T1S01a4_A_Covering_Note_for_W3C_v1_1.md`
**Binding review scope:** `Deblock4_T1_W3C_Review_Scope_v1_11.md`
**Binding work queue:** `Deblock4_Standing_Task_Register_T_Series_v1_16.md`
**Authority checked:** `Deblock4_MPEG2_Deblocking_Investigation_and_Decided_Architecture_v1_05.md`
**Verification record checked:** `Deblock4_Verification_And_Tiering_Decisions_v1_11.md`
**Controlling charter checked:** `AI_Charter_and_Invariants_Card_v1_31.md`
**Roadmap checked:** `Deblock4_Forward_Roadmap_v1_21.md`
**Source tree checked read-only:** W3X-supplied `src(20260818-051446).zip`
**Encoding:** US-ASCII; CRLF.

---

# Plain-English summary

The central ordering defect is real, and the proposed repair is substantially
sound: scalar Schedule-SA and Schedule-SB comparison candidates must exist
before their quality comparison, while the accepted ReleaseSafe scalar oracle
cannot be accepted until the winning schedule is known. I agree with the
two-stage role distinction, but it should not be read as requiring two
permanent independently implemented scalar codebases.

The explicit LED-026 question is answered YES: the two-senses-of-freeze reading
holds and my earlier threshold warning is dissolved, with one important
constraint - if step 9 changes any formula, threshold, footprint or other input
held fixed for the comparison, the comparison evidence is stale and the
candidate/comparison cycle must be repeated.

There is, however, a METHOD defect in this sub-tranche: LED-031 and LED-032
re-adjudicate section-23 material already adjudicated by T1S01a2 LED-010,
despite the a4 coverage declaration saying the ledger set was swept for exactly
that overlap. LED-032 is also substantively misclassified as OPERATIVE-SPEC:
the binding scope reserves that disposition for a specification the code
actually implements, while the current Deblock4 source remains a pass-through
shell.

I therefore recommend retaining the useful LED-026/LED-029 technical work but
reissuing a4 to remove/reconcile the repeated adjudication before T1S01a4 is
closed.

No source was modified. No build, execution, test, patch, delivery machinery or
git operation was performed.

---

# DECISIONS/QUESTIONS FOR W3X

## Q1. Reissue T1S01a4 before closing it because LED-031/LED-032 repeat T1S01a2 LED-010

I recommend YES.

`T1S01a2_A_Ledger_Currency_Statements_v1_1.md`, LED-010, already adjudicates:

```text
the 2D/3D/4D/5D shorthand
AND
"Q14 and the architecture/API reconciliation are now prerequisites before
2D's pixel mathematics can be responsibly scoped."
```

The present a4 ledger then creates:

```text
LED-031  the old-roadmap 2D/3D/4D/5D shorthand
LED-032  the prerequisites sentence
```

as fresh entries.

That is not merely similar material. It is the same section-23 text and the
same propositions.

This matters especially because a4 section 0 states:

```text
THE LEDGER SET WAS SWEPT BEFORE THIS ONE WAS WRITTEN.
T1S01a2 and T1S01a3 were read for overlap with this range.
The overlap found is listed above and is excluded rather than re-derived.
```

That assertion is false as written.

The clean repair is either:

1. remove LED-031 and LED-032 from a4 and leave the old-format LED-010 for the
   already-planned T1S01a5 final consistency/atomicity pass; or

2. explicitly REOPEN LED-010, state why it is being reopened, supersede its old
   treatment and replace it with the corrected atomic entries.

I recommend option 1 unless W3X specifically wants the old LED-010 atomicity
repair brought forward.

This is a METHOD finding because the package explicitly claims the pre-ledger
overlap sweep prevented the exact thing that occurred.

Refs: a4 coverage declaration; T1S01a2 v1.1 LED-010; a4 LED-031; a4 LED-032.

## Q2. Ratify the CORE of LED-029's two-role repair, with a wording refinement

I recommend YES, after the reissue records the refinement.

The required sequence is, in substance:

```text
7   fix the common scalar candidate mathematics/thresholds/footprints/etc.

8a  build scalar Schedule-SA and Schedule-SB comparison candidates sufficient
    to run the section-14.4 controlled comparison

9   run the comparison and other quality decisions; select the schedule and
    freeze the canonical scalar algorithm

8b  construct/accept the ReleaseSafe scalar oracle under the oracle-
    construction acceptance rule, now that SCHEDULE is a frozen obligation

10  only then build later ReleaseFast/vector backends and diff them against
    the accepted oracle
```

This follows independently from three current statements:

- authority section 14.4 requires SA and SB to be compared in SCALAR FORM;
- authority line 1153 says the winner becomes part of the future scalar oracle;
- the controlling oracle-construction rule requires SCHEDULE among the authored
  obligations used to accept the oracle-construction scope.

The refinement is important:

```text
TWO ROLES / TWO ACCEPTANCE STATES are required.
TWO PERMANENT, SEPARATELY IMPLEMENTED SCALAR CODEBASES are NOT established.
```

The winning comparison candidate does not become the oracle merely by winning.
A later 8b scope must still construct/validate/accept the ReleaseSafe oracle
under the oracle-construction rule.

Whether 8b may reuse, refactor or harden code from the winning candidate is a
later implementation/scoping question. Nothing I read requires throwing away
the winning candidate and rewriting the scalar implementation from scratch,
provided the 8b acceptance basis remains independently authored and is actually
satisfied.

Refs: authority 14.4 and line 1153; charter oracle-construction exception;
Verification and Tiering Decisions 20.2; LED-029.

## Q3. LED-026 explicit verdict: the two-senses-of-freeze reading HOLDS and my earlier warning is dissolved

This is the explicit verdict required by DEC-47:

```text
THE TWO-SENSES READING HOLDS.
MY EARLIER THRESHOLD WARNING IS DISSOLVED.
```

The precise reading I support is:

```text
step 7:
    freeze/fix the common candidate inputs needed for a controlled comparison -
    formula, thresholds, footprint, clipping/boundary policy and other common
    scalar obligations

step 9:
    after quality evidence, freeze the complete CANONICAL scalar algorithm,
    including the selected schedule
```

Section 14.4 positively requires identical formulas, thresholds, geometry,
clipping and boundary policy between SA and SB. Those values therefore must be
fixed before the comparison. Appendix D saying those items are open TODAY is
not a contradiction; step 7 is the future step that resolves/fixes them.

One constraint must be stated so this reading is not abused:

```text
If step 9's quality work changes any step-7 value that section 14.4 required
to be held identical/fixed during the comparison, the old comparison no longer
proves the revised candidate. Return to the candidate stage and rerun the
affected comparison/quality evidence.
```

So I agree with W3D's resolution, but not with an interpretation under which
step 9 can silently revise thresholds/formulas after the comparison while
retaining the old comparison as evidence.

Refs: authority 14.4; section 23 steps 7 and 9; Appendix D; LED-026; DEC-47.

## Q4. Keep DEC-46's candidate-acceptance gap OPEN; it is real

I recommend YES.

The gap is real.

Section 20.1 is written around modification of an established pixel-producing
or frame-construction path and comparison against an existing ReleaseSafe
oracle. At 8a there is no accepted Deblock4 oracle.

Section 20.2 is the special exception for the bounded scope that constructs
the ReleaseSafe scalar oracle. Under the proposed repair, 8a deliberately does
NOT construct/accept that oracle.

Therefore neither rule plainly supplies the acceptance basis for the 8a
comparison instruments.

I would describe the missing rule narrowly as:

```text
an independently authored acceptance basis for scalar comparison instruments
whose pixels are used to decide Schedule-SA versus Schedule-SB before the
ReleaseSafe oracle exists
```

It does not need to be closed during T1, but it must be closed before any 8a
scope is issued. Because those instruments determine a design decision, they
cannot simply be "experimental code, therefore unverified."

I agree with W3D that W3D should not author and self-verify that future
acceptance criterion.

Refs: DEC-46; charter oracle-construction exception; Verification and Tiering
Decisions 20.1/20.2; LED-029.

---

# METHOD FINDING - duplicated adjudication survived the claimed overlap sweep

This belongs above the per-entry verdicts because it concerns the method rather
than one mistaken entry.

The a4 ledger says its set was swept against T1S01a2/T1S01a3 before writing,
and that overlap was excluded rather than re-derived.

But T1S01a2 v1.1 LED-010 already adjudicates the exact shorthand and prerequisite
sentence that a4 reintroduces at LED-031/LED-032.

That is the same class of failure this countermeasure was introduced to stop.

The a4 coverage declaration also says the adjudicated tail is through line
1712, while the current authority's prerequisite sentence continues through
line 1713. The proposition itself is quoted in full at LED-032, so this is a
range-recording defect rather than lost substantive text, but the "exact
coverage" line should be corrected to include line 1713.

Recommended correction:

```text
- remove LED-031/LED-032 as fresh a4 adjudications, or explicitly reopen LED-010;
- correct the tail range to line 1713;
- keep LED-031's roadmap observation, if useful, only as evidence supporting
  LED-029 rather than as a second adjudication of already-ledgered source text.
```

---

# Technical findings and entry verdicts

## LED-025 - DISAGREE as recorded; disposition is sound, SWEPT is inadequate for one claim

The substantive outcome is sound:

```text
CURRENT-DUPLICATE
POINTER
canonical home: D4-Q16 / its detailed obligations
```

However, REASON explicitly says the statement is "unaffected by the T1/T5
reversal". The binding scope requires SWEPT whenever unaffectedness is claimed.

The present SWEPT field records a corpus search for the D4-Q16 token. That
search demonstrates duplication; it does NOT establish unaffectedness by the
T1/T5 sequencing reversal.

Fix by recording the current queue/sequence material actually checked to prove
the post-Q14 D4-Q16-before-pixel-work relationship survived the reversal.

VERDICT: DISAGREE as recorded; narrow evidence-field correction.

## LED-026 - AGREE

Disposition:

```text
CURRENT-DUPLICATE / POINTER
```

is sound.

The DERIVED two-senses-of-freeze analysis also holds, subject to the rerun
constraint stated in Q3.

EXPLICIT DERIVED VERDICT:

```text
AGREE.
THE TWO-SENSES READING HOLDS.
THE EARLIER THRESHOLD WARNING IS DISSOLVED.
```

## LED-027 - DISAGREE as recorded; disposition sound, canonical home should be the controlling charter rule

`CURRENT-DUPLICATE / POINTER` is sound.

The canonical-home statement is not quite right.

The ledger says Verification and Tiering Decisions section 20.2 is the
canonical home because verification rules live there. But that document's own
header says it is a durable DECISIONS-OF-RECORD document and that the charter
and README are controlling and prevail for controlling rules.

The current charter itself carries the oracle-construction exception, including
the independently authored obligations and SCHEDULE requirement.

So the hierarchy should be:

```text
canonical controlling rule:
    AI Charter v1.31 oracle-construction exception

detailed durable decision record / rationale:
    Verification and Tiering Decisions 20.2
```

The disposition and pointer action do not change.

VERDICT: DISAGREE as recorded; canonical-home correction only.

## LED-028 - AGREE

The statement that SA/SB quality comparison and canonical schedule/algorithm
freeze belong after candidate availability is current.

`CURRENT-DUPLICATE / POINTER` to section 14/14.4 is reasonable for this
section-23 work-queue restatement.

VERDICT: AGREE.

## LED-029 - AGREE with the derived repair after the refinement in Q2

The CONFLICTING finding is correct.

A completed accepted oracle cannot precede the schedule decision when:

```text
the winner becomes part of the oracle
AND
schedule is an oracle-construction obligation.
```

A bare 8/9 swap is also wrong because 14.4 requires scalar SA/SB candidates to
exist before the comparison can occur.

The repair's CORE is therefore sound.

I refine "the project needs two artifacts" to "the project needs two distinct
ROLES / ACCEPTANCE STATES". The comparison candidates are not accepted oracles;
the later oracle must earn oracle status under its own acceptance rule. This
does not yet prove that the winning candidate's implementation must be thrown
away and independently rewritten.

The acceptance gap at 8a is real and correctly left open.

One source-hierarchy correction: where PREVAILS relies on the oracle acceptance
rule, name the current controlling charter rule first, with Verification and
Tiering Decisions 20.2 as the detailed record.

VERDICT: AGREE, subject to those refinements.

## LED-030 - DISAGREE as recorded; disposition sound, canonical home/copy list need correction

The substantive rule is current:

```text
after the accepted scalar oracle/canonical freeze,
later vector backends are differentially validated against it.
```

`CURRENT-DUPLICATE / POINTER` is sound.

As with LED-027, the controlling canonical rule is in the charter; Verification
and Tiering Decisions 20.2 is the detailed durable record.

Also, the claimed non-canonical copy in "charter G5 capability-guard rule" is
not the same proposition. G5 is a capability/guard rule; the relevant
cross-backend/oracle acceptance material is G7 plus the charter's
oracle-construction bootstrap wording.

The roadmap Stage 4D/5D copies are enough to demonstrate duplication.

VERDICT: DISAGREE as recorded; mapping/evidence correction only.

## LED-031 - DISAGREE

First and most importantly: this should not be a fresh a4 disposition because
T1S01a2 LED-010 already adjudicates the same old-roadmap shorthand.

Second, the DERIVED claim of a "three-way disagreement" overstates what the
Forward Roadmap says.

Roadmap v1.21 states:

```text
Stage 2D:
    scalar core/oracle work including "schedules A/B"

Stage 3D:
    scalar quality decisions and canonical-algorithm freeze
```

That does NOT say the Schedule-SA/SB WINNER is selected in Stage 2D.
It is naturally compatible with:

```text
Stage 2D -> build scalar A/B candidates
Stage 3D -> compare quality / select winner / canonical freeze
```

which is essentially the role split proposed by LED-029.

The roadmap still has its separately known stale "midpoint" content, but that
does not establish a schedule-order conflict.

So this entry should not be used as evidence that three live arrangements
disagree.

Recommended treatment:

```text
remove as a fresh adjudication because LED-010 already owns the source text;
if the roadmap comparison is retained as LED-029 evidence, state that its
Stage-2D/Stage-3D split is compatible with candidate-then-quality sequencing,
not contrary evidence.
```

VERDICT: DISAGREE.

## LED-032 - DISAGREE; already adjudicated, and OPERATIVE-SPEC is wrong

First: T1S01a2 LED-010 already adjudicates this prerequisite sentence.

Second: under Review Scope v1.11, OPERATIVE-SPEC means:

```text
"a specification the code actually implements"
```

and every OPERATIVE-SPEC entry is Tier B, requiring source inspection.

LED-032 labels itself OPERATIVE-SPEC but then marks itself Tier C. That alone
violates the binding tier rule.

I performed the required read-only source inspection.

`src/deblock4_ar_all_frames_ready.zig`, lines 24-27, sends all three Deblock4
tier arms to:

```text
passThroughWritableCopy(...)
```

There is no Deblock4 filtering kernel implementing the Q14/API prerequisite
statement. The absence of a kernel demonstrates that the project has obeyed a
development/process prohibition; it does NOT turn that prohibition into a code
specification implemented by the runtime.

So OPERATIVE-SPEC is the wrong disposition.

If this text is reopened rather than left to LED-010/a5, treat it as current
knowledge/process gating and adjudicate it under CURRENT-DUPLICATE/atomic-claim
rules, with its Q14 and D4-Q16 components mapped to their actual canonical
homes.

VERDICT: DISAGREE.

---

# Acceptance-gap assessment in more detail

DEC-46 is not an invented problem caused by over-splitting the sequence.

The candidate comparison is decision-bearing. If either scalar candidate is
wrong in a way that favours or disfavors one schedule, the project can freeze
the wrong schedule even if the later oracle is perfectly accepted.

Therefore 8a needs an acceptance basis that proves at least:

```text
- both candidates implement the same step-7 common obligations;
- only the intended schedule/order differs;
- relevant arithmetic/geometry/footprint behaviour is checked independently;
- memory/bounds failures cannot contaminate the quality comparison;
- the quality harness compares like with like.
```

Those are examples of what a future criterion may need, not a proposed
ratified rule here.

The important conclusion for T1 is only:

```text
the gap is real;
it is narrower than "all Deblock4 verification is missing";
it blocks candidate-building scope 8a;
it does not block completion of T1.
```

---

# Coverage result

The substantive steps 6-10 are represented.

However the declared coverage is NOT clean because:

1. LED-031/032 duplicate already-adjudicated T1S01a2 LED-010 material;
2. the exact tail line range should extend through authority line 1713.

VERDICT ON COVERAGE: DISAGREE AS RECORDED; reissue required before a4 closure.

---

# Consolidated verdict table

```text
LED-025  DISAGREE   outcome sound; unaffectedness SWEPT basis incomplete
LED-026  AGREE      two-senses reading HOLDS; earlier warning DISSOLVED
LED-027  DISAGREE   outcome sound; canonical home should be controlling charter
LED-028  AGREE
LED-029  AGREE      core repair sound, refined to two roles/acceptance states
LED-030  DISAGREE   outcome sound; canonical home/copy evidence correction
LED-031  DISAGREE   already adjudicated at a2 LED-010; derived roadmap conflict
                    is also overstated
LED-032  DISAGREE   already adjudicated at a2 LED-010; OPERATIVE-SPEC and Tier C
                    are both wrong under scope v1.11
```

---

# Current W3C position

The important technical work is usable:

```text
LED-026:
    explicit question discharged
    two-senses reading holds
    prior threshold warning dissolved

LED-029:
    ordering conflict confirmed
    candidate-before-comparison / accepted-oracle-after-winner repair confirmed
    with the two-roles refinement

DEC-46:
    candidate acceptance gap confirmed real
    leave open; close before any 8a scope
```

But I do NOT recommend closing T1S01a4 on ledger v1.1 because the claimed
overlap sweep failed and LED-031/032 repeat T1S01a2 LED-010.

Recommended next action:

```text
W3D reissue a4 narrowly:
    remove/reconcile LED-031/032 overlap;
    fix the exact line range;
    apply the small LED-025/027/030 evidence/home corrections;
    preserve the accepted LED-026 and refined LED-029 analysis.

Then W3C can perform a delta review rather than restart this sub-tranche.
```

T1S01a5 should not begin until that narrow a4 reissue is checked, because a5 is
the final cross-entry consistency pass for this authority and should inherit a
clean a4 ledger.

---

*Revision history*

```text
v1.0 (2026-08-18) First W3C review of T1S01a4. Confirms the section-23
     oracle/schedule ordering conflict and substantially accepts the proposed
     candidate-comparison / later-accepted-oracle repair. Gives the mandatory
     LED-026 verdict: the two-senses-of-freeze reading holds and the earlier
     threshold warning is dissolved, subject to rerunning evidence if quality
     work changes a fixed comparison input. Confirms the pre-oracle candidate
     acceptance gap. Finds a METHOD defect: LED-031/032 re-adjudicate source
     text already owned by T1S01a2 LED-010 despite a claimed overlap sweep.
     Also rejects LED-032's OPERATIVE-SPEC/Tier-C classification after read-only
     source inspection, corrects several canonical-home/evidence details, and
     requests a narrow a4 reissue before closure. No source change; no
     build/test/git.
```
