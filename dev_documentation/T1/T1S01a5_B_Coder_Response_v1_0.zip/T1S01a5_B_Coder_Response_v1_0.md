# Deblock4 - W3C Method Review of T1S01a5 Designer Batch v5

**Deliverable:** T1S01a5_B - W3C METHOD REVIEW
**Version:** 1.0
**Date:** 2026-08-19
**Author:** W3C
**Route:** W3C -> W3X -> W3D
**Reviews:** `T1S01a5_A_Designer_Batch_v5.zip`
**Ledger:** `T1S01a5_A_Ledger_Body_Part1_v1_3.md`
**Covering note:** `T1S01a5_A_Covering_Note_for_W3C_v1_3.md`
**Corpus manifest:** `T1S01a5_A_Corpus_Manifest_v1_2.md`
**Binding review scope:** `Deblock4_T1_W3C_Review_Scope_v1_11.md`
**Binding work queue:** `Deblock4_Standing_Task_Register_T_Series_v1_25.md`
**Most recently supplied corpus:** `dev_documentation(20260819-005736).zip`
**Encoding:** US-ASCII; CRLF.

---

# Plain-English summary

The v5 replacement batch fixes the two defects that stopped the preceding
generation: the compound dispositions have been split, and the false claim
that a5 was the first STAY-CANONICAL use in T1 is withdrawn.

I nevertheless cannot begin the formal entry-by-entry verdict round yet. The
batch says its SWEPT population is 87 files from a 519-file tree, but applying
the ratified DEC-60 rule to the most recently supplied W3X corpus produces
94 searchable files from a 526-file tree. Seven live files are present in the
supplied corpus but absent from the manifest, and at least one of them - the
earlier a5 v1.0 ledger - directly contains propositions that v1.3 currently
calls CURRENT-UNIQUE. The population mismatch therefore can change
adjudications; it is not bookkeeping.

A separate METHOD defect also remains: nine CURRENT-UNIQUE or
CURRENT-DUPLICATE entries are labelled Tier B even though Review Scope v1.11
reserves Tier B for OPERATIVE-SPEC and gives Tier B only the code-implementation
classification question. There are also two stale mechanical counts in the
live framing: the package still asks W3C to review thirty-one entries although
v1.3 has thirty-four, and three files say the ledger has thirty-nine SWEPT
fields although it has thirty-four.

I therefore stop before issuing entry verdicts. The designer should correct
the population/corpus mismatch and the tier/framing defects first; W3C can
then resume without losing any substantive review work.

No source was modified. No build, execution, test, patch, delivery machinery
or git operation was performed.

---

# DECISIONS/QUESTIONS FOR W3X

## Q1. Supply or establish the current corpus that the a5 SWEPT claims are to be judged against

**Recommendation: fix this before formal a5 entry review continues.**

The binding DEC-60 rule says:

```text
A file is EXCLUDED from the T1 search population if ANY folder in its path
has a name beginning "superseded" or "scheduled_for_deletion".
Everything else in the supplied dev_documentation tree is IN.
```

The a5 ledger/manifest say that rule was applied to:

```text
519 total files
432 excluded
 87 searched
```

W3C independently applied the same rule to the most recently supplied corpus:

```text
526 total files
432 excluded
 94 searched
```

The seven searchable files present in W3X's supplied corpus but absent from
the a5 manifest are:

```text
T1/Deblock4_Standing_Task_Register_T_Series_v1_22.md
T1/Deblock4_Standing_Task_Register_T_Series_v1_23.md
T1/Deblock4_T1_Resume_Brief_v1_6 (1).md
T1/Deblock4_T1_Resume_Brief_v1_6.md
T1/T1S01a5_A_Covering_Note_for_W3C_v1_0.md
T1/T1S01a5_A_Designer_Batch.zip
T1/T1S01a5_A_Ledger_Body_Part1_v1_0.md
```

This matters because ledger section 0.5 expressly says:

```text
A copy sitting in a T1 process artifact is still a copy for the purpose of
refuting a uniqueness claim.
```

The extra a5 v1.0 ledger is not inert. For example it contains:

```text
LED-034's "four kinds of statements" proposition
LED-056's measurement-absorption proposition
LED-060's prior-art record material
```

Those are propositions that v1.3 currently calls CURRENT-UNIQUE. Under the
literal DEC-60 / section-0.5 population now supplied to W3C, those earlier-ledger
copies refute uniqueness.

So W3C cannot silently choose 87 over 94.

The clean options are:

```text
A. W3X supplies the refreshed current dev_documentation tree against which
   batch v5 / manifest v1.2 was actually generated, with obsolete T1
   generations placed under the mechanically excluded superseded tree;

OR

B. W3X decides that the 526-file tree is current, in which case W3D must rerun
   every a5 SWEPT claim over the 94-file population and revise dispositions
   where the seven extra files change the result.

OR

C. W3X changes the search-population rule so current-step/superseded-by-version
   T1 process artifacts are excluded by an explicit mechanical rule. That is a
   process-criterion change and must carry the appropriate I7 treatment.
```

W3C recommends **A** if the seven files are simply old process generations that
should already have been retired. It is the smallest repair and preserves the
already-ratified DEC-60 mechanism.

The two chat-blurb digest differences previously noticed are understood as
intentional W3X in-place edits and are not treated here as unexplained
corruption. They do, however, mean the manifest hashes are no longer an exact
description of those two supplied files.

Refs: DEC-60; Review Scope 4.2.0b and 5.3; ledger section 0.5; corpus manifest
sections 1-3.

## Q2. Correct the Tier B classifications before review

**Recommendation: yes.**

Review Scope v1.11 defines:

```text
TIER B - CLASSIFICATION CHECK.
Every entry marked OPERATIVE-SPEC.
One question only: is this really a specification the code implements?
```

But the a5 ledger marks the following nine entries Tier B while their
DISPOSITION is CURRENT-UNIQUE or CURRENT-DUPLICATE, not OPERATIVE-SPEC:

```text
LED-038
LED-039
LED-040
LED-045
LED-049
LED-051a
LED-052
LED-053a
LED-059
```

This is not a harmless higher-scrutiny label. If W3C followed the binding Tier
B instruction literally, those entries would receive only the
code-implementation classification question and would *not* receive the five
normal Tier-C questions plus Q-F where applicable.

The entries must therefore not remain Tier B.

If W3X wants a CURRENT-UNIQUE / CURRENT-DUPLICATE entry elevated from the
normal Tier-C spot-check to a full review, that can be recorded explicitly;
Tier B is the wrong mechanism because it has a different question set.

Refs: Review Scope sections 6 and 8.

---

# METHOD FINDING 1 - the corpus manifest still does not describe the corpus W3C holds

This is the highest-priority defect because every CURRENT-UNIQUE and many
CURRENT-DUPLICATE entries rely on SWEPT.

The designer correctly fixed the earlier retired-folder problem by making the
exclusion rule mechanical. The remaining problem is now different: the
mechanical rule is being applied to two different trees.

The ledger says:

```text
"Everything else in the supplied dev_documentation tree is IN."
```

The tree W3C was actually supplied contains seven additional non-retired files.
The batch cannot simultaneously say the search population is defined from the
supplied tree and ignore those files.

The mismatch is also self-demonstrating rather than hypothetical: the old a5
ledger quotes propositions claimed unique in the new ledger.

**Formal entry review is therefore blocked until the population is reconciled
by W3X rather than inferred by W3C.**

---

# METHOD FINDING 2 - Tier B is being used for the wrong disposition class

The nine entries named in Q2 are routine CURRENT entries, not OPERATIVE-SPEC.

This matters because the scope deliberately gives Tier B a *different review
question*, not merely a different effort level.

W3C will not reinterpret Tier B as "important current entry". The scope is
binding.

---

# FRAMING / SELF-CHECK DEFECTS TO FIX IN THE SAME REISSUE

These do not independently block review, but they are the same
partial-replacement class already recorded at DEC-51 and should be fixed while
the batch is open.

## 1. Thirty-one versus thirty-four entries

Ledger v1.3 has **34 entries**:

```text
LED-033 through LED-063
plus LED-051a, LED-052a and LED-053a
```

The covering note's digest section correctly says:

```text
31 entries at v1.2 -> 34 at v1.3
```

but live current framing still says:

```text
section 3: "This ledger covers sections 1-8 in thirty-one entries"
section 5: "Review the thirty-one entries under the binding review scope"
```

Those should say thirty-four.

## 2. Thirty-nine versus thirty-four SWEPT fields

W3C mechanically counted the actual fields:

```text
grep '^SWEPT' ledger v1.3 -> 34
```

but all three batch artifacts repeat the figure 39:

```text
ledger section 0.5:
    "all 39 SWEPT fields"

corpus manifest section 2:
    "all 39 SWEPT fields"

covering note section 0a:
    "all 39 SWEPT fields"
```

The count is false as written. There is one SWEPT field per entry, including
LED-063, for a total of 34.

Because the batch is explicitly using machine-checkable counts as evidence,
this should be corrected rather than dismissed as prose.

## 3. Ledger footer still says v1.0

The final live line says:

```text
End of T1S01a5 ledger v1.0.
```

The file is v1.3.

Minor by itself, but it is another live framing residue after a multi-round
replacement and should be included in the DEC-51 replacement-scope search.

---

# Corrections from the withdrawn generation that DO pass

These were the reasons W3C stopped the earlier generation, and W3C rechecked
them before finding the new blockers.

## Compound dispositions

PASS.

The three compound-disposition entries were split:

```text
LED-051  + LED-051a
LED-052  + LED-052a
LED-053  + LED-053a
```

The disposition is now atomic at the entry level.

## False "first STAY-CANONICAL use" claim

PASS.

The claim is withdrawn in LED-036 and closing question Q-C, and the resume
brief was corrected at source. T1S01a3 LED-020 and LED-021 are correctly
recognised as earlier uses.

---

# W3C review status

```text
T1S01a5 entry-by-entry substantive review:
    NOT YET ISSUED

reason:
    METHOD BLOCKER - current supplied corpus does not match the population on
    which the ledger's SWEPT claims rest, and the difference demonstrably can
    change CURRENT-UNIQUE dispositions.

additional method correction required:
    Tier B labels on nine non-OPERATIVE entries.

work preserved:
    the corrected atomic splits and STAY-CANONICAL framing have been checked
    and need not be rediscovered in the next generation.
```

Once the corpus/population and tier labels are reconciled, W3C can resume the
formal entry review directly.

---

*Revision history*

```text
v1.0 (2026-08-19) Method review of T1S01a5 designer batch v5. Confirms the
     previous atomic-disposition and STAY-CANONICAL-first-use corrections.
     Stops formal entry review because the batch defines an 87-file search
     population from a 519-file tree while the most recently supplied W3X
     corpus mechanically yields 94 searchable files from 526; seven live T1
     files are absent from the manifest, including an earlier a5 ledger that
     directly duplicates propositions currently called CURRENT-UNIQUE.
     Separately finds nine non-OPERATIVE entries incorrectly labelled Tier B
     under Review Scope v1.11, plus stale 31-entry, 39-SWEPT-field and v1.0
     footer framing. No source change; no build/test/git.
```
