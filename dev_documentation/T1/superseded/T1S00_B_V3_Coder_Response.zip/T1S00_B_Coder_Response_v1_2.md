# Deblock4 - T1S00_B W3C Final Focused Confirmation of Manifest v1.3

**Deliverable:** T1S00_B - CODER RESPONSE
**Version:** 1.2
**Date:** 2026-08-18
**From:** W3C
**Route:** W3C -> W3X -> W3D
**Reviewed:** `T1S00_A_Scope_Manifest_v1_3.md`
**Companions:** T1 review scope v1.5; Task Register v1.5.
**Nature:** narrow mechanical confirmation of the corrections requested in
`T1S00_B_Coder_Response_v1_1.md`. No T1S01 adjudication performed.
**Encoding:** US-ASCII; CRLF.

---

# Summary

The requested v1.3 corrections are present and the manifest is operationally
ready for T1S01.

The registered search frame is now Groups 1-12, exactly 90 terms, and is
explicitly frozen for T1. Group 12 contains all nine terms requested in the
second W3C pass. The pinned HolyWu C++ sources and licence are now explicit
section-2 exclusions, so the population rule and the 47-document arithmetic no
longer depend on an exclusion recorded elsewhere.

I found no remaining method or coverage defect that justifies another manifest
round before the first ledger-bearing step.

---

# DECISIONS/QUESTIONS FOR W3X

None.

**Recommendation: approve manifest v1.3 as the frozen T1S00 frame and release
T1S01_A.**

---

# 1. Required second-pass corrections

## Group 12 and term freeze

**CLOSED.**

Manifest v1.3 contains:

```text
GROUP 12 - decisions and Q14 integrity vocabulary
    architecture c\b
    D4-D
    false.confident
    held.out
    calibration
    viab
    ground truth
    per.MB
    frame/field
```

The manifest states Groups 1-12 are the frozen 90-term frame and records that
any later addition requires a W3X decision plus re-scan of already-adjudicated
steps.

That is the correct integrity rule.

## HolyWu source exclusion

**CLOSED.**

Section 2.0b now explicitly excludes:

```text
reference/holywu_r9/deblock.cpp
reference/holywu_r9/deblock_sse4.cpp
reference/holywu_r9/deblock.h
reference/holywu_r9/LICENSE
```

with the correct reason: pinned third-party reference implementation/licence,
not Deblock4 project knowledge. The provenance and SHA256 records remain in the
47-document population.

The population-first rule is now literally satisfied rather than satisfied only
by arithmetic.

## T1S01 arithmetic

**CLOSED.**

The step assignment correctly records:

```text
13 documents
~5,741 lines
1,114 original-42-term hits
    395 authority
  + 486 Scopes architecture record
  + 233 GAIS record
```

No T1S01 adjudication has been done in this confirmation.

## Generation-neutral retired-folder wording

**SUBSTANTIVELY CLOSED.**

Section 2 no longer pins the retired-folder population to a count that becomes
false whenever another process document is retired. The retirement description
is now family/generation based.

## Scope wording

**CLOSED.**

Scope v1.5 correctly distinguishes:

- B2 = adopted primary candidate;
- D = mandatory comparator/fallback;
- neither has passed Q14 or entered kernel/oracle development;
- T1 may adjudicate existing kernel principles/mathematics;
- no new kernel mathematics or kernel scope opens before Q14.

---

# 2. Non-blocking currency residue

These are worth cleaning at the next natural touch, but **do not justify
delaying T1S01**.

## M1 - Task Register v1.5 stops at the 81-term decision

The ratified register's DEC-18 still says the term set was extended
42 -> 81 (Groups 8-11). Manifest v1.3 is newer on this specific search-frame
matter and now freezes 90 terms after Group 12.

Because the manifest is the artifact that defines the T1 search frame, there is
no operational ambiguity for T1S01. But the Task Register says it carries the
method forward, so at its next bump it should record the second-pass outcome,
for example:

```text
DEC-21  T1 TERM FRAME FINALISATION.
        Groups 1-12, 90 terms, frozen before T1S01. Group 12 added nine
        decision/Q14-integrity terms after W3C's second independent PR-4 pass;
        measured +93 otherwise-unmatched lines at zero population change.
        Any later term addition requires W3X decision and re-scan of all
        already-adjudicated steps.
```

This is a record-currency correction, not a need to re-review the manifest.

## M2 - two pieces of historical prose remain snapshot-specific

Section 3's opening explanation still names `task register v1_4` and
`review scope v1_4` when explaining the four self-artifacts excluded from the
earlier 51-text-document snapshot.

That is historical explanation and the actual exclusion rule at 2.0a covers
**all generations**, so it cannot change the population.

Likewise section 5 W3 still says "350 files are excluded" even though section 2
was deliberately made generation-neutral. The exact retired-file count is not
used in the 47-document arithmetic and will keep drifting during T1.

At the next manifest/documentation touch I recommend making both passages
generation-neutral. They are clerical residue only.

---

# 3. Final T1S00 verdict

**T1S00 is complete enough to proceed.**

I do not recommend a manifest v1.4 merely for M1/M2.

Before reviewing T1S01 in any chat, the standing scope rule still applies:
W3C must have the then-current complete `dev_documentation` reference corpus
and source tree. The refreshed corpus should contain manifest v1.3 (or its
committed identical copy) so the frozen 90-term frame is part of the reference
set.

Subject to that normal evidence-supply rule:

**RELEASE T1S01_A.**
