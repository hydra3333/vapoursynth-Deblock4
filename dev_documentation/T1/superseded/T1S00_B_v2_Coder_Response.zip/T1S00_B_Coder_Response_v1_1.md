# Deblock4 - T1S00_B W3C Focused Re-Review of Amended Manifest v1.2

**Deliverable:** T1S00_B - CODER RESPONSE
**Version:** 1.1
**Date:** 2026-08-18
**From:** W3C
**Route:** W3C -> W3X -> W3D
**Reviewed:** `T1S00_A_Scope_Manifest_v1_2.md`
**Companion checks:** T1 review scope v1.5; Task Register v1.5; most-recently
supplied complete `dev_documentation` corpus.
**Scope:** focused second pass on the amendments made after
`T1S00_B_Coder_Response_v1_0.md`. No T1S01 adjudication has been performed.
**Encoding:** US-ASCII; CRLF.

---

# Summary

The v1.2 amendment closes the important structural findings from my first
T1S00 review.

I independently reproduced the key mechanical claims:

```text
current adjudication population                   47 documents
original term groups 1-7                          42 terms
new groups 8-11                                   39 terms
current registered total                          81 terms

authority v1.05: old-set hits 395 -> 664          +269
README v1.12:    old-set hits 463 -> 703          +240
whole 47-document population: 2598 -> 3840       +1242
```

So W3D's statement that the additions buy "about 1,300" further statement-level
hit lines is fair, and the document population remains unchanged.

The population-first/search-second rule is the right structural answer to PR-5.
The explicit T1-process-artifact exclusion and closure audit are also sound.

I found one remaining substantive PR-4 vocabulary gap and one formal
population-rule inconsistency, plus a few clerical currency remnants. They are
small enough for one final manifest bump; I recommend fixing them BEFORE the
T1S01 ledger is generated so the registered search frame does not move after
adjudication starts.

---

# DECISIONS/QUESTIONS FOR W3X

## Q1 - One final manifest bump before T1S01?

**Recommendation: YES - issue manifest v1.3, then start T1S01 without another
full T1S00 review.**

The required changes are narrow:

1. add the small Group-12 term set in F1;
2. move the HolyWu reference-source exclusion into the explicit exclusion
   section so it obeys DEC-17 literally;
3. clean the stale 42-term / retired-count / v1.1 wording listed in F3.

After that I do **not** recommend another broad PR-4 derivation. A short
mechanical confirmation of the listed edits is enough.

---

# Closure of first-pass findings

## Population and search separated

**CLOSED.**

Section 0.1 now makes the document population a recursive inventory and the
term search a second, independent mechanism. This is exactly the structural
protection PR-5 needed.

## Term groups 8-11

**CLOSED AS FAR AS THE FIRST-PASS PROPOSAL WENT.**

The 39 proposed terms were adopted and measured rather than accepted on
argument. I reproduced their principal counts independently.

A residual PR-4 gap remains; see F1.

## T1 self-artifacts / evolving register recursion

**CLOSED.**

The task register, T1 review scopes and their reviews, manifest, ledger batches
and step responses are now explicitly excluded from content adjudication and
audited for pointer/version currency at T1 closure.

That is a deliberate, challengeable exclusion rather than a label-based skip.

## Outgoing-designer evidence ZIP

**CLOSED.**

It is explicitly reference evidence rather than an authority sweep target. The
two judgement documents remain positions to test; Q3/Q4 remain record. The
fifth file is the handover summary/wrapper rather than a fifth independent
finding.

## Orphan-family check

**CLOSED AS A METHOD EXPERIMENT.**

W3D actually ran it. The 74-family raw result proved the filename-family method
too blunt because renames and completed-stage process artifacts dominate it.
The refined surviving candidate is carried forward to T1S05 rather than being
silently declared absorbed.

That is the right disposition of a negative method result.

## Population/count arithmetic

**SUBSTANTIVELY CLOSED.**

I independently derive the same 47-document current adjudication population
from the supplied corpus under the stated exclusions.

The T1S01 original-42-term arithmetic is also correct:

```text
authority              395
six Scopes docs        486
six GAIS docs          233
                      ----
                      1114
```

---

# F1 - PR-4 residual: nine directly relevant terms still add 93 otherwise-unmatched lines

## Verdict: SMALL BUT REAL; FIX BEFORE T1S01

The 81-term set is much better, but a fresh independent scan found a compact
set of current MPEG-2/architecture vocabulary that still produces important
lines not matched by any of those 81 terms.

Recommended **GROUP 12 - decisions and Q14 integrity vocabulary**:

```text
    architecture c\b
    D4-D
    false.confident
    held.out
    calibration
    viab
    ground truth
    per.MB
    frame/field
```

Case-insensitive, following the same regex convention as the existing groups.

### Measured effect

Against the same 47-document population:

```text
additional otherwise-unmatched lines:       93
additional lines inside T1S01 documents:    63
document population change:                  0
```

The additions are not generic noise. They recover:

- explicit **Architecture C** rejection statements;
- **D4-Dxx ratified decision identifiers**, including D4-D01/D02/D07/D08/D12;
- Q14's **false-confident** metric;
- the ratified **calibration / held-out** anti-tuning discipline;
- the independent **viability** requirement for B2/D;
- **ground-truth** extraction language;
- abbreviated **per-MB** truth language;
- direct **FRAME/FIELD** mixture/geometry language.

### Two particularly clear misses

Without `architecture c\b`, four live lines naming the rejected motion
Architecture C are not caught by any current term, including one in the
authority and one in the re-decision brief.

Without `D4-D`, twenty-two current lines containing ratified D4-D decision
identifiers are otherwise unmatched, many in the authority's decision register.

Those two alone justify the amendment. The remaining seven terms are the same
kind of low-noise, high-value Q14 integrity vocabulary.

I would **not** continue expanding indefinitely after this. The corpus is now
inventory-defined, the adjudicated sections are read in full, and Group 12
closes the obvious current-architecture terms exposed by this independent
second pass.

---

# F2 - formal population-rule inconsistency: HolyWu reference source is excluded outside section 2

## Verdict: CORRECT INTENT, WRONG LOCATION

Section 0.1 says:

```text
RECURSIVELY ENUMERATE every file...
Then apply ONLY explicit, recorded exclusions (section 2).
```

The 47-document count is correct only because four live
`reference/holywu_r9/` files are also omitted:

```text
deblock.cpp
deblock_sse4.cpp
deblock.h
LICENSE
```

Section 3.4 explains the reason correctly: they are third-party reference
implementation/material, not project knowledge documents, and the provenance
record is what T1 sweeps.

But that is an exclusion stated in section 3, not section 2, so the manifest
does not literally obey its new population rule.

### Recommended correction

Add an explicit section 2 exclusion:

```text
EXCLUDED FROM PROJECT-KNOWLEDGE ADJUDICATION:
    reference/holywu_r9/deblock.cpp
    reference/holywu_r9/deblock_sse4.cpp
    reference/holywu_r9/deblock.h
    reference/holywu_r9/LICENSE

Reason:
    pinned third-party reference implementation/licence, not Deblock4 project
    knowledge. The live provenance document and SHA256 record remain in the
    T1 population. Source evidence may still be consulted where a ledger entry
    requires it.
```

No population count changes; this only makes the rule and the actual count
consistent.

---

# F3 - clerical/current-generation remnants

## Verdict: NON-SUBSTANTIVE, FIX IN THE SAME v1.3

These do not alter T1 coverage, but the manifest is precisely the place where
currency should be exact.

### 1. Section 5 still says "42 terms"

W1 and W5 still describe the active search as 42 terms even though v1.2 has 81.
After Group 12 it will be 90.

Replace those historical-current statements with the actual active count, or
say "the registered term set" so future bumps do not stale the prose again.

### 2. Section 7 still says corrections will be folded into "manifest v1.1"

That instruction has already happened twice. Replace it with:

```text
Corrections found in T1S00 are folded into the manifest BEFORE T1S01 begins.
```

### 3. Retired-folder count has drifted by one in the most-recent corpus

Manifest v1.2 says four retired folders contain 352 files. In the refreshed
corpus supplied with this pass they contain **353**.

The reason is benign process churn: Task Register v1.4 has since moved to
`superseded/` while v1.5 is live. T1 process artifacts are excluded anyway, so
the 47-document adjudication population is unchanged.

Update the number or make it generation-neutral.

### 4. "retired on 2026-08-18" list is incomplete in the refreshed corpus

The current `superseded/` folder also contains Task Register v1.0 and v1.4,
not only v1.1-v1.3.

Again, no content-coverage effect; just record the current state accurately.

### 5. Section 2.0b's live-citation prose names Task Register v1.1

v1.1 is now retired and the current work queue is v1.5. Because the whole
T1-register family is excluded from adjudication, this is not a missed ledger
entry, but the prose should not call v1.1 a live document.

---

# Scope v1.5 and Task Register v1.5

Both companion amendments are consistent with the intended process.

Scope v1.5 correctly fixes the earlier shorthand:

- B2 is the adopted PRIMARY CANDIDATE;
- D is the mandatory comparator/fallback;
- neither has passed Q14 or entered kernel/oracle development;
- T1 may adjudicate EXISTING kernel principles/mathematics;
- no NEW kernel mathematics or kernel scope opens before Q14.

Task Register v1.5 also records the T1S00 outcomes rather than leaving them in
conversation, including DEC-17 through DEC-20.

I found no blocker in either companion document during this focused pass.

---

# Release recommendation

**Manifest v1.2 is structurally sound but I recommend one final v1.3 cleanup
before T1S01 ledger generation.**

The reason is narrow: Group 12 changes the registered statement-search frame,
and that frame should be frozen before the first adjudication batch.

After v1.3:

```text
- no further broad T1S00 review;
- mechanically confirm Group 12 + explicit HolyWu exclusion + clerical fixes;
- begin T1S01_A.
```

No architecture, T1 methodology or prior W3X decision needs to be reopened.
