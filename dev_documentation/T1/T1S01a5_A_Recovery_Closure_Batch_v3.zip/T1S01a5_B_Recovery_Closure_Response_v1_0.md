# Deblock4 - W3C Review of T1S01a5 Recovery Closure Batch v2

**Deliverable:** T1S01a5_B - RECOVERY CLOSURE REVIEW
**Version:** 1.0
**Date:** 2026-08-19
**Author:** W3C
**Route:** W3C -> W3X -> W3D
**Reviews:** `T1S01a5_A_Recovery_Closure_Batch_v2.zip`
**Common documentation base checked:** `dev_documentation(20260819-133331).zip`
**Primary ledger reviewed:** `T1S01a5_A_Ledger_Body_Part1_v1_6.md`
**Binding review scope supplied:** `Deblock4_T1_W3C_Review_Scope_v1_11.md`
**Encoding:** US-ASCII; CRLF.

---

# Plain-English summary

The recovery direction is now basically correct, but T1S01a5 is NOT ready to
close and T1S01a5b should NOT start yet.

The Tier C sample is settled. W3X selected eleven of the thirty-three Tier C
entries, W3C reviewed exactly those eleven, and the result was 3 AGREE / 8
DISAGREE / 0 UNSURE / 0 MISSING. DEC-73 correctly records that this sample is
not reopened. Any recovery text saying W3X still owed a Tier C sample was stale
and was not a real outstanding gate.

The remaining defects are bounded. No new a5 search round is indicated, no
Tier C resampling is indicated, and no architecture question is reopened.
However, ledger v1.6 still contains partial replacements and several false
self-check claims. In particular, three of W3C's eight Tier C DISAGREE findings
are still not fully propagated through the affected entries; the ledger misses
two source propositions from its declared 223-715 coverage; LED-059's proposed
canonical home is factually wrong; LED-063 is framed around a report that
"may not exist" even though a strong likely W3C report referent is present under
a different filename; and the recovery/status documents still contain stale
instructions that can explain why the successor designer thought Tier C work
was owed.

This should be repaired as ONE bounded recovery reissue. W3D should not rerun
the settled 22 probes. After the corrected ledger and recovery-status records
are issued, W3C can delta-review the changed areas plus Tier-A LED-063. If that
review is clean, W3X can close a5 and a5b can begin.

No source was modified. No build, execution, test, patch, delivery machinery or
git operation was performed.

---

# DECISIONS/QUESTIONS FOR W3X

None.

DEC-68 already ratifies the a5/a5b split. DEC-73 already closes the special
recovery-route problem by returning the W3D-authored ledger to ordinary
independent W3C review. The present defects can be corrected within those
decisions and do not require another W3X process ruling.

---

# 1. Overall verdict

```text
Tier C sample status                         PASS - settled; do not reopen
3 AGREE / 8 DISAGREE record                 PASS
settled 22-probe search/classification      PASS - do not rerun
recovery route under DEC-73                  PASS in principle

ledger v1.6 source coverage                  DISAGREE
all eight Tier C findings applied            DISAGREE
STAY-CANONICAL evidence                      DISAGREE in affected entries
tested coverage claims                       DISAGREE in LED-047
LED-059 conditional disposition              DISAGREE
LED-063 Tier-A framing/provenance             DISAGREE
split set / 39-entry closure claim            DISAGREE pending LED-055
delta/provenance self-check                  DISAGREE
register current-state consistency            DISAGREE
manifest / concise-summary current status     DISAGREE

RESULT: REISSUE REQUIRED. DO NOT START T1S01a5b YET.
```

---

# 2. Tier C sample - CLOSED, NOT OWED

The sample W3X selected was:

```text
LED-034
LED-037
LED-040
LED-043
LED-046
LED-049
LED-051a
LED-053
LED-055
LED-058
LED-061
```

W3C reviewed exactly those eleven in
`T1S01a5_B_Coder_Response_v1_1.md`.

Result:

```text
AGREE:
    LED-040
    LED-049
    LED-051a

DISAGREE:
    LED-034
    LED-037
    LED-043
    LED-046
    LED-053
    LED-055
    LED-058
    LED-061

TOTAL:
    3 AGREE
    8 DISAGREE
    0 UNSURE
    0 MISSING
```

DEC-73 now records that result correctly and explicitly says the Tier C sample
is not reopened.

## Why the successor could nevertheless think a sample was still owed

The live register v1.31 still contains an older, unqualified sentence inside
DEC-62:

```text
W3X ACTION NOW OWED: 33 entries are Tier C, so W3X must select the random
sample for W3C...
```

That historical sentence is no longer current after the sample was selected and
reviewed. DEC-73 later corrects the state, but a successor reading the decision
log sequentially can still encounter a live imperative that says the work is
owed.

Required repair: do NOT delete the historical DEC-62 record. Add an explicit
resolution annotation immediately there, for example:

```text
RESOLVED / SATISFIED 2026-08-19:
W3X selected 11 entries; W3C reviewed them in
T1S01a5_B_Coder_Response_v1_1.md; result 3 AGREE / 8 DISAGREE.
See DEC-73. The sample is not owed and is not reopened.
```

This is the most plausible direct documentary source of the anomalous recovery
state W3X reported.

---

# 3. The eight Tier C DISAGREE findings - not all fully applied

Ledger question Q-K2 says all eight are now applied. W3C checked that statement
against its own original review.

```text
LED-034    PASS
LED-037    PASS
LED-043    PARTIAL / FAIL
LED-046    PASS
LED-053    PASS
LED-055    FAIL
LED-058    PASS
LED-061    PARTIAL / FAIL
```

## LED-034 - PASS

The unsupported T3 protection-gap proposition has been withdrawn while the
CURRENT-UNIQUE taxonomy disposition is retained.

## LED-037 - PASS on the substantive Tier C correction

The ledger now gives a separate corpus uniqueness basis rather than treating
truth of the within-authority naming audit as proof of corpus uniqueness.

The old restoration prose elsewhere in section 0.4f is stale; that is a
separate delta/provenance defect discussed below.

## LED-043 - PARTIAL / FAIL

The important atomic correction is present:

```text
(a)/(b) duplicated codec signalling facts;
(c1) separately dispositioned codec fact;
(c2) duplicated Q14 no-fabrication project rule.
```

But the same entry's SWEPT field still says the broad search found:

```text
the GAIS files
```

as part of the "live corpus". W3C's original Tier C correction explicitly said
to refresh that applicable SWEPT population WITHOUT GAIS/T1 evidence. DEC-66
now excludes GAIS_investigations/ from T1 search and adjudication.

There is also a local action/evidence mismatch. The entry says the Scopes
no-fabrication carrier for (c2) is:

```text
the concrete non-canonical copy the (a)/(b) STAY-CANONICAL claim needs
```

It is not. The Scopes occurrence is a carrier of c2. The entry already names
the section-3 regime table as a concrete noncanonical copy of (a)/(b); use that
for the (a)/(b) STAY-CANONICAL evidence.

Required repair:
- remove the stale GAIS/T1 applicable-population wording;
- keep the c2 Scopes carrier attached to c2;
- keep the section-3 regime table as the named (a)/(b) copy.

No search rerun is needed.

## LED-046 - PASS

The stale cross-reference is corrected:

```text
LED-049 -> LED-052a
```

## LED-053 - PASS on the sampled correction

The old bundled treatment is split so the e_c/x_c coordinate proposition can
remain unique while the no-midpoint and Case-(b) pitch-2 propositions carry
their duplicate evidence separately.

The same-file Appendix-A carrier is handled as cited evidence outside the
current sub-tranche rather than silently adjudicated; see Q-K below.

## LED-055 - FAIL

The REASON correctly withdraws the blanket uniqueness claim and correctly names
README plus the Scopes re-decision brief as mechanism carriers.

But PREVAILS STILL SAYS, literally:

```text
the DERIVATION -> this section, uniquely.
```

That is the exact blanket statement W3C rejected.

More importantly, W3C's original Tier C finding did not merely say "change the
word unique". It found at least three atomic layers:

```text
duplicated row-projection mechanism;
possibly unique derivation qualifiers;
duplicated D4-D01 conclusion.
```

The potentially unique qualifiers included:

```text
progressive/frame-DCT generality;
"correctness requirement, not performance preference".
```

W3C explicitly required those potentially unique derivation qualifiers to be
split/re-swept separately from the duplicated mechanism/conclusion.

v1.6 has not done that. It leaves the entire derivation under one
CURRENT-DUPLICATE entry and simultaneously retains a false "uniquely" phrase.

Required repair:
1. remove the false PREVAILS uniqueness wording;
2. atomically separate or narrow the derivation qualifiers;
3. use the already-settled candidate material to establish whether those
   qualifiers are unique or duplicated.
Do not start another broad corpus-search round. This is a bounded proposition
classification repair on material already exposed by the Tier C review.

Until this is settled, the five-new-suffix / 39-entry closure total is not a
stable final result. A further atomic entry may be required.

## LED-058 - PASS on the sampled correction

The unique document-local reading rule is split from the duplicated mapping /
significance / evidence-limit material.

The stale phrase "regime 3, mixed" is now correctly recorded as an ACTUAL
exposure in Grid Knowledge, rather than a hypothetical future exposure.

## LED-061 - PARTIAL / FAIL

The repaired SWEPT table is good. It correctly says:

```text
coder introduction    DIFFERENT - charter I7 verification rule
D2 HolyWu schedule    DIFFERENT - verification of D2, not the GAIS rule
coder chat blurb      CARRIER
```

But the entry's REASON still says the standing rule is stated in:

```text
the coder introduction
the D2 HolyWu Real Schedule document
```

and DUPLICATE-ACTION still lists those two as known noncanonical copies.

The same entry therefore both rejects and relies on the same two files.

Required repair:
- remove coder introduction and D2 from REASON/DUPLICATE-ACTION carrier lists;
- retain the designer introduction and both relevant chat-blurb carriers;
- retain the split unique GAIS instrument assessment separately.

This is a classic DEC-51 partial-replacement defect.

---

# 4. Q-A - coverage: DISAGREE

Ledger section 0.2 declares authority lines 223-715 adjudicated.

W3C checked the source range against the 39 DOCUMENT ranges in v1.6.

The expected split-entry overlaps are understandable, but two actual source
propositions are not represented by an entry:

## Missing proposition 1 - authority line 225

```text
Deblock4 is the project's MPEG-2-aware deblocking filter, initially aimed at
PAL 576i material recorded by consumer DVD recorders.
```

LED-033 starts at lines 226-229 and adjudicates the document-purpose /
single-source proposition. It does not capture this project-scope/target
statement at line 225.

Required repair: add it to an existing atomic entry only if the disposition and
action truly match; otherwise create a separate entry.

## Missing proposition 2 - authority line 269

```text
Unless explicitly stated otherwise:
```

That sentence scopes the coordinate-convention block that follows. LED-038 to
LED-040 adjudicate the individual coordinate definitions/rules, but no entry
currently captures the default-scope qualification itself.

Required repair: explicitly capture the qualification in the coordinate
convention adjudication.

## Range error - LED-060

LED-060 says:

```text
DOCUMENT authority v1.05, section 7, lines 646-673
```

but its CLAIM expressly includes P4's qualification:

```text
This is NOT a claim that no such prior art exists.
```

That sentence is authority line 674.

Required correction:

```text
lines 646-674
```

This is a range-record defect, not a source-content omission.

Minor line-record cleanup also recommended:
- LED-038 still refers to its local copy as line 269 although `e` is at 272;
- LED-040's local-copy line wording should be reconciled to the actual source
  lines.

---

# 5. Q-B - a5/a5b split: SUBSTANCE AGREE; RECORD DISAGREE

DEC-68 ratified the split:

```text
a5   sections 1-8
a5b  sections 9-13
```

The split itself remains sound for this recovery review.

But ledger section 0.1 still says:

```text
THIS SPLIT REQUIRES W3X RATIFICATION. It is declared, not assumed.
```

That is stale and directly contradicts later text and DEC-68.

Required repair: change section 0.1 to state that the split IS RATIFIED, with
DEC-68 as the record.

No new W3X decision is needed.

---

# 6. Q-C - STAY-CANONICAL: COUNT PASS; EVIDENCE DISAGREE

The ledger's mechanical count of SIXTEEN STAY-CANONICAL occurrences is
reproducible, including the mixed-action entry.

The count itself is not the problem.

The affected evidence remains wrong at least in:

```text
LED-055    PREVAILS still says "the DERIVATION -> this section, uniquely"
LED-061    REASON/ACTION still call coder introduction and D2 carriers despite
           SWEPT classifying both DIFFERENT
LED-043    c2's Scopes carrier is incorrectly described as evidence for the
           (a)/(b) STAY-CANONICAL claim
```

Therefore Q-C is DISAGREE until those per-proposition evidence records are
reconciled.

---

# 7. Q-D - the two tested claims: MIXED; LED-047 needs correction

## LED-037 - PASS

W3C independently checked the authority's Schedule naming audit.

The authority contains the expected active Schedule-SA/SB/SC use and bare
historical Schedule A/B/C only in explicit old-vocabulary contexts. The
separate uniqueness-probe basis is now recorded.

## LED-047 - FAIL AS WRITTEN

The entry says:

```text
POPULATION: every occurrence of the string "H.262-VERIFIED" in this document
RESULT: seven hit lines - 33, 286, 298, 304, 310, 338, 366
```

A literal search for the string `H.262-VERIFIED` returns EIGHT lines, because
line 291 contains:

```text
[DERIVED FROM H.262-VERIFIED FACTS]
```

The ledger notices line 291 separately, but that does not make the stated
literal-string population/result true.

Two valid repairs are available:

```text
A. redefine the tested population as exact standalone [H.262-VERIFIED] tags
   and keep the seven-result count;

or

B. report eight literal-string hits and classify line 291 separately as the
   derived compound tag.
```

This is a DEC-50 check-evidence accuracy defect.

---

# 8. Q-E - DERIVED leakage: no new broad defect beyond named repairs

W3C did not find a reason to reopen the DERIVED method generally.

The known corrections remain:
- LED-034 protection-gap inference withdrawn;
- LED-058/058a actual external stale-shorthand exposure distinguished from the
  document-local reading rule;
- the LED-055 atomic decomposition still needs completion.

No new search methodology is required.

---

# 9. Q-F - LED-059 conditional disposition: DISAGREE; resolve now

LED-059 says the file-level corpus composition is duplicated in section 15 and
proposes section 15 as canonical home, while admitting it has not actually
confirmed section 15.

W3C read authority section 15 directly.

Section 15 defines:
- Q14 ground-truth fields/classes;
- B2 and D measurement/reporting requirements;
- calibration versus held-out discipline;
- the architecture decision rule.

It does NOT state the file-level corpus composition:

```text
LG MLS
LG XP/SP/LP/EP
home_576i
home_576p
```

Therefore the conditional PREVAILS claim is factually wrong.

The file-level composition does appear in Grid Knowledge, but that does not
make section 15 its canonical home.

Required repair now, not at a6:
- remove the assertion that section 15 duplicates the file-level composition;
- remove the pointer to section 15 as canonical home;
- unless another applicable canonical statement is established, retain
  authority section 6.3 as the present canonical home for the file-level corpus
  composition;
- keep the significance sentence mapped to LED-058 as appropriate.

This fact was checkable from the supplied authority and should not remain a
conditional future gate.

---

# 10. Q-G - LED-063 Tier A: DISAGREE; strong likely referent found

The exact filename named by authority section 24 R8 is not present:

```text
Deblock4_D4_W3C_Verification_and_Design_Review_v1_0.md
```

That filename/reference defect is real.

But v1.6 overstates the consequence when it says:

```text
THE "W3C VERIFICATION REPORT" MAY NOT [exist].
```

The current Scopes tree contains:

```text
Scopes/
Deblock4_D4_PreScope_Round_Brief_for_W3C_v1_2_CODER_RESPONSE.md
```

Its header is:

```text
# Deblock4 - D4 Pre-Scope - W3C Verification and Independent Design Review
Deliverable: W3C-D4-VERIFY-1
Version: 1.0
From: W3C
Route: W3C -> W3X -> W3D
```

It contains:

```text
PART A - VERIFICATION
V4.1 Chroma organisation
V4.3 dct_type signalling and semantics
```

Those are precisely the V4.1 / V4.3 shorthand references the authority uses for
F4/F5 provenance.

This is strong evidence that the W3C verification REPORT CONTENT survives under
a different filename.

W3C is not using this review to ratify that identity as an authority-reference
edit. But LED-063 must not continue to say the report "may not exist" without
opening and assessing this actual W3C-authored candidate.

Required repair:
1. open/read the coder-response report as the primary candidate referent;
2. distinguish:
   - exact R8 filename missing/wrong;
   - report content apparently retrievable under a different filename;
3. record the likely filename/reference reconciliation for a6;
4. do not use ignored GAIS material as a substitute.

LED-063 also contains plainly stale population text:

```text
six documents in GAIS_investigations/ plus two response captures in the root,
all live and in T1's population at T1S01b and T1S05.
```

Under DEC-66:
- GAIS_investigations/ is ignored for T1 search/adjudication;
- T1S01b is Scopes-only;
- the two response captures are no longer root T1 evidence.

That text must be removed/reframed.

---

# 11. Q-H - split set: DISAGREE pending LED-055

The currently printed 39 ledger entries are mechanically countable.

The current new-rewrite suffix set is:

```text
LED-043a
LED-053c
LED-053d
LED-058a
LED-061a
```

Those five additions produce 39 from the delivered v1.3 population of 34.

However, LED-055's original sampled finding still requires atomic treatment of
its possibly unique qualifiers. Until W3D resolves that, W3C cannot endorse:

```text
LED-055 needs no suffix
```

or the 39-entry total as final closure structure.

This does NOT mean "make it 40". It means:
- fix LED-055's proposition decomposition first;
- then count the resulting entry set mechanically.

Do not choose the target count before the propositions are settled.

---

# 12. Q-J - WITHDRAWN: AGREE

The LED-046 cross-reference question was already answered in the Tier C sample.
v1.6 correctly applies the LED-052a correction and leaves Q-J only as a
withdrawal record.

No new question is owed.

---

# 13. Q-K - same-file Appendix A carrier outside the a5 range: AGREE

LED-053d uses Appendix A as evidence that the proposition is duplicated, while
not adjudicating Appendix A inside a5.

That is consistent with the ledger's cited-as-evidence rule:
- the carrier is allowed to affect the current disposition;
- the out-of-range occurrence itself remains for its assigned later
  sub-tranche.

No special same-file exception is needed.

---

# 14. Q-K2 - "all eight Tier C findings applied": DISAGREE

The enumeration of the eight DISAGREE entries is correct.

The implementation is not.

At minimum:

```text
LED-043    partial - stale GAIS applicable-population wording remains
LED-055    not complete - false "uniquely" remains and atomic qualifier work
           is still owed
LED-061    partial - REASON/ACTION contradict repaired SWEPT classifications
```

Therefore the statement "all eight applied" must be withdrawn until those
entries are repaired and checked end-to-end, not merely in the field that was
edited.

---

# 15. Q-L - provenance/delta completeness: DISAGREE

The document asks W3C to verify that every v1.3 -> v1.6 difference appears in
section 0.4c's COMPLETE delta set or section 0.4f's restoration set.

It does not.

## 0.4c false completeness claim

Section 0.4c says:

```text
THE COMPLETE DELTA SET FROM v1.3
...
NOTHING ELSE CHANGED.
```

But direct Tier C corrections such as LED-037 and LED-046 changed ledger text
and are not both represented inside that claimed complete D1-D7 set.

They appear elsewhere in recovery prose/revision history, which is precisely
why "complete delta set" is false.

Required repair: either:
- make 0.4c genuinely complete; or
- rename it to the narrower set it actually enumerates and point to the other
  declared change sets.

## 0.4f contradicts LED-037's correction

0.4f says the restored LED-037 material includes:

```text
the REASON's original reasoning
```

and describes the restoration set as verbatim v1.3 text.

But v1.6's LED-037 then changes/withdraws the original uniqueness reasoning.
The recovery narrative and the live entry cannot both be described that way.

Required repair: state exactly which LED-037 evidence was restored and exactly
which reasoning was deliberately changed.

## 0.4e contains its own stale count

The section correctly derives:

```text
34 + 5 = 39 entries
```

but later in the SAME section says:

```text
This ledger's count ... lands at 40.
```

That is a direct DEC-51 partial-replacement defect.

Remove/correct the stale 40 sentence after the LED-055 structure is resolved.

## Covering-note wrong diff target

The covering note tells W3C:

```text
diff v1.3 against v1.5
```

but the review target supplied is v1.6 and the recovery batch does not include
v1.5.

Required correction:

```text
diff v1.3 against v1.6
```

or a precise staged comparison if W3D intentionally wants both generations
supplied.

The covering note also pins the binding work queue at v1.30 although the batch
supplies v1.31. Reconcile that pointer.

---

# 16. Package-level current-state defects

These are important because one of them likely caused the Tier C anomaly.

## Standing Task Register v1.31

Current-facing section 0 still says:

```text
a5 LEDGER v1.5 DELIVERED; AWAITING W3C REVIEW
```

while the supplied review target is v1.6.

Section 0a still says the project is:

```text
NOT READY FOR a5b YET.
READY FOR SUCCESSOR-W3D RECOVERY VERIFICATION OF THE a5 LEDGER.
```

That was the pre-DEC-73 gate. DEC-73 says successor W3D has already rebuilt the
ledger and the ordinary W3C review is now the closure route.

Required repair:
- current status -> W3D ledger v1.6 under W3C recovery-closure review;
- retire/de-currentise the old section-0a successor-W3D verification gate;
- annotate DEC-62's "W3X ACTION NOW OWED" Tier C sample sentence as RESOLVED;
- preserve DEC-73's no-resampling rule.

The latest `v1_31a` in the supplied dev_documentation is byte-identical to
batch v1.31, so it does not contain a hidden later fix.

## T1S00 Scope Manifest v1.6

Its frozen 90-term / 47-document survey role should remain frozen.

But the field labelled CURRENT STATUS still describes the W3C recovery ledger
v1.4 and says successor W3D must independently verify/adopt/correct it.

That recovery step has happened.

DEC-69 explicitly allowed delivery/status description without reopening the
frozen frame. Apply a bounded CURRENT STATUS correction only. Do not touch the
frozen survey tables/terms/counts.

## Concise Project Summary v1.7

Its live section still says:

```text
W3C reconstructed v1.4;
successor W3D must independently verify/adopt/correct it;
a5b waits on that closure.
```

That is now one recovery generation behind.

Update only after the corrected a5 ledger/recovery state is settled so the
summary does not need another immediate rewrite.

## Other root continuity documents

The latest dev_documentation still contains several root/current-facing
documents whose live-state sections reflect the older v1.4 recovery gate,
including Project Status, Documentation Currency Audit, Forward Roadmap and
some orientation files.

W3C does NOT recommend another broad continuity rewrite before the corrected a5
reissue. First make the a5 recovery state true and stable. Then perform one
bounded post-closure currency pass so those documents all point to the same
settled endpoint.

---

# 17. Required bounded reissue - NO NEW SEARCH ROUND

W3C recommends W3D make one recovery-correction generation containing only the
following classes of change:

```text
A. LEDGER COVERAGE / RANGES
   - capture authority line 225 proposition
   - capture authority line 269 default-scope qualification
   - LED-060 range 646-674
   - clean minor stale line pointers

B. TIER C PARTIAL REPLACEMENTS
   - LED-043 remove stale GAIS/T1 applicable-search framing and fix c2 vs a/b
     noncanonical-copy attribution
   - LED-055 complete atomic decomposition/re-sweep of unique qualifiers;
     remove false "derivation ... uniquely"
   - LED-061 remove coder-introduction/D2 false-carrier remnants

C. TESTED CLAIM
   - LED-047 report the H.262-VERIFIED population/result accurately

D. LED-059
   - remove false section-15 corpus-composition duplication/canonical-home claim

E. LED-063
   - evaluate the actual W3C-D4-VERIFY-1 coder-response report as likely R8
     content referent
   - distinguish wrong/missing exact filename from surviving report content
   - remove stale GAIS/T1S01b population language

F. RECOVERY SELF-CHECK
   - section 0.1 split status -> RATIFIED DEC-68
   - section 0.4c completeness claim fixed
   - section 0.4e stale "40" fixed after proposition count is settled
   - section 0.4f LED-037 restoration wording reconciled
   - Q-K2 "all eight applied" only after it is actually true
   - covering note v1.3-v1.6 diff target and v1.31 work-queue pointer

G. CURRENT STATUS RECORDS
   - task register current sections and DEC-62 resolved annotation
   - T1S00 current-status paragraph only
   - defer broader root continuity refresh until corrected a5 closure
```

Explicitly NOT required:

```text
NO Tier C resampling.
NO rerun of the settled 22-probe search round.
NO reopening of DEC-67 search methodology.
NO architecture reopening.
NO source/code/build/test work.
```

---

# 18. What W3C should review next

After W3D issues the bounded correction:

```text
1. delta-review v1.6 -> corrected ledger;
2. verify the three previously partial Tier C entries end-to-end:
       LED-043
       LED-055
       LED-061
3. verify Q-A coverage/ranges;
4. verify LED-047 tested-count repair;
5. verify LED-059 against section 15;
6. full Tier-A review of corrected LED-063, including the
   W3C-D4-VERIFY-1 candidate referent;
7. verify recovery self-check/delta provenance;
8. verify current register/manifest route no longer says Tier C is owed.
```

If those pass, W3C sees no presently known reason to keep a5 open. W3X can then
close T1S01a5 and successor W3D can start ratified T1S01a5b.

---

# Current W3C position

```text
TIER C SAMPLE                         CLOSED / SETTLED
TIER C RESAMPLING                     NOT OWED
22-PROBE SEARCH ROUND                 CLOSED / SETTLED
CLASSIFICATION REPAIR v1.1            SUBSTANTIVELY SETTLED

RECOVERY LEDGER v1.6                  REISSUE REQUIRED
a5 FORMAL CLOSURE                     NOT YET
a5b START                             NOT YET

NEXT WORK                             BOUNDED RECOVERY CORRECTION ONLY
```

---

*Revision history*

```text
v1.0 (2026-08-19) Independent W3C audit of Recovery Closure Batch v2 against
     the latest supplied dev_documentation tree and W3C's own completed Tier C
     sample review. Confirms the Tier C sample was completed at 11 entries with
     3 AGREE / 8 DISAGREE and must not be reopened. Finds three Tier C
     corrections still only partially propagated (LED-043, LED-055, LED-061),
     two uncovered authority propositions plus one source-range defect, an
     inaccurate LED-047 literal-hit count, a false LED-059 section-15
     canonical-home assumption, and a strong likely surviving W3C report
     referent for LED-063 under the W3C-D4-VERIFY-1 coder-response filename.
     Also finds partial-replacement defects in ledger recovery self-checks,
     stale register language that still says W3X owes the Tier C sample, and
     current-status records lagging the W3D v1.6 recovery state. Requires one
     bounded reissue only: no Tier C resampling, no 22-probe rerun, no method
     reopening and no architecture reopening.
```
