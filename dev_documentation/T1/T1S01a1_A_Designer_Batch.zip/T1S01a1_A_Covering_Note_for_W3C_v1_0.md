# Deblock4 - Covering Note for W3C: T1S01a1, the First Ledger Tranche

**Route:** W3X -> W3C
**Date:** 2026-08-18
**Encoding:** US-ASCII; CRLF.

---

## Before anything else

Check that you have the complete `dev_documentation` corpus and the `src` tree
in front of you. If either is missing, STOP and ask for it - do not review from
the ledger alone. The reason is in the review scope at 4.2.0 and 4.2.1, and it
is the same defect you yourself found in an earlier version of that scope.

The corpus should contain scope manifest v1.3. That manifest holds the frozen
90-term search frame this sweep runs on.

## Where we are

The manifest step (T1S00) is closed. Your three reviews of it produced two
blocking findings, a structural improvement to how the document population is
built, two arithmetic corrections and two rounds of search vocabulary. All were
adopted. The frame is now frozen: 90 terms, 47 documents, and any later term
addition needs a W3X decision plus a re-scan of everything already adjudicated.

**This is the first step containing actual adjudications.** From here your job
changes shape. T1S00 was mechanical - counts, greps, file lists, all of it
reproducible by running the same commands. What follows is judgement: does this
quoted text support this conclusion, is this statement superseded, does the
older document win. None of that can be checked by re-running anything, so the
weight falls on you reading the swept sections yourself rather than accepting
the designer's account of them.

## What changed in the plan

T1S01 was too big for one honest pass - 13 documents and 5,741 lines. It is
split, and the split is declared rather than done quietly:

```text
T1S01a   the ratified MPEG-2 authority document (1,983 lines).
         Carries the two pre-registered items PR-1 and PR-2.
T1S01b   the working record BEHIND it - the six architecture re-decision
         documents and the six external-research documents (3,758 lines).
```

The boundary is real: one adjudicates the authority, the other adjudicates the
record it was built from. Task Register v1.6 records this as DEC-22, and also
records the frozen term frame as DEC-21.

## What is in this tranche, and why so little

Two entries only. Both pre-registered, both Tier A.

They come first and alone because **PR-1 blocks the next major design task.**
The register forbids the detector-mathematics work from starting until PR-1
resolves, so bringing it to W3X now - rather than at the end of a 47-document
sweep - is the entire reason the steps were ordered by risk instead of by size.
The rest of the authority document follows in later tranches.

## The two entries in plain terms

**PR-1** asks whether a limit currently written as an argument against a
rejected design actually applies to every design. The limit is this: when a
harmless real edge in the picture and a genuine compression seam produce
exactly the same six pixel values, no threshold can tell them apart, because
there is nothing to tell apart. The designer's verdict is that the limit IS
general, but with a refinement the designer derived rather than inherited -
the limit applies to every architecture's decision about WHETHER to filter,
while its severity depends on whether an architecture also leans on that same
local test to work out WHERE the edge is. That gradation puts Architecture D in
an awkward middle position, and the entry says so.

**PR-2** asks whether a design rule has quietly become a historical footnote.
The rule: you may make the evidence test stricter before deciding to correct a
pixel, but once the test passes you correct at full strength - you do not
half-correct. It currently appears in the authority only while describing what
the rejected design used to do.

## Three things worth attacking hardest

```text
1. The PR-1 gradation is the DESIGNER'S OWN derivation, not something carried
   over from the previous designer. Argue it from the pixel construction
   quoted in the entry. If it is broader or narrower than claimed - especially
   if Architecture D's residual exposure is overstated or understated - say
   so. Getting this wrong mis-shapes the detector mathematics that follow.

2. PR-2 is dispositioned "current in substance, superseded in form". That is
   not one of the five permitted dispositions. If it is a dodge, say so and
   name which of the five it should be.

3. BOTH entries propose changes to the ratified authority document, and the
   designer wrote both the finding AND the proposed remedy. That is exactly
   the self-affecting shape the charter's independent-verification rule
   covers. Test the remedy at least as hard as the finding.
```

## Reminders that still apply

- Read the authority sections in the corpus. The entries quote them, but a
  quotation chosen by the designer cannot show you what the designer walked
  past - and one of your five questions is precisely about omissions.
- You will get no feedback before the next tranche. Silence is not agreement.
  If you raise something and it recurs later, raise it again.
- If the problem is the METHOD rather than an entry - entries too thin to
  check, a disposition category being misapplied, a format you cannot review -
  put it at the TOP of your response as a method problem, not buried in a
  verdict. This is the first ledger you have seen, so this is the moment that
  kind of fault is cheapest to fix.
- Disagreement is the product. Bare agreement on a Tier A entry tells nobody
  whether you checked. An honest "unsure, and here is what would settle it" is
  worth more than a confident guess.

Deliver as `T1S01a1_B_Coder_Response.zip`.
