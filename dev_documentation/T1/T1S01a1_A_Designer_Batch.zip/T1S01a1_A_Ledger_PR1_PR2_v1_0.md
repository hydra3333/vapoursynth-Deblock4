# Deblock4 - T1S01a Ledger, Tranche 1: PR-1 and PR-2

**Deliverable:** T1S01a_A - LEDGER TRANCHE 1
**Version:** 1.0
**Date:** 2026-08-18
**Author:** W3D
**Route:** W3D -> W3X -> W3C
**Step:** T1S01a - adjudication of the MPEG-2 authority document v1.05
**Search frame:** the frozen 90-term set, manifest v1.3
**Status:** PROPOSED ADJUDICATIONS. Nothing here is decided. Every entry is a
position for W3C to test and W3X to rule on.
**Encoding:** US-ASCII; CRLF.

---

# 0. What this tranche is, and what it is not

T1S01a adjudicates the ratified MPEG-2 authority document. This is the FIRST
TRANCHE of that step and covers only the two pre-registered items that live in
it: PR-1 and PR-2. The remaining authority sections follow in later tranches.

They are delivered first and alone because **PR-1 gates T5**. The task register
blocks the detector-mathematics task until PR-1 resolves, so bringing it to
W3X early - rather than at the end of a 47-document sweep - is the whole reason
the steps were ordered by risk.

```text
TIER:     both entries are TIER A (pre-registered items).
EVIDENCE: source text is quoted verbatim inside each entry, and the
          supporting re-decision record is quoted where the reasoning was
          actually done. W3C should read those sections in the corpus, not
          rely on these extracts.
```

---

# LED-001  PR-1: the in-principle false-activation limit

## Source, quoted

Authority v1.05 section 12.5, lines 1021-1046. Section 12 is titled
`ARCHITECTURE A TRANSPOSED TO WHOLE-FRAME COORDINATES - REJECTION PROOF`.

```text
## 12.5 In-principle local false-activation limit

For a harmless non-block step and a true compression seam that present the
same local samples:

    p2,p1,p0 = A,A,A
    q0,q1,q2 = A+d,A+d,A+d

side activity is zero. A canonical boundary-vs-side-activity gate reduces to a
condition of the form:

    d < alpha_candidate
    and side-flatness tests pass

No threshold can distinguish two different causes that generate the identical
sample tuple. Lowering the candidate threshold trades false positives for weak
seam misses; raising it trades the other way. Threshold scaling can tune the
trade, not eliminate it.

This is why `midpoint_threshold_scale` is not a proof of safety. [...]
```

## The corroborating record

The reasoning was performed in the W3C evaluation during the re-decision -
a document the previous survey never saw (PR-5). Section 8.3 derives it
exactly, with worked numbers:

```text
"No local threshold can distinguish two physically different causes that
produce the same pixel footprint."

"This does not prove A gives bad pictures. It proves tuning cannot remove the
failure class in principle."
```

The evaluation also demonstrates it is not probabilistic: for `d=2` under
illustrative 8-bit thresholds, every scale from 1.00 down to 0.25 activates,
and rejecting the pattern requires a threshold that also rejects a genuine
two-level seam with the identical six samples.

## What the authority states, and what it omits

```text
STATES:   the limit itself, correctly and completely.
OMITS:    any statement that it constrains architectures other than A.
CONTEXT:  filed inside the A rejection proof; the closing paragraph is
          entirely about `midpoint_threshold_scale`, a parameter of the
          rejected design.
```

## Adjudication

**The universality claim is CORRECT** - and it is derivable from the quoted
construction alone, without appeal to the outgoing designer's authority. The
construction makes no reference to Architecture A. It is a statement about any
local activation gate reading six samples around a candidate position: if two
physically different causes present identical samples, no function of those
samples can separate them. That is information-theoretic, not architectural.
Every architecture's kernel predicate is such a function. So every
architecture's kernel gating inherits the limit.

**But the outgoing designer's framing is imprecise in a way that matters**,
and this is the part W3D did not inherit and should be tested hardest:

```text
THE LIMIT IS UNIVERSAL FOR KERNEL GATING - deciding WHETHER a scheduled
candidate is an artifact.

IT IS NOT UNIVERSAL IN CONSEQUENCE. What differs between architectures is
whether the local gate is also load-bearing for GEOMETRY - deciding WHERE the
edge is.

    Architecture A     made the local gate resolve BOTH. It hypothesised two
                       candidate positions and relied on activation to sort
                       out which was real. A false activation therefore meant
                       filtering a position that was not an edge at all.
                       THIS is why the limit was fatal to A specifically.

    Architecture B2    resolves geometry by classifying macroblock STRUCTURE,
                       then gates locally at a position already believed to be
                       a real transform edge. A false activation is an
                       ordinary filter false-positive, not a phantom edge.

    Architecture D     is IN BETWEEN, and this is not a detail. D retains ONE
                       uncertain internal pitch-1 candidate whose reality is
                       decided locally - so D inherits a residual dose of
                       exactly A's problem. The authority already lists this
                       at line 907 as D's first risk: "false activation at the
                       internal pitch-1 candidate in a FIELD macroblock".
```

## Consequences

```text
FOR T5 (load-bearing): the outgoing designer's stated consequence - that this
limit is WHY B2 classifies structure rather than relying on edge-local
evidence alone - is CORRECT and survives the refinement above. T5 must treat
it as a boundary condition: it caps what any activation threshold can achieve
on flat content, and it is the reason the detector exists at all. A detector
derived without it in view would be derived half-blind.

FOR Q14's D LEG: D's residual exposure is a measurable quantity, not a
footnote. D's independent viability bar must include the false-activation rate
at its internal pitch-1 candidate, because that is where D still asks a local
gate to do geometry work. This strengthens the existing rule that D must earn
viability on its own criteria rather than winning by default.

FOR FUTURE READERS: do NOT re-derive this as a B2-specific problem later. It
is general, it is already proved, and re-deriving it would waste a round and
risk reaching a narrower conclusion.
```

## Disposition

```text
DISPOSITION  CURRENT-UNIQUE, but MISFILED.
             The content is correct and is the only statement of it. Its
             LOCATION is the defect: a general constraint on all kernel gating
             sits inside one rejected architecture's rejection proof, where a
             reader looking for detector boundary conditions will not find it.
CONFLICTS    none.
PREVAILS     n/a - no competing statement exists.
PROPOSED
ACTION       W3X-ratified authority version bump: relocate or restate 12.5 as
             a general constraint in its own right, with the A-specific
             consequence retained in section 12 as an APPLICATION of it. Add
             the architecture gradation above, including D's residual
             exposure.
             THIS IS A PROPOSAL. W3D does not edit the ratified authority.
TIER         A
VERDICT      [W3C]
```

**Why this cannot wait for T1 to close:** T5 is blocked on it, and the
proposed action is a version bump to the authority that T5 will then derive
from. Bringing it now is the intended behaviour of the risk-ordered step plan.

---

# LED-002  PR-2: the tc0-unscaled principle

## Source, quoted

Authority v1.05 section 9.1, lines 736-745. The two passages are four lines
apart:

```text
[narrative, describing what the REJECTED design did]

`tc0` and the one-sample correction addition were deliberately not scaled, so a
midpoint that activated was corrected at normal strength.

[the retained-ideas list, four lines later]

Good engineering ideas retained from A:

- creation-time fixed-point conversion;
- immutable threshold sets;
- no float/multiply in the pixel loop;
- deterministic/stateless operation;
- uncertainty should be measurable and explicit.
```

## The principle at stake

Stated plainly: **evidence thresholds may be tightened, but a test that PASSES
corrects at FULL strength. Do not half-correct.**

The outgoing designer's independent list of retained engineering (evidence
document Q2, classified JUDGEMENT - a position to test) records this as S5 and
flags it as easily lost, having been a one-line remark in README 3.13.

## Adjudication

**The principle is present in the authority but not as a principle.** It
appears only inside the narrative describing Architecture A's mechanism, and
is absent from the retained-ideas list four lines below it. Since A is
rejected, the sentence now reads as a description of a dead design rather than
a rule that still binds.

**Is it a standing principle, or was it A-specific?** Standing, and the reason
is structural rather than historical. The two decisions are independent:

```text
WHERE to set the evidence bar   - a question about how much confidence is
                                  required before acting.
HOW MUCH to correct once past it - a question about what the correct output is
                                  at a position agreed to be an artifact.
```

Coupling them - tightening the bar AND softening the correction - applies a
partial fix at positions that passed a stricter test, which is the worst of
both: it neither leaves real detail alone nor properly removes the artifact.
Nothing in that reasoning depends on Architecture A. It applies to any design
that scales an evidence threshold, which explicitly includes Architecture D:
the authority permits an A-derived threshold scale at D's uncertain internal
candidate (section 11, and D4-Q05), so the coupling question arises there
directly.

**Note the connection to LED-001.** The two are the same subject seen from
opposite ends: LED-001 says threshold tuning cannot eliminate the error class,
only trade it; LED-002 says that once you have paid for a tighter threshold,
you should not also pay again by weakening the correction. Reading 12.5's
closing line - that midpoint scaling "changes the hard pass/fail activation
threshold and the old A design then applies normal correction strength" -
shows the authority states both halves without ever naming the second as a
principle.

## Disposition

```text
DISPOSITION  SUPERSEDED-IN-FORM, CURRENT-IN-SUBSTANCE.
             The statement's content is live; its PRESENTATION as history of a
             rejected design is what has decayed.
             Per DEC-15 all SUPERSEDED-class entries are Tier A regardless of
             remedy - this one qualifies on presentation, not on content, and
             the tier is retained.
CONFLICTS    none in content. Tension in status: the same document narrates it
             as A history and omits it from the ideas it says it retained.
PREVAILS     the principle stands.
PROPOSED
ACTION       W3X-ratified authority version bump: add the tc0-unscaled rule to
             the section 9.1 retained-ideas list as a sixth item, stated as a
             standing kernel principle, with the A narrative left as its
             origin. PROPOSAL only.
TIER         A
VERDICT      [W3C]
```

---

# What W3C is asked here

Beyond the five standing questions, three specific things:

```text
1. LED-001's GRADATION is W3D's own derivation, not inherited from anyone.
   Argue it from the quoted construction. If the limit is broader or narrower
   than stated - in particular if B2's kernel gate is MORE exposed than
   claimed, or if D's residual exposure is smaller than claimed - say so.
   Getting this wrong mis-shapes T5.

2. LED-002 asks whether a principle can be "current in substance, superseded
   in form". That is not one of the five standard dispositions. If that
   framing is a dodge, say so and name which of the five it should be.

3. BOTH proposed actions are authority version bumps. W3D wrote both the
   finding and the remedy, which is exactly the self-affecting shape charter
   I7 covers. Test the remedy as hard as the finding.
```

No other authority sections are adjudicated in this tranche. The remaining
T1S01a content follows; T1S01b then adjudicates the architecture re-decision
record and the GAIS evidence in their own right.

---

*Revision history*
```text
v1.0 (2026-08-18) First tranche of T1S01a. PR-1 adjudicated as CORRECT with a
     W3D-derived refinement distinguishing universality of the limit from
     universality of its consequence, and identifying D's residual exposure at
     its uncertain internal candidate. PR-2 adjudicated as a live principle
     that has decayed into rejection-narrative history. Both carry proposed
     authority version bumps, neither of which W3D may make.
```
