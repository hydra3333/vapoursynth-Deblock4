# Deblock4 - T1S01a1_B W3C Review of PR-1 and PR-2

**Deliverable:** T1S01a1_B - CODER RESPONSE
**Version:** 1.0
**Date:** 2026-08-18
**From:** W3C
**Route:** W3C -> W3X -> W3D
**Reviewed:** `T1S01a1_A_Ledger_PR1_PR2_v1_0.md`
**Reference set used:** complete supplied `dev_documentation` corpus
(2026-08-18 03:35 generation), the current source tree already supplied in
this chat, T1 review scope v1.5, Task Register v1.6, MPEG-2 authority v1.05,
README v1.12, and Charter v1.29.
**Scope:** Tier-A review of LED-001 / PR-1 and LED-002 / PR-2 only.
**Encoding:** US-ASCII; CRLF.

---

# Summary

I agree with the core information-theoretic observation behind PR-1, but I
DISAGREE with the ledger's breadth and with part of its proposed remedy. The
six-sample construction proves an observation-limited indistinguishability
result; it does not prove that every future Deblock4 kernel predicate uses only
that observation, nor that this limit is literally "the reason the detector
exists at all." The authority already contains the important architecture-level
generalisation in section 13.1: a local artifact predicate must not become an
implicit geometry classifier.

I DISAGREE more strongly with PR-2. The source proves that rejected
Architecture A deliberately left `tc0` and the one-sample correction addition
unscaled. It does not prove a project-wide standing rule that stricter evidence
must always be followed by unscaled/full correction strength. The authority
explicitly leaves final luma predicate, correction formula, thresholds/strength
behaviour and D's internal-candidate strictness OPEN.

The first ledger also exposes a METHOD issue: both entries mix the disposition
of an EXISTING source statement with a newly derived/generalised proposition.
That should be separated before the pattern reaches later tranches.

---

# DECISIONS/QUESTIONS FOR W3X

## Q1 - METHOD: separate source disposition from newly derived/missing propositions?

**Recommendation: YES, before the next ledger tranche.**

The five `DISPOSITION` values classify an EXISTING statement. They should not
be stretched to carry a new rule that the source does not actually state.

Recommended ledger discipline:

```text
DISPOSITION
    exactly one of the five registered values, applied only to the quoted
    existing statement.

OMISSION / DERIVED PROPOSITION
    separate field, used when review concludes that a broader rule or missing
    statement ought to exist elsewhere.

PROPOSED ACTION
    says what W3D proposes W3X do about the existing statement and/or the
    separately identified omission.
```

Why this matters immediately:

- LED-001 says `CURRENT-UNIQUE, but MISFILED`, then proposes adding a broader
  general rule not actually contained in the source.
- LED-002 invents `SUPERSEDED-IN-FORM, CURRENT-IN-SUBSTANCE`, which is not one
  of the five permitted dispositions.

The current two entries remain reviewable and do NOT need to be thrown away,
but the template should be corrected before T1S01a2.

**Refs:** METHOD-F1; LED-001; LED-002.

## Q2 - PR-1: what should be ratified so T5 can eventually proceed?

**Recommendation: RATIFY THE NARROWED OBSERVATION-LIMIT PRINCIPLE, not the
ledger's full wording.**

Recommended substance:

```text
If two physically different causes produce identical values for every input
available to a decision rule, that rule cannot distinguish the causes.

Therefore a local artifact predicate cannot be relied upon as an implicit
geometry classifier. Tightening a local activation threshold trades false
positives against misses; it cannot prove causal origin when its observations
are identical.
```

Recommended authority placement: section 13.1, beside the already-ratified
scheduler/kernel separation rule, with section 12.5 retained as the
Architecture-A application/counterexample.

Do NOT ratify these stronger ledger statements:

```text
"Every architecture's kernel predicate is such a function."
"this ... is the reason the detector exists at all."
```

The final D4 luma predicate and footprint are explicitly OPEN, and B2's
structure classifier exists to recover hidden transform topology/dct_type, not
to solve the semantic natural-edge-versus-compression-seam problem.

The useful architecture consequence is narrower:

- A used a local activation gate as part of choosing between competing
  geometry hypotheses, so the observation limit compounded A's geometry
  problem.
- B2 chooses geometry separately; its later artifact predicate STILL has
  ordinary natural-edge false-positive risk at real scheduled transform edges.
- D retains one uncertain internal candidate, so its local gate still carries
  some geometry-selection burden there.

Sections 11 and 15.3 ALREADY record D's residual false-candidate exposure. Do
not duplicate that whole gradation into a second authority location.

This resolution is sufficient to give T5 the correct boundary condition once
W3X records it in the authority. It does not settle T5 detector mathematics.

**Refs:** LED-001; authority 9.3, 11, 12.5, 13.1, 15.3, 21 D4-Q02/D4-Q04,
Appendix D.

## Q3 - PR-2: make "strict evidence -> full correction strength" a standing kernel rule?

**Recommendation: NO.**

Keep the source statement as a correct fact about rejected Architecture A.
Do NOT add it to the retained-ideas list as a standing kernel principle.

If W3X wants to preserve the question, record it as an OPEN kernel/quality
decision under D4-Q02 / D4-Q05:

```text
If a future D-specific confidence/strictness control changes only the
activation evidence threshold, should the correction law/limit remain
unchanged, or should correction magnitude also depend on that confidence?
```

That is a design/quality question, not something proved by Architecture A's
old choice.

**Refs:** LED-002; authority 9.1, 11, 21 D4-Q02/D4-Q05, Appendix D; README
3.13-3.14.

---

# METHOD-F1 - the first ledger is conflating adjudication with invention

**VERDICT: METHOD BLOCKER FOR FUTURE TRANCHES; current tranche remains
reviewable.**

The scope gives five dispositions for statements already present in the
documentation. Both first entries use the disposition field to carry a second
operation: deriving a broader principle that the quoted source does not state.

That makes the taxonomy elastic:

```text
LED-001  CURRENT-UNIQUE + "MISFILED" + new universality/gradation content
LED-002  SUPERSEDED-IN-FORM, CURRENT-IN-SUBSTANCE
```

The danger is not cosmetic. Later reviewers could make a source statement
"current in substance" by first inventing the substance they wish it had.

Use the strict split in Q1. A missing/generalised rule can still be found by
Q-D and proposed to W3X; it simply must not mutate the source statement's
disposition.

---

# LED-001 / PR-1 - in-principle false-activation limit

**W3C VERDICT: DISAGREE AS WRITTEN; AGREE WITH A NARROWER CORE.**

## Q-A - does the quoted source support the conclusion?

**PARTLY.**

Supported directly:

```text
For the stated local observation
    p2,p1,p0 = A,A,A
    q0,q1,q2 = A+d,A+d,A+d

two different physical causes that present that identical observation cannot
be distinguished by a decision rule whose inputs are restricted to that
observation.

Changing the threshold changes the error trade; it cannot create information
that is absent from the inputs.
```

Not supported by that construction:

```text
"Every architecture's kernel predicate is such a function."
```

Authority v1.05 Appendix D explicitly says the final luma predicate and final
read/write footprint are NOT YET FROZEN. A future predicate may use a larger
observation vector or future trusted side data. The correct universal statement
must therefore be conditional on the **complete observation available to the
decision rule**, not hard-coded to six samples.

Also not proved by the construction:

```text
"it is the reason the detector exists at all"
```

B2's map producer exists because the transform organisation/dct_type is hidden
after decode and the scheduler needs topology. The local false-activation
construction is a reason NOT to use the local artifact gate as the geometry
classifier; it is not the sole causal reason B2 needs a topology classifier.

## Q-B - is the disposition right?

**The existing section-12.5 statement is CURRENT.**

`CURRENT-UNIQUE, but MISFILED` is not a clean use of the disposition taxonomy.
The section-12.5 statement is a valid Architecture-A rejection/application
record and should remain there.

What is missing is a **separate general observation-limit statement** near
section 13.1. That is an omission/new authority proposition, not a different
disposition of the existing A-specific application.

## Q-C - does anything wrongly prevail?

There is no direct competing statement.

However, the proposed generalisation must not prevail over the authority's
explicit OPEN status for final kernel mathematics. Ratifying an
observation-limit principle does not freeze the future predicate's input
footprint or formula.

## Q-D - what did the ledger walk past?

Four existing authority passages materially constrain the proposed remedy:

1. **Section 9.3** already separates map/topology from the D4-owned local
   artifact predicate.
2. **Section 13.1** already states the general architecture rule:
   `Do not let a local edge predicate become an implicit geometry classifier.`
   This is the natural home for the observation-limit principle.
3. **Section 11 and section 15.3** already identify and measure D's false
   internal candidate in FIELD macroblocks. The proposed action should not
   duplicate that whole gradation elsewhere.
4. **Section 21 D4-Q02/D4-Q04 and Appendix D** explicitly leave the final
   predicate and footprint open.

The ledger's `OMITS any statement that it constrains architectures other than A`
is therefore too strong. The authority omits the **information-theoretic
statement in general form**, but it already contains the general
scheduler-versus-local-predicate consequence.

## Q-E - anything relying on something untrue?

Three phrases are too strong:

```text
"Every architecture's kernel predicate is such a function."
```

Unsupported because final predicate/footprint remain open.

```text
"A false activation [under B2] is an ordinary filter false-positive, not a
phantom edge."
```

The distinction is correct, but it must not imply harmlessness. B2 does not
solve natural-edge false positives; it only prevents the artifact predicate
from selecting competing geometry.

```text
"THIS is why the limit was fatal to A specifically."
```

Overstated. A has independent rejection proofs: wrong whole-frame footprint,
colliding faithful hypotheses and candidate-count cost. The false-activation
floor compounds A's design but is not the sole reason A fails.

## Proposed corrected action

Keep section 12.5 as the A-specific application.

Add a short observation-limit paragraph to section 13.1, immediately adjacent
to the existing "do not let a local edge predicate become an implicit geometry
classifier" rule, and cross-reference section 12.5.

Do NOT duplicate the full A/B2/D gradation there; sections 9.3, 11 and 15.3
already own those consequences.

---

# LED-002 / PR-2 - `tc0` unscaled after stricter activation

**W3C VERDICT: DISAGREE.**

## Q-A - does the quoted source support the conclusion?

The quote supports one fact:

```text
Architecture A scaled midpoint alpha/beta but deliberately did NOT scale tc0
or the one-sample correction addition; an activated midpoint used the normal
A correction law/limit.
```

It does NOT support this general rule:

```text
"evidence thresholds may be tightened, but a test that PASSES corrects at
FULL strength - do not half-correct."
```

That is a new design proposition.

The ledger's structural argument does not prove it. Detection confidence and
correction magnitude can be separate controls, but "separate" does not mean
they are forbidden from being intentionally coupled by a future algorithm.

## Q-B - is the outcome right?

**No.**

`SUPERSEDED-IN-FORM, CURRENT-IN-SUBSTANCE` is not one of the five permitted
dispositions and, more importantly, assumes the disputed conclusion.

The existing authority sentence is still a correct historical statement about
Architecture A. It is not superseded merely because A is rejected.

For T1 purposes the exact duplicate/home status can be reconciled when the
README counterpart is adjudicated, but the statement is certainly not a
superseded general principle because no such general principle has yet been
ratified.

## Q-C - what prevails?

There is no content conflict requiring one statement to beat another.

The omission from the section-9.1 "retained ideas" list is evidence AGAINST
claiming that v1.05 already retained this as a standing rule. It should not be
silently promoted merely because the old A mechanism once used it.

## Q-D - what did the ledger walk past?

The authority contains explicit contrary-to-closure status:

- **D4-Q02**: final luma kernel mathematics OPEN.
- **D4-Q05**: the old threshold-scale mechanism is rejected; a threshold-scaling
  IDEA may be measured for D, with no automatic right to survive.
- **Appendix D**: final luma boundary/activity predicate, final luma correction
  formula, D internal-candidate strictness and final thresholds/strength
  behaviour are NOT YET FROZEN.
- **Section 15.3** requires a strictness/threshold sweep for D rather than
  pre-declaring the strength behaviour.

The README also demonstrates why the ledger's claimed structural separation is
not a project-wide invariant: its `boundary_strength_offset` intentionally
moves both `alpha` and `tc0`, changing acceptance AND the correction limit.
That older specification may itself be adjudicated later, but it is enough to
show that the project has not historically treated acceptance and correction
strength as logically forbidden from coupling.

## Q-E - anything relying on something untrue?

Yes:

```text
"tightening the bar AND softening the correction ... is the worst of both"
```

That is an unsupported quality judgement, not a logical consequence. A future
algorithm could deliberately choose a conservative, confidence-weighted
correction. Whether that is good Deblock4 behaviour is an empirical/algorithmic
question.

Also, "FULL strength" is dangerously imprecise. Unscaled `tc0` does not mean
the maximum possible delta is always applied; the actual correction remains
sample-dependent and clipped by the normal formula. The accurate historical
statement is "normal/unscaled correction law and correction limit."

## Proposed corrected action

Do not add a sixth retained-idea rule to section 9.1.

If W3X wants the issue preserved, add or clarify an OPEN D4-Q02/D4-Q05 question:

```text
If a future uncertainty/strictness control changes the evidence threshold,
whether it also changes the correction law/limit is a separate kernel/quality
decision and must be specified and validated; Architecture A's unscaled choice
is prior-art/design history, not authority for the answer.
```

That preserves the potentially useful idea without prematurely freezing kernel
behaviour.

---

# Additional observations

## A1 - PR-1 does still matter to T5

My narrowing does NOT make PR-1 irrelevant.

T5 must not derive a classifier whose decisive geometry decision simply
repackages the same local artifact predicate. The observation-limit principle
and section 13.1 together are a legitimate boundary condition on T5.

What T5 is free to do is use broader macroblock-structure evidence, which is
precisely why the observation domain must be stated correctly.

## A2 - B2 does not solve artifact-cause ambiguity

This distinction should stay explicit in future authority wording:

```text
B2 solves / estimates TRANSFORM TOPOLOGY.
The local D4 predicate still decides FILTERABILITY at the scheduled topology.
```

A natural edge that happens to lie on a true transform boundary can still be
misclassified by the artifact predicate. B2 removes the phantom-geometry class,
not the ordinary artifact false-positive class.

## A3 - no source implementation fact changes these two entries

The current Deblock4 dispatch path remains pass-through; no D4 pixel kernel is
implemented. Nothing in current source can promote PR-2 from design proposal to
operative specification.

---

# Release / next-tranche recommendation

**Do not propagate the present elastic disposition format into T1S01a2.**

W3D should first absorb METHOD-F1 into the ledger template.

Substantively:

- PR-1 can be resolved now by W3X in the narrowed form recommended in Q2 and
  then recorded into the authority before T5 begins.
- PR-2 should NOT be promoted to a standing kernel principle; preserve it as
  Architecture-A history and, if useful, an OPEN future kernel/quality question.

After the method correction, T1S01a may continue with the remaining authority
tranches. No broad re-review of this tranche is needed unless W3D disputes or
materially changes these adjudications; the final three-way process remains the
normal closure mechanism.
