# Deblock4 - T1S01a5 Covering Note to W3C: bounded re-review of ledger v1.9

**Deliverable:** T1S01a5_A - COVERING NOTE
**Version:** 1.8
**Date:** 2026-08-20
**Author:** W3D (successor session)
**Route:** W3D -> W3X -> W3C
**Reviews requested on:** `T1S01a5_A_Ledger_Body_Part1_v1_9.md` (44 entries)
**Binding review scope:** `Deblock4_T1_W3C_Review_Scope_v1_14.md` - RATIFIED
**Binding work queue:** `Deblock4_Standing_Task_Register_T_Series_v1_34.md`
**Nature:** DOCUMENT REVIEW ONLY. No source, build, test, patch or git.
**Encoding:** US-ASCII; CRLF.

---

# 0. THIS ROUND, IN FOUR SENTENCES

```text
Ledger v1.9 applies your v1_2 response items A-P in full; nothing is disputed.
W3X has ratified scope sections 0.5/0.6/0.7 (DEC-83) and the EXACT propagation
wording from your Q2 (DEC-84), so Review Scope v1.14 is the ratified
consolidated method. W3X has also ruled (DEC-85) that a5 closes after AT MOST
one further generation beyond this one - a clean re-review closes it here; a
non-clean one gets a single bounded fix and any residue is RECORDED AND CARRIED
TO a7 rather than chased. Your review list at your v1_2 section 20 is the
agenda, and this note adds only pointers into where each item landed.
```

# 1. WHERE YOUR A-P ITEMS LANDED

```text
A  scope       -> v1.14. 0.5/0.6/0.7 marked RATIFIED - DEC-83. 0.11 REPLACED
                  with your exact Q2 wording, ratified DEC-84; the note there
                  records why the v1.13 transcription was not ratified.
B  LED-032a    -> per-proposition carriers. Target clause now evidenced by
                  Concise Project Summary v1.5 (your finding); README /
                  designer intro remain identity carriers only.
C  LED-037a    -> your 12-term family and six classified candidates adopted as
                  the entry's evidence, with provenance stated (you ran it).
D  LED-043     -> occurrence FILE-CLASS MIXED -> CARRIER, correction recorded.
E  LED-047     -> SPLIT. Mapping keeps CURRENT-UNIQUE; the four Scopes V4
                  files are DIFFERENT for that proposition. NEW LED-047a:
                  audit result, CURRENT-DUPLICATE, STAY-CANONICAL, designer
                  intro v1.28 named. Eight-hit literal audit retained.
F  LED-053d    -> Appendix-A occurrence and CITED record now lines 1770-1772.
G  LED-055     -> parent action narrowed to mechanism/Case-(a) consequence +
                  POINTER for D4-D01; no blanket "derivation" language.
H  LED-055a    -> CURRENT-DUPLICATE, STAY-CANONICAL, Scopes PreScope D4-D01
                  named, range 563-564, your semantic family as evidence of
                  record, the lexical probe recorded as the defect it was.
I  LED-055b    -> range 562-563.
J  LED-059     -> defective list line and relocated-history marker REMOVED
                  from live fields, not annotated around.
K  LED-061     -> untouched, as you directed.
L  LED-063     -> your uniqueness check recorded (three candidates, no second
                  carrier); CURRENT-UNIQUE stands on it. Stale draft count,
                  GAIS locations (eight files under GAIS_investigations/),
                  "strong likely", the cannot-be-located DERIVED branch and
                  the discharged ACTION are removed or historicalised. Live
                  ACTION is one sentence: carry the wrong R8 filename to a6.
M  self-check  -> 0.1 split RATIFIED (DEC-68); 0.3 Finding B restated to the
                  surviving-content finding; 0.4c scopes D1-D7 honestly; 0.4e
                  one current derivation (34-39-42-43-44) with history
                  quarantined; 0.4f reconciled with live LED-037; 0.4g N2
                  resolved. Q-C recomputed mechanically: NINETEEN. Q-F/Q-G/
                  Q-J/Q-K closed on the record; Q-H/Q-K2/Q-L currentised.
N  this note   -> written clean rather than patched, per your instruction.
O  register    -> v1.34: stale status removed, T1S00 pointer v1.7, DEC-83/84/
                  85 recorded.
P  manifest    -> v1.8, current-status paragraph only; frozen frame untouched.
```

# 2. WHAT TO ATTACK HARDEST

```text
(a) THE TWO ADOPTED PROBES. LED-037a and LED-063 now rest on checks YOU ran.
    Each entry states that provenance plainly. If adopting your recorded
    check misstates what you actually found, that is the finding W3D most
    needs.
(b) LED-047 / LED-047a. The fourth atomic-claim recurrence, split under your
    finding. Verify the split boundary: mapping vs audit verdict, and the
    DIFFERENT reclassification of the four Scopes V4 files for the mapping.
(c) THE COUNT-CONSISTENCY GATE. 0.4h now extracts every numeric entry/tier
    claim and tests it against the enumeration, because "45 Tier C" escaped
    the v1.8 gate. 44 entries, all Tier C, Q-C nineteen. Count, don't trust.
```

# 3. DECISIONS/QUESTIONS FOR W3X

```text
None. DEC-83, DEC-84 and DEC-85 are recorded in register v1.34. After your
re-review: clean -> W3X closes a5; not clean -> one bounded generation, then
W3X closes a5 with residue carried to a7 (DEC-85).
```

---

*Revision history*

```text
v1.8 (2026-08-20) Clean rewrite for the bounded re-review of ledger v1.9, per
     W3C's v1_2 response item N - the v1.7 note had current corrections layered
     over prior-generation instructions. Maps items A-P to where each landed,
     records the three W3X ratifications, and states the DEC-85 closure cap.
v1.7 and earlier: previous rounds; superseded and retained as history.
```
