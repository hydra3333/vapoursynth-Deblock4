# Deblock4 - W3C Review Scope: the T1 Documentation Consolidation Sweep

**Deliverable:** T1-W3C-REVIEW-SCOPE
**Version:** 1.14 - RATIFIED CONSOLIDATED METHOD
**Date:** 2026-08-19
**Author:** W3D (designer), issued to W3C by W3X.
The v1.12 consolidation was PROPOSED BY W3C, drafted by W3D, and is verified by
W3C and ratified by W3X - so the party the criteria judge is not the party that
asked for them (charter I7).
**Route:** W3D -> W3X -> W3C
**Status:** BOUNDED REVIEW SCOPE. Live once W3X issues it.
**Encoding:** US-ASCII; CRLF.

---

# 0. CONSOLIDATED METHOD - READ BEFORE ANYTHING ELSE

```text
WHY THIS SECTION EXISTS. Between v1.11 and v1.12 the binding rules of this
sweep stopped living in this document. They accumulated in the Standing Task
Register's decision log and in Classification Repair v1.1, while this scope -
the document called BINDING in every batch - kept only the original method.

THAT IS NOT A THEORETICAL HAZARD. A successor designer read v1.11's perfectly
valid generic line "Tier C: W3X selects a random sample", did not see anywhere
in this document that a5's sample had ALREADY been selected and completed, and
asked W3X for something W3X had already provided. It cost a round.

The shape of that failure is the shape of the incident this whole sweep exists
to correct: ratified material sitting unread in a document nobody consolidated.

W3C PROPOSED THIS CONSOLIDATION. NO SUBSTANTIVE RULE IS CHANGED BY IT.

BUT THE RULES BELOW DO NOT ALL HAVE THE SAME STATUS, AND v1.12 WRONGLY SAID
THEY DID. It claimed every rule in this section was "already binding through a
ratified decision". That was false for three of them, and W3C found it.
READ THE STATUS MARKERS - each subsection below carries one:

    [RATIFIED]   already binding through a named ratified decision. This
                 section only relocates it.
    [RATIFIED - DEC-83]   a criterion originated by W3C, drafted by W3D,
                 VERIFIED BY W3C at the delta review of 2026-08-20, and
                 RATIFIED BY W3X on 2026-08-20. The I7 chain is COMPLETE:
                 proposer, drafter, verifier and ratifier are the required
                 different parties, in order.

WHY THE DISTINCTION IS NOT PEDANTRY: recording an I7 chain as complete while
standing in the middle of it is exactly the false-assurance failure DEC-48
records, and v1.12 committed it inside the document written to consolidate the
rules against that class of error.
```

## 0.1 STANDING NOTICE - T1S01a5 TIER C IS COMPLETE   [RATIFIED - DEC-73]

```text
FOR T1S01a5 ONLY:
    TIER C SAMPLING IS COMPLETE.
    W3X selected ELEVEN entries: LED-034, LED-037, LED-040, LED-043, LED-046,
    LED-049, LED-051a, LED-053, LED-055, LED-058, LED-061.
    W3C reviewed exactly those eleven.
    RESULT: 3 AGREE / 8 DISAGREE / 0 UNSURE / 0 MISSING.
    DO NOT SELECT OR REVIEW ANOTHER a5 TIER C SAMPLE.        (DEC-73)

ALSO SETTLED FOR a5 AND NOT TO BE REOPENED:
    the 22-probe search round - settled and independently reproduced;
    Classification Repair v1.1 - substantively settled;
    the a5/a5b split at the section 8/9 boundary - ratified at DEC-68;
    DEC-67's search methodology.

The generic Tier C instruction in section 6 remains correct FOR EVERY OTHER
SUB-TRANCHE. It is not the live instruction for a5.
```

## 0.2 THE POPULATIONS AND THE THREE MECHANICAL EXCLUSIONS   [RATIFIED - DEC-60/63/66]

```text
THREE POPULATIONS EXIST. THEY ARE NOT RECONCILED BY REWRITING HISTORY.
    47   frozen T1S00 survey record - what was surveyed on 2026-08-18
    41   current T1 adjudication population, after DEC-66
    46   settled a5 SEARCH snapshot - what a5's SWEPT fields ran over

EXCLUSIONS, ALL PATH-MECHANICAL, NOT JUDGEMENTAL:
    folders beginning "superseded" or "scheduled_for_deletion"        DEC-60
    everything under T1/                                             DEC-63
    everything under GAIS_investigations/                             DEC-66

POPULATION IS AN INVENTORY, NOT A SEARCH RESULT. A zero-hit document is still
a population member. T1/ is a workshop, not a knowledge shelf: material there
cannot establish or refute a uniqueness result by existing. GAIS_investigations/
is ignored for search AND adjudication alike; the files remain as history.

EACH SUB-TRANCHE DERIVES ITS OWN POPULATION. It does not inherit an earlier
snapshot. a5's 46 is a5's evidence of record; a search run today would not
return the same 46.
```

## 0.3 THE THREE SWEEP RULES AND THEIR COROLLARY   [RATIFIED - DEC-67]

```text
RATIFIED AT DEC-67.

RULE 1  OPEN EVERY HIT. A returned candidate that is not classified is NOT
        SWEPT.
RULE 2  NORMALISE WHITESPACE for phrase searches. The corpus wraps sentences
        across lines, so raw line matching returns silent zeroes.
RULE 3  SEARCH THE PROPOSITION, NOT MERELY THE SOURCE SENTENCE, in the bounded
        form:
            declare the proposition;
            declare a bounded probe family covering its material concepts,
                including the source wording and reasonable independent
                reformulations;
            run it over the declared population;
            open every candidate file;
            classify each occurrence;
            if a genuine carrier exposes an equivalent phrasing the family
                missed, ADD IT, RECORD WHY, and rerun the SAME population;
            claim no exhaustiveness beyond the declared population and probe
                family.

THE COROLLARY, WHICH SURVIVED ALL THREE RULES AND IS THE ONE TO CARRY:
    OPENING A HIT IS NOT THE SAME AS READING IT.
In the a5 re-sweep every hit was opened as Rule 1 requires and SEVEN FILES
WERE STILL MISCLASSIFIED. A Zig comment about a version string was counted as
the MPEG-2 single-source rule. Charter I7 independent verification was counted
as the GAIS rule. The substring inside the identifier D4-Q01 was counted as
the edge-position convention.

AND: A COUNT THAT COMES OUT RIGHT CAN STILL HAVE THE WRONG MEMBERS. In one
entry a false candidate entered while a real carrier escaped the probe, and
the two cancelled to give the correct total. COMPARE THE LISTS, NOT THE TOTALS.
```

## 0.4 THE CLASSIFICATION LABELS   [RATIFIED - Classification Repair v1.1]

```text
FROM CLASSIFICATION REPAIR v1.1, CONSOLIDATED HERE SO THE BINDING SCOPE
CONTAINS THEM.

    CARRIER     the passage ASSERTS the proposition.
    APPLIES     the passage USES or DEPENDS ON it without stating it.
    DIFFERENT   a lexical hit for a DIFFERENT proposition.
    IDENTIFIER  the match is a source symbol or project identifier, not prose.
    NOISE       binary or archive content decoded as text.
    MIXED       ONE FILE CARRIES MORE THAN ONE MEANING.

    CANONICAL   not a sixth non-carrier category. It is the HOME MARKER shown
                separately for the proposed canonical home. W3C asked that it
                be listed explicitly here so nobody wonders why the register's
                condensed list omits it.

A WORKING TEST FOR THE CARRIER/APPLIES BOUNDARY, offered as guidance and NOT
as a binding mechanical criterion: could a cold reader recover the proposition
from this passage WITHOUT already knowing it? If yes, lean CARRIER. If it only
works by assuming the proposition, lean APPLIES.

MIXED IS NOT FOR REPEATED PROPOSITIONS. Do not use MIXED merely because the
same proposition occurs twice in one file. See 0.5.
```

## 0.5 OCCURRENCE-LEVEL EVIDENCE   [RATIFIED - DEC-83]

```text
THE GOVERNING RULE:
    A FILE-LEVEL SEARCH HIT DOES NOT ESTABLISH OCCURRENCE-LEVEL UNIQUENESS
    INSIDE THAT FILE.

The harness returns ONE file even when the proposition occurs twice in it, in
sections owned by DIFFERENT sub-tranches. a5 met this once, at LED-053d, where
authority section 4.5 and Appendix A state the same proposition and only one
hit was returned. MIXED was stretched to cover it; that was pragmatic and is
NOT a redefinition.

WHERE IT MATERIALLY MATTERS, record occurrences rather than inventing another
top-level class:

    FILE:         <path>
    FILE-CLASS:   CARRIER / APPLIES / DIFFERENT / IDENTIFIER / NOISE / MIXED
    OCCURRENCES:
        <section or line range>   CANONICAL occurrence of proposition P
        <section or line range>   CARRIER occurrence of proposition P

THIS MATTERS MOST AT T1S01a6, which holds Appendix A, section 24 and the D4
registers - all of which restate propositions from the body.
```

## 0.6 CITED-OUTSIDE-RANGE   [RATIFIED - DEC-83]

```text
WHEN EVIDENCE FOR A DISPOSITION LIES IN ANOTHER SUB-TRANCHE'S TERRITORY, the
carrier MAY affect the current disposition, and the out-of-range occurrence
REMAINS for its owning sub-tranche. Adjudicating it here would breach the
tranche boundary - the DEC-56 overlap defect. Citing it without recording the
obligation leaves the later tranche free to reach an inconsistent conclusion.

RECORD IT EXPLICITLY:

    CITED-OUTSIDE-RANGE:
        location
        proposition
        evidence use in the current tranche
        owning later tranche
        the later tranche must reconcile the occurrence with this evidence use

T1S01a7's whole-document consistency pass is where these finally reconcile.
```

## 0.7 THE ENTRY-SWEEP GATE   [RATIFIED - DEC-83]

```text
AFTER EDITING ANY FIELD OF AN ENTRY, RE-READ THE WHOLE ENTRY AND CHECK THAT NO
OTHER FIELD CONTRADICTS THE EDIT.

THIS IS DEC-51 AT ENTRY LEVEL, AND IT IS THE FAILURE THAT HAS RECURRED MOST.
Each case below is a real defect in ledger v1.6, where the designer corrected
exactly the field the mandate named and left the rest of the entry stale:

    LED-055  the uniqueness claim was withdrawn in REASON while "the
             DERIVATION -> this section, uniquely" still stood in PREVAILS,
             three lines above it.
    LED-061  SWEPT was rebuilt to classify two files as DIFFERENT while REASON
             and DUPLICATE-ACTION in the SAME ENTRY still listed both as
             carriers. THE ENTRY CONTRADICTED ITSELF.
    LED-043  one half of SWEPT was rebuilt while the other half still named a
             population that DEC-66 excludes.

IT IS PARTLY MECHANICAL: after each edit, diff the entry's remaining fields for
the terms the edit was meant to remove.

THE SAME DISCIPLINE ONE LEVEL UP - ENUMERATE THE ROUNDS, NOT ONLY THE DELTAS.
Ledger v1.5 built its delta list from the classification-repair round alone and
missed two of eight Tier C findings, because the Tier C round preceded it. The
deltas were enumerated meticulously; the ROUNDS were never enumerated at all.
And never name a document as used unless it was opened - v1.5's provenance
section listed the Tier C review among artifacts used when it had not been.
```

## 0.8 CHECK EVIDENCE, PARTIAL REPLACEMENT AND TIER DERIVATION   [RATIFIED - DEC-50/51/62]

```text
DEC-50 - A CLAIMED CHECK MUST BE INDEPENDENTLY TESTABLE. Identify the actual
object or population and the result or basis. Bounded range or set checks
ENUMERATE the population and results. Other checks state the identifiers and
method used, and must NOT invent an artificial range to look rigorous. A bare
"the set was swept" assurance is NOT evidence. Keep it as short as the check
allows - DEC-50 becomes bureaucratic if every trivial check grows a table.

DEC-51 - AFTER CORRECTING A REJECTED PROPOSITION:
    declare the bounded replacement scope FIRST;
    search for the PROPOSITION, not only the old string;
    enumerate and classify candidate remnants;
    claim nothing beyond the declared method and scope;
    NEVER accept "all fixed" as evidence by itself.

DEC-62 - TIER IS DERIVED FROM DISPOSITION, NEVER TYPED:
    CURRENT-UNIQUE, CURRENT-DUPLICATE  -> C
    CONFLICTING, SUPERSEDED            -> A
    OPERATIVE-SPEC                     -> B
The designer does not choose how hard its own work is reviewed.
```

## 0.9 FORM WITHOUT PURPOSE - HOW THESE RULES FAIL WHILE BEING FOLLOWED   [GUIDANCE]

```text
W3C's own list, recorded because a rule obeyed in form and missed in purpose
is harder to catch than one simply broken:

    OPEN EVERY HIT obeyed, and the passage semantically misclassified;
    the right total containing the wrong members;
    a corrected field with stale framing elsewhere in the same entry;
    a SWEPT probe family that does not actually represent the proposition;
    STAY-CANONICAL naming a concrete copy OF THE WRONG CLAUSE;
    a correctly derived tier sitting on a non-atomic entry;
    a file classification concealing occurrence multiplicity.
```


## 0.10 SOURCE-COVERAGE MAP   [RATIFIED - DEC-77]

```text
AN OVERLAP CHECK AGAINST PRIOR ENTRIES IS NOT A COVERAGE CHECK AGAINST THE
SOURCE. Every sub-tranche owes BOTH.

    OVERLAP CHECK   does any range in this ledger collide with a range already
                    adjudicated by an earlier sub-tranche?
    COVERAGE CHECK  does any proposition INSIDE the declared source range have
                    NO ENTRY?

WHY THIS RULE EXISTS. The a5 ledger enumerated its overlap against 33 prior
entries meticulously, from v1.0 onward, and NEVER ONCE WALKED THE SOURCE RANGE
looking for propositions with no entry. Two were missing - the project-scope
statement at authority line 225 and the default-scope qualification at line 269
- and they survived FIVE LEDGER GENERATIONS AND A TIER C SAMPLE before W3C
checked the source against the entry ranges.

THE OBLIGATION, AND ITS TIMING:
    a5b AND EVERY LATER SUB-TRANCHE MUST PRODUCE AN EXACT SOURCE-COVERAGE MAP
    BEFORE ADJUDICATION, NOT AFTER. Walk the declared range; for every
    proposition, name the entry that adjudicates it; for every gap, either
    write an entry or record why the text carries no adjudicable proposition.
    A coverage map produced afterwards documents what was done rather than
    testing whether it was complete.
```

## 0.11 SUPERSEDED-KIND AND PROPAGATION   [RATIFIED - DEC-84, EXACT W3C WORDING]

```text
RATIFIED BY W3X ON 2026-08-20 IN THE EXACT W3C-VERIFIED WORDING BELOW. The
v1.13 transcription was NOT ratified: it shortened "scope/method" to "scope"
in the final limit and dropped "using the method appropriate to the
proposition" from step 2. Both qualifications are material - a narrow or
unsuitable method must not gain apparent exhaustiveness merely because its
scope was declared. Nothing below may be paraphrased when applied; cite it.

IT BINDS NOW, AND IN ANY CASE BEFORE T3 REACHES THE REJECTED ARCHITECTURE-A
MATERIAL - the first real ERRONEOUS case, and where getting it wrong costs
most.

SUPERSEDED-KIND
    OVERTAKEN | ERRONEOUS

OVERTAKEN
    The statement was valid in its former context/state and has been replaced
    by a later statement. PROPAGATION is normally N/A unless evidence suggests
    dependent work may not remain valid.

ERRONEOUS
    The statement was false, materially misleading, or otherwise invalid in
    the context in which project work may have relied on it.

PROPAGATION - REQUIRED FOR ERRONEOUS
    1. DECLARE THE PROPAGATION SCOPE / POPULATION: identify the bounded set of
       current documents, decisions, code, mathematics, tests or other project
       objects in which reliance could materially survive.
    2. SEARCH FOR RELIANCE ON THE PROPOSITION, NOT MERELY ITS WORDING, using
       the method appropriate to the proposition.
    3. ENUMERATE AND CLASSIFY CANDIDATE DEPENDENCIES, identifying actual
       reliance and non-reliance with attackable location/basis.
    4. ROUTE EACH ACTUAL DEPENDENCY: remains valid for an independent reason,
       needs correction/re-verification, or is itself superseded/erroneous.
    5. If none are found, record "none found" with scope and method.
    6. Claim no exhaustiveness beyond declared scope/method.

PROPAGATION is about potentially affected CURRENT work. It is not an
archaeological search for every historical mention.
```


---

# 1. Read this first: what this scope is NOT

This is not a coding scope. Nothing in it asks you to change, build, patch or
test any source file.

```text
NO source changes.          NO build.        NO proof matrix.
NO delivery package.        NO patch.        NO restore_to_base folder.
NO apply_to_tree folder.    NO git anything.
```

If you find yourself preparing a delivery package, you have misread the scope.
Your entire output is written review, sent as ordinary documents.

One point of charter hygiene, because a bounded scope never suspends a charter
rule. No build, test or proof run happens anywhere in T1, so the standing
restriction on claiming PASS (C-DELIV-07) is simply NOT TRIGGERED here - it is
not waived, relaxed or replaced. You must not imply you executed anything. Your
outputs are review verdicts (AGREE / DISAGREE / UNSURE / MISSING), and none of
them is W3X acceptance of anything.

---

# 2. What is going on, in plain English

The project keeps its knowledge in about twenty documents. Over time the same
facts got written down in several of them, and some of those copies are now
out of date, contradict each other, or describe a design the project has since
rejected. Nobody has ever gone through the whole set systematically.

That is not a hypothetical worry. It has already cost us once, and the story
matters because it explains why this task is shaped the way it is.

```text
WHAT HAPPENED. The designer ran four rounds of external research to settle
how MPEG-2 lays out its blocks and to decide an architecture for the new
filter. That work finished and produced a decided architecture. Then, while
starting to tidy the documents, the designer opened the README - and found
that a complete, already-approved design for the same problem had been
sitting in it the whole time. Nobody in the investigation had read it.

WHY IT WAS MISSED. The designer had swept the source code thoroughly and
swept the decision records thoroughly. The README was skipped because an
index document described it as "fallback general guidance" - and that
description was believed instead of checked. It is a 2,800-line document
containing an approved architecture.

WHAT IT COST. Everything downstream reopened. The just-decided architecture
went back on the table and a full re-evaluation was needed - which you took
part in. The rediscovered design was eventually rejected, but only after
proper analysis, and that analysis produced the current primary candidate,
which is better than what the investigation had reached on its own.

So the near-miss ran BOTH ways: we nearly shipped past good work, and we
nearly missed the argument that improved the design.
```

Task T1 is the sweep that should have happened. The designer reads every
MPEG-2-related statement in every live document and records a decision about
each one: is it still true, is it a duplicate, does it contradict something
else, is it superseded. Those decisions go into a running record called the
LEDGER, one numbered entry per statement.

**Your job is to review those ledger entries.**

---

# 3. Why you specifically, and what W3X is buying

W3X's judgement, which you should take at face value: you have repeatedly
shown independent thinking when asked for it, and the three-way no-fault
review has proved its worth on this project over time. That is the reason
this review exists rather than the designer simply marking their own homework.

Be aware of the specific failure mode you are the defence against. The
designer will read several hundred statements across roughly twenty documents.
Reading attention degrades. More dangerously, PARTIAL FAMILIARITY BREEDS
SKIPPING - the original miss happened because the designer had read parts of
that README earlier in the project, and that is exactly what made skipping it
feel safe. A thin or hurried adjudication will still LOOK like a complete
ledger entry. It will have a document reference, a quoted line and a stated
reason, and it will read as reasonable.

You are being asked to notice when it is not.

**A note on how you will receive the entries.** W3X has decided you get the
ledger with the designer's reasoning already in it, rather than being given
raw document extracts and asked to work them out independently. That is a
deliberate cost decision and it is settled - do not ask to change it. But it
has a known weakness and you should hold it consciously: reading someone's
reasoning makes it easy to find that reasoning reasonable. The designer's
entries are written to be persuasive because that is what writing is. Where an
entry is in the top tier, the source text is included verbatim inside the
entry, so **check the quoted source against the conclusion drawn from it**
rather than checking whether the conclusion sounds sensible.

---

# 4. What arrives, and when

The work is split into six STEPS, not one big document. Each step is roughly
one document's worth of ledger entries. You review one step and send it back;
the next step arrives later, in a different session.

The reason for splitting it up is blunt: two designer sessions have already
died mid-task, and one died holding finished work that was never sent.
Anything not delivered is lost. The same applies to your reviews - send each
step back when you finish it, do not accumulate.

```text
THE SIX STEPS

T1S00  The scope manifest. The list of every document in the sweep and the
       search terms used to build it. NO ledger entries - your job here is
       the fourth pre-registered item (PR-4): review the search terms and
       say what they would still miss.
T1S01  The MPEG-2 authority document. Holds PR-1 and PR-2.
T1S02  The README, part 1 - decision-status table, sections 3.11 to 6.2,
       and the F12-F17 findings series.
T1S03  The README, part 2 - Appendices A and B, section 20.
T1S04  The charter (read, never stripped; holds PR-3), plus the D0
       knowledge index and the D2 HolyWu schedule document (holds PR-4).
T1S05  Everything remaining - project status, verification and tiering,
       the old grid-knowledge document, roadmap, currency audit, the
       chat introductions and blurbs, and the smaller records.
```

## 4.0a A step may arrive in SUB-TRANCHES

A step covering a large document is delivered in parts. Each part is a
separately reviewable package with its own number, and you review each as it
lands rather than waiting for the whole document.

```text
T1S01a1   authority document, part 1   (issued; both entries rejected)
T1S01a2   authority document, part 2
T1S01a3   authority document, part 3   ...and so on until the document is done
```

**Why the work is chopped up:** a designer session that dies mid-document
loses everything not yet delivered. Sub-tranches cap that loss at one part.
The same logic applies to your side - send each response when you finish it.

**THE ONE RULE THAT DEPENDS ON THIS.** Some entries only conflict with OTHER
entries, and those may be in a part you have not seen. So:

```text
PER SUB-TRANCHE:  review the entries in front of you normally - all five
                  standard questions, plus Q-F where an entry has a DERIVED
                  field.

AT THE FINAL SUB-TRANCHE OF A DOCUMENT: the designer will say plainly that
                  it is the last one. ALSO check the document's entries
                  AGAINST EACH OTHER - contradictory dispositions, the same
                  statement adjudicated twice differently, a PREVAILS chain
                  that loops, a principle declared unique in one entry and
                  found elsewhere in another.
```

You are NOT expected to spot cross-entry contradictions against entries you
have not been shown. If you suspect one but cannot check it, say so and name
what you would need.

## 4.1 File naming

Every file carries its step number at the FRONT, so a directory listing keeps
a step and its answer together. `_A_` is what goes TO you; `_B_` is what comes
BACK from you, so the answer always sorts directly after the question.

```text
T1S01a2_A_Ledger_<subject>_v1_0.md          the ledger you review
T1S01a2_A_Designer_Batch.zip                what W3X sends you
T1S01a2_B_Coder_Response.zip                what you send back

Read the identifier as: step T1S01, part a, sub-tranche 2, `_A_` to you.

Name your response zip with the SAME step number and the _B_ marker. If a
step needs a second pass, keep the step number and bump your document
version inside the zip.
```

## 4.2 What arrives in each session

You have no memory between sessions, so every session is self-contained.

```text
AT THE START OF YOUR CHAT, AND AGAIN FROM TIME TO TIME - THE REFERENCE SET:
  - the COMPLETE dev_documentation zip. Every live project document,
    locatable by folder and filename. This is your reference library for
    the whole sweep: the task register, the MPEG-2 authority, the charter,
    the outgoing designer's evidence set, and every document any step
    adjudicates are all inside it.
  - the SOURCE tree zip. dev_documentation does NOT contain source, and
    Tier B asks questions that can only be answered by reading the code.
    See 4.2.3.
  - the current version of this scope.

W3X supplies this set at the start of your chat and MAY RE-SUPPLY IT LATER -
typically after a significant step, when a refreshed copy is likely to be
useful. That is normal, not an error signal. But it has one consequence you
must handle - see 4.2.0b.

IF YOUR CHAT IS EVER REPLACED, THE SET MUST BE SUPPLIED AGAIN. You have no
memory across chats. See 4.2.0 - do not proceed without it.

WITH EACH STEP:
  - that step's ledger;
  - the task register, IF it has been bumped since the last supply (it
    carries the decisions and method forward, so the newest version wins);
  - a statement of exactly which document and which sections that step
    adjudicates.

If you believe you are missing something you need, ASK W3X. Do not infer the
base from an earlier conversation, from the status document, or from any
recorded hash. If evidence is insufficient to answer a question honestly,
report that entry as UNSURE or as a METHOD BLOCKER and say what you need -
DO NOT infer the answer.
```

### 4.2.0 First thing in every chat: confirm you actually have the corpus

Before reviewing anything, check that the dev_documentation zip is present in
your context. If it is not:

```text
STOP. Say so plainly to W3X and ask for it. Do not begin the step.
Do not work from the ledger alone, and do not reconstruct what a document
probably says from the ledger's quotations of it.
```

This is not a formality. Working from the ledger alone makes two of your five
review questions impossible to answer honestly - see 4.2.1 - while still
producing a response that LOOKS complete. A missing corpus must fail loudly.

### 4.2.0b When you hold two generations of the same document

Because the reference set may be supplied more than once in a chat, you can
end up holding TWO copies of the same document - an earlier one and a later
one - and they may differ.

```text
THE MOST RECENTLY SUPPLIED COPY WINS. Always.

Where a filename carries a version, the highest version wins, and if the
most recent supply contains a LOWER version than one you already hold,
that is a defect: STOP and tell W3X rather than choosing for yourself.

If you notice that an earlier and a later copy differ in a way that
affects an entry you are reviewing, SAY SO in your response.
```

This matters more here than it would elsewhere. Reasoning from a superseded
copy of a document, while believing it current, is the precise failure this
entire task exists to correct. Do not let the review method reproduce the
defect it is reviewing.

### 4.2.0a How to use the corpus - read the step, not the library

The zip is a reference library, not a reading assignment. Each step names the
document and sections it adjudicates: read THOSE in full, and consult anything
else in the corpus when a specific entry sends you there - a conflict
adjudication, a claim about what some other document says, a supersession
call. Do not attempt to read the whole corpus; you will exhaust the session
before reviewing anything.

### 4.2.1 Why you need the documents and not just the ledger

An earlier version of this scope sent you the ledger without the documents it
adjudicated. Your own review of that version found the defect, and the reason
is worth stating so nobody quietly undoes the fix later.

One of the five review questions (Q-D in section 8) asks whether the designer
walked past something without logging it. **A ledger can only show what the
designer DID log. It cannot show what the designer did NOT log.** Asking you
to find omissions while giving you only the record of what was found is asking
for something the evidence cannot support - and omission is precisely the
failure this whole task exists to correct.

The corpus fixes this completely: you read the swept sections yourself, in
full, from the original document. Note in particular that you are NOT limited
to the extracts the designer chose to quote. A designer-chosen extract cannot
reveal what the designer overlooked, so where an entry's quotation looks thin
or conveniently bounded, GO AND READ THE SURROUNDING TEXT.

### 4.2.2 The same point at the level of PR-4

PR-4 asks what the search terms would still miss. A manifest is a list
produced BY the search - it cannot show you a document the search failed to
select. You would be looking for absences inside a list of presences.

The corpus fixes this too: you can see every live document, including the ones
that matched nothing. Judge from their content, not their filenames, whether
anything bears on MPEG-2 matters without using the search terms - and remember
the whole reason this task exists is that a document's LABEL was believed
instead of its contents being checked.

### 4.2.3 Read-only source inspection is permitted and expected

Section 1 forbids source CHANGES. It does not forbid source READING, and the
previous version's phrase "do not touch source" was ambiguous. To be exact:

```text
PERMITTED and, for Tier B, REQUIRED:
    reading the source tree to establish what the code actually implements.

NOT PERMITTED, at any point, for any reason:
    modification, build, execution, patch, delivery package, git operation.
```

Tier B asks whether a statement is a specification the code implements or
background knowledge dressed as one. That is a question about the code, and it
cannot be answered honestly from documents alone.

## 4.3 You will not get feedback between steps - this matters

W3X collects your responses and reviews them TOGETHER at the END of the sweep,
against the completed ledger. That is a deliberate decision about W3X's own
reading load, not an oversight.

Two consequences you must hold consciously:

```text
- SILENCE IS NOT AGREEMENT. Nobody has accepted your step-1 findings by the
  time step 2 reaches you. Do not treat an unanswered point as settled, in
  either direction, and do not stop raising a concern because you raised it
  before. If the same problem recurs in a later step, RAISE IT AGAIN.

- IF THE PROBLEM IS THE METHOD, NOT THE ENTRY, ESCALATE IT LOUDLY AND
  IMMEDIATELY. A wrong entry costs one entry. A wrong METHOD - entries whose
  quoted extracts are too short to check, a whole outcome category being
  misapplied, a format you cannot actually review - gets repeated across
  every remaining step before anyone notices. Put that kind of finding in
  your TOP questions section, stated plainly as a method problem, not buried
  in an entry verdict. The first response you send is read promptly by W3X
  precisely so this class of problem is caught early.
```

## 4.4 How the sweep actually closes - the final three-way round

No adjudication becomes final because the designer proposed it, and none
becomes final because you agreed or disagreed with it. The closure is a
separate round after the last step:

```text
after T1S00..T1S05 are complete:

  W3X assembles the completed ledger plus all six of your responses.
  W3D answers EVERY unresolved disagreement, UNSURE, MISSING and method
      finding - in writing, item by item.
  W3C independently checks those proposed resolutions - BOUNDED to the
      entries where the designer DISAGREED WITH YOU or CHANGED an
      adjudication. Entries where you agreed and nothing moved are not
      re-reviewed.
  W3X decides and records the final adjudications.
```

A METHOD-level blocker is the exception and may be acted on immediately,
because letting a broken method continue multiplies the defect across every
remaining step. Entry-level items wait for this closure round.

Two things follow from this that are worth holding on to. Your findings are
not lost by being deferred - they are held. And an entry you marked UNSURE is
not a failure to do your job; it is an open question routed to the person who
can settle it, which is better than a confident wrong answer that closes the
file.

---

# 5. What a ledger entry looks like

```text
LED-047

  --- WHAT THE DOCUMENT SAYS (findings about existing text only) ---
  DOCUMENT     which document, which section, which line
  CLAIM        the actual words in that document, quoted briefly
  ASSERTS      what that claim means, in plain English
  CLASS        what kind of evidence it is - verified against the MPEG-2
               standard / a specification / from source / measured /
               reasoned / approved by W3X
  DISPOSITION  EXACTLY ONE of the five values below. Never anything else.
               It must cover ONE proposition - see 5.2.
  REASON       why that outcome
  CONFLICTS    what it contradicts, if anything
  PREVAILS     which statement wins, and where that leaves the loser
  SWEPT        REQUIRED whenever the entry claims a statement is UNIQUE,
               INDEPENDENT of something, or UNAFFECTED by something. Record
               WHAT WAS SEARCHED to establish it: which document, which
               sections, which terms, and what was found. See 5.3.

  --- WHAT THE DESIGNER INFERRED (optional; omit when there is none) ---
  DERIVED      any proposition the designer reasoned to rather than found in
               the text. Stated separately BECAUSE IT IS NOT A FINDING ABOUT
               THE DOCUMENT - it is new reasoning, and it is reviewable on
               its own terms.
  DERIVED-BASIS  what the derivation rests on, so you can attack the
               reasoning rather than only the conclusion.

  --- ROUTING ---
  TIER         A, B or C - how hard you are being asked to look
  PROPOSED
  ACTION       what the designer proposes W3X do, if anything
  VERDICT      yours
```

## 5.4 RETAIN-SUMMARY - when a non-canonical duplicate legitimately survives

```text
DEFAULT: a CURRENT-DUPLICATE copy that is NOT the canonical source becomes a
         POINTER to the canonical source.

EXCEPTION: an explicitly designated SUMMARY, INDEX or ORIENTATION layer INSIDE
         the canonical authority may be RETAINED as a subordinate summary,
         where its declared function requires a concise restatement.

STAY-CANONICAL: where the copy being adjudicated IS the canonical home, it
         simply STAYS. It does not need the exception and must not be
         labelled with it. Added at v1.10 - see below.

TO CLAIM THE EXCEPTION an entry must:
    identify the canonical source PER PROPOSITION - not "the register and the
        body sections" generically;
    show the retained copy introduces NO UNIQUE NORMATIVE CONTENT - anything
        the summary says that its source does not is a finding, not a summary;
    show the retained copy is not being treated as an independent authority.
```

**Why this exception exists.** The MPEG-2 authority's section 0 restates
decisions recorded formally elsewhere in the same document. Strictly that is
duplication - but section 0 is the read-first compression every orientation
document in this project sends a cold successor to, and reducing it to pointers
would follow the rule correctly while destroying the document's usability.

**Why it is worded like this and not the way the designer first proposed it.**
The designer proposed classifying duplicates as DESIGNED or INCIDENTAL. You
rejected that axis, correctly: a stale duplicate can be deliberately designed
too. What matters is not the author's intent but whether the copy has an
APPROVED CONTINUING ROLE. You also observed that the de-duplication task's
actual wording strips duplicates out of OTHER documents into pointers to the
authority, and never instructed anyone to hollow out the authority's own
summary - so the danger the designer described was overstated. This wording is
yours.

## 5.4a STAY-CANONICAL, and the one thing it must not become

```text
STAY-CANONICAL
    This proposition's copy IS the canonical home. It stays because it is
    canonical, not by exception.

RETAIN-SUMMARY
    This copy is NOT the canonical home, but it satisfies the narrow 5.4
    exception: inside the canonical authority, summary role explicitly
    declared, no unique normative content.

POINTER
    This copy is NOT the canonical home and does not satisfy 5.4.
```

**Where this came from.** You found it. The rule ratified at v1.9 already
said a canonical-home copy stays, but the action vocabulary offered only the
two non-canonical outcomes, so the commonest case had no label and two
entries were marked with an exception they did not need. No sixth
disposition is created; the five are untouched. This names an outcome the
ratified rule already produced.

**THE STAY-CANONICAL EVIDENCE REQUIREMENT.**

```text
An entry claiming STAY-CANONICAL must NAME AT LEAST ONE CONCRETE
NON-CANONICAL COPY of the proposition, AND ITS LOCATION, sufficient to
demonstrate that the proposition is genuinely CURRENT-DUPLICATE.

It SHOULD record the other non-canonical copies found by the applicable
T1 sweep. It MUST NOT imply that the list is exhaustive unless the
recorded sweep establishes exhaustiveness.
```

**Why the requirement exists.** Every other action carries a test -
RETAIN-SUMMARY must clear three conditions, POINTER follows from failing them.
Without this, STAY-CANONICAL would be the only action established by pure
assertion, and therefore the easiest to reach for. An entry that cannot name
a single other copy has not shown the statement is a DUPLICATE at all, so the
DISPOSITION is in question and not merely the action.

**Why ONE copy, and not the list.** One independently locatable second copy is
logically sufficient to establish duplication. An exhaustive inventory is a
much stronger claim, and this scope already has a place for claims of that
kind - the SWEPT field, where the search is recorded and can be attacked. An
implied inventory sitting in the action field would be a coverage claim with
no recorded search behind it, which is the defect this project has already
had to withdraw once. PHRASE IT ACCORDINGLY: "known non-canonical copies
include ...", not "the non-canonical copies are ...", unless a recorded sweep
supports the definite article.

```text
CHARTER I7 PROVENANCE. THIS RULE HAS TWO PARTS AND THEY HAVE TWO CHAINS.
Recording them as one would hide that the second was unverified for a time.

  THE STAY-CANONICAL ACTION ITSELF
      proposer:  W3C (T1S01a3_B v1.1, Q1)
      verifier:  W3D, against this scope's own text
      ratifier:  W3X, 2026-08-18

  THE EVIDENCE REQUIREMENT ABOVE
      proposer:  W3D, as verifier of the action, at scope v1.10
      verifier:  NOBODY, AT FIRST. W3D cannot verify a criterion applied to
                 W3D's own ledger, and W3X ratification is not a
                 different-party check. W3D raised the gap; W3C then
                 supplied the verification.
      verifier:  W3C - ACCEPT IN PRINCIPLE, WITH THE WORDING REFINEMENT
                 ADOPTED ABOVE: at least one named copy proves duplication;
                 record others; do not imply exhaustiveness without a sweep.
      ratifier:  W3X, 2026-08-18, on the refined wording
```

**What to attack.** RETAIN-SUMMARY is the easier answer and will be reached for
when POINTER is correct. Test every use: is the copy really inside the
canonical authority, is its summary function really declared, and does it
really add nothing normative? A retained copy that quietly adds a qualifier the
source lacks is not a summary.

## 5.2 ONE DISPOSITION COVERS ONE PROPOSITION - the atomic-claim rule

A disposition describes the status of ONE claim. If a quoted sentence contains
two propositions with DIFFERENT statuses, it gets TWO ENTRIES, or the CLAIM is
narrowed so the entry covers only the one being dispositioned.

```text
NEVER: give the whole sentence one disposition and preserve the other
       clause's status in REASON. That is a second, unrecorded disposition
       hiding in prose.
```

**Where this came from.** In the first sub-tranche of the authority document
one entry marked a whole sentence SUPERSEDED while its own reasoning said the
clause after the comma remained binding, and another marked a compound
statement CONFLICTING while noting half of it was current. You found both. The
proposed remedies were clause-selective and correct - the LEDGER RECORD was
not, and the ledger is what proves coverage.

If you see a disposition standing over text with two different outcomes, that
is a finding, not a stylistic preference.

## 5.3 THE SWEPT FIELD - claims of uniqueness, independence and unaffectedness

This field exists because of a specific repeated designer failure, and you
should know the history so you can attack the field rather than accept it.

```text
THREE TIMES the designer asserted something without searching for the
counter-evidence, and each time the counter-evidence sat in a document
already open:

  claimed a section was the UNIQUE home of a principle
        -> another section of the SAME document already stated it;
  claimed two design decisions were INDEPENDENT
        -> one shipped parameter moves both;
  claimed a list's tail was UNAFFECTED by a reordering
        -> the same document elsewhere makes one tail item depend on a
           later one.

Twice the designer had flagged the risk in that very entry and still did not
check. "More care" has now failed three times, so the check is made VISIBLE
instead of left internal.
```

So: any claim of uniqueness, independence or unaffectedness must record what
was swept to establish it. An entry that cannot fill in SWEPT has not earned
the claim.

**What this gives you:** you can attack the SEARCH rather than only the
conclusion. If SWEPT names three sections and you can think of a fourth, that
is a finding. If SWEPT is absent from an entry making such a claim, that is a
method finding.

## 5.1 Why the two halves are separated - this is a corrected defect

The first ledger this project produced did NOT separate them, and the
consequence appeared immediately. One entry dispositioned a statement as
"SUPERSEDED-IN-FORM, CURRENT-IN-SUBSTANCE" - a value that does not exist -
and thereby assumed its own conclusion: it decided the statement's substance
was live by asserting substance the text did not contain.

You found that. The rule that follows, in your own words, is worth keeping
exactly as you put it:

```text
Otherwise future entries can make a statement "current in substance" by
inventing the substance they wish it had.
```

So: DISPOSITION describes only what is on the page. Anything the designer
reasons TO goes in DERIVED, marked as inference, with its basis stated. If you
see an entry where a conclusion has migrated from DERIVED into DISPOSITION or
ASSERTS, that is a method finding and belongs at the TOP of your response.

The five possible dispositions. There are FIVE, there will only ever be five,
and an entry using a sixth is a defect rather than a wording preference:

```text
CURRENT-UNIQUE      still true, and this is the only place it is written.
                    Leave it where it is.
CURRENT-DUPLICATE   still true, and written in more than one place. The
                    entry must IDENTIFY THE CANONICAL HOME - the one place
                    the statement belongs - and then say which side this
                    copy is on:
                      this copy IS the canonical home -> it STAYS, and the
                        non-canonical copies elsewhere are what T3 reduces
                        to pointers;
                      this copy is NOT the canonical home -> it becomes a
                        pointer to the home.
                    Do NOT use CURRENT-UNIQUE for a statement that is merely
                    in its correct home while also appearing elsewhere. It is
                    a DUPLICATE; what varies is which copy survives.
                    Every CURRENT-DUPLICATE entry states:
                        DUPLICATE-ACTION:
                            STAY-CANONICAL | RETAIN-SUMMARY | POINTER
                    See 5.4. THREE cases, because the rule has always had
                    three: this copy IS the home; this copy is not the home
                    but earns the narrow summary exception; this copy is not
                    the home and becomes a pointer.
CONFLICTING         it contradicts another document. A decision is needed
                    about which one wins.
SUPERSEDED          no longer true. Retire or delete it.
OPERATIVE-SPEC      it is not background knowledge, it is a specification
                    the code actually implements. It stays where it is and
                    gets a pointer added alongside.
```

---

# 6. How hard to look: the three tiers

Effort is deliberately unequal, because the cost of a wrong entry is
unequal. Getting a duplicate wrong wastes a paragraph. Getting a conflict
wrong writes a false statement into the document that the whole project
treats as authoritative.

```text
TIER A - FULL REVIEW. Every entry marked CONFLICTING; EVERY entry marked
    SUPERSEDED, whether the plan is to delete it or to replace it with a
    pointer; and all four pre-registered items in section 7.
    (An earlier version tiered only the deletion cases, which left
    pointer-replacement superseded entries with no tier at all. Retiring
    knowledge is high-risk either way - a wrongly-retired statement is
    gone whether it was deleted or merely pointed away from - so the
    whole category is Tier A.)
    The source text is included verbatim in these entries.
    For each one, answer all five questions in section 8.

TIER B - CLASSIFICATION CHECK. Every entry marked OPERATIVE-SPEC.
    One question only: is this really a specification the code
    implements, or is it background knowledge dressed as one?
    WHY THIS TIER EXISTS AT ALL: "this document is just general
    guidance" is the precise judgement that caused the original miss.
    It is the single call this project has already got wrong, so it
    gets its own tier even though it looks minor.

TIER C - SPOT CHECK. Entries marked CURRENT-UNIQUE or CURRENT-DUPLICATE.
    W3X selects a random sample - the designer does not choose which
    ones you see.
    FOR T1S01a5 THIS IS ALREADY DONE. Eleven were selected and reviewed;
    3 AGREE / 8 DISAGREE. DO NOT SELECT ANOTHER a5 SAMPLE - see 0.1.
    This generic instruction remains live for every OTHER sub-tranche. Same five questions as Tier A on the sampled entries.
    You are checking whether the routine entries are as solid as the
    important ones, which is where hurried work shows up first.
```

---

# 7. The four pre-registered items - read these before anything else

These four were identified before the sweep started, and registered so they
could not get lost along the way. All four are Tier A. The first one is the
most important thing in this scope.

```text
PR-1  A LIMIT THAT MAY APPLY TO EVERY DESIGN IS CURRENTLY FILED AS AN
      ARGUMENT AGAINST ONE REJECTED DESIGN.

      The limit itself is not in dispute. Take a run of pixels that is flat
      on both sides of a step - three identical values, then three identical
      higher values. A genuine compression seam and a harmless real edge in
      the picture produce EXACTLY THE SAME NUMBERS. No threshold can tell
      them apart, because there is nothing to tell apart: the observations
      are identical. Tightening the threshold trades one kind of error for
      the other; it cannot remove the problem.

      Here is the issue. That reasoning currently sits inside the section of
      the authority document that explains why the old Architecture A was
      rejected, and it ends with a paragraph about a parameter belonging to
      that rejected design. So it reads as an argument against A.

      The previous designer's position - and it is a POSITION, not an
      approved finding - is that this limit is UNIVERSAL. It constrains how
      ANY of these designs can decide whether to filter a given edge, and
      it is the underlying reason the primary candidate classifies picture
      STRUCTURE instead of relying on what the pixels look like right at the
      edge.

      WHY THIS ONE MATTERS MORE THAN THE OTHERS: the designer's next task
      after this sweep is to derive the mathematics of that structure
      classifier. If the limit really is universal, it is a boundary
      condition on that work - it caps what any threshold can achieve and
      supplies the reason the classifier exists at all. The register
      therefore BLOCKS that next task until this item is resolved.

      WHAT YOU ARE ASKED: is the universality claim correct? Argue it
      yourself from the pixel reasoning above - do not simply agree that it
      sounds right. If you think it is narrower than claimed, say where the
      boundary actually falls.

PR-2  A DESIGN PRINCIPLE HAS QUIETLY TURNED INTO A HISTORICAL FOOTNOTE.

      The principle: you may make the EVIDENCE test stricter before deciding
      to correct a pixel, but once the test passes you correct at FULL
      strength. You do not half-correct.

      Where it now lives: the authority document mentions it only while
      describing what the REJECTED design used to do. It is not in that
      document's list of ideas kept from that design. Since the design is
      rejected, the sentence now reads as history rather than as a rule that
      still binds.

      WHAT YOU ARE ASKED: is this a standing rule for kernel work, or was it
      genuinely specific to the rejected design? If it stands, where should
      it live so a future kernel author cannot miss it?

PR-3  A LIVE RULE IS WRITTEN IN THE VOCABULARY OF A DEAD MECHANISM.

      The charter contains a rule (E3) stating that "midpoint activation"
      reads the CURRENT state of the output at that exact point in the
      processing order, and must not read the original untouched picture.
      The underlying rule is live and load-bearing - it is what makes the
      output depend on the processing order in a defined, repeatable way.
      But "midpoint activation" is part of the rejected design and no longer
      exists.

      The risk: a reader concludes the rule has no trigger any more and
      therefore does not apply. A rule that appears inapplicable stops being
      enforced.

      There is a companion rule (E4) saying the opposite for a different
      situation - a strength map reads the ORIGINAL UNTOUCHED picture in a
      pre-pass. The two are deliberate opposites and must be checked
      together; the new design's classifier is an E4-style reader.

      WHAT YOU ARE ASKED: confirm the underlying rule is still live,
      and comment on whether E3 and E4 remain correctly paired for the
      current design. NOTE: this is charter text. Neither you nor the
      designer edits it. It becomes a proposal to W3X.

PR-4  A DOCUMENT WAS INVISIBLE TO THE ORIGINAL SEARCH.

      The original survey found seventeen documents using one set of search
      terms. Re-running a WIDER set of terms surfaces documents the first
      set could not see - most trivially, but one of them
      (Deblock4_Stage_2C_D2_HolyWu_Real_Schedule_v1_7) is a member of the
      approved Stage 2C document set.

      It was not skipped. It was never on the list, so it could not even be
      skipped deliberately.

      WHAT YOU ARE ASKED: review the search terms in the scope manifest and
      say what ELSE they would still miss. Think about how MPEG-2 material
      can be discussed without using any obvious MPEG-2 word.
```

---

# 8. The five questions - what to answer for each Tier A and Tier C entry

```text
Q-A  Does the quoted source text actually support the conclusion drawn from
     it? Read the quote first and form your own view before reading the
     designer's reason. This is the question that catches a hurried entry.

Q-B  Is the outcome right? If you would have chosen a different one of the
     five outcomes, say which and why.

Q-C  Where the entry says one statement beats another, is that the right way
     round? NEWER DOES NOT AUTOMATICALLY WIN. The older README held good
     engineering that the newer investigation had lost, and one of the four
     items above (PR-2) is a case where the NEWER document made things
     WORSE. If the older statement is better, say so.

Q-D  Is anything missing? Does that document section contain something the
     designer walked past without logging? This is the highest-value thing
     you can find, because a missing entry is invisible in the ledger.

Q-E  Does the entry rely on something you know to be untrue from your own
     knowledge of this project's source, decisions or measurements?

Q-F  IF THE ENTRY HAS A DERIVED FIELD: is the derivation sound, and is it
     doing work it is not entitled to do? Four specific traps, all of which
     have already occurred:
       - IS THE ENTRY ALREADY APPLYING A RULE THAT HAS NOT BEEN RATIFIED?
         This happened at full scale: a ledger proposed a new duplicate-
         handling exception, wrote that it must NOT be applied retroactively,
         and had already applied it in seven entries' PREVAILS fields. A
         proposal being present in the DERIVED half does not license the
         findings half to assume it. If an entry's action is only possible
         under a proposed rule, that is a method finding;
       - does the derived proposition ALREADY EXIST somewhere the designer
         did not check? In the first ledger the designer declared one section
         the unique home of a principle that another section of the SAME
         document already stated, more generally;
       - is a claim of independence or uniqueness checkable against the
         source or the parameter surface, and was it checked? The designer
         asserted that evidence thresholds and correction strength were
         independent while one shipped control moves both;
       - has anything from DERIVED leaked into DISPOSITION, ASSERTS or
         PREVAILS, where it would be read as a finding about the text?
```

---

# 9. Disagreement is the product

The three-way process is NO-FAULT. Nobody loses anything by being wrong, and
a disagreement is not friction - it is the output W3X is paying for.

```text
- Say plainly when you disagree, and say what would change your mind.
- "I agree" on a Tier A entry is only useful WITH your own reasoning
  attached. Bare agreement tells W3X nothing about whether you checked.
- If you are unsure, say UNSURE and say what would settle it. An honest
  "I do not know" is worth more than a confident guess - a wrong
  adjudication made confidently is worse than an open question, because
  it closes the file.
- Do not soften a finding because the designer's reasoning is coherent.
  Coherent and wrong is the normal case for a careful person working at
  speed.
- You go through W3X, never directly to the designer, and W3X decides.
  A disagreement is not routed around by anyone.
```

---

# 10. What to send back per step

```text
1. A plain-English summary first - three to six sentences. What you
   reviewed, what you found, what worried you.

2. Any decisions or questions for W3X, in ONE section near the TOP,
   numbered Q1, Q2, Q3. Each one self-contained: the question in plain
   words, why it matters, YOUR RECOMMENDATION, the options if there is a
   real choice, and any ID tags LAST on a refs line. If you have none,
   say so in one line - silence is not "no questions".
   (This is the standing coder communication convention, v1_0 or later.
   It applies to everything you send W3X.)

3. Entry-by-entry verdicts. For each: AGREE / DISAGREE / UNSURE / MISSING,
   with your reasoning. Keep the detailed technical argument here - this is
   the part written for the designer and the record.

4. Anything you noticed that was not part of the question.

Deliver it as a zip named for the sub-tranche with the _B_ marker - for
example T1S01a2_B_Coder_Response.zip - so it sorts directly after the package
it answers.
```

---

# 11. What you must not do

```text
- Do not confirm. Being asked to review is not being asked to approve.
- Do not accept a conclusion because the reasoning around it is fluent.
- Do not treat the previous designer's judgement documents as findings.
  Two of the four evidence documents are explicitly positions to test.
- Do not treat a document's LABEL as a fact about its contents. That is
  the exact mistake this whole task exists to correct.
- Do not accept a DERIVED proposition because the entry's findings are
  sound. They are separate claims and they fail separately: an entry can
  quote its source correctly and still reason wrongly from it. Both of the
  first ledger's entries were like that.
- Do not MODIFY source, do not build, do not execute, do not produce a
  delivery package. Reading the source is permitted and, for Tier B,
  expected - see 4.2.3.
- Do not fix the documents. The designer writes; W3X decides and commits.
```

---

# 12. Authority set for this scope

```text
The charter (AI_Charter_and_Invariants_Card, highest committed version)
    PREVAILS over this scope and everything else.
The MPEG-2 authority (Deblock4_MPEG2_Deblocking_Investigation_and_Decided_
    Architecture, v1_05 or later) is the approved single source of truth for
    MPEG-2 and architecture matters. Read its section 0 first.
The task register (Deblock4_Standing_Task_Register_T_Series, v1_3 or later)
    holds the work queue and the decisions behind this task.
The coder communication convention (333_W3X_Coder_Communication_Convention,
    v1_0 or later) binds everything you send W3X.
The outgoing designer's evidence set - two documents record, two judgement.

Current project position, so you are not working from memory: the Classic
filter is complete for its approved integer backends (scalar, SSE4.1, AVX2)
at identity 0.1.0-dev+5C. The Deblock4 filter has NO filtering kernel at all -
every dispatch path is a pass-through copy.

Two candidate architectures remain live. B2 is the ADOPTED PRIMARY CANDIDATE,
and classifies macroblock structure; D is the mandatory detector-free
COMPARATOR AND FALLBACK, and must meet its own separate viability bar rather
than winning by default if B2 fails. NEITHER has passed the Q14 experiment, and
neither has been selected to enter kernel or oracle development. The experiment
that decides between them has not been designed yet.

No Deblock4 kernel scope may be opened, and NO NEW kernel mathematics may be
derived, until Q14 reports and W3X ratifies the architecture allowed to enter
development. T1 itself is explicitly permitted to adjudicate kernel-related
principles that ALREADY EXIST - PR-2 asks exactly that, and the mathematical
inventory running inside T1 catalogues existing mathematics without deriving
any.
```

---

*Revision history*
```text
v1.14 (2026-08-20) RATIFICATION GENERATION. NO RULE TEXT CHANGED except 0.11,
     which is REPLACED with the exact W3C-verified wording W3X ratified at
     DEC-84 - the v1.13 transcription had shortened "scope/method" to "scope"
     and dropped "using the method appropriate to the proposition", both
     material. Sections 0.5, 0.6 and 0.7 are marked RATIFIED at DEC-83 (W3X,
     2026-08-20, on W3C's completed I7 verification); the marker legend now
     records the completed chain. This scope is now the ratified consolidated
     method for a5's remaining closure and for a5b.
v1.13 (2026-08-20) STATUS CORRECTION AND COMPLETION OF THE CONSOLIDATION.
     W3C DECLINED TO RATIFY v1.12 and was right. v1.12 stated that every rule
     in section 0 was "already binding through a ratified decision". THAT WAS
     FALSE FOR THREE OF THEM: 0.5 occurrence-level evidence, 0.6
     CITED-OUTSIDE-RANGE and 0.7 the entry-sweep gate are new W3C-originated
     criteria that were still mid-I7-chain. Recording a chain as complete while
     standing in the middle of it is DEC-48's false assurance, committed inside
     the document written to consolidate rules against that class of error.
     EVERY SUBSECTION NOW CARRIES A STATUS MARKER - [RATIFIED] with its
     decision, or [VERIFIED - AWAITING W3X RATIFICATION]. W3C verified the
     three new refinements at the delta review of 2026-08-20, so only W3X
     ratification remains.
     THE CONSOLIDATION WAS ALSO INCOMPLETE ON THE DAY IT SHIPPED, which W3C
     also found. Two rules were missing and are added:
       0.10  DEC-77's SOURCE-COVERAGE MAP - an overlap check against prior
             entries is not a coverage check against the source, and every
             sub-tranche owes both. DEC-77 explicitly binds a5b, so its absence
             from the "one place" scope was the exact defect v1.12 existed to
             prevent.
       0.11  DEC-64/78's SUPERSEDED-KIND and PROPAGATION wording, verified by
             W3C and awaiting W3X ratification. It must bind before T3.
     NO SUBSTANTIVE RULE IS CHANGED BY v1.13. No review obligation, tier
     boundary, question or pre-registered item is weakened.
v1.12 (2026-08-19) CONSOLIDATION ONLY - NO SUBSTANTIVE RULE CHANGED, AND NO
     REVIEW OBLIGATION, TIER BOUNDARY, QUESTION OR PRE-REGISTERED ITEM
     WEAKENED. W3C PROPOSED IT; W3D drafted it; W3C verifies and W3X ratifies,
     so the party the criteria judge is not the party that asked for them.
     WHY: between v1.11 and v1.12 the binding rules stopped living in the
     binding document. They accumulated in the Standing Task Register's
     decision log and in Classification Repair v1.1 while this scope kept only
     the original method. A successor designer then read v1.11's generic
     "W3X selects a random sample", saw nothing here saying a5's sample was
     already complete, and asked W3X for something already provided. It cost a
     round. That is the same shape as the incident this sweep exists to
     correct: ratified material unread in a document nobody consolidated.
     NEW SECTION 0 CONSOLIDATES, each already binding through a ratified
     decision: the standing a5 Tier-C-complete notice (0.1, DEC-73); the three
     populations and three mechanical exclusions (0.2, DEC-60/63/66); DEC-67's
     three sweep rules with the opening-is-not-reading corollary and the
     wrong-members warning (0.3); the classification labels including CANONICAL
     as the home marker, which W3C asked be stated explicitly (0.4); DEC-50
     check evidence, DEC-51 partial replacement and DEC-62 tier derivation
     (0.8).
     THREE ADDITIONS, ALL W3C-ORIGINATED AND NONE ALTERING AN EXISTING RULE:
       0.5 OCCURRENCE-LEVEL EVIDENCE. A file-level hit does not establish
           occurrence-level uniqueness inside that file. MIXED keeps its
           meaning - one file, more than one meaning - and is NOT to be used
           merely because a proposition occurs twice. Matters most at a6.
       0.6 CITED-OUTSIDE-RANGE. Evidence lying in another sub-tranche's
           territory may affect the current disposition while its own
           adjudication stays with the owning tranche, and the reconciliation
           obligation is recorded rather than assumed.
       0.7 THE ENTRY-SWEEP GATE. After editing any field of an entry, re-read
           the whole entry. DEC-51 at entry level, with the three real ledger
           v1.6 failures named.
     Also records at 0.9 W3C's list of how these rules fail while being
     followed, and marks the section 6 Tier C instruction as already
     discharged for a5 while remaining live for every other sub-tranche.
v1.11 (2026-08-18) REFINES the STAY-CANONICAL evidence requirement and
     completes its I7 chain, which was incomplete at v1.10.
     THE PROCESS DEFECT: v1.10 recorded ONE provenance chain for a rule that
     has TWO parts. W3C proposed the STAY-CANONICAL action and W3D verified
     it - complete. But W3D then ADDED the evidence requirement, and that
     addition had no different-party verifier: W3D cannot verify a criterion
     applied to W3D's own ledger, and W3X ratification is not a
     different-party check. W3D raised the gap; W3C confirmed the diagnosis,
     noting that its own earlier clearance had checked COMPLIANCE with the
     new criterion and mistaken that for verification OF it.
     THE REFINEMENT, W3C's and adopted: at least ONE named non-canonical copy
     with its location, which is logically sufficient to establish
     duplication; record other copies found; do not imply an exhaustive list
     without a recorded sweep. W3D's original wording asked for "where the
     non-canonical copies are", which reads as a completeness claim and would
     have put a coverage assertion in the action field with no search behind
     it - the SWEPT field is where coverage claims belong and can be
     attacked.
     No disposition, tier, evidence-supply rule or pre-registered item
     changed.
v1.10 (2026-08-18) Adds STAY-CANONICAL as a third DUPLICATE-ACTION value
     and section 5.4a. THE GAP: v1.9's rule already said a canonical-home
     copy stays, but the action vocabulary offered only RETAIN-SUMMARY and
     POINTER - both non-canonical outcomes - so the commonest case had no
     label, and two entries in the first ledger written under the rule were
     marked with an exception they did not need. W3C found this. No sixth
     disposition is created and no tier, evidence-supply rule or
     pre-registered item changed.
     W3D ADDED ONE THING AS VERIFIER: an entry claiming STAY-CANONICAL must
     name where the non-canonical copies are. Every other action carries a
     test; without this, STAY-CANONICAL would be the only one established by
     assertion and would become the easy answer - the same failure mode W3C
     warned about for RETAIN-SUMMARY.
     Charter I7 provenance, running opposite to v1.9: W3C proposed, W3D
     independently verified and strengthened, W3X ratified.
v1.9 (2026-08-18) Adds 5.4 RETAIN-SUMMARY, the narrow exception under which a
     non-canonical CURRENT-DUPLICATE copy may survive, plus the required
     DUPLICATE-ACTION field. THE WORDING IS W3C's, not W3D's: W3D proposed a
     DESIGNED/INCIDENTAL axis and W3C rejected it as the wrong test, since a
     stale duplicate can also be deliberately designed - what matters is
     whether the copy has an approved continuing role. W3C also showed the
     de-duplication danger W3D described was overstated. Charter I7
     provenance: W3D proposed, W3C independently verified and supplied the
     replacement wording, W3X ratified.
     Q-F gains a fourth trap - an entry applying a rule that has not been
     ratified - after a ledger proposed this very exception, wrote that it
     must not be applied retroactively, and had already applied it seven
     times.
     No tier boundary, disposition VALUE, evidence-supply rule or
     pre-registered item changed.
v1.8 (2026-08-18) Three process-criteria corrections, all found by W3C in its
     review of the first authority-document sub-tranche, all applying to
     criteria that judge W3D's own ledger. Charter I7 provenance: W3C found
     them and drafted the substance, W3D drafted the exact wording, W3C
     verifies, W3X ratifies.
     5.2 ATOMIC-CLAIM RULE: one disposition covers one proposition; a sentence
     whose clauses have different statuses is split or narrowed, never given
     one disposition with the other status preserved in REASON.
     5.3 SWEPT FIELD, now required for any claim of uniqueness, independence
     or unaffectedness, recording what was actually searched. Added after the
     designer made that class of unchecked assertion three times, twice in
     entries where the designer had flagged the risk in the same breath.
     CURRENT-DUPLICATE redefined: it must identify the CANONICAL HOME and say
     which side this copy is on. The old wording told the reader to replace
     "this copy" with a pointer, which is wrong when the copy being
     adjudicated IS the home - a gap W3C hit immediately.
     No tier boundary, disposition VALUE, evidence-supply rule or
     pre-registered item changed.
v1.7 (2026-08-18) Records sub-tranche delivery for steps covering large
     documents (4.0a): each part is separately reviewable and reviewed as it
     lands, so a designer session death costs one part rather than a whole
     document. Added the rule that depends on it - cross-entry consistency
     within a document is checked at the FINAL sub-tranche, which the designer
     must identify as the last, because a reviewer cannot be asked to spot
     contradictions against entries it has not been shown. Naming examples
     updated to the sub-tranche form. No tier boundary, disposition value,
     review question, evidence-supply rule or pre-registered item changed.
v1.6 (2026-08-18) Ledger template corrected after W3C's review of the first
     ledger tranche found it defective, and both of that tranche's entries
     were rejected. The entry is now split into two explicitly labelled
     halves: findings about existing text, where DISPOSITION is exactly one
     of the five registered values and nothing else; and a separate DERIVED /
     DERIVED-BASIS pair for anything the designer reasoned to rather than
     found. Section 5.1 records why, keeping W3C's own statement of the
     danger verbatim. Added review question Q-F covering derived
     propositions, naming the three traps that have already occurred: a
     derived proposition that already exists elsewhere unchecked, an
     unchecked claim of independence or uniqueness, and derived material
     leaking into the findings half. Added a matching entry to the
     what-not-to-do list, since findings and derivations fail separately.
     No tier boundary, disposition value, evidence-supply rule or
     pre-registered item changed.
v1.5 (2026-08-18) Section 12 corrected after W3C's focused re-review (finding
     M1), which was right on both counts. "Neither is chosen" flattened two
     different things: B2's adoption as primary candidate is a ratified
     decision, while passing Q14 is not, and the old wording could be read as
     no decision having been taken about either. Separately, "nothing about
     the kernel may be designed" contradicted this scope's own instructions
     two sections earlier - PR-2 asks W3C whether an existing kernel principle
     still stands, and the mathematical inventory catalogues existing kernel
     mathematics. The constraint is narrower than the old wording: no kernel
     SCOPE and no NEW kernel mathematics before Q14. No review obligation,
     tier, question or pre-registered item changed.
v1.4 (2026-08-18) Two mechanical corrections following W3X's supply
     decisions. The SOURCE tree now travels routinely with the reference
     set rather than only with steps containing Tier-B entries, so Tier-B
     questions are always answerable without a round trip. Added 4.2.0b:
     because the reference set may be re-supplied mid-chat, the coder can
     hold two generations of the same document - the most recent supply
     wins, a lower version arriving later is a defect to report rather
     than resolve, and any difference affecting an entry under review must
     be stated. No review obligation, tier boundary, question or
     pre-registered item changed.
v1.3 (2026-08-18) W3X decisions on the evidence package. The COMPLETE
     dev_documentation corpus is now supplied once at the start of the coder
     chat, replacing the per-step document extracts and the separate file
     inventory of v1.2 - a simpler and cheaper mechanism that discharges the
     same two obligations more completely. Added 4.2.0 (stop and ask if the
     corpus is absent - a missing corpus must fail loudly rather than produce
     a response that merely looks complete) and 4.2.0a (read the step's
     documents in full; the corpus is a reference library, not a reading
     assignment). Recorded that the corpus must be re-supplied if the coder
     chat is ever replaced. The source tree remains a separate supply for
     Tier-B steps, since dev_documentation does not contain source. The
     second coder pass in the closure round is confirmed BOUNDED to disputed
     and changed entries (4.4, unchanged from v1.2 and ratified by W3X).
     No review obligation, tier boundary, question or pre-registered item
     changed.
v1.2 (2026-08-18) Issued after W3C's independent review of v1.1, which found
     that the evidence package could not support several of the review
     obligations the scope assigned. Corrected: the complete swept document
     now travels with every ledger step, because a ledger cannot reveal what
     the designer failed to log (4.2.1); T1S00 receives a complete file
     inventory rather than only the search-derived manifest, because a list
     produced by the search cannot reveal what the search excluded (4.2.2);
     read-only source inspection is stated as permitted and, for Tier B,
     expected (4.2.3, section 11); ALL superseded entries are Tier A, closing
     a category that previously had no tier at all (section 6); the final
     three-way closure round is written down explicitly, with the second
     coder pass bounded to disputed and changed entries (4.4); and the
     charter-hygiene wording in section 1 no longer says a charter rule
     "does not apply" - the PASS restriction is not triggered, not waived.
     The standing pack is trimmed on cost grounds: the authority travels
     every session, the charter only with the step that sweeps it, the
     source tree only with steps containing Tier-B entries.
     No review obligation, tier boundary, question or pre-registered item was
     weakened; two were made dischargeable that previously were not.
v1.11a - see v1.12. No separate v1.11a exists; this line prevents a successor
     inferring one from any prose that mentions an intermediate generation.
v1.1 (2026-08-18) W3X decisions absorbed: the six named steps T1S00-T1S05
     listed explicitly; the step-number-first file naming scheme with _A_ to
     the coder and _B_ back from the coder; what arrives in the first session
     versus later sessions; and a new subsection 4.3 stating that responses
     are reviewed together at the END of the sweep - silence between steps is
     not agreement, and a fault in the METHOD rather than in an entry must be
     escalated at the top of the response rather than buried in a verdict.
     No review obligation, tier, question or pre-registered item changed.
v1.0 (2026-08-18) First issue. Bounded review scope for the T1 consolidation
     sweep: three-tier effort model, five review questions, four
     pre-registered items, batch delivery, no source work of any kind.
```
