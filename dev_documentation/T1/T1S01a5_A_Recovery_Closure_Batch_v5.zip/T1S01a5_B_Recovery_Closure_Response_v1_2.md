# Deblock4 - W3C Recovery-Closure Delta Review of Ledger v1.8

**Deliverable:** T1S01a5_B - RECOVERY CLOSURE RESPONSE
**Version:** 1.2
**Date:** 2026-08-20
**Author:** W3C
**Route:** W3C -> W3X -> W3D
**Reviews:** `T1S01a5_A_Recovery_Closure_Batch_v4(2).zip`
**Primary review target:** `T1S01a5_A_Ledger_Body_Part1_v1_8.md`
**Covering note:** `T1S01a5_A_Covering_Note_for_W3C_v1_7.md`
**Method document reviewed:** `Deblock4_T1_W3C_Review_Scope_v1_13.md`
**Work queue checked:** `Deblock4_Standing_Task_Register_T_Series_v1_33.md`
**Manifest checked:** `T1S00_A_Scope_Manifest_v1_7.md`
**Authority checked:** `Deblock4_MPEG2_Deblocking_Investigation_and_Decided_Architecture_v1_05.md`
**Historical search population reproduced:** the settled 46-file a5 snapshot
**Nature:** DOCUMENT REVIEW ONLY. No source, build, test, patch or git.
**Encoding:** US-ASCII; CRLF.

---

# Plain-English summary

Ledger v1.8 is another material improvement and several of the v1.7 defects are
now genuinely fixed. The source-range coverage is now substantively complete;
LED-043's old stale sentence was removed; LED-053d now uses occurrence-level
evidence rather than stretching MIXED; LED-061 remains clean; LED-059's
section-15 error remains corrected; LED-063 correctly abandons CONFLICTING and
correctly establishes that the W3C-D4-VERIFY-1 report content survives.

a5 is nevertheless NOT ready to close. The two largest remaining substantive
defects are LED-055a and LED-047. LED-055a's CURRENT-UNIQUE search uses only
near-verbatim "correctness requirement" wording and misses a Scopes D4-D01
carrier which states the whole-frame input rule as mandatory for geometric
correctness. LED-047 still places two different propositions - the unique
F-to-V provenance mapping and the duplicated "no active H.262-VERIFIED claim
rests on GAIS" audit result - under one CURRENT-UNIQUE disposition.

W3C independently reproduced the settled 46-file a5 population and ran bounded
semantic checks for the newly-created/narrowed uniqueness questions. Those
checks provide enough evidence to repair LED-037a and LED-063 without sending
W3D into another broad search. They also expose the LED-055a and LED-047
problems directly. This is NOT a rerun of the settled 22 probes and does not
reopen the Tier C sample.

There are also several end-to-end recovery defects: LED-043 now violates the
new occurrence rule by calling repeated same-proposition occurrences MIXED;
LED-032a names wrong carriers for its PAL-576i target proposition; LED-059
still contains stale noncanonical/action prose; LED-063 still contains old
"report may be missing" consequences and a wrong 45-entry tier count; section
0.4 and the closing questions retain mutually incompatible old generations;
and the covering note/register/manifest remain partly one generation behind.

The required next step is ONE bounded correction generation. No architecture
reopening, no old 22-probe rerun, no Tier C resampling and no general new
methodology round are indicated. After that generation W3C should review only
the explicitly changed surfaces. If those are clean, W3C presently sees no
reason for another general a5 recovery round before W3X closes a5 and a5b
starts.

---

# DECISIONS/QUESTIONS FOR W3X

## Q1 - Ratify the three new Review Scope refinements after this W3C verification?

**Question:** Does W3X ratify Review Scope v1.13 sections 0.5, 0.6 and 0.7 -
occurrence-level evidence, CITED-OUTSIDE-RANGE and the entry-sweep gate -
subject only to W3D mechanically correcting the scope header/status on reissue?

**Why it matters:** these are new criteria applied to W3D's own ledger, so
charter I7 requires a different-party verification before W3X ratification.
W3C has now checked their substance against the knowledge-capture response and
the failures that motivated them.

**W3C recommendation:** **YES.** W3C verifies all three in substance and
recommends ratification now. W3D can then issue the corrected consolidated
scope with those three marked RATIFIED rather than requiring another method
review round.

**Options:**
A. Ratify 0.5/0.6/0.7 now, subject to the mechanical scope-header reissue -
   **W3C recommends A**.
B. Leave them provisional and require another W3C scope review - not
   recommended; W3C has already completed the independent substantive check.

Refs: charter I7; Review Scope 0.5/0.6/0.7; DEC-76/79 lineage.

## Q2 - Ratify the exact W3C-refined SUPERSEDED propagation wording?

**Question:** Does W3X ratify the exact W3C-refined
`SUPERSEDED-KIND / PROPAGATION` rule now?

**Why it matters:** Review Scope v1.13 section 0.11 is directionally correct
but is NOT an exact transcription of the W3C-verified wording. In particular
it shortens the final limit from "no exhaustiveness beyond declared
scope/method" to "no exhaustiveness beyond declared scope", and also drops the
explicit requirement that the reliance search use the method appropriate to
the proposition. Those qualifications are material: a narrow or unsuitable
method must not gain apparent exhaustiveness merely because its scope was
declared.

**W3C recommendation:** **YES - RATIFY THE EXACT WORDING BELOW, not the
shortened v1.13 transcription:**

```text
SUPERSEDED-KIND
    OVERTAKEN | ERRONEOUS

OVERTAKEN
    The statement was valid in its former context/state and has been replaced
    by a later statement. PROPAGATION is normally N/A unless evidence suggests
    dependent work may not remain valid.

ERRONEOUS
    The statement was false, materially misleading, or otherwise invalid in
    the context in which project work may have relied on it.

PROPAGATION - REQUIRED FOR ERRONEOUS
    1. DECLARE THE PROPAGATION SCOPE / POPULATION: identify the bounded set of
       current documents, decisions, code, mathematics, tests or other project
       objects in which reliance could materially survive.
    2. SEARCH FOR RELIANCE ON THE PROPOSITION, NOT MERELY ITS WORDING, using
       the method appropriate to the proposition.
    3. ENUMERATE AND CLASSIFY CANDIDATE DEPENDENCIES, identifying actual
       reliance and non-reliance with attackable location/basis.
    4. ROUTE EACH ACTUAL DEPENDENCY: remains valid for an independent reason,
       needs correction/re-verification, or is itself superseded/erroneous.
    5. If none are found, record "none found" with scope and method.
    6. Claim no exhaustiveness beyond declared scope/method.

PROPAGATION is about potentially affected CURRENT work. It is not an
archaeological search for every historical mention.
```

W3D should transcribe this exact substance into the corrected Review Scope
generation. If W3X ratifies it here, no further independent method review is
needed merely to check a faithful transcription.

Refs: DEC-64; DEC-78; W3C Knowledge Capture Response Capture 6; charter I7.

---

# 1. Overall verdict

```text
a5 Tier C sample                         COMPLETE / SETTLED - DO NOT REOPEN
settled 22-probe search/classification  COMPLETE / SETTLED - DO NOT RERUN
Classification Repair v1.1              SETTLED

Review Scope v1.13:
  older ratified-rule consolidation     AGREE
  0.5 occurrence-level evidence         AGREE / W3C VERIFIED
  0.6 CITED-OUTSIDE-RANGE               AGREE / W3C VERIFIED
  0.7 entry-sweep gate                  AGREE / W3C VERIFIED
  0.10 source-coverage rule             AGREE / already ratified DEC-77
  0.11 propagation concept              AGREE
  0.11 exact transcription              DISAGREE - material qualifiers lost
  header/I7 status                      DISAGREE - says verified/ratified
                                        before W3X ratification

ledger v1.8 mechanical entry count      43
ledger v1.8 tier count                  43 Tier C / 0 Tier A / 0 Tier B

LED-032a                                DISAGREE - carrier attribution
LED-037a                                RECORDED PROBE INADEQUATE;
                                        W3C expanded check supports UNIQUE
LED-043                                 DISAGREE - MIXED misuse
LED-047                                 DISAGREE - non-atomic / audit duplicate
LED-053d                                AGREE IN PRINCIPLE; tighten location
LED-055 parent                          DISAGREE - blanket "derivation" action
LED-055a                                DISAGREE - CURRENT-UNIQUE refuted
LED-055b                                AGREE in disposition; range correction
LED-059                                 DISAGREE - stale entry residue
LED-061                                 AGREE
LED-063                                 CURRENT-UNIQUE supportable after W3C
                                        bounded check, but entry still stale

source proposition coverage 223-715     AGREE after 032a/037a additions
recovery self-check / closing questions DISAGREE
covering note currency                  DISAGREE
register current-state consistency      DISAGREE
manifest current-status currency        DISAGREE

a5 FORMAL CLOSURE                       NOT YET
a5b START                               NOT YET
```

---

# 2. Mechanical delta and source-coverage check

W3C independently counted the finished v1.8 ledger.

```text
ENTRY HEADINGS: 43

CURRENT-DUPLICATE: 26
CURRENT-UNIQUE:    17

TIER C: 43
TIER A: 0
TIER B: 0
```

v1.7 contained 42 entries. v1.8 adds one entry:

```text
LED-055b
```

and changes these existing entries:

```text
LED-032a
LED-037a
LED-043
LED-047
LED-053d
LED-055a
LED-059
LED-063
```

No entry was removed.

W3C also walked authority lines 223-715 against all 43 DOCUMENT ranges.
The two substantive source omissions found in the previous review are now
covered:

```text
authority lines 225-226 -> LED-032a
authority line 269      -> LED-037a
```

The remaining uncovered nonblank lines in the mechanical range walk are
headings, fence markers or separators rather than unlogged propositions.

The remaining range overlaps are explainable source/atomic splits, including:
- LED-032a / LED-033 at line 226;
- LED-043 / LED-043a;
- LED-052 / LED-052a;
- LED-055 / LED-055a / LED-055b;
- LED-058 / LED-058a;
- LED-061 / LED-061a.

So the **source proposition coverage defect itself is now repaired**. The
individual range accuracy defects at LED-055a/b and the too-broad Appendix-A
evidence location remain, as recorded below.

---

# 3. Review Scope v1.13

## 3.1 Consolidated older method - AGREE

The v1.13 consolidated statements of:
- a5 Tier C completion;
- 47 / 41 / 46 populations;
- DEC-60/63/66 exclusions;
- DEC-67 sweep rules;
- semantic classification labels;
- DEC-50;
- DEC-51;
- DEC-62;
- atomic claims;
- SWEPT;
- STAY-CANONICAL / RETAIN-SUMMARY / POINTER;
- DEC-77 source coverage

are materially consistent with the settled method.

The scope correctly prevents the old Tier-C anomaly by saying explicitly that
a5's eleven-entry sample is complete and must not be selected again.

## 3.2 New 0.5 / 0.6 / 0.7 refinements - W3C VERIFIED

W3C verifies the three additions.

### 0.5 occurrence-level evidence

Correct:

```text
A file-level search hit does not establish occurrence-level uniqueness inside
that file.
```

Correctly preserves MIXED as "different meanings in one file", rather than
using it for repeated copies of the same proposition.

### 0.6 CITED-OUTSIDE-RANGE

Correct:
an occurrence in another sub-tranche may establish duplication or another
current disposition fact without being adjudicated early, provided its
location, proposition, evidence use, owning tranche and reconciliation
obligation are recorded.

### 0.7 entry-sweep gate

Correct:

```text
After editing any field, re-read the whole entry and check that no other field
contradicts the edit.
```

This is justified by the repeated partial-replacement failures.

W3C therefore completes the independent verification limb for all three.

## 3.3 Header/status contradiction

The v1.13 header says the v1.12 consolidation:

```text
is verified by W3C and ratified by W3X
```

while section 0 correctly says 0.5/0.6/0.7 are:

```text
VERIFIED - AWAITING W3X RATIFICATION
```

and explains that falsely recording the I7 chain as complete is itself the
DEC-48 failure.

The header is therefore false as issued.

If W3X accepts Q1, W3D can correct it mechanically to say the three have now
been independently verified and ratified.

## 3.4 Section 0.11 is NOT the exact W3C wording

The important difference is not stylistic.

W3C's Capture-6 wording says:

```text
2. ... using the method appropriate to the proposition.
6. Claim no exhaustiveness beyond declared scope/method.
```

v1.13 compresses that to:

```text
2. SEARCH FOR RELIANCE ON THE PROPOSITION, not merely for its wording;
6. Claim no exhaustiveness beyond the declared scope.
```

The omitted METHOD limit is what prevents a declared but unsuitable search
method from acquiring an unjustified completeness claim.

Use the exact Q2 wording on reissue.

---

# 4. Reproduction of the three v1.8 bounded probes

W3C reconstructed the same settled 46-file a5 search population independently
from the historical common base under DEC-60/63/66.

The population count reproduced exactly:

```text
46 files
```

W3C then reproduced and attacked the three v1.8 probe families.

---

# 5. LED-037a - CURRENT-UNIQUE can be supported, but not by the recorded probe

v1.8's probe is:

```text
"Unless explicitly stated otherwise"
"unless stated otherwise"
"unless otherwise stated"
```

It returns one file, the authority.

W3C reproduces that result.

The problem is Rule 3: those are grammatical permutations of the same
sentence, not reasonable independent reformulations of the proposition. The
entry itself admits that wording such as "these are defaults" or "except where
noted" would escape the family.

W3C therefore ran this bounded expansion:

```text
Unless explicitly stated otherwise
unless stated otherwise
unless otherwise stated
unless otherwise noted
unless noted otherwise
unless otherwise specified
except where noted
except as noted
except where stated
these are defaults
are defaults
by default
```

It returned six candidate files:

```text
CANONICAL
  Deblock4_MPEG2_Deblocking_Investigation_and_Decided_Architecture_v1_05.md
      the actual default-scope qualification on the coordinate conventions

DIFFERENT
  AI_Charter_and_Invariants_Card_v1_31.md
      unrelated "by default" project/safety language

DIFFERENT
  README_Deblock4_Design_Spec_v1_12.md
      "Chroma is processed by default"

DIFFERENT
  Deblock4_Toolchain_Findings_v1_4.md
      FloatMode `.optimized` by default

DIFFERENT
  Scopes/Deblock4_D4_PreScope_Round_Brief_for_W3C_v1_2_CODER_RESPONSE.md
      heuristic/fallback behaviour by default

DIFFERENT
  Scopes/Deblock4_T1_W3C_Review_Scope_v1_7.md
      an architecture not winning "by default"
```

No second carrier of the coordinate-convention default-scope proposition was
found.

**W3C disposition:** the CURRENT-UNIQUE result is supportable, but W3D should
replace the inadequate recorded family/evidence with this expanded independent
check or an equivalent faithful record. No further broad search is needed.

---

# 6. LED-032a - duplicate disposition is sound, named target carriers are not

The range is now correctly lines 225-226 and the overlap with LED-033 is
properly declared.

The charter is a valid canonical source for BOTH propositions:
- Deblock4 project identity;
- immediate/originating PAL-576i consumer-DVD-recorder purpose.

The CURRENT-DUPLICATE disposition is also supportable.

But v1.8's REASON and DUPLICATE-ACTION say the PAL-576i / consumer-recorder
target is in the README and designer introduction. W3C checked the settled
snapshot:

```text
README v1.12:
    no "576i" occurrence.

designer introduction v1.28:
    does not carry the PAL-576i / consumer-DVD-recorder target proposition.

Concise Project Summary v1.5:
    DOES carry it:
    Deblock4 is initially focused on PAL tape material recorded to MPEG-2 by
    consumer DVD recorders.
```

The README/introduction can remain identity carriers where they genuinely
carry identity. They must not be presented as copies of the target clause.

Required:
- make carrier evidence PER PROPOSITION;
- use an actual target carrier, e.g. Concise Project Summary v1.5;
- do not let a copy of the identity clause prove duplication of the target
  clause.

This is the same "copy of the wrong clause" failure recorded in Review Scope
0.9.

---

# 7. LED-043 - old repair passes; new occurrence record violates the new rule

The stale v1.7 sentence which called the c2 Scopes carrier evidence for
(a)/(b) is now removed. Section 3 is correctly retained as the concrete
(a)/(b) duplicate; the Scopes evaluation remains attached to c2.

That part is AGREE.

But the new occurrence block says:

```text
FILE: this authority
FILE-CLASS: MIXED
OCCURRENCES:
    section 2 / F5  NON-CANONICAL c2
    section 15      CANONICAL c2
```

This is the same proposition twice, not two meanings.

Review Scope 0.5 says explicitly not to use MIXED for this case.

Required:

```text
FILE: this authority
FILE-CLASS: CARRIER
OCCURRENCES:
    section 2 / F5   NON-CANONICAL occurrence of c2
    section 15       CANONICAL occurrence of c2
```

or an equivalent representation that preserves the two occurrence roles
without redefining MIXED.

The CITED-OUTSIDE-RANGE limb to a6 is otherwise appropriate.

---

# 8. LED-047 - DISAGREE: two propositions still share one CURRENT-UNIQUE disposition

This is the largest remaining atomicity defect after LED-055a.

LED-047 expressly says its CLAIM contains TWO propositions:

```text
(a) the F-series -> V4 verification mapping;
(b) the audit result:
    no active [H.262-VERIFIED] claim in this document depends on GAIS.
```

It then gives both one:

```text
DISPOSITION CURRENT-UNIQUE
```

They do not share that status.

## 8.1 Proposition (a) - F-to-V mapping

W3C reproduces v1.8's six candidate files for:

```text
provenance record
verification report V4
V4.1
V4.3
```

The candidate set is correct.

The classification is not.

The four Scopes documents are labelled `CARRIER`, immediately followed by:

```text
THE VERIFICATION, NOT THE MAPPING.
```

For the proposition actually searched - a record mapping F-series claims to
V-numbered W3C verification - those files do NOT assert the proposition.

They carry the V4 verification content, but they do not use F-numbering and do
not connect an F-number to a V-number.

Classification should therefore be:

```text
CANONICAL authority section 2.1

DIFFERENT Scopes PreScope coder response
DIFFERENT Scopes Verification Round Brief v1.0
DIFFERENT Scopes Verification Round Brief v1.1
DIFFERENT Scopes PreScope Round Brief v1.2

DIFFERENT AI Charter v1.31
```

The mapping itself is supportably CURRENT-UNIQUE.

## 8.2 Proposition (b) - audit result

W3C ran a separate bounded family for the audit result:

```text
no active [H.262-VERIFIED]
no active H.262-VERIFIED
depends on GAIS
rests on unverified GAIS
unverified GAIS testimony
```

It returned two proposition-bearing files.

The authority is the canonical occurrence.

The designer introduction v1.28 explicitly states, in its H.262 provenance
section, that the current authority carries a fresh provenance audit and:

```text
no active H.262-verified claim rests on GAIS
```

That is a direct second carrier of the audit-result proposition.

Therefore:

```text
proposition (b) is CURRENT-DUPLICATE, not CURRENT-UNIQUE.
```

Required:
- split/narrow LED-047 atomically;
- keep F-to-V mapping as CURRENT-UNIQUE with corrected candidate classes;
- make the audit result CURRENT-DUPLICATE;
- canonical home: authority section 2.1;
- concrete noncanonical copy: designer introduction v1.28;
- duplicate action: STAY-CANONICAL for the authority occurrence.

This may add another suffix entry. Do not preserve 43 as a target; recount only
after the proposition structure is correct.

The eight-literal-hit DEC-50 audit remains correct and should be preserved.

---

# 9. LED-053d - occurrence method AGREE; evidence location too broad

The important method repair is now correct:

```text
FILE-CLASS: CARRIER
```

rather than MIXED, with separate section-4.5 and Appendix-A occurrences.

The CITED-OUTSIDE-RANGE handling is also correct in principle.

But the Appendix-A location is recorded as:

```text
lines 1762-1932
```

which is the whole Appendix A.

The actual carrier is precise:

```text
1770 Case (b)
1771 MPEG-2 FIELD PICTURES...
1772 ... woven frame, same-field horizontal filtering uses row pitch 2.
```

Per DEC-50, use the smallest attackable relevant range, e.g. 1770-1772.

No disposition change is required.

---

# 10. LED-055 / LED-055a / LED-055b - DISAGREE

## 10.1 Parent LED-055 still overclaims "the derivation"

v1.7/v1.8 correctly says the derivation is no longer one proposition and
qualifiers have moved to LED-055a/b.

But the active DUPLICATE-ACTION still says:

```text
STAY-CANONICAL for the derivation
```

and names noncanonical copies of "the derivation".

That is now too broad.

The parent owns:
- row-projection mechanism / Case-(a) chroma consequence;
- D4-D01 conclusion.

It does NOT own the two qualifier propositions now split to LED-055a/b.

Required:
- say STAY-CANONICAL for the mechanism / Case-(a) chroma consequence;
- POINTER for the D4-D01 conclusion;
- do not use blanket "derivation" language that reaches into 055a/b.

## 10.2 LED-055a recorded range

The current source sentence is:

```text
563 SeparateFields cannot be the general MPEG-2 input contract. Whole-frame input
564 is a codec-geometry correctness requirement, not a performance preference.
```

The 055a proposition itself is the second sentence/qualification.

Use:

```text
lines 563-564
```

not 562-564.

## 10.3 LED-055b recorded range

LED-055b claims:

```text
The same problem exists for progressive/frame-DCT geometry.
Therefore SeparateFields cannot be the general MPEG-2 input contract.
```

Those words span:

```text
562-563
```

not line 562 only.

## 10.4 LED-055a uniqueness probe is too narrow and CURRENT-UNIQUE is refuted

v1.8 searches only:

```text
"correctness requirement, not a performance"
"not a performance preference"
"correctness requirement"
```

It returns the authority only.

W3C reproduces that lexical result.

But DEC-67 Rule 3 requires reasonable independent reformulations. The recorded
family will obviously miss a document saying the contract is mandatory because
the alternative cannot correctly process the geometry.

W3C therefore tested this bounded semantic family:

```text
whole-frame input contract
whole-frame input
correctness requirement
not a performance preference
reason (geometric
no field-clip instance can deblock
```

It returned four files:

```text
authority

Scopes/Deblock4_D4_Architecture_ReDecision_W3C_Evaluation_v1_0.md

Scopes/Deblock4_D4_Architecture_ReDecision_Brief_for_W3C_v1_0.md

Scopes/Deblock4_D4_PreScope_Round_Brief_for_W3C_v1_2.md
```

The PreScope brief is a clear carrier. Its D4-D01 record says:
- whole-frame input contract;
- separated-field input is NOT supported;
- reason: geometric;
- SeparateFields tears frame-organised blocks;
- no field-clip instance can deblock the relevant chroma.

A cold reader can recover that whole-frame input is a correctness constraint,
not an optional performance trade.

The Architecture ReDecision Brief likewise records D4-D01 as a WHOLE-FRAME
INPUT CONTRACT and says no field-clip instance can deblock Case-(a) chroma or
progressive material.

Therefore:

```text
LED-055a CURRENT-UNIQUE is FALSE.
LED-055a must be CURRENT-DUPLICATE.
```

Recommended canonical home:
authority section 5, beside the derivation it qualifies.

Recommended action:
STAY-CANONICAL, naming at least the Scopes PreScope D4-D01 carrier.

No further uniqueness probe is needed once a real second carrier is established
unless W3D wants to claim an exhaustive carrier list, which it should not.

## 10.5 LED-055b

The CURRENT-DUPLICATE disposition is sound. The Scopes PreScope carrier
directly states the progressive-material generality.

Correct the source range to 562-563.

---

# 11. LED-059 - core disposition is right; stale entry residue remains

The important v1.7/v1.8 correction remains right:
authority section 15 is NOT the home of the file-level corpus composition.
Section 6.3 is the canonical home.

But the entry still contains a stale sentence in DUPLICATE-ACTION:

```text
KNOWN NON-CANONICAL COPIES INCLUDE: this section, and designer introduction...
```

"This section" is now the canonical home and cannot simultaneously be one of
its noncanonical copies.

The designer introduction also names corpus classes but does not thereby state
the FILE-LEVEL composition. Do not use it as a composition carrier without a
passage that actually asserts that proposition.

The live PROPOSED ACTION also still contains relocated-but-not-removed
historical v1.6 text about W3D not wanting the old mapping ratified.

Required:
- remove "this section" from the noncanonical list;
- retain only genuine file-composition carriers;
- move all old-action history out of the live ACTION field;
- keep Q-F withdrawn rather than leaving an old live decision question.

This is an entry-sweep / DEC-51 defect, not a new architecture issue.

---

# 12. LED-061 - AGREE

The v1.6/v1.7 carrier contradiction remains fixed.

The coder introduction and D2:
- are DIFFERENT, not carriers;
- are no longer listed in REASON as carriers;
- are no longer listed as noncanonical copies.

No further correction from this review is required.

---

# 13. LED-063 - CURRENT-UNIQUE is supportable, but the entry is not end-to-end clean

The major v1.8 disposition correction is conceptually right:

```text
CONFLICTING -> CURRENT
```

W3C's prior full Tier-A review established that:
- W3C-D4-VERIFY-1 is a report FROM W3C;
- V4.1 and V4.3 content survives;
- section 24 R8 has the wrong/stale filename;
- the section-8 pointer is not in conflict with another proposition.

## 13.1 W3C bounded uniqueness check

v1.8 does not record a search establishing that section 8 is the only place in
the 46-file population stating WHERE the detailed calibration record lives.

W3C ran:

```text
detailed calibration record
calibration record
raw GAIS evidence
W3C verification report
```

It returned three files:

```text
CANONICAL
  authority section 8 - the actual location pointer

DIFFERENT
  Scopes/Deblock4_D4_Verification_Round_Brief_for_W3C_v1_1.md
      calibration-record planning/coverage material, not a pointer saying
      where the detailed record lives

DIFFERENT
  Scopes/Deblock4_D4_PreScope_Round_Brief_for_W3C_v1_2.md
      calibration planning/record requirements, not the location proposition
```

No second carrier of the section-8 location pointer was found.

So CURRENT-UNIQUE is supportable once this evidence is recorded.

## 13.2 Wrong tier/entry count

The entry says:

```text
ZERO Tier A and 45 Tier C
```

The finished v1.8 ledger mechanically contains:

```text
43 entries
43 Tier C
0 Tier A
```

Correct the entry to 43, subject to recount after LED-047 is atomically split.

## 13.3 GAIS location text still stale

The REASON says:

```text
six documents in GAIS_investigations/ plus two response captures in the root
```

After DEC-66/W3X's move, the current tree contains eight files under
GAIS_investigations/:
- six investigation documents;
- GAIS_GATING_RESPONSE.txt;
- GAIS_MPEG2_GRID_CONFIRMATION_RESPONSE.txt.

The two response captures are no longer at documentation root.

They remain excluded historical material, but their location must be stated
accurately.

## 13.4 "strong likely referent" is stale

The same REASON first says report content is ESTABLISHED, then says:

```text
But a STRONG LIKELY REFERENT does exist...
```

That is the old uncertainty and must be removed/historicalised.

## 13.5 DERIVED / DERIVED-BASIS / ACTION still assume the report may be missing

The live DERIVED says:

```text
If that report cannot be located...
```

It has been located.

DERIVED-BASIS still says:

```text
the four searches above
```

after SWEPT expressly records FIVE checks.

PROPOSED ACTION still says:

```text
establish what the W3C verification report is, whether it survives...
IF IT CANNOT BE ESTABLISHED...
```

Those questions are answered.

Required:
- record the W3C uniqueness probe above;
- keep CURRENT-UNIQUE if W3D accepts that evidence;
- retain only the a6 R8 filename reconciliation as forward work;
- remove all "whether report survives / if it cannot be located" live logic;
- update four -> five checks;
- update GAIS file locations;
- recompute entry/tier count after all splits.

---

# 14. Recovery self-check - DISAGREE

The ledger still contains mutually incompatible generations of its own state.

## 14.1 Section 0.1

The heading/body still presents the a5/a5b split as something W3D declares
under a split provision. The split is already RATIFIED at DEC-68.

State that the split IS ratified. Historical derivation can remain labelled
history.

## 14.2 Section 0.3 Finding B

It still says, in substance:

```text
SECTION 8's calibration record points at a document that may not exist
```

v1.8's own LED-063 says the report content EXISTS and identifies it.

Replace the old finding with the current one:
- report content survives;
- R8 exact filename is stale/wrong;
- a6 owns the reference correction.

## 14.3 Section 0.4c falsely claims complete delta

The heading says:

```text
THE COMPLETE DELTA SET FROM v1.3
```

and ends:

```text
NOTHING ELSE CHANGED. Every other word ... is v1.3's.
```

That is false in v1.8.

The file now contains coverage additions, later Tier-C repairs, bounded probes,
recovery corrections, occurrence records and many changed fields not in D1-D7.

Either:
- rename D1-D7 as the original classification-repair delta set; or
- make the list genuinely complete through v1.8.

Do not keep "NOTHING ELSE CHANGED".

## 14.4 Section 0.4e contains incompatible live entry-count narratives

The opening current arithmetic is good:

```text
34 -> 39 at v1.6
39 -> 42 at v1.7
42 -> 43 at v1.8
```

Then the same live section says:
- a draft 40 was corrected to 39;
- LED-055a is "unmandated and is not created here";
- LED-051 and LED-055 take no suffix;
- the ledger "lands at 40";
- no delivered ledger ever had 39.

Those are no longer current truths. v1.6 was delivered/reviewed and contained
39 entries; v1.7/v1.8 do create LED-055a.

It also points to an enumeration at `0.4i`, but no section 0.4i exists.

Required:
retain historical failed arithmetic only inside a clearly marked historical
record, separate from the current count derivation, or remove it from live
logic.

## 14.5 Section 0.4f contradicts live LED-037

It says restoration includes:

```text
the REASON's original reasoning, which the repair's own LED-037 probe table
endorses.
```

Live LED-037 correctly withdrew the old "no other document can hold it"
reasoning as invalid uniqueness proof.

Record exactly what evidence/rationale was restored and what old reasoning was
deliberately not restored.

## 14.6 Section 0.4g N2 is now resolved

N2 still says the Appendix-A issue is "flagged ... and raised at Q-K".

v1.8 plus Review Scope 0.5/0.6 already answer it.

Add a resolved annotation and point to LED-053d's occurrence/CITED record.

---

# 15. Closing questions - several are stale

## Q-C STAY-CANONICAL count

The current ledger has **18** entries whose active DUPLICATE-ACTION first line
contains STAY-CANONICAL:

```text
LED-036
LED-041
LED-042
LED-043
LED-045
LED-046
LED-048
LED-049
LED-051
LED-053c
LED-053d
LED-054
LED-055
LED-055b
LED-057
LED-058
LED-059
LED-061
```

Q-C still says 16 and omits new LED-055b and LED-059.

After LED-055a is corrected to CURRENT-DUPLICATE it may become 19, depending on
the final action. Recompute only after the final proposition set is fixed.

## Q-H

Still says only the five v1.5 suffix entries exist and LED-055 needs no suffix.

That is obsolete after LED-032a, LED-037a, LED-055a and LED-055b.

Replace with a current mechanical entry/split check or withdraw it.

## Q-K

Still asks whether same-file out-of-range evidence needs different treatment,
although the question is already answered and Review Scope 0.5/0.6 plus
LED-053d implement the answer.

Withdraw/update it.

## Q-K2

Says v1.7 applies all three partial Tier-C findings end-to-end.

v1.8's own history says v1.7 still left stale sentences, and the current
LED-055 family remains incomplete.

Update rather than preserving a false closure claim.

## Q-L

Its proposed test depends on 0.4c being a complete delta set. It is not.

Reframe Q-L around the actual declared delta generations, or withdraw it after
a mechanically complete provenance/delta table is built.

---

# 16. Covering Note v1.7 - current framing still has partial replacements

The top correctly says the target is ledger v1.8 and Review Scope v1.13.

But the same note still contains several prior-generation instructions:

```text
Binding work queue: v1.30
```

while the batch supplies v1.33.

It first says LED-063 is CURRENT-UNIQUE and the ledger has zero Tier A, then
later says:

```text
Tier A gets full review; there is exactly ONE Tier A entry, LED-063.
```

It still says:

```text
diff v1.3 against v1.5
```

instead of describing the actual v1.7 -> v1.8 delta plus the separate
preservation-baseline check against v1.3.

It still contains:
- old 34 -> 39 framing as though current;
- old statement that LED-055a is not created;
- references to old v1.5 review targets;
- T1S00 v1.6 where the supplied manifest is v1.7.

Required:
issue a clean current covering note for the next bounded review. Do not leave
old live instructions above/below corrected paragraphs.

---

# 17. Standing Task Register v1.33

Good corrections:
- top status recognises ledger v1.8 / 43 / zero Tier A;
- old section 0a recovery gate is now clearly HISTORICAL / DISCHARGED;
- DEC-75's false v1.7 "end-to-end" claim is annotated as corrected at DEC-80;
- Tier C is no longer presented as owed.

Remaining current-state defect:

```text
a5 < LEDGER v1.8 DELIVERED. 43 entries...
```

is immediately followed by:

```text
v1.7 applies that review. AWAITING W3C DELTA REVIEW. NOT CLOSED. 42 entries.
```

That leaves two generations in the live status block.

Required:
make section 0.1 say only the current v1.8 result and this W3C response's
bounded reissue requirement; historical v1.7 state belongs in DEC history.

Minor:
T1S00 is called complete at v1.6 while the supplied manifest is v1.7. Since
v1.7 is current-status-only, update the generation pointer without implying the
frozen survey was rerun.

---

# 18. T1S00 Manifest v1.7

The frozen survey frame remains correctly preserved.

The method/population history is not reopened.

But its CURRENT STATUS still says:

```text
ledger v1.7, 42 entries, awaiting W3C DELTA REVIEW
```

The supplied target is v1.8.

DEC-69 already permits current-status-only maintenance without touching the
frozen 90 terms/population/hit tables.

Update only that current-status paragraph after W3D issues the corrected
ledger generation. Do not touch the frozen search frame.

---

# 19. Exact bounded reissue list

W3D should make ONE further correction generation.

```text
A. REVIEW SCOPE
   - correct header/I7 status
   - if W3X ratifies Q1, mark 0.5/0.6/0.7 RATIFIED
   - replace 0.11 with the exact Q2 wording if W3X ratifies it
   - no further substantive W3C method review needed for a faithful
     transcription

B. LED-032a
   - retain range 225-226
   - keep charter mapping for both propositions
   - correct carrier attribution per proposition
   - use an actual PAL-576i/consumer-recorder carrier, e.g. Concise Summary
   - do not call README/designer-intro copies of that clause when they are not

C. LED-037a
   - replace the under-search with the W3C expanded bounded family/results
   - CURRENT-UNIQUE may then remain

D. LED-043
   - FILE-CLASS MIXED -> CARRIER for same proposition twice
   - retain occurrence roles and CITED-OUTSIDE-RANGE

E. LED-047
   - atomically split/narrow the F-to-V mapping from the GAIS audit result
   - mapping: CURRENT-UNIQUE
   - four Scopes V4 files: DIFFERENT for the mapping, not CARRIER
   - audit result: CURRENT-DUPLICATE
   - canonical authority section 2.1
   - designer introduction v1.28 is a concrete noncanonical audit-result copy
   - retain the corrected eight-hit literal-string audit

F. LED-053d
   - keep occurrence/CITED method
   - Appendix-A location -> lines 1770-1772

G. LED-055
   - narrow "STAY-CANONICAL for the derivation" to the parent mechanism /
     Case-(a) chroma consequence only

H. LED-055a
   - source range -> 563-564
   - CURRENT-UNIQUE -> CURRENT-DUPLICATE
   - canonical section 5
   - STAY-CANONICAL
   - name Scopes PreScope D4-D01 carrier
   - replace the narrow lexical probe record with the semantic evidence above
   - no exhaustive carrier claim

I. LED-055b
   - source range -> 562-563
   - CURRENT-DUPLICATE remains

J. LED-059
   - remove canonical "this section" from noncanonical-copy list
   - do not use class-only designer-intro text as file-composition copy
   - remove relocated historical v1.6 prose from live ACTION
   - keep Q-F withdrawn

K. LED-061
   - no substantive change required

L. LED-063
   - record W3C bounded uniqueness evidence
   - CURRENT-UNIQUE may remain
   - 45 Tier C -> actual current count after final recount
   - eight GAIS files are under GAIS_investigations/, not 6 + 2 root
   - remove "strong likely" language; referent is established
   - remove "if report cannot be located" DERIVED branch
   - "four searches" -> five checks
   - live ACTION only: carry wrong R8 filename to a6 for correction
   - do not ask a6 to rediscover whether the report exists

M. LEDGER SELF-CHECK
   - section 0.1 split -> RATIFIED DEC-68
   - section 0.3 Finding B -> surviving report content / wrong R8 filename
   - 0.4c no false "complete delta / nothing else changed"
   - 0.4e one current count derivation; historical failed counts labelled
     historical if retained; remove nonexistent 0.4i pointer
   - 0.4f reconcile LED-037 old reasoning
   - 0.4g mark N2 resolved
   - Q-C recompute STAY-CANONICAL mechanically after final entries
   - Q-H/Q-K/Q-K2/Q-L currentise or withdraw

N. COVERING NOTE
   - current work queue
   - zero Tier A consistently
   - correct delta target
   - remove old "LED-055a not created" / 39-entry live instructions

O. REGISTER
   - remove v1.7/42 stale live-status block
   - update T1S00 generation pointer to v1.7

P. MANIFEST
   - current-status paragraph only, after corrected ledger
   - frozen frame untouched
```

---

# 20. What W3C should review next

The next W3C review should be strictly bounded to the reissue delta:

```text
1. Review Scope header/status and exact 0.11 transcription
2. LED-032a
3. LED-037a
4. LED-043
5. LED-047 split
6. LED-053d precise occurrence location
7. LED-055 / 055a / 055b
8. LED-059
9. LED-063
10. ledger 0.1 / 0.3 / 0.4 / closing questions
11. covering note
12. register current status
13. manifest current-status paragraph
```

No unchanged ledger entry needs another substantive review.

No old 22-probe search needs rerunning.

No a5 Tier C sample needs selecting or reviewing.

No architecture question is reopened.

The three W3C bounded searches in this response should be recorded as review
evidence and used directly; W3D should not repeat them merely to produce the
same result.

---

# 21. W3C state after this review

```text
a5 Tier C sample                    COMPLETE / SETTLED
old 22-probe search                 COMPLETE / SETTLED
classification repair              COMPLETE / SETTLED

source-range coverage              SUBSTANTIVELY COMPLETE
v1.8 ledger                        BOUNDED REISSUE REQUIRED
Review Scope v1.13                 SUBSTANCE MOSTLY SOUND;
                                   I7/status + 0.11 exactness correction
a5 closure                         NOT YET
a5b                                NOT YET

NEXT ACT                           ONE BOUNDED W3D REISSUE
NEXT W3C ACT                       DELTA-ONLY REVIEW OF NAMED SURFACES

NO Tier C resampling.
NO old-probe rerun.
NO general method reopening.
NO architecture reopening.
NO source/build/test/git work.
```

---

*Revision history*

```text
v1.2 (2026-08-20) W3C bounded delta review of ledger v1.8 and recovery batch
     v4(2), continuing the same W3C session that reviewed v1.6 and v1.7.
     Mechanically establishes 43 ledger entries, all Tier C. Confirms source
     proposition coverage for authority lines 223-715 after LED-032a/037a.
     Independently reconstructs the settled 46-file a5 population and attacks
     the three new uniqueness probes. Supplies an expanded LED-037a probe which
     supports CURRENT-UNIQUE; refutes LED-055a CURRENT-UNIQUE by finding direct
     Scopes whole-frame-contract geometric carriers; and establishes that
     LED-047's F-to-V mapping may remain unique while its separate
     no-H.262-verified-claim-rests-on-GAIS audit result is CURRENT-DUPLICATE
     via the designer introduction. Supplies bounded uniqueness evidence
     supporting LED-063 CURRENT-UNIQUE while finding its entry still carries
     old missing-report logic and a false 45-tier count. Finds LED-043's new
     occurrence block incorrectly uses MIXED for the same proposition twice,
     LED-032a attributes the PAL-576i target to documents that do not carry it,
     LED-053d's Appendix-A range is unnecessarily broad, parent LED-055 still
     uses blanket derivation wording, and LED-059 still contains stale
     noncanonical/action prose. Finds extensive recovery self-check, closing-
     question, covering-note and status partial replacements. Verifies Review
     Scope 0.5/0.6/0.7 in substance and recommends W3X ratify them; finds 0.11
     directionally correct but not an exact transcription of W3C's propagation
     rule because the method limit was dropped. Requires one bounded reissue
     only; no Tier-C resampling, settled-probe rerun, general method reopening
     or architecture reopening.
```
