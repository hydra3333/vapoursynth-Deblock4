# Deblock4 - W3C Delta Review of Reissued T1S01a4 Ledger v1.2

**Deliverable:** T1S01a4_B - W3C DELTA REVIEW
**Version:** 1.1
**Date:** 2026-08-18
**Author:** W3C
**Route:** W3C -> W3X -> W3D
**Reviews:** `T1S01a4_A_Designer_Batch_v3.zip`
**Ledger:** `T1S01a4_A_Ledger_Section23_Tail_v1_2.md`
**Covering note:** `T1S01a4_A_Covering_Note_for_W3C_v1_2.md`
**Binding review scope:** `Deblock4_T1_W3C_Review_Scope_v1_11.md`
**Binding work queue:** `Deblock4_Standing_Task_Register_T_Series_v1_17.md`
**Compared against:** `T1S01a2_A_Ledger_Currency_Statements_v1_1.md`,
`T1S01a1_A_Ledger_PR1_PR2_v1_0.md`, authority v1.05, and W3C's
`T1S01a4_B_Coder_Response_v1_0.md`
**Encoding:** US-ASCII; CRLF.

---

# Plain-English summary

The narrow reissue correctly withdraws LED-031 and LED-032, preserves their
source text under T1S01a2 LED-010, corrects the main a4 adjudicated range to
1694-1700, and applies most of the technical corrections from W3C's first
review. The technical core remains sound: LED-026's two-senses-of-freeze
reading holds, the section-23 ordering conflict is real, the two-role /
two-acceptance-state repair is the correct model, and the pre-oracle candidate
acceptance gap remains real.

However, the new DEC-48 countermeasure does not yet pass its own first
application. Because the reissue names what it checked, it made two new
problems visible: LED-001 and LED-002 are not T1S01a2 entries at all, and
T1S01a2 LED-004's recorded range ends at 1694, which overlaps the a4 range at
exactly the step-6 line. The propositions do not overlap, but the earlier
ledger has another range-recording defect that should be registered for a5.

There are also several partial-replacement remnants: LED-029 and DEC-45 still
state the old "one artifact where the project needs two" / "different
artifacts" premise even though W3C's accepted refinement is two ROLES and two
ACCEPTANCE STATES; LED-026 still points to withdrawn LED-031; and LED-027's
PROPOSED ACTION still points to Tiering Decisions rather than the newly
corrected canonical charter home.

I recommend one more very narrow reissue. No technical redesign is required
and the accepted LED-026/LED-029 core is not reopened.

No source was modified. No build, execution, test, patch, delivery machinery or
git operation was performed.

---

# DECISIONS/QUESTIONS FOR W3X

## Q1. DEC-48 is sound in principle, but I recommend refining its wording before treating its I7 chain as complete

This package explicitly asks W3C to test the new countermeasure, so I am
reviewing the criterion itself, not merely complying with it.

**Verdict: ACCEPT IN PRINCIPLE, WITH A NARROW WORDING REFINEMENT.**

The useful principle is correct:

```text
A check used as evidence must be recorded in a form that makes the check
falsifiable. A bare statement such as "the set was swept" is not enough.
```

For a bounded overlap/coverage check such as this one, enumerating each member,
its range and the comparison result is excellent. It exposed defects that the
old assurance hid.

But DEC-48 is currently written globally:

```text
a claim that a check was done must NAME the items examined - document,
section or entry identifier, and range - so the claim can be tested by
counting
```

That is too broad as a universal process criterion. Not every legitimate check
has a meaningful line range or is tested by counting. Examples include
byte-identity checks, file-hash checks, build checks, source-tree searches and
whole-document semantic comparisons.

I recommend:

```text
CHECK-EVIDENCE RULE

A claim that a check was performed must identify the actual object or
population examined AND the result/basis in a form that makes the claim
independently testable.

For a bounded set/range sweep, overlap check or coverage check, enumerate the
population examined and record each member's relevant range/result so an
omission is visible.

For other checks, record the identifiers and method/basis appropriate to that
check. Do not invent a line range where no natural range exists.

A bare assurance such as "the set was swept" is not evidence and must not be
written as though the check were demonstrated.
```

This keeps the countermeasure's strength while avoiding a new ritual in which
authors attach artificial ranges to checks that are not range checks.

I7 provenance should therefore be recorded separately:

```text
DEC-48 / check-evidence criterion:
    proposer:  W3D, derived from W3C's method finding
    verifier:  W3C - ACCEPT IN PRINCIPLE WITH THE REFINEMENT ABOVE
    ratifier:  W3X, if W3X adopts the refined wording
```

Refs: Task Register v1.17 DEC-48; charter I7; Review Scope v1.11 DEC-44
discipline.

## Q2. Reissue a4 once more, narrowly, before closing it

I recommend YES.

The technical core does NOT need another review. The remaining corrections are
mechanical/process consistency:

1. fix the DEC-48 first-application list;
2. register T1S01a2 LED-004's range defect for a5;
3. finish replacing the old two-artifact language with the accepted
   two-role/two-acceptance-state model;
4. remove the stale LED-031 pointer;
5. make LED-027's proposed pointer target agree with its corrected canonical
   home;
6. tighten LED-025's unaffectedness sweep wording;
7. restore W3C's full rerun constraint to include other affected quality
   evidence, not only the SA/SB comparison;
8. correct the covering note's statement that W3C previously used scope v1.10.

After those narrow edits, I expect a delta check rather than another substantive
T1S01a4 review.

---

# 1. DEC-48 first application - DISAGREE as recorded

The new section 0 says:

```text
EVERY T1S01a2 ENTRY, EXAMINED AND ITS RANGE COMPARED WITH 1694-1700:
  LED-001, LED-002 ...
  LED-003 ...
  ...
  LED-012 ...
```

The naming is useful, but the list is not accurate.

## 1.1 LED-001 and LED-002 are not T1S01a2 entries

The current reissued T1S01a2 currency ledger v1.1 contains LED-003 through
LED-012.

LED-001 and LED-002 belong to **T1S01a1**, not T1S01a2:

```text
LED-001 -> PR-1, authority section 12.5
LED-002 -> PR-2, authority section 9.1
```

They are also not "header/section 0 currency statements" as the a4 list says.

So the statement "EVERY T1S01a2 ENTRY" should enumerate LED-003 through
LED-012, not LED-001 through LED-012.

If W3D intended to say "every prior ledger entry", that is a different
population and should be named that way and enumerated accurately.

## 1.2 LED-004 is not outside the a4 range by its recorded range

T1S01a2 LED-004 says:

```text
DOCUMENT authority v1.05, section 23, steps 1-5 (lines 1683-1694)
```

Authority line 1694 is:

```text
6. Reconcile D4-Q16 public parameter/diagnostic surface before real pixel work.
```

That is the first line adjudicated by a4 at LED-025.

Therefore the a4 comparison result:

```text
LED-004 ... 1683-1694 - outside this range
```

is false as a **range** statement.

The underlying propositions do not overlap: LED-004 claims only steps 1-5,
which end at line 1693, while LED-025 claims step 6 at 1694. So this is another
T1S01a2 range-recording defect, not duplicate adjudication.

Recommended treatment:

```text
T1S01a2 LED-004:
    recorded range: 1683-1694
    proposition actually covered: steps 1-5, ending 1693
    line 1694 is step 6 and belongs to T1S01a4 LED-025
    -> register as an a5 range-recording correction, alongside LED-010's
       1703-1710 / sentence-to-1713 defect
```

This finding is evidence **for** the new countermeasure's core idea: because
the comparison was finally enumerated, the boundary defect became visible.

But the current first application is not yet a PASS.

---

# 2. Withdrawn LED-031/LED-032 - AGREE

The withdrawal is correct.

Their source text remains owned by T1S01a2 LED-010. Its atomicity repair and
range correction belong to the final a5 consistency pass, as W3X selected from
W3C's option 1.

The roadmap observation is also correctly demoted from an independent
adjudication to background evidence under LED-029.

VERDICT: AGREE.

---

# 3. LED-025 unaffectedness sweep - conclusion sound, check claim still overstates what was examined

The substantive conclusion remains sound:

```text
the T1/T5 reversal did not alter D4-Q16's post-Q14 / before-real-pixel-work
relationship
```

However the new SWEPT field says:

```text
Checked the Standing Task Register's decision log for EVERY decision touching
sequence: DEC-02 ... DEC-03 ...
```

That is not true of register v1.17. The current register also has later
sequence/order decisions including DEC-32, DEC-45 and DEC-49.

Those later decisions do not appear to disturb D4-Q16 step 6, but the check
claim should not say "every decision touching sequence" when it names only
DEC-02 and DEC-03.

For the claim REASON actually makes, the cleaner proof is narrower:

```text
Checked DEC-02 and DEC-03, the decisions constituting the T1/T5/T6 reversal
being referred to. Neither reaches D4-Q16, the public parameter surface or
post-Q14 step 6. Therefore that reversal did not alter this relationship.
```

If W3D wants the stronger statement that **no current register decision**
changes D4-Q16's position, then it must name/search the broader decision set
accordingly.

VERDICT: DISAGREE as recorded; unaffectedness conclusion remains accepted.

---

# 4. LED-026 rerun constraint - substantially correct, restore the full W3C scope

The important constraint landed correctly:

```text
if step 9 changes a step-7 value that section 14.4 required to be held fixed,
the old comparison no longer proves the revised candidate; return to the
candidate stage and rerun
```

That preserves the two-senses-of-freeze reading.

One phrase is slightly narrower than W3C's previous recommendation. W3C said to
rerun the affected **comparison/quality evidence**. The ledger currently says
only to rerun the affected comparison.

If a changed threshold/formula/footprint also underpins another quality
decision at step 9, that evidence is stale for the same reason.

I recommend:

```text
the candidate stage is re-entered and the affected comparison AND ANY OTHER
QUALITY EVIDENCE THAT DEPENDED ON THE CHANGED VALUE are rerun
```

The mandatory DEC-47 verdict remains unchanged:

```text
AGREE.
THE TWO-SENSES READING HOLDS.
THE EARLIER THRESHOLD WARNING IS DISSOLVED.
```

VERDICT: AGREE on the reading; narrow wording completion requested.

---

# 5. LED-027 canonical-home correction - finding fixed, proposed action still stale

The PREVAILS correction landed correctly:

```text
canonical controlling home:
    Charter oracle-construction exception

detailed durable record:
    Verification and Tiering Decisions section 20.2
```

But LED-027's live PROPOSED ACTION still says:

```text
Pointer to Verification and Tiering Decisions section 20.2 at T3.
```

That contradicts the newly corrected canonical-home finding.

The T3 pointer should go to the canonical controlling charter rule, with
Tiering Decisions 20.2 optionally named as the detailed record/rationale.

VERDICT: correction incomplete.

---

# 6. LED-029 two-role refinement - core still AGREE, replacement incomplete

This is the most important residual delta defect.

W3C's prior refinement was:

```text
TWO ROLES AND TWO ACCEPTANCE STATES are required.
TWO PERMANENT, SEPARATELY IMPLEMENTED SCALAR CODEBASES are NOT established.
```

The new text adds that refinement, but leaves the old premise immediately above
and elsewhere:

```text
"STEP 8 NAMES ONE ARTIFACT WHERE THE PROJECT NEEDS TWO."

"These are different artifacts with different acceptance bases"

"the two-artifact reading"

"If W3C refutes the two-artifact distinction ..."
```

Those are not harmless historical phrases. They are live DERIVED and
PROPOSED-ACTION text.

They reintroduce the stronger proposition W3C explicitly declined to establish.
Two roles may be embodied successively in one evolving implementation. What is
proved is the separation of **status and acceptance basis**, not object
identity.

Recommended live wording:

```text
THE DEFECT IS NOT A BARE 8/9 ORDERING SWAP. STEP 8 CONFLATES TWO ROLES AND TWO
ACCEPTANCE STATES:

    8a comparison candidate role
       not an accepted oracle

    8b ReleaseSafe oracle role
       accepted under the oracle-construction rule after schedule freeze

The same implementation may potentially be reused/refactored/hardened across
those roles; that is a later scoping question. The project does not currently
require two persistent implementation artifacts.
```

Replace live references to "two-artifact reading/distinction" with
"two-role/two-acceptance-state reading/distinction".

The same stale premise remains in **Task Register DEC-45**, whose title still
says `THE TWO-ARTIFACT ORDERING REPAIR` and whose body still says step 8 names
"ONE artifact where the project needs TWO." DEC-49 records the refinement, but
a later corrective entry does not make DEC-45's still-live provisional wording
safe to ratify by reference.

Update DEC-45 before any final ratification.

The covering note also still calls the live provisional position the
"two-artifact repair/distinction". That should be aligned too.

VERDICT:

```text
LED-029 technical core: AGREE
two-role refinement as applied: DISAGREE - partial replacement
```

---

# 7. LED-026 stale pointer to withdrawn LED-031

LED-026 SWEPT still says:

```text
The roadmap's Stage 2D line was found and is recorded at LED-031.
```

LED-031 is withdrawn.

The roadmap material now lives only as corrected background under LED-029.

Replace the stale pointer accordingly or remove it.

VERDICT: narrow clerical/traceability correction.

---

# 8. LED-030 correction - AGREE

The correction landed as intended:

- charter G5 is gone from the copy list;
- G7 / the charter oracle rule are correctly identified;
- Tiering Decisions 20.2 is treated as the detailed record;
- the roadmap Stage 4D/5D copies are enough to demonstrate duplication.

VERDICT: AGREE.

---

# 9. Roadmap three-way-disagreement claim - withdrawal AGREE

The claim was correctly withdrawn rather than weakened.

The roadmap's Stage-2D/Stage-3D split is compatible with candidate construction
followed by quality comparison/canonical freeze. It is not independent evidence
of a third ordering conflict.

The actual ordering conflict remains fully supported by authority line 1153 and
the oracle acceptance rule.

VERDICT: AGREE.

---

# 10. Covering-note currency statement - small correction

The v1.2 covering note tells W3C:

```text
Deblock4_T1_W3C_Review_Scope_v1_11.md was v1.10
```

That is not the previous W3C review state. W3C's T1S01a4_B v1.0 explicitly
reviewed under **scope v1.11** and register v1.16, exactly as W3X supplied.

For this delta:

```text
scope:    v1.11 -> unchanged
register: v1.16 -> v1.17
```

This does not affect the ledger result, but the routing/currency statement
should be corrected because this project treats exact generation discipline as
load-bearing.

---

# Consolidated delta verdicts

```text
DEC-48 criterion itself
    ACCEPT IN PRINCIPLE WITH WORDING REFINEMENT
    I7 different-party verification supplied by this response

DEC-48 first application
    DISAGREE AS RECORDED
    - LED-001/002 are not T1S01a2 entries
    - LED-004's recorded 1683-1694 range overlaps line 1694
    - register LED-004 range defect for a5

LED-025
    DISAGREE AS RECORDED
    conclusion sound; "every sequencing decision" check claim overbroad

LED-026
    AGREE on two-senses reading
    earlier threshold warning remains DISSOLVED
    extend rerun wording to all affected quality evidence

LED-027
    canonical-home correction AGREE
    proposed T3 pointer target remains stale

LED-028
    unchanged; prior AGREE stands

LED-029
    technical core AGREE
    live two-artifact remnants DISAGREE; replace fully with roles/states

LED-030
    AGREE

LED-031 / LED-032
    withdrawal AGREE

roadmap three-way-disagreement claim
    withdrawal AGREE

DEC-46 acceptance gap
    prior finding stands: REAL, open, blocks 8a scope rather than T1
```

---

# Current W3C position

T1S01a4 is **very close**, but I do not recommend closing ledger v1.2.

The remaining defects are narrow and mostly demonstrate why the new
countermeasure is useful:

```text
- accurate previous-ledger enumeration;
- one additional a2 range defect registered for a5;
- exact check-evidence wording;
- complete two-artifact -> two-role replacement;
- one stale withdrawn-entry pointer;
- one stale proposed pointer target;
- one overbroad sweep claim;
- one small rerun-scope completion;
- one covering-note version statement.
```

No substantive reversal of the a4 technical result is required.

Recommended next action:

```text
W3D issue a narrow ledger v1.3 / package reissue.
W3C performs a mechanical delta check.
If those items are clean, close T1S01a4 and proceed to T1S01a5.
```

---

*Revision history*

```text
v1.1 (2026-08-18) Delta review of ledger v1.2 / designer batch v3.
     Independently tests the new DEC-48 check-evidence criterion rather than
     merely complying with it; accepts the principle with a generality
     refinement. Finds that the first application is not yet accurate:
     LED-001/002 belong to T1S01a1, and T1S01a2 LED-004's recorded range
     overlaps a4 at line 1694, exposing another a2 range defect for a5.
     Confirms withdrawal of LED-031/032, LED-026's two-senses core,
     LED-029's ordering repair, LED-030's G5 correction and the roadmap
     withdrawal. Finds partial-replacement remnants of the rejected
     "two-artifact" wording in LED-029, DEC-45 and the covering note; a stale
     LED-031 pointer; a stale LED-027 T3 pointer target; an overbroad LED-025
     check claim; and a small rerun-scope/currency correction. Requests one
     more narrow reissue before a4 closure. No source change; no
     build/test/git.
v1.0 (2026-08-18) First W3C review of T1S01a4.
```
