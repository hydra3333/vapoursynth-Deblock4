# Deblock4 - T1S01a5b Batch 2 Correction Review 1 Section 12 W3C Findings

**Deliverable:** T1S01a5b_B_Batch2_Correction1_S12_Findings
**Version:** 2.0
**Date:** 2026-08-23
**Author:** W3C
**Route:** W3C -> W3X -> W3D
**Encoding:** US-ASCII; CRLF.

---

# DECISIONS/QUESTIONS FOR W3X

None.

---

# Findings

## F32 - LED-091a substantive overturn is right, but the entry contradicts it

W3C agrees with the F23 substantive correction: Re-Decision Evaluation
595-607, especially 606-607, is a CARRIER of the proposition that threshold
tuning does not establish safety, so CURRENT-DUPLICATE / STAY-CANONICAL is
supported.

However, two stale fields survive the edit:

1. SWEPT says the reformulation family including `does not prove` produced
   eight loci in seven files that were `all DIFFERENT per REASON`. That now
   contradicts REASON, which correctly classifies Evaluation 595-607 as a
   CARRIER.
2. The CITED-OUTSIDE-RANGE closing instruction still says the
   not-a-safety-proof finding `is CURRENT-UNIQUE`. The disposition is now
   CURRENT-DUPLICATE.

This is exactly the scope-0.7 entry-sweep failure mode.

Recommended repair: rebuild the affected SWEPT classification/count statement,
replace the stale CURRENT-UNIQUE text, and re-read the whole entry for the old
uniqueness formulation.

## F33 - LED-091b retains a stale claim about LED-091a

The F24 occurrence additions are sound: README 652 and 694 and Appendix C
1877-1878 are real carriers of the hard-activation / normal-correction-strength
proposition.

But REASON still says LED-091b was split from LED-091a because `this limb has
carriers, its neighbour has none`. After F23, LED-091a explicitly has the
Evaluation 595-607 carrier. The statement is therefore false in the corrected
ledger and violates the entry-sweep gate.

Recommended repair: replace that historical evidence-status rationale with one
that remains true after F23, then rerun the whole-entry gate. No change to
CURRENT-DUPLICATE / STAY-CANONICAL is otherwise indicated.
