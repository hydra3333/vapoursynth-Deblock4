# Deblock4 - T1S01a5b Batch 2 Correction Review 1 Section 13 W3C Findings

**Deliverable:** T1S01a5b_B_Batch2_Correction1_S13_Findings
**Version:** 2.0
**Date:** 2026-08-23
**Author:** W3C
**Route:** W3C -> W3X -> W3D
**Encoding:** US-ASCII; CRLF.

---

# DECISIONS/QUESTIONS FOR W3X

None.

---

# Findings

## F34 - LED-092 still contains the provenance claim that was split out as false

The narrowing of LED-092 to the true RETENTION limb is correct in principle.
However, its CANONICAL-HOME paragraph still says:

    `the README remains their historical ORIGIN`

about the retained section-13 rules. LED-092a now establishes that this is
false for 13.1 and 13.5. The repaired LED-092 therefore contradicts the new
split entry inside the same correction generation.

Recommended repair: remove or narrow that blanket provenance sentence so
LED-092 states retention only; leave provenance to LED-092a. Rerun the
whole-entry gate.

## F35 - LED-092a nil propagation is not demonstrated to DEC-84 standard

W3C agrees with the substantive F25 split: the authority's blanket claim that
all five section-13 rules are older README rules is false, and ERRONEOUS is the
right superseded-kind. Independent checking also supports the stated absence of
README carriers for 13.1 and 13.5.

The mandatory PROPAGATION record, however, does not satisfy Review Scope 0.11's
required attackable method:

- it does not explicitly DECLARE the bounded propagation scope/population in
  the PROPAGATION block;
- it does not state the reliance-search method appropriate to this provenance
  proposition;
- it jumps directly to `Four candidates were opened` rather than showing how
  those candidates exhaust the declared method;
- the Re-Decision Evaluation 858-875 is a current README-provenance/retention
  occurrence already recognised in LED-092, but it is not reconciled in the
  four-candidate propagation enumeration. It appears to be NON-RELIANCE based
  on independent earlier README evidence, but DEC-84 step 3 requires candidate
  dependencies to be enumerated and classified rather than silently omitted.

The ZERO-dependents result may well be correct; the present record does not yet
prove it under the ratified six-step method.

Recommended repair: rewrite PROPAGATION explicitly against DEC-84 steps 1-6,
state the 38-file/current-object scope and semantic reliance method, enumerate
all candidates including Evaluation A5 as reliance/non-reliance, route any
actual dependencies, and limit the exhaustiveness claim to that scope/method.

## F36 - LED-094 still misses a current direct carrier and cites an undeclared generation

The F26 reclassification of designer introduction 134-136 from APPLIES to
CARRIER is correct. The same current document also states at line 731:

    `scheduler/kernel separation; detector is an unmodified-source pre-pass`

That is a direct carrier of the pre-pass limb and is found by the entry's own
`pre-pass` probe, but LED-094 does not classify it.

The repaired REASON also says the 134-136 line `survives unchanged in designer
introduction v1.34`. The declared Population Delta v1.1 and the supplied
38-file corpus contain designer introduction v1.33, not v1.34. No v1.34 is
present in the supplied reference set. A correction-round entry cannot rely on
an undeclared/unsupplied generation.

Recommended repair: add/classify v1.33 line 731 and remove the v1.34 assertion
unless W3X supplies and declares a new population generation. Rerun the
whole-entry gate.

## F37 - LED-095 still omits direct current-introduction temporal-state carriers

The F27 additions at designer introduction 134-136 and 731-732 and the prior
W3C PreScope response are sound. The same current designer introduction has at
least two further direct occurrences that the repaired entry does not
classify:

- line 801: `hidden cross-frame detector hysteresis under fmParallel` is in the
  explicit REJECTED / DO NOT RESURRECT list;
- line 850: the current-architecture checklist states `no hidden temporal
  state` directly.

Line 801 is reached by the entry's own `cross-frame` / `fmParallel` family.
Line 850 is a straightforward reformulation of the central proposition. Both
are CARRIER occurrences, not merely implementation references.

Recommended repair: add/classify these current-document occurrences and rerun
the whole-entry gate. CURRENT-DUPLICATE / STAY-CANONICAL is not otherwise
challenged.
