# Deblock4 - T1S01a5b Batch 2 Correction Review 1 Section 11 W3C Findings

**Deliverable:** T1S01a5b_B_Batch2_Correction1_S11_Findings
**Version:** 2.0
**Date:** 2026-08-23
**Author:** W3C
**Route:** W3C -> W3X -> W3D
**Encoding:** US-ASCII; CRLF.

---

# DECISIONS/QUESTIONS FOR W3X

None.

---

# Findings

## F29 - LED-082a sweep count is stale after the F19 repair

The repaired SWEPT field says `Six loci in three files`, but its own finished
enumeration now contains seven loci: authority 896-897, authority 1877,
Evaluation 108, Evaluation 552, Brief 54-59, authority section-0 item 12
169-171, and the newly added D4-Q05 register occurrence 1541-1544. Those are
seven occurrence loci across the same three files.

The F19 substantive repair is otherwise sound: D4-Q05 1541-1544 is a real
CARRIER and the CITED-OUTSIDE-RANGE routing is appropriate.

Recommended repair: change the derived locus count from six to seven and rerun
the whole-entry gate.

## F30 - LED-083 widened sweep still omits direct frame/frame carriers

The F20 additions at Evaluation 117-119 and 670 are sound, but the widened
entry is still incomplete. At minimum:

- Re-Decision Evaluation 1041-1042 states D's measured `frame-frame
  approximation cost`, directly carrying the frame/frame-approximation limb;
- authority 1224-1225 requires measurement of D's pitch-2 treatment versus
  exact pitch-1 treatment on FRAME/FRAME boundaries, another direct carrier
  in later a6 territory.

These are material occurrences of the proposition being swept. The latter
also requires CITED-OUTSIDE-RANGE treatment under scope 0.6.

Recommended repair: add/classify both occurrences, route 1224-1225 to a6, and
rerun the whole-entry gate. CURRENT-DUPLICATE / STAY-CANONICAL is not otherwise
challenged.

## F31 - LED-084 still omits a direct risk-2 carrier

Evaluation 117-119 states that D processes a FRAME/FRAME macroblock-row
boundary in the pitch-2 conservative form rather than the exact pitch-1 form.
That is a direct carrier of LED-084 risk 2 and closely matches the entry's own
probe wording `pitch-2 rather than`. It is absent from the repaired occurrence
record even though the correction round already used that same passage at
LED-083.

Recommended repair: add/classify Evaluation 117-119 and rerun the whole-entry
gate. The substantive CURRENT-DUPLICATE / STAY-CANONICAL outcome is not
otherwise challenged.
