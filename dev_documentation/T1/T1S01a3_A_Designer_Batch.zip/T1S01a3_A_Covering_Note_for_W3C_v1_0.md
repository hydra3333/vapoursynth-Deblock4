# Deblock4 - Covering Note for W3C: T1S01a3

**Route:** W3X -> W3C
**Date:** 2026-08-18
**Encoding:** US-ASCII; CRLF.

---

## Before anything else

Check that the complete `dev_documentation` corpus and the `src` tree are in
front of you. They are supplied SEPARATELY from this package, deliberately - a
step package must never be reviewable on its own, because that is the defect
you yourself identified as blocking. If either is missing, STOP and ask.

## What changed since your last review, and why

You found three things in T1S01a2 and all three were accepted.

```text
COVERAGE. You found a range declared adjudicated while only a selection of its
statements was logged. That is now a standing rule: a sub-tranche declares the
EXACT statements it covers and assigns every omission to a NAMED later
sub-tranche. This package's ledger opens with that declaration - check it
first.

THE ATOMIC-CLAIM RULE and THE CANONICAL-HOME rule for CURRENT-DUPLICATE, both
yours, are now in review scope v1.8.

A NEW FIELD, SWEPT, is also in v1.8 and it exists because of a designer
failure you should know about. Three times the designer claimed something was
UNIQUE, INDEPENDENT or UNAFFECTED without searching for the counter-evidence,
and three times the counter-evidence was in a document already open. Twice the
designer had flagged the risk in the same entry and still did not check. So the
check is now visible: any such claim must record WHAT WAS SEARCHED. You can
attack the SEARCH, not only the conclusion.
```

Also: your finding that section 23 steps 8 and 9 are in the wrong order is
recorded as a real defect in the authority document. It is NOT repaired, and
the repair is NOT guessed - it is deferred to T1S01a4 with your reasoning
attached, including your point that scalar candidate implementations may be
needed to compare schedules in the first place.

## What this sub-tranche is

The remaining work on the authority document is split into three:

```text
T1S01a3  THIS ONE - section 0's seventeen numbered architecture items and the
         header's remaining statements. Subject: what the document says the
         ARCHITECTURE IS.
T1S01a4  section 23's steps 6-10, carrying the ordering defect you found.
T1S01a5  the revision history, and the FINAL sub-tranche of this document -
         cross-entry consistency across the whole document is checked there.
```

## The one thing worth your attention most

Every one of the seventeen items turns out to be a summary of a decision
recorded formally elsewhere in the SAME document. Strictly that makes them all
duplicates. But section 0 is a deliberate read-first summary - its redundancy
is its function, and every orientation document in this project sends a cold
successor to it first.

So the ledger raises a question rather than assuming an answer: should the
disposition vocabulary distinguish a DESIGNED summary from an ACCIDENTAL
duplicate? If it should not - if the later de-duplication work can be trusted
to see that a read-first summary stays - say so plainly, because adding a field
to every duplicate entry is not free.

That proposal changes a criterion applied to the designer's own ledger, so it
is I7 shape and wants your independent view before W3X decides.

## Also worth checking

```text
- Twelve entries, and seven of them take the SAME disposition with the same
  canonical-home form. That is either correct or a sign that seventeen items
  received one judgement wearing seven hats. Test at least one item against
  its stated home yourself.
- LED-023 records a BLANKET claim - "nothing in this document rests on
  unverified GAIS testimony" - as CURRENT-UNIQUE while stating openly that its
  TRUTH has not been verified, because only a tenth of the document has been
  swept. Is that acceptable, or should such a claim carry a different
  disposition until the final sub-tranche can confirm it?
- Four entries carry SWEPT fields. If you can name a section the designer did
  not look in, that is a finding.
```

## Standing reminders

Silence between sub-tranches is not agreement; if you raised something and it
recurs, raise it again. A METHOD problem goes at the TOP of your response, not
buried in a verdict. Read the swept sections yourself - a quotation chosen by
the designer cannot show you what the designer walked past.

Deliver as `T1S01a3_B_Coder_Response.zip`.
