# Deblock4 - W3C Review of T1S01a5 Classification Repair

**Deliverable:** T1S01a5_B - CLASSIFICATION REPAIR REVIEW
**Version:** 1.0
**Date:** 2026-08-19
**Author:** W3C
**Route:** W3C -> W3X -> W3D
**Reviews:** `T1S01a5_A_Classification_Repair_v1_0.md`
**Batch:** `T1S01a5_A_Classification_Repair_Batch.zip`
**Register:** `Deblock4_Standing_Task_Register_T_Series_v1_29.md`
**Common base:** `dev_documentation(20260819-042914).zip`
**Population basis:** DEC-63 and DEC-66, including W3X's post-snapshot relocation
of the two root GAIS response files into the ignored `GAIS_investigations/`
tree.
**Encoding:** US-ASCII; CRLF.

---

# Plain-English summary

The substantive classification repair now passes W3C's cross-check.

W3C independently reproduced the exact candidate-file membership for every
probe family actually tabulated in repair v1.0. The corrected classifications
also resolve the seven QC-3 defects W3C previously identified: the false
version-string and D4-Q01 matches are no longer treated as knowledge; the
Scopes F7 copies are correctly CARRIERs; the LED-061 coder-introduction and
D2 hits are correctly DIFFERENT; and the repaired LED-035/036/049
classifications are semantically supportable. No new technical or architecture
defect was found in those classifications.

The repair is not yet self-contained in the form it promises, however. Section
0 says that FOR EVERY PROBE the artifact contains the exact candidate file list
with every file labelled, but section 3 deliberately omits nine of the 22
tables and refers back to earlier W3C/evidence material instead. There are also
two small record errors: "CARRIER LISTS REBUILT - seven" actually enumerates
eight entries, and LED-035 says "9 W3C computed" where W3C reproduced nine
CANDIDATE HITS, not nine carriers.

These are bounded evidence-record corrections only. No search should be rerun,
no classification should be reopened, and no new methodology round is needed.
W3C recommends one mechanical repair v1.1, followed immediately by the ledger
rewrite.

No source was modified. No build, execution, test, patch, delivery machinery
or git operation was performed.

---

# DECISIONS/QUESTIONS FOR W3X

None.

No new W3X technical or process decision is required.

DEC-67 already contains the ratified search/classification rules. This review
only checks whether W3D's repair correctly instantiates them.

---

# Overall verdict

```text
raw settled probe outputs                 PASS
13 tabulated candidate-file lists         PASS - exact membership reproduced
corrected QC-3 classifications            PASS
six disposition-change plan               PASS
LED-051 carrier result                    PASS
LED-051 11-row / 12-row correction        PASS
28-of-34 disposition arithmetic           PASS

repair artifact self-containment          FAIL - nine probe tables omitted
"carrier lists rebuilt - seven" count     FAIL - list contains eight
LED-035 "9 W3C computed" wording          FAIL - nine HITS, not carriers
```

**RESULT: SUBSTANTIVE PASS; NARROW MECHANICAL REISSUE REQUIRED.**

---

# 1. Candidate membership for every TABULATED probe - PASS

W3C independently applied the already-settled probe families to the 46-file
population.

The exact candidate sets in repair v1.0 match W3C's reproduction for every
table actually printed:

```text
LED-033    11 / 11 exact
LED-035     9 /  9 exact
LED-036     3 /  3 exact
LED-040     4 /  4 exact
LED-041     4 /  4 exact
LED-044     2 /  2 exact
LED-045     5 /  5 exact
LED-047     1 /  1 exact
LED-049     6 /  6 exact
LED-053d    2 /  2 exact
LED-055     7 /  7 exact
LED-058     6 /  6 exact
LED-061     6 /  6 exact
```

The LED-033 Rule-3 expansion is also correctly recorded. With:

```text
PREVAILING MPEG-2 AUTHORITY
```

added to the bounded probe family, the designer introduction enters as the
previously missed semantic carrier and the false Stage-1B3 version-string hit
remains visibly DIFFERENT.

No further search expansion is indicated by this review.

---

# 2. Corrected classifications - PASS

## LED-033

PASS.

The designer introduction is now correctly included as a CARRIER. The
Stage-1B3 runtime-guard scope is correctly DIFFERENT: its "single source"
language concerns the version string, not MPEG-2 authority.

The stray T1 review-scope v1.7 remains visibly identified as a process artifact
that happens to sit under `Scopes/`.

## LED-035

PASS on classification.

The three newly opened false candidates are correctly DIFFERENT:

```text
Forward Roadmap
    deferred Classic Stage-3C acceptance basis

Project Status
    status-versus-acceptance-state proposition

D0 index
    oracle-construction acceptance basis
```

The Scopes re-decision evaluation is correctly CARRIER because it expressly
states that Classic thresholds are illustrative and not a Deblock4 acceptance
basis.

The PreScope coder response is also a CARRIER.

## LED-036

PASS.

The designer introduction states both the SA/SB renaming and the collision it
prevents, so CARRIER is correct.

Project Status merely uses the current Schedule-SA/SB spelling while discussing
the a4 ordering defect, so APPLIES is correct.

## LED-040

PASS.

Charter B5 is correctly shown as the canonical project-wide rule. The authority
copy being adjudicated is a local CARRIER/restatement.

## LED-041

PASS.

No classification defect found in the four-file set.

## LED-044

PASS.

The designer introduction's future trusted-side-data bullet is reasonably
classified APPLIES rather than as a second statement of F6's complete
post-decode knowledge-limit proposition.

## LED-045

PASS.

The two Scopes files now correctly classify as CARRIER because each actually
states that TFF/BFF does not affect block geometry.

The README match is correctly DIFFERENT: it merely lists field order as a
frame-level property exposed by BestSource.

## LED-047

PASS.

The authority is the only returned file for the provenance-re-audit
proposition.

## LED-049

PASS.

Grid Knowledge is correctly MIXED: it carries the specific MediaInfo regime
route and separately carries a broader MediaInfo/ffprobe evidence statement.

The Scopes evaluation reports that the old document recorded the cheap check;
it does not restate the command/triage route itself. Treating that occurrence
as APPLIES rather than a carrier is acceptable for this ledger purpose and
does not affect the duplicate disposition.

## LED-053d

PASS.

The authority correctly receives MIXED treatment at FILE level because section
4.5 is the adjudicated/canonical detailed statement while Appendix A in the
same physical file independently restates the row-pitch-2 proposition.

The Scopes coder response is a genuine second-file CARRIER.

## LED-055

PASS.

The repair now correctly distinguishes files that carry only the whole-frame
conclusion from files that also carry the tearing mechanism.

In particular W3C confirms the newly recorded second non-authority mechanism
carrier:

```text
Scopes/Deblock4_D4_Architecture_ReDecision_Brief_for_W3C_v1_0.md
```

which says SeparateFields tears frame-organised blocks across two clips,
four rows each.

That reinforces the withdrawal of the old blanket "derivation is unique"
claim.

## LED-058

PASS.

Grid Knowledge is now correctly treated as the actual live stale
`regime 3, mixed` exposure rather than a hypothetical one.

The authority remains the detailed canonical home and also contains the unique
document-local corrective reading rule.

## LED-061

PASS.

Both false `independent verification` hits are now correctly DIFFERENT:

```text
coder introduction
    charter I7 independent verification

D2 HolyWu schedule
    W3C independent verification of D2
```

The actual GAIS standing-rule carriers are correctly separated from those
unrelated uses.

This is unaffected by ignoring `GAIS_investigations/**`: none of the raw GAIS
files is needed to establish the current classification.

---

# 3. The nine adopted W3C classifications - substantive acceptance

Repair section 3 says W3D accepts W3C's existing classifications for:

```text
LED-034
LED-037
LED-038
LED-039
LED-042
LED-043
LED-046
LED-048
LED-053c
```

W3C does not require those classifications to be reopened.

The important previously disputed results remain correctly stated, including:

```text
LED-038
    three Scopes hits;
    D4-Q01 substring -> IDENTIFIER;
    re-decision evaluation defining e/q0 -> CARRIER;
    PreScope formula use -> APPLIES.

LED-042
    six Scopes carriers, not five.

LED-053c
    README and Scopes equivalents are CARRIERs;
    luma-primary/midpoint references are DIFFERENT.
```

The problem is not their substantive classification. It is that repair v1.0
does not actually print the promised exact tables for these nine probes.

---

# 4. SELF-CONTAINMENT DEFECT - section 0 promises 22 complete tables but supplies 13

This is the one material repair-artifact defect.

Section 0 says:

```text
"For every probe: the EXACT candidate FILE list - every file, none summarised
away; each file labelled..."
```

and:

```text
"THE TABLE IS GENERATED FROM THE SEARCH, NOT TYPED."
```

But section 3 says:

```text
"The nine probes not tabulated above..."
```

and then summarizes or refers to classifications already stated in W3C's
cross-check/re-sweep evidence.

So the repair is not the self-contained evidence artifact it says it is.

This matters because the entire purpose of the repair is to become the stable,
auditable classification basis from which the rewritten ledger is generated.
A future reviewer should not need to reconstruct nine of 22 candidate lists by
cross-reading previous dispute documents.

## Required repair

**Do not rerun anything.**

For the nine omitted probes, insert the already-settled exact candidate lists
and classifications into the same generated table format:

```text
LED-034
LED-037
LED-038
LED-039
LED-042
LED-043
LED-046
LED-048
LED-053c
```

Use the candidate sets already produced by the settled searches and the
classifications W3D has explicitly adopted from W3C.

Then section 0's completeness claim becomes literally true.

---

# 5. Mechanical count defect - "seven" carrier lists actually enumerates eight

Section 4 says:

```text
CARRIER LISTS REBUILT - seven, not four as previously stated:
  LED-033, LED-035, LED-036, LED-038, LED-042, LED-049, LED-055, LED-061
```

That is **eight** entries.

Required correction:

```text
CARRIER LISTS REBUILT - eight, not four as previously stated:
```

No other consequence.

---

# 6. LED-035 historical wording - W3C reproduced nine HITS, not nine CARRIERS

Section 1 says:

```text
"The carrier count falls from the 8 W3D claimed, and the 9 W3C computed, to
SIX."
```

That is not an accurate description of W3C's prior finding.

W3C reproduced:

```text
9 candidate FILE HITS
```

and specifically criticised the earlier text for calling that set a carrier
set while one of its members was labelled APPLIES.

The repaired table now contains:

```text
5 non-canonical CARRIER-labelled files
1 CANONICAL authority file
3 DIFFERENT files
= 9 candidate hits
```

So if W3D wants to count proposition-bearing files including the canonical
home, that count is six. But it should not say W3C computed nine carriers.

Recommended replacement:

```text
"The nine candidate hits W3C reproduced resolve to six proposition-bearing
files: the canonical authority plus five non-canonical carriers."
```

This is a record-accuracy correction only.

---

# 7. Six disposition changes and 28/34 arithmetic - PASS

The repair now enumerates six original entries whose disposition structure
changes:

```text
LED-043
LED-051
LED-053
LED-055
LED-058
LED-061
```

Therefore:

```text
34 - 6 = 28
```

The statement that 28 of the 34 original entries retain their disposition
structure is arithmetically consistent.

This corrects the withdrawn 24/34 figure.

W3C also confirms the already-settled content feeding those changes:

```text
LED-051
    Scopes re-decision evaluation is a CARRIER
    -> CURRENT-DUPLICATE

LED-051 DERIVED wording
    one pitch-2 six-sample edge spans 11 frame rows
    two-parity union spans 12 frame rows
    -> old "13 rows" wording is wrong
```

No further substantive review is required at classification-repair stage.

---

# 8. What should happen next

W3C recommends a **mechanical v1.1 reissue only**:

```text
1. insert the nine omitted exact candidate-file tables;
2. seven -> eight in the rebuilt-carrier-list count;
3. correct LED-035's "9 W3C computed" wording to nine candidate hits.
```

No probe rerun.
No synonym expansion.
No classification reconsideration.
No new method rule.
No architecture reopening.

After that short delta is clean, the classification repair should close and W3D
can generate the rewritten T1S01a5 ledger directly from it.

Given the cost already incurred in a5, W3C specifically recommends resisting
any attempt to broaden this correction into another research or methodology
round.

---

# Current W3C position

```text
CLASSIFICATION REPAIR SUBSTANCE     PASS
CLASSIFICATION REPAIR RECORD        THREE NARROW FIXES
SEARCH ROUND                         CLOSED
TECHNICAL ARCHITECTURE              NOT REOPENED
NEXT AFTER MECHANICAL FIX           REWRITTEN T1S01a5 LEDGER
```

---

*Revision history*

```text
v1.0 (2026-08-19) Independent W3C review of classification repair v1.0.
     Reproduces exact candidate membership for all 13 probe families actually
     tabulated and accepts the corrected semantic classifications, including
     all seven prior QC-3 disputes. Finds no new architecture defect. Finds
     three bounded record defects: nine of 22 probe tables are omitted despite
     the artifact's promise of a complete exact file-by-file table; "carrier
     lists rebuilt - seven" enumerates eight entries; and LED-035 incorrectly
     says W3C computed nine carriers where W3C reproduced nine candidate hits.
     Confirms six disposition-structure changes and the corrected 28/34
     arithmetic. Requests no search rerun and no methodology reopening.
```
