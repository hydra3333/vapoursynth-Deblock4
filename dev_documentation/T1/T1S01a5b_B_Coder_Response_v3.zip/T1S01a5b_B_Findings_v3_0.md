# Deblock4 - T1S01a5b Batch 1 v3 W3C Correction Review Findings

**Deliverable:** T1S01a5b_B - CODER RESPONSE / BATCH 1 CORRECTION REVIEW 2 FINDINGS
**Version:** 3.0
**Date:** 2026-08-22
**Author:** W3C
**Route:** W3C -> W3X -> W3D
**Reviews:** `T1S01a5b_A_Designer_Batch_v3_SLIM.zip`
**Primary ledger:** `T1S01a5b_A_Ledger_Body_Part2_v1_3.md`
**Reference corpus:** W3X-supplied 2026-08-22 `dev_documentation` tree
**Binding scope:** `Deblock4_T1_W3C_Review_Scope_v1_15.md`
**Nature:** DOCUMENT REVIEW ONLY. No source, build, test, patch or git.
**Encoding:** US-ASCII; CRLF.

---

# Plain-English summary

This was the bounded second correction review requested by covering note v1.5,
not a fresh Batch-1 review. W3C verified only the six open verdict fields and
the F15 ledger-level metadata repair. The 23 recorded AGREE entries were not
reopened.

Four of the six corrected items AGREE. Two still require a small correction,
both in the F10 no-multiply split: LED-066 points the split token to the wrong
authority line, and new LED-066b repeats that wrong line and overstates the
number of files in its declared multiply/multiplication sweep.

Result for this correction round: 4 AGREE / 2 DISAGREE, with 0 UNSURE and 0
MISSING. F15's population/coverage metadata repair is accepted. The
substantive conclusion of LED-066b remains supported: the no-multiply-as-
retained-from-A proposition is CURRENT-UNIQUE on the declared 38-file
population. The residual defects are attackability/accounting defects, not a
change to that disposition.

---

# DECISIONS/QUESTIONS FOR W3X

None at this review stage.

W3C recommends one further tightly bounded designer correction of LED-066 and
LED-066b only. No other Batch-1 entry should be reopened. No a5 work, final
a5b cross-entry pass, source work or authority edit is requested by this
review.

---

# 1. Review basis and bounded-scope checks

W3C used:
- covering note v1.5;
- designer ledger v1.3;
- Population Delta v1.1;
- Population and Coverage Map v1.0, subject to the ledger-recorded amendments;
- Review Scope v1.15, including DEC-84 section 0.11;
- the W3X-supplied current 38-file documentation corpus;
- T1S01a5b_B v2 findings F10-F15 as the settled correction baseline.

Mechanical/bounded checks reproduced:

```text
SLIM package inventory:                         5 files, as declared
Open correction-review verdict fields:         6
Carried recorded AGREE entries:                23
Changed existing entry bodies vs ledger v1.2: LED-066, LED-070b,
                                                LED-074b, LED-079, LED-081a
New entry:                                      LED-066b
Unexpected carried-entry body changes:         0
Current a5b population:                         38 files
```

No source/build/test/git work was performed. LED-081a's unchanged `src tree -
NONE FOUND` statement was therefore not independently rerun; the v3 repair
under review was its document/process-artifact propagation enumeration, which
is independently decidable from the supplied documentation.

---

# 2. Correction-round verdict summary

```text
AGREE (4):
    LED-070b
    LED-074b
    LED-079
    LED-081a

DISAGREE (2):
    LED-066     - F16
    LED-066b    - F17

UNSURE:   0
MISSING:  0

F15 ledger-level metadata repair: ACCEPTED
```

---

# 3. F16 - LED-066 points the split token to the wrong authority line
## Affects LED-066

The F10 substance is correctly repaired. Evaluation lines 654-655 now include
the retention verb for the no-float limb, and separating the no-multiply token
into LED-066b prevents a subset carrier from proving the larger conjunction.

The reissued entry, however, locates that split token incorrectly twice:

```text
"Token-level split of line 741"
"the /multiply token of item 3 at line 741 is LED-066b"
```

In the supplied authority v1.05, the relevant source lines are:

```text
741  - creation-time fixed-point conversion;
742  - immutable threshold sets;
743  - no float/multiply in the pixel loop;
744  - deterministic/stateless operation;
```

Thus the `/multiply` token is at authority line 743, not 741. Because this
round creates an atomic split whose attackable source location is part of the
correction itself, the wrong line cannot be carried as accepted evidence.

Required correction: change the LED-066 references to the split token from
line 741 to line 743. No disposition, tier or substantive retention finding
needs to change.

VERDICT: DISAGREE.

---

# 4. F17 - LED-066b has a wrong source line and a wrong file count
## Affects LED-066b

The substantive search result is sound. W3C independently reran the declared
case-insensitive `multiply|multiplication` family over the exact current
38-file population and reproduced 11 line loci. The sole CARRIER of the
no-multiply-as-retained-from-A proposition is the authority itself; the other
hits are correctly distinguishable as APPLIES or DIFFERENT. The DERIVED
wording-scope note remains explicitly labelled as an observation and proposes
no action, so W3C does not object to it in this bounded round.

Two attackability/accounting defects remain.

First, the entry's `DOCUMENT` field says the `/multiply` token is authority
line 741, and DERIVED again refers to the literal breadth of line 741. The
actual token is at authority line 743.

Second, SWEPT says:

```text
Eleven loci in eight files
```

W3C reproduces:

```text
11 loci in 7 files
```

The seven files are:

```text
Deblock4_Stage_2C_D0_Preface_and_Binding_Knowledge_Index_v1_14.md
Deblock4_Stage_2C_D2_HolyWu_Real_Schedule_v1_7.md
Deblock4_MPEG2_Deblocking_Investigation_and_Decided_Architecture_v1_05.md
Deblock4_DISPATCH_RELATED_Backend_Objects_Explained_v1_4.md
Deblock4_MPEG2_Grid_Field_DCT_Knowledge_v1_2.md
README_Deblock4_Design_Spec_v1_12.md
Scopes/Deblock4_D4_Architecture_ReDecision_Brief_for_W3C_v1_0.md
```

Their 11 loci are exactly the loci already printed by LED-066b: authority
743/1328; Re-Decision Brief 60; README 653/1923; D0 252; D2 187/245/410;
Grid Knowledge 141; dispatch explainer 397. The entry therefore has the right
locus set but the wrong distinct-file count.

Required correction:
- change LED-066b's source-line references from 741 to 743, including DERIVED;
- change `eleven loci in eight files` to `eleven loci in seven files`.

No disposition or tier change is required. CURRENT-UNIQUE remains supported.

VERDICT: DISAGREE.

---

# 5. Repairs accepted in this round

## LED-070b - AGREE

The F11 occurrence locations are now attackable and correct. Authority
1658-1659 carries `B2 / macroblock-topology architecture PRIMARY candidate`,
and 1806-1808 carries `Architecture B2 / Primary current candidate`. The
CURRENT-DUPLICATE conclusion is unchanged and supported.

## LED-074b - AGREE

The declared geometry family now reproduces exactly as ten line loci in two
files. W3C independently obtained authority 137, 463, 812, 815, 861 and
Re-Decision Evaluation 71, 257, 701, 793, 804. The previously missed exact
`M = 16*m` occurrence at Evaluation 257 is now present and classified. No
additional file matched the declared family.

## LED-079 - AGREE

The F13 accounting now reproduces exactly:

```text
files containing case-insensitive literal "seam": 18
raw substring matches:                         77
deduplicated line loci:                        76
```

The printed line-locus table sums to 76; the charter contributes 10 line loci
but 11 raw matches because line 757 contains the term twice. The repair
correctly records the old `81` as unreproducible from the recorded method and
supersedes it rather than inventing a missing basis.

## LED-081a - AGREE

The F14 document/process propagation repair now satisfies the defect W3C
identified in v2. Step 1 names Population Delta v1.1 as the current population.
For the current 38-file population, W3C independently reproduces exactly six
case-insensitive `section 15` candidates:

```text
coder blurb v1.7:49                 ACTUAL RELIANCE
designer blurb v1.9:40              ACTUAL RELIANCE
authority v1.05:873                 SOURCE DEFECT / SELF
authority v1.05:1580                NON-RELIANCE
README v1.12:3072                   DIFFERENT / NON-RELIANCE
README v1.12:3289                   DIFFERENT / NON-RELIANCE
```

The two README hits are indeed external RFC 6386 section-15 material, not
Deblock4 section-15 routing. The historical Population Delta v1.0 line 208 and
Map v1.0 lines 232-234/332 are separately enumerated as actual batch-process
dependencies and routed; Population Delta v1.1 line 208 carries the corrected
`section 16` value. This resolves F14 without changing the already accepted
SUPERSEDED / ERRONEOUS technical conclusion.

## F15 ledger metadata - ACCEPTED

The ledger header now points to Population Delta v1.1, and section 0.1 no
longer claims unqualified `without deviation`; it explicitly qualifies Part B
by the four recorded v1.2 amendment rows. F15 is closed for this round.

---

# 6. Requested next correction boundary

A further designer generation need address only:

```text
LED-066     F16: line 741 -> 743 for the split /multiply token
LED-066b    F17: line 741 -> 743; 8 files -> 7 files
```

LED-070b, LED-074b, LED-079, LED-081a and F15 should be carried forward as
accepted and not reopened unless a concrete consequential edit requires it.
