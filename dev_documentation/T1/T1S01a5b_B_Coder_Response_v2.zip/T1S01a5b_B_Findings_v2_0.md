# Deblock4 - T1S01a5b Batch 1 v2 W3C Correction Review Findings

**Deliverable:** T1S01a5b_B - CODER RESPONSE / BATCH 1 CORRECTION FINDINGS
**Version:** 2.0
**Date:** 2026-08-22
**Author:** W3C
**Route:** W3C -> W3X -> W3D
**Reviews:** `T1S01a5b_A_Designer_Batch_v2_SLIM.zip`
**Primary ledger:** `T1S01a5b_A_Ledger_Body_Part2_v1_2.md`
**Reference corpus:** W3X-supplied 2026-08-22 `dev_documentation` tree
**Binding scope:** `Deblock4_T1_W3C_Review_Scope_v1_15.md`
**Nature:** DOCUMENT REVIEW ONLY. No source, build, test, patch or git.
**Encoding:** US-ASCII; CRLF.

---

# Plain-English summary

This was the bounded correction review requested by the v1.2 covering note,
not a fresh Batch-1 review. W3C verified only the 16 open correction fields,
plus the changed population/coverage evidence. The 12 entries already marked
AGREE from T1S01a5b_B were carried forward unchanged and were not reopened.

Most of W3D's F1-F9 repairs are sound. Eleven of the 16 corrected/new/reissued
items AGREE. Five still require correction: LED-066, LED-070b, LED-074b,
LED-079 and LED-081a. In addition, the ledger's own population/coverage
metadata contains two stale statements outside any entry verdict field.

Result for this correction round: 11 AGREE / 5 DISAGREE, with 0 UNSURE and 0
MISSING. The substantive F9 conclusion remains sound: LED-081a is properly
SUPERSEDED / SUPERSEDED-KIND ERRONEOUS and the authority pointer should be
`section 16`, not `section 15`; the remaining LED-081a defect is in its
mandatory DEC-84 propagation record, not in that technical conclusion.

---

# DECISIONS/QUESTIONS FOR W3X

None at this review stage.

W3C recommends that W3D issue a bounded correction of the five DISAGREE
entries plus the ledger-level F15 declarations. No a5 work, final a5b
cross-entry pass, source work or authority-document edit is requested by this
review. LED-081a's authority remedy should remain staged until its correction
entry and propagation record are accepted through the normal review path.

---

# 1. Review basis and bounded-scope checks

W3C used:
- the v1.2 correction-round covering note;
- the v1.2 designer ledger;
- Population Delta v1.1;
- Population and Coverage Map v1.0, Part B, subject to the amendments recorded
  by the v1.2 ledger;
- Review Scope v1.15;
- the W3X-supplied current 38-file documentation corpus;
- the prior T1S01a5b_B reviewed v1.1 ledger and findings F1-F9 as the settled
  comparison baseline.

Mechanical/bounded checks reproduced:

```text
SLIM package inventory:                    6 files, as declared
Open correction-review verdict fields:    16
Carried prior AGREE entries:               12
Carried-entry body changes:                0
Current a5b population:                    38 files
Population membership vs Delta v1.1:       exact match
v1.2 disposition enumeration:              24 CURRENT-DUPLICATE
                                           3 CURRENT-UNIQUE
                                           1 SUPERSEDED/ERRONEOUS
                                           = 28 entries
```

For the seven `REPAIR-v1_2` entries, W3C also compared v1.2 with the prior
reviewed v1.1 baseline. Outside the labelled repair blocks and verdict fields,
the entry bodies are unchanged. This review therefore stayed inside W3D's
correction-round boundary.

The current checkpoint explicitly excludes source/build/test/git work. W3C did
not independently rerun the `src/` grep asserted inside LED-081a's PROPAGATION
record. That does not determine the LED-081a verdict below because the document
population portion of the propagation record already contains independently
reproducible defects.

---

# 2. Correction-round verdict summary

```text
AGREE (11):
    LED-064
    LED-066a
    LED-067
    LED-067a
    LED-068
    LED-069
    LED-070
    LED-073
    LED-073a
    LED-074
    LED-081

DISAGREE (5):
    LED-066     - F10
    LED-070b    - F11
    LED-074b    - F12
    LED-079     - F13
    LED-081a    - F14

UNSURE:   0
MISSING:  0
```

The 12 carried T1S01a5b_B AGREE entries remain untouched:
LED-065, LED-070a, LED-071, LED-072, LED-074a, LED-075, LED-076, LED-077,
LED-078, LED-078a, LED-078b and LED-080.

---

# 3. F10 - LED-066 still overstates the duplicate evidence
## Affects LED-066

W3D correctly split the fifth uncertainty clause into LED-066a. The remaining
LED-066 proposition, however, is still a four-item conjunction and its cited
non-canonical carrier does not support all four items as retained-from-A.

The authority source proposition includes:

```text
creation-time fixed-point conversion
immutable threshold sets
no float/multiply in the pixel loop
deterministic/stateless operation
```

The Re-Decision Evaluation passages cited to establish duplication say:

```text
1072-1073: RETAIN A's good engineering ideas - immutable creation-time
           threshold sets, fixed-point scaling, no hidden state ...

654-655:   The fixed-point creation-time scaling, immutable threshold sets
           and no-float kernel discipline remain excellent patterns.
```

Two defects follow.

First, LED-066 cites `633-654`; line 654 ends after `no-float`, while the verb
that makes the sentence a retention statement is on line 655. The attackable
range must include line 655.

Second and more importantly, neither cited Evaluation passage states that the
`no multiply in the pixel loop` limb was retained from A. W3C searched the
current 38-file population for this material. The authority itself carries the
source limb; README material carries the live no-multiply practice rather than
the retained-from-A proposition; and the Re-Decision Brief is pre-decision
APPLIES material. The Evaluation supports `no-float`, but not the full
`no float/multiply` retained-from-A limb.

This repeats the evidential form of F3 at a smaller boundary: a subset carrier
cannot prove a conjunction whose remaining limb has different occurrence
status.

Required correction:
- fix the Evaluation range to include line 655; and
- either split/narrow the no-multiply retention limb so each atomic proposition
  receives its own evidence/disposition, or provide a genuine second carrier
  for that retained-from-A limb.

The general retention decision is not challenged.

VERDICT: DISAGREE.

---

# 4. F11 - LED-070b's same-file copy locations do not contain the claim
## Affects LED-070b

The new LED-070b correctly captures the previously omitted source proposition:

```text
Architecture B2 - PRIMARY CANDIDATE
```

CURRENT-DUPLICATE / Tier C is substantively sound. The defect is occurrence-
level evidence in two CITED-OUTSIDE-RANGE locations that the covering note
specifically asked W3C to open.

The ledger cites:

```text
D4-D12 register: 1658
Appendix material: 1804-1806
```

But the authority actually reads:

```text
1658  Old Architecture A rejected; generic regional B superseded; B2
1659  macroblock-topology architecture PRIMARY candidate; ...
```

Thus line 1658 alone does not carry PRIMARY-candidate status. An attackable
range is, for example, 1658-1660.

Likewise:

```text
1804  Rejected old separated-field primary/midpoint union-grid architecture.
1806  Architecture B2
1807  Primary current candidate: per-MB FRAME/FIELD/UNKNOWN map -> ...
```

The cited 1804-1806 range stops before the proposition. The relevant range is,
for example, 1806-1808.

Required correction: repair the REASON/SWEPT/CITED-OUTSIDE-RANGE locations to
point at the lines that actually carry the proposition. No disposition or tier
change is required.

VERDICT: DISAGREE.

---

# 5. F12 - LED-074b's declared sweep misses an exact occurrence
## Affects LED-074b

The F6 atomicity split is correct, and CURRENT-DUPLICATE remains supported.
The new entry's SWEPT evidence is nevertheless incomplete under the binding
occurrence-level rule.

LED-074b declares this probe family, including the exact expression:

```text
"M = 16*m"
```

It then lists the Re-Decision Evaluation only at line 71 and says no other file
matched. The same Evaluation has another direct occurrence at line 257:

```text
Within a 16-row macroblock beginning at `M = 16*m`:
```

That is not a marginal lexical hit. It directly carries the row-origin limb of
LED-074b's proposition and is an exact match to one of the entry's own declared
probes. Evaluation line 701 also contains `16-pixel macroblock segments` and
should be opened/classified when the reformulation family is rerun.

Required correction: rerun the same declared family, add/classify Evaluation
line 257 at minimum, and enumerate any other returned occurrences. The
CURRENT-DUPLICATE disposition does not need to change on the evidence W3C saw.

VERDICT: DISAGREE.

---

# 6. F13 - LED-079's DEC-50 count reconciliation is arithmetically inconsistent
## Affects LED-079 REPAIR-v1_2 only

The important part of F7 is now present: the repair prints the 18-file result
set instead of leaving the claimed sweep unenumerated. W3C reproduced the same
18 files. The printed counts, however, do not reconcile as stated.

The 18 per-file numbers printed in REPAIR-v1_2 sum to 77, not 76. The source of
that one-count difference is the charter: it has 11 raw occurrences of the
substring `seam` but only 10 distinct line loci because one line contains the
term twice.

W3C independently reproduced, on the exact current 38-file population:

```text
files containing case-insensitive literal "seam":  18
raw substring matches:                              77
deduplicated line loci:                             76
```

Therefore:
- if the per-file table is a line-locus table, the charter row must be 10 and
  the total 76;
- if the per-file table contains raw matches, its current rows total 77;
- the repair's statement that v1.1's `81` was the raw regex count is not
  reproducible from the method stated in the repair. If 81 came from a broader
  regex, that exact regex/basis must be stated so another reviewer can obtain
  81; otherwise the raw figure should be corrected to 77.

This is a DEC-50 evidence-accounting defect only. W3C found no reason to change
CURRENT-DUPLICATE, STAY-CANONICAL, or the semantic classification of the seam
families.

VERDICT: DISAGREE.

---

# 7. F14 - LED-081a's DEC-84 propagation record is still incomplete
## Affects LED-081a

W3C AGREEs with W3D on the substantive F9 correction:

```text
CONFLICTING -> SUPERSEDED
SUPERSEDED-KIND -> ERRONEOUS
false target: section 15
correct target: section 16
Tier: A
```

W3C independently re-read authority sections 15 and 16. Section 15 is the Q14
architecture-discriminator experiment; section 16 is `UNKNOWN POLICY REVISIT`
and contains the actual post-Q14 revisit requirement. Population Delta v1.1
also correctly changes its routed occurrence at line 208 from section 15 to
section 16. Map v1.0 still contains the old section-15 routing at lines 232-234
and 332, exactly as the ledger says is pending a map bump.

The mandatory DEC-84 PROPAGATION record has two residual defects.

## F14.1 Current population record is misidentified

Step 1 says the current 38-file population is `Population Delta v1.0`. In this
correction package, Population Delta v1.1 is explicitly the population of
record. Historical references to v1.0 in steps 3-4 are correct where they name
the actual faulty dependency that was repaired; the step-1 CURRENT population
pointer is not.

Required: identify v1.1 as the current 38-file population while retaining v1.0
where the record is deliberately describing the historical dependency.

## F14.2 Candidate dependencies are not fully enumerated/classified

DEC-84 step 3 requires candidate dependencies to be enumerated and classified
with attackable location/basis. LED-081a enumerates the actual dependencies,
then collapses the rest into:

```text
all other current "section 15" references - NON-RELIANCE
(they reference section 15 for the Q14 experiment itself ...)
```

That is not an enumeration, and its stated reason is factually false for all
remaining candidates. On the exact current 38-file population, the
case-insensitive `section 15` candidates are:

```text
coder blurb v1.7:49                 ACTUAL RELIANCE
  routes the pre-identified LED-081 obligation to section 15

designer blurb v1.9:40              ACTUAL RELIANCE
  states LED-081 -> section 15

authority v1.05:873                 SOURCE DEFECT / SELF
  the erroneous pointer being propagated

authority v1.05:1580                NON-RELIANCE
  correct reference to section 15 as the Q14 experiment

README v1.12:3072                   DIFFERENT / NON-RELIANCE
  RFC 6386 section 15, external VP8 material

README v1.12:3289                   DIFFERENT / NON-RELIANCE
  RFC 6386 section 15, external VP8 material
```

The two README candidates plainly do not reference Deblock4 section 15 as the
Q14 experiment. They are external RFC references. They still need to be
enumerated/classified because the declared candidate search returned them.

Required: replace the aggregate `all other` statement with an occurrence-level
candidate list/classification (including the source defect itself), while
retaining the four actual dependencies and their existing routing.

Per the live checkpoint, W3C did not rerun the separate `src/` grep. The entry
already fails DEC-84 step 3 on documentation evidence, so no source inspection
was needed to reach this verdict.

VERDICT: DISAGREE.

---

# 8. F15 - Ledger-level population/coverage declarations are stale
## Affects ledger metadata / section 0.1, not an entry verdict field

Two v1.2 declarations need the entry-sweep equivalent at document level.

First, the ledger header still says:

```text
Population: ... T1S01a5b_A_Population_Delta_v1_0.md
```

The supplied correction package declares Population Delta v1.1 as the current
population of record. The header should point to v1.1.

Second, section 0.1 says the batch follows Map v1.0 Part B segmentation
`without deviation`, then in the same declaration records four amended rows
and says they are a `MAP PART-B AMENDMENT` pending the map v1.1 bump. The
covering note also explicitly says the Part-B amendment is recorded in the
ledger pending that bump.

Required: qualify the coverage sentence, for example:

```text
... follows the map's Part B segmentation except for the explicitly recorded
v1.2 amendments below:
```

This finding does not require reopening the population derivation or the
coverage walk. It repairs the v1.2 ledger's description of the already-declared
current state.

---

# 9. Repairs accepted in this round

The following correction items were checked and AGREE:

- LED-064: F1.1 cross-record plus F2 Grid Knowledge conflict are correctly
  added; the authority remains canonical.
- LED-066a: the measurable/explicit-uncertainty retained-from-A clause is
  properly atomic and CURRENT-UNIQUE on the declared current corpus.
- LED-067: authority line 718 and Grid Knowledge conflict are correctly added.
- LED-067a: Appendix C lines 1873-1901 do carry the promised exact rejection
  proof; the v1.1 over-restriction is correctly withdrawn.
- LED-068 / LED-069: authority line 749 is correctly cross-recorded as the B
  supersession-status occurrence without changing LED-068's historical claim.
- LED-070: F1.3 is correctly routed to the new LED-070b; LED-070's four-layer
  proposition itself is unchanged.
- LED-073: the role/origin proposition is correctly separated from the section
  11 pointer.
- LED-073a: the section-11 pointer is CURRENT-UNIQUE on the declared search,
  and section 11 contains the promised Case-(a) topology for later LED-082
  reconciliation.
- LED-074: the exactly-once half-open ownership proposition is properly
  separated and remains CURRENT-UNIQUE on W3C's current-corpus search.
- LED-081: the missing designer-introduction revisit carrier is correctly
  added and the false `no other file matched` statement is retracted.

These AGREE verdicts do not perform the deferred final a5b cross-entry
consistency pass.

---

# 10. Requested next correction boundary

A further designer generation need only address:

```text
LED-066     F10 evidence/atomicity boundary
LED-070b    F11 occurrence locations
LED-074b    F12 omitted sweep occurrence(s)
LED-079     F13 count basis/arithmetic
LED-081a    F14 DEC-84 propagation record
ledger      F15 current population pointer and Part-B qualification
```

Everything else reviewed in this correction round should be carried forward,
not reopened, unless a concrete consequential change requires it.
