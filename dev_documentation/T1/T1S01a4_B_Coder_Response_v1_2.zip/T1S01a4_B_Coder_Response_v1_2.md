# Deblock4 - W3C Mechanical Delta Review of T1S01a4 Ledger v1.3

**Deliverable:** T1S01a4_B - W3C MECHANICAL DELTA REVIEW
**Version:** 1.2
**Date:** 2026-08-18
**Author:** W3C
**Route:** W3C -> W3X -> W3D
**Reviews:** `T1S01a4_A_Designer_Batch_v4.zip`
**Ledger:** `T1S01a4_A_Ledger_Section23_Tail_v1_3.md`
**Covering note:** `T1S01a4_A_Covering_Note_for_W3C_v1_3.md`
**Binding review scope:** `Deblock4_T1_W3C_Review_Scope_v1_11.md`
**Binding work queue:** `Deblock4_Standing_Task_Register_T_Series_v1_18.md`
**Compared against:** W3C responses v1.0 and v1.1
**Encoding:** US-ASCII; CRLF.

---

# Plain-English summary

This was a mechanical delta check only. I did not reopen the technical result.

The important corrections now pass: DEC-50 carries the refined check-evidence
rule in the wording W3C supplied; section 0 correctly enumerates the prior T1
ledger population by ledger; LED-004's line-1694 range defect is explicitly
registered for a5; LED-025's unaffectedness check is narrowed to DEC-02/03;
LED-026 carries the full rerun constraint and no longer points operationally to
withdrawn LED-031; LED-027's action points to the charter; and LED-029's live
DERIVED text correctly states two roles and two acceptance states rather than
requiring two persistent implementation artifacts.

I nevertheless found a second-layer partial-replacement defect in the live
framing around those corrected fields. The ledger's current "What W3C is asked
here" section still asks about "every T1S01a2 entry" and "every sequencing
decision", even though v1.3 explicitly corrects both formulations. The current
covering note still calls DEC-45 the "TWO-ARTIFACT REPAIR", and DEC-45's final
STATUS paragraph still says the provisional repair rests on the candidate and
oracle being "different artifacts".

Those are operative statements, not harmless revision history. They contradict
the corrections the same documents say were applied. I therefore recommend one
last framing-only reissue before closing T1S01a4.

No source was modified. No build, execution, test, patch, delivery machinery or
git operation was performed.

---

# DECISIONS/QUESTIONS FOR W3X

## Q1. One final framing-only reissue before T1S01a4 closure

I recommend YES.

No finding, disposition, technical derivation or accepted repair needs to be
reopened.

The required changes are only:

```text
1. Rewrite the ledger's current "What W3C is asked here" items 1 and 2 so they
   describe the v1.3 state rather than the superseded v1.2 state.

2. In the covering note's live provisional-adoption paragraph, replace
   "TWO-ARTIFACT REPAIR" with
   "TWO-ROLE / TWO-ACCEPTANCE-STATE REPAIR".

3. In DEC-45's live STATUS paragraph, replace the premise that the comparison
   instruments and accepted oracle are "different artifacts" with the accepted
   distinction: different ROLES and ACCEPTANCE STATES; object identity is not
   established and the same implementation may potentially evolve across both
   roles.
```

Historical references inside revision history or explanatory text saying that
the OLD wording used "two artifacts" may remain, provided they are plainly
historical. The defect is only where that wording still states the current
question/rule.

After those edits I expect T1S01a4 can close on a very short mechanical check.

---

# 1. DEC-50 refined check-evidence rule - PASS

DEC-50 records the independently verified refinement correctly:

```text
A claim that a check was performed must identify the actual OBJECT OR
POPULATION examined AND the result or basis, in a form that makes the claim
independently testable.

For a bounded set/range/overlap/coverage check:
    enumerate the population and record each member's relevant range/result.

For other checks:
    record the identifiers and method/basis appropriate to that check.

Do not invent a line range where no natural range exists.

A bare assurance such as "the set was swept" is not evidence.
```

The I7 provenance is also correctly separated:

```text
proposer:  W3D
verifier:  W3C, with refinement
ratifier:  W3X
```

VERDICT: PASS.

---

# 2. First application of DEC-50 - PASS in section 0

The corrected section-0 population is now named accurately:

```text
T1S01a1
    LED-001 and LED-002
    pre-registered PR-1 / PR-2 material

T1S01a2
    LED-003 through LED-012

T1S01a3
    LED-013 through LED-024 plus LED-020a
```

That is the correct prior-ledger population.

The two defects found in the previous delta are also represented correctly:

```text
LED-001 / LED-002
    correctly moved out of the T1S01a2 population and described by their real
    subject

LED-004
    recorded range 1683-1694
    proposition actually steps 1-5, ending line 1693
    line 1694 is step 6 and belongs to a4 LED-025
    -> range-recording defect, not duplicate adjudication
    -> registered for T1S01a5 alongside LED-010's range defect
```

This is exactly the behaviour the countermeasure was intended to produce:
errors in the claimed check become visible and countable.

VERDICT: PASS on the section-0 enumeration itself.

---

# 3. LED-025 - PASS

The unaffectedness check is now stated only for what was actually examined:

```text
DEC-02 and DEC-03
```

and the ledger expressly declines the broader claim that no current register
decision changes D4-Q16's position.

That is the narrowing W3C requested.

VERDICT: PASS.

---

# 4. LED-026 - PASS

Both requested corrections landed:

```text
- the stale operational pointer to LED-031 is replaced by the corrected
  roadmap-background reference under LED-029;

- the rerun constraint now covers the affected comparison AND ANY OTHER
  QUALITY EVIDENCE that depended on a changed step-7 value.
```

The substantive verdict remains unchanged:

```text
THE TWO-SENSES READING HOLDS.
THE EARLIER THRESHOLD WARNING IS DISSOLVED.
```

VERDICT: PASS.

---

# 5. LED-027 - PASS

The canonical home and proposed T3 action now agree:

```text
canonical controlling home:
    charter oracle-construction exception

detailed durable record:
    Verification and Tiering Decisions section 20.2
```

The proposed pointer action now points to the charter and names the tiering
record as supporting detail.

VERDICT: PASS.

---

# 6. LED-029 operative DERIVED text - PASS

The corrected technical wording now says what W3C intended:

```text
STEP 8 CONFLATES TWO ROLES AND TWO ACCEPTANCE STATES

8a
    comparison-candidate role
    not an accepted oracle

8b
    ReleaseSafe-oracle role
    accepted after schedule freeze
```

It also states explicitly:

```text
WHAT IS PROVED IS THE SEPARATION OF STATUS AND ACCEPTANCE BASIS,
NOT OBJECT IDENTITY.

The same implementation may be reused, refactored or hardened across the
roles.

The project does not currently require two persistent implementation
artifacts.
```

That fully captures W3C's refinement.

VERDICT: PASS on LED-029's actual operative DERIVED/repair text.

---

# 7. LED-030 - PASS

The prior correction remains clean:

```text
- G5 is not used as evidence for the oracle/vector equivalence proposition;
- the charter acceptance rule is canonical;
- Tiering Decisions 20.2 is the detailed record;
- the remaining named duplicate copies are sufficient.
```

VERDICT: PASS.

---

# METHOD / FRAMING DEFECT - the closing instructions still describe the superseded state

This is now the only reason I do not close a4.

## 8.1 Ledger "What W3C is asked here" item 1 is stale

The current ledger says:

```text
Section 0 ... names every T1S01a2 entry, its range, and the comparison.
```

But the corrected section 0 explicitly says that formulation was wrong.

The population is:

```text
every entry in every prior T1 ledger
```

enumerated separately for T1S01a1, T1S01a2 and T1S01a3.

This current question therefore asks W3C to test a claim the same document has
already withdrawn.

Recommended replacement:

```text
Section 0 names every entry in every prior T1 ledger, grouped by ledger, with
the relevant location/range and overlap result. Verify that population and the
recorded boundary exceptions.
```

## 8.2 Ledger "What W3C is asked here" item 2 is stale

The current ledger says LED-025 proves unaffectedness by:

```text
checking every sequencing decision in the register
```

But v1.3 explicitly says that was the overbroad v1.2 claim and corrects it to:

```text
DEC-02 and DEC-03, which are the T1/T5/T6 reversal being referred to.
```

Recommended replacement:

```text
LED-025 now checks DEC-02 and DEC-03, the reversal actually named by REASON,
and expressly makes no broader no-current-decision claim. Verify that this
narrow evidence supports the stated unaffectedness proposition.
```

These are not historical references. They are the live instructions to the
reviewer.

---

# 9. Covering note still calls the live repair "TWO-ARTIFACT"

The covering note's current section:

```text
Two things W3X had already decided, restated because they still hold
```

says:

```text
W3X PROVISIONALLY ADOPTS LED-029's TWO-ARTIFACT REPAIR
```

and then immediately asks whether the two-role/two-acceptance-state distinction
is wrong.

The first phrase is therefore stale operative terminology, not history.

Recommended replacement:

```text
W3X PROVISIONALLY ADOPTS LED-029's TWO-ROLE /
TWO-ACCEPTANCE-STATE REPAIR, SUBJECT TO W3C REVIEW.
```

Historical revision-history descriptions of the old "two-artifact" wording may
remain.

---

# 10. DEC-45 still ends on the rejected "different artifacts" premise

DEC-45's title and main repair body are now correctly rewritten.

However its current STATUS paragraph still says:

```text
The repair is DERIVED DESIGNER REASONING resting on a distinction the
ratified text does not draw - that the comparison instruments and the
accepted oracle are different artifacts. If W3C refutes the distinction,
the provisional adoption falls...
```

That is exactly the stronger proposition W3C declined to establish.

It also contradicts DEC-45's immediately preceding corrected text:

```text
What is proved is the separation of STATUS AND ACCEPTANCE BASIS,
not object identity.
```

Recommended replacement:

```text
STATUS: W3X provisionally adopts, SUBJECT TO W3C's independent review at
T1S01a4. The repair is DERIVED DESIGNER REASONING resting on a distinction
the ratified text does not itself draw explicitly - the COMPARISON-CANDIDATE
ROLE and the ACCEPTED-ORACLE ROLE have different acceptance states and must
occur at different points in the sequence. This does not establish different
object identity. If W3C refutes that roles/acceptance-state distinction, the
provisional adoption falls and the defect needs a different answer.
```

Again, DEC-45 may retain the historical paragraph explaining that its old
wording said "two artifacts". The problem is the live current-status premise.

---

# Consolidated mechanical verdict

```text
DEC-50 refined rule                         PASS
section-0 prior-ledger enumeration          PASS
LED-004 a5 registration                     PASS
LED-025 narrowed unaffectedness evidence    PASS
LED-026 full rerun constraint               PASS
LED-026 withdrawn-entry pointer correction  PASS
LED-027 canonical action target             PASS
LED-029 operative roles/states repair       PASS
LED-030 G5/canonical-home correction        PASS
covering-note currency correction           PASS

LEDGER live closing question 1              FAIL - stale v1.2 population
LEDGER live closing question 2              FAIL - stale v1.2 sweep claim
COVERING NOTE live provisional wording      FAIL - "TWO-ARTIFACT REPAIR"
DEC-45 live STATUS premise                   FAIL - "different artifacts"
```

These failures are all one defect class: a correction landed in the target
field while surrounding live framing retained the superseded proposition.

---

# Current W3C position

The T1S01a4 technical result is settled from W3C's side.

I do not request any further technical derivation, source inspection or
re-adjudication.

I recommend one final framing-only reissue:

```text
- two ledger closing-question edits;
- one covering-note phrase;
- one DEC-45 STATUS paragraph.
```

After those are clean, W3C should be able to close T1S01a4 immediately and
proceed to T1S01a5.

---

*Revision history*

```text
v1.2 (2026-08-18) Mechanical delta review of designer batch v4 / ledger v1.3.
     Confirms DEC-50, the corrected prior-ledger enumeration, LED-004's a5
     registration, and all substantive LED-025/026/027/029/030 corrections.
     Finds no technical reopening. Finds one remaining partial-replacement
     class in live framing: the ledger's closing questions still describe the
     superseded T1S01a2-only / every-sequencing-decision checks; the covering
     note still calls the provisional repair "TWO-ARTIFACT"; and DEC-45's
     live STATUS paragraph still rests on "different artifacts". Requests one
     final framing-only reissue before a4 closure. No source change; no
     build/test/git.
v1.1 (2026-08-18) Delta review of ledger v1.2 / designer batch v3.
v1.0 (2026-08-18) First W3C review of T1S01a4.
```
