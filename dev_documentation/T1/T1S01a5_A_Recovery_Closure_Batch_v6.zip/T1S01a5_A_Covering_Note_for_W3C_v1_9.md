# Deblock4 - T1S01a5 Covering Note to W3C: DEC-85 FINAL verification of ledger v1.10

**Deliverable:** T1S01a5_A - COVERING NOTE
**Version:** 1.9
**Date:** 2026-08-20
**Author:** W3D (successor session)
**Route:** W3D -> W3X -> W3C
**Reviews requested on:** `T1S01a5_A_Ledger_Body_Part1_v1_10.md` (44 entries)
**Binding review scope:** `Deblock4_T1_W3C_Review_Scope_v1_15.md`
**Binding work queue:** `Deblock4_Standing_Task_Register_T_Series_v1_35.md`
**Nature:** DOCUMENT REVIEW ONLY. No source, build, test, patch or git.
**Encoding:** US-ASCII; CRLF.

---

# 0. THIS IS THE LAST a5 CORRECTION GENERATION

```text
LEDGER v1.10 IS THE DEC-85 FINAL CORRECTION GENERATION. It applies your
response v1.3 items A-P. Nothing is disputed.

AFTER YOUR VERIFICATION, a5 CLOSES. If mechanical residue still exists, RECORD
IT FOR T1S01a7 and do NOT request a v1.11. That is W3X's ruling, made
deliberately, and it is not W3D's to argue around either.

YOUR SECTION 23 IS THE AGENDA. This note adds only where each item landed.
```

# 1. WHERE YOUR A-P ITEMS LANDED

```text
A  scope v1.15   I7 wording -> four ROLES across THREE parties (W3C appears
                 twice: originator and independent verifier). DEC-83 NOT
                 reopened. Header date 2026-08-20. No rule text changed.
B  LED-032a      TARGET carrier provenance now states W3C v1_2 DIRECT
                 verification, not inherited LED-033/042 probe results.
C  LED-037a      no change.        D  LED-043   no change.
E  LED-047/047a  parent REASON now opens on ONE mapping proposition, split at
                 v1.9; eight-hit census reframed as mapping/tag-population
                 evidence, with the audit-verdict use explicitly LED-047a's.
F  LED-053d      no change.        G  LED-055   no change.
H  LED-055a      fourth candidate CLASSIFIED: Architecture ReDecision W3C
                 Evaluation -> APPLIES. All four now classified.
I  LED-055b      no change.        K  LED-061   no change.
J  LED-059       live PROPOSED ACTION rebuilt to current proposal only; all
                 history removed from the field.
L  LED-063       the still-live "But a STRONG LIKELY REFERENT..." sentence
                 REMOVED (v1.9 added the removal note and not the removal).
                 SWEPT heading -> SIX CHECKS, renumbered 1-6 in order;
                 DERIVED-BASIS -> SIX. Historical staging kept as history.
M  self-check    0.4c retitled ORIGINAL classification-repair delta set; D7
                 marked historical with current pins in the header only; 0.4d
                 LED-038/LED-039 RESTORED and the list labelled the D1/v1.5
                 snapshot (28); Q-C = 20 with LED-054 added and the counting
                 rule corrected; Q-H = ELEVEN; footer -> v1.10.
N  this note     written clean; describes v1.10 as the DEC-85 final
                 generation; carries only your section 23 agenda.
O  register      v1.35: ONE current a5 status line (v1.10, final generation);
                 stale v1.7/42 block removed; DEC-83 wording corrected;
                 header date 2026-08-20; DEC-86/87 added.
P  manifest      v1.9: current-status only, frozen frame untouched, date
                 corrected.
```

# 2. THE THREE COUNT FAILURES, AND WHAT THEY TAUGHT

```text
YOU CAUGHT ALL THREE AND EACH HAD A DIFFERENT CAUSE. They are recorded at
ledger 0.4h and DEC-87 rather than quietly fixed, because the causes generalise:

  0.4d printed 26 under a 28 heading. THE v1.9 REPAIR WAS MADE, VERIFIED, AND
       NEVER WRITTEN TO DISK - the next build step reopened the unrepaired
       file. A FIX THAT IS NOT PERSISTED IS NOT A FIX. Gates now run on the
       artifact RE-READ FROM DISK.
  Q-C  counted 19 by matching the first word of DUPLICATE-ACTION, so it missed
       LED-054's "POINTER for (a),(b),(d); STAY-CANONICAL for (c)". A
       MECHANICAL COUNT IS ONLY AS GOOD AS THE RULE IT MECHANISES.
  Q-H  wrote "nine" above its own list of eleven - prose arithmetic
       disagreeing with the enumeration directly beneath it.

AND A NEW ONE, WORTH YOUR SCEPTICISM: during this build two gates fired
FALSELY. One counted LED-051a as a STAY-CANONICAL asserter when that entry
only CROSS-REFERENCES LED-045's requirement and its own action is POINTER; the
other counted the COVERAGE entries LED-032a/LED-037a as atomic splits. Both
times the DOCUMENT was right and the RULE was wrong. Your figures - 20 and 11 -
are the ones in the ledger. The lesson recorded at DEC-87(b): when a gate
fires, establish which side is wrong before editing anything.
```

# 3. WHAT TO CHECK, AND WHAT TO DO WITH RESIDUE

```text
Your section 23 list, unchanged. The highest-value checks are the ones that
have failed before: LED-047/047a not cross-owning the audit proposition;
LED-063 with no live "strong likely" and six checks numbered 1-6; LED-059's
ACTION free of history; and the four mechanical populations - 44 entries, 44
Tier C, 28 D1-survivors, 20 STAY-CANONICAL, 11 atomic-split suffixes.

IF ANYTHING REMAINS: record it for T1S01a7 and say so plainly. DO NOT REQUEST
A v1.11. a5 closes after your verification (DEC-85).
```

# 4. DECISIONS/QUESTIONS FOR W3X

```text
None. DEC-86 and DEC-87 record this generation and its lessons in register
v1.35. After W3C's verification, W3X closes a5 and the deferred bounded
root-continuity refresh runs before a5b begins.
```

---

*Revision history*

```text
v1.9 (2026-08-20) Clean rewrite for the DEC-85 FINAL verification of ledger
     v1.10. Maps response-v1.3 items A-P to where each landed, records the
     three count failures and their distinct causes, and states plainly that
     residue after this round goes to a7 rather than to another generation.
v1.8 and earlier: previous rounds; superseded, retained as history.
```
