# Old-Designer Answers for New Designer - Q3: What Was Actually Read and
# Judged During the Aborted T1 Pass

**Version:** 1.0  **Date:** 2026-08-17  **Author:** outgoing W3D
**Encoding:** US-ASCII; CRLF.

## The direct answer

NO document was read and consciously judged out of scope under T1. None.
T1 consisted of exactly two acts before it stopped:

```text
1. The mechanical hit survey across the dev_documentation root (the
   17-document list; term set in the Q4 document).
2. Partial reading of ONE document - README v1_11 - specifically:
     - the decision-status table (~line 294 region),
     - section 3.11 (~526) and section 3.13 (~600) in full.
   That reading produced the Architecture-A discovery, W3X re-opened the
   architecture, and T1 was PAUSED THERE by W3X direction.
```

So for every OTHER document on the 17-list, the correct classification is
NEVER REACHED - not "rejected for a stated reason". There are no hidden
adjudications to trust or distrust. Every out-of-scope judgement is yours
to make fresh.

## Near-miss category to be aware of (NOT T1 adjudications)

Earlier in the same session, for OTHER purposes, the outgoing designer
read parts of several documents on the list: the charter (C-DELIV-09 and
delivery-rule sections, during M1/M2), Project Status v1_26/v1_27 (which
is how the missed 2026-08-12 identifier-cleanup ruling was eventually
found - by the CODER, not by W3D), the currency audit, the D0 index, and
both intros. None of those readings was a systematic MPEG-2 adjudication,
and none should be counted as T1 coverage. The one transferable lesson
from them: the currency audit's one-line document descriptions are
CLASSIFICATION CLAIMS, not facts - the "fallback general guidance" label
on the README is what caused the whole miss, and the equivalent labels on
the other 16 documents deserve the same suspicion.

## One more honest note

The 17-document list itself came from a single grep with a finite term
set (Q4 document). A document whose MPEG-2 content uses none of those
terms would not be on the list at all. When you run your own sweep,
consider extending the term set (suggestions in Q4) and diffing the
resulting document list against the original 17 before trusting the
frame.
