# Old-Designer Answers for New Designer - Q1: README Sections Carrying
# Ratified Design (Where to Slow Down)

**Version:** 1.0  **Date:** 2026-08-17  **Author:** outgoing W3D
**Caveat that governs everything below:** this analysis was run MECHANICALLY
against README v1_11 (the outgoing designer's last held copy). The current
README is v1_12; the coder revised it after the architecture re-decision.
Line numbers WILL have moved and some sections may have been rewritten or
supersession-marked. Treat this as a SLOW-DOWN MAP to re-locate in v1_12,
not as line-accurate. Terms scanned per section: mpeg2/mpeg-2, dct_type,
field-dct, 8x8, grid_mode, interlac*, luma_step, chroma_step, midpoint,
edge_step.
**Encoding:** US-ASCII; CRLF.

## The honest headline

During the investigation the outgoing designer read ONLY sections 3.11, 3.13
and the decision-status table. The list below is therefore a mechanical map
PLUS judgement about section TYPE from titles and from what surfaced later -
it is NOT a claim to have now read these sections. That reading is exactly
the T1 work handed to you.

## Sections judged RATIFIED-DESIGN class (slow down hard)

```text
line~  sec    hits  why it matters
 294   2       10   DECISION-STATUS TABLE. This is where "identifier-
                    cleanup RULED"-style entries live for the README's
                    domain. Read every row as a potential ruling. It was
                    rows here (incl. "no per-MB dct_type map from
                    BestSource"; "H.262 has no normative in-loop deblock")
                    that duplicated questions we later re-asked externally.
 526   3.11    19   Coded transform size vs processing edge-grid pitch.
                    RATIFIED (Architecture A geometry rationale). Now
                    REJECTED as mechanism but the section defines terms
                    (pitch, position classes) still used elsewhere.
 600   3.13    15   Midpoint position class + threshold scale. RATIFIED
                    fixed-point mechanism (S=round_half_up(scale*65536),
                    immutable creation-time sets, tc0 unscaled, canonical
                    read order). Mechanism orphaned; ENGINEERING patterns
                    retained - see Q2 document.
 660   3.14     8   Public API and meaning-based parameter names -
                    RATIFIED naming policy; D4-Q16 redesign must respect
                    or explicitly supersede it.
 832   grid_mode 7  Accepted grid_mode values - the RATIFIED parameter
                    vocabulary that D4-D02 partially retires. What
                    survives vs retires must be adjudicated row by row.
1248   6.2      7   "Bounds must be derived from the algorithm" +
1337   min-extent 6 minimum extent from step and footprint - RATIFIED
                    bounds/footprint DESIGN RULES, not description. B2's
                    edge topology must satisfy or supersede these.
 987   pre-pass 2   "Strength maps use an unmodified-source pre-pass" -
                    RATIFIED analyser rule; already echoed in authority
                    doc D4-D06 vicinity, verify consistency.
3153   F12      3   "Grid step is 4, and the consequence for MPEG-2 (new
                    finding)" - a FINDINGS series (F-numbered!) inside the
                    README. F12-F17 (3153-3255) are RULING-class:
3164   F13      2     F13 BestSource decoded frames
3172   F14      4     F14 field-separated candidate set (superseded
                      mechanism - but check for surviving sub-claims)
3186   F15      9     F15 MPEG-2 4:2:0 chroma geometry - OVERLAPS the
                      authority doc's F4; verify identical, record which
                      prevails on any nuance
3225   F17      3     F17 remaining measurement gates / deferred scope -
                      may contain gates never carried into the D4-Q register
3313   20       4   Proposed development stages - check against the
                    ratified T-register/roadmap for contradiction.
```

## Appendices - MIXED class (knowledge, mostly absorbed, verify)

```text
3415  Appendix A (A.1-A.12, ~360 lines) - MPEG-2/H.262 transform blocks
      and separated-field grids. A.4.x/A.5/A.6/A.8/A.9.3 restate what the
      authority document now owns with H.262-VERIFIED provenance. The
      RISK here is divergence in detail (esp. A.9.3 interlaced 4:2:0
      chroma and A.6 definitive luma table) - where they differ, the
      authority document PREVAILS; record each such row in the T1 log.
3733  Appendix B (B.1-B.5) - BestSource findings incl. B.3 "no recorder-
      brand default" and B.5 open items. B-series may hold open items
      never migrated to D4-Q. Check B.5 especially.
```

## Sections judged GENERAL-DESCRIPTION class (normal reading)

1.0/1.1/1.3 (two-filters framing, working recommendation), 3.15 (Classic
API), 11.x source-file map, 13.6, 14.x validation layers, revision-history
entries (2707-2963 region - note these are HISTORY, cite-only).

## One instruction

Where any section above conflicts with
Deblock4_MPEG2_Deblocking_Investigation_and_Decided_Architecture v1_05+,
the authority document WINS - but T1 requires each conflict RECORDED, not
silently passed. The decision-status table (line ~294) is the section most
likely to contain a ruling nobody has re-checked.
