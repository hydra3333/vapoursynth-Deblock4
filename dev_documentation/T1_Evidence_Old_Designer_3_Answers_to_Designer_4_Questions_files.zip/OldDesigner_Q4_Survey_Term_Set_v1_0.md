# Old-Designer Answers for New Designer - Q4: The Exact Term Set Behind the
# "137 Hits / 17 Documents" Figures

**Version:** 1.0  **Date:** 2026-08-17  **Author:** outgoing W3D
**Encoding:** US-ASCII; CRLF.

## The exact command (re-run and verified 2026-08-17 on the outgoing
## designer's held generation)

```text
for %f in (*.md) - per document, case-insensitive LINE count (grep -ci):

  grep -ci "mpeg-2\|mpeg2\|dct_type\|field.dct\|8x8 grid\|grid_mode\|interlac"

Term notes:
  - COUNTS LINES CONTAINING >=1 TERM, not term occurrences.
  - "field.dct" - the dot is a regex ANY-CHARACTER: matches field-dct,
    field DCT, field_dct.
  - "8x8 grid" - the two-word phrase, NOT bare "8x8" (bare 8x8 was used
    only in the later per-section README scan, which is why per-section
    numbers do not sum to 137).
  - "interlac" - stem: matches interlaced/interlacing.
  - Case-insensitive throughout.
```

## The verified per-document result (outgoing generation - versions will
## have advanced; re-run on current)

```text
 137  README_Deblock4_Design_Spec_v1_11.md
  35  Deblock4_MPEG2_Grid_Field_DCT_Knowledge_v1_1.md
  29  111_New_Chat_Introduction_for_Designer_v1_20.md
  28  111_New_Chat_Introduction_for_Designer_v1_19.md   (superseded dup)
  21  Deblock4_Concise_Project_Summary_v1.3.md
  18  AI_Charter_and_Invariants_Card_v1_27.md
  11  Deblock4_Verification_And_Tiering_Decisions_v1_11.md
   7  111_New_Chat_Introduction_for_Coder_v1_25.md
   6  Deblock4_Project_Status_v1_26.md
   6  Deblock4_Designer_Chat_2_Death_Resume_Brief_v1_0.md
   5  111_New_Chat_Introduction_for_Coder_v1_20.md      (superseded dup)
   4  Deblock4_Stage_2C_D0_Preface_and_Binding_Knowledge_Index_v1_13.md
   4  Deblock4_Stage_1C_Creation_Error_Message_Table_v1_1.md
   4  Deblock4_Forward_Roadmap_v1_18.md
   4  Deblock4_Documentation_Currency_Audit_v1_0.md
   1  Deblock4_Session_Bootstrap_Header_v1_0.md
   1  Deblock4_DISPATCH_RELATED_Backend_Objects_Explained_v1_4.md
```
Note "17" counted files including two superseded-generation duplicates of
intros; the DISTINCT current-document count was 15. Your sweep should run
on the CURRENT generation only, with superseded/ excluded, so expect a
different list shape.

## Known blind spots of this term set - extend before you rely on it

```text
MISSING terms that MPEG-2-relevant text can use without tripping any of
the originals (all seen in this project's documents):
  bare "8x8" without "grid"        "field pictures" / picture_structure
  "macroblock" / "16x16"           frame_pred_frame_dct
  "chroma" geometry text           "H.262" / "13818"
  "SeparateFields" / "woven"       "midpoint" / "edge_step" /
  "pitch" (edge/row pitch)           luma_step / chroma_step
  "deblock" alone (too noisy raw; useful with context)
The later per-section README scan already used a wider set (adds bare
8x8, luma_step, chroma_step, midpoint, edge_step) - which is precisely
why its numbers exceed the 137-line frame. Recommendation: define YOUR
term set explicitly in the T1 log, run it, and diff the document list
against the table above; any document that appears under your set but
not this one was invisible to the original survey.
```
