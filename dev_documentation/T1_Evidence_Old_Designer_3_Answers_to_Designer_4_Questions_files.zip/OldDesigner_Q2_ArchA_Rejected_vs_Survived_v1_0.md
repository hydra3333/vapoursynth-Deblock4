# Old-Designer Answers for New Designer - Q2: Architecture A - What Was
# Rejected as Geometry vs What Survived as Engineering

**Version:** 1.0  **Date:** 2026-08-17  **Author:** outgoing W3D
**Basis:** the outgoing designer's own re-decision record (authority doc
Appendix C, which W3D wrote) plus the W3C evaluation. The outgoing designer
has NOT read v1.05 section 9.1 in full (reviewed v1.03 structurally only),
so this is the INDEPENDENT list to DIFF against 9.1 - that is more useful
to you than a confirmation would be.
**Encoding:** US-ASCII; CRLF.

## REJECTED - and WHY class matters (three different failure kinds)

```text
R1  The union step-4 candidate GEOMETRY itself.        [COORDINATE ARTEFACT]
    Frame-DCT and field-DCT boundaries only shared a same-field six-tap
    footprint in SEPARATED-FIELD coordinates. Woven, they are different
    edge types with different footprints (pitch-1 consecutive vs two
    pitch-2 parity edges). Not adaptable - false in the new coordinates.
R2  The midpoint POSITION CLASS as the uncertainty carrier.  [SAME]
    Its transposition tests 6/8 and 7/9 (pitch 2) where the real frame-DCT
    edge is 7/8 (pitch 1): wrong edge, wrong taps.
R3  Both-phase testing per position (the union idea).   [WRITE DISCIPLINE]
    Faithful whole-frame union DOUBLE-WRITES rows adjacent to macroblock-
    row boundaries - breaks single-pass write discipline. Architecture D
    survives only because it reduces the union to ONE true pitch-1
    internal candidate plus always-valid pitch-2 boundary edges.
R4  "Let the activation test sort it out" as the LOAD-BEARING premise.
                                                        [IN-PRINCIPLE LIMIT]
    A,A,A|A+d,A+d,A+d has identically-zero side activity; a real
    compression seam and a benign step are IDENTICAL observations. A
    threshold trades the two errors; it cannot separate them. Note this
    limit CONSTRAINS EVERY architecture's kernel gating on flat content -
    it is why B2 classifies structure rather than relying on edge-local
    evidence alone. Do not re-derive R4 as a B2 problem; it is universal.
```

## SURVIVED as engineering (my complete retained list - diff against 9.1)

```text
S1  Fixed-point threshold conversion: S = round_half_up(scale * 65536);
    scale_threshold(t,S) = (i64(t)*i64(S) + 32768) >> 16.
S2  CREATION-TIME conversion into IMMUTABLE threshold sets - no multiply,
    no conversion, no float in any pixel kernel.
S3  No-float-in-pixel-loop as a standing kernel discipline (wider than S1/
    S2; a project norm the A design exemplified).
S4  Canonical-schedule READ ORDERING: an edge decision reads the CURRENT
    destination state at its point in the canonical schedule - makes
    output schedule-defined and deterministic.
S5  The tc0-unscaled principle: evidence thresholds may be tightened, but
    a PASSED test corrects at FULL strength - do not half-correct.
    (Easily lost; it is a one-line remark in 3.13.)
S6  THRESHOLD-SCALING AT AN UNCERTAIN CANDIDATE - the idea itself -
    survives INTO ARCHITECTURE D: its single true pitch-1 internal
    candidate may be tested with a stricter (scaled) threshold. That is
    the only place the midpoint idea legitimately lives on.
S7  Meaning-based parameter naming policy (3.14) - not part of A's
    geometry at all; survives independently into D4-Q16.

If v1.05 section 9.1 lists only four retained ideas, check which of S5,
S6, S7 it dropped - S5 and S6 are the two most likely to be silently lost,
and S6 is load-bearing for Architecture D's definition.
```

## The boundary rule between the lists

Everything in R-series is about WHERE edges are and WHICH positions to
test. Everything in S-series is about HOW a decided test is evaluated and
executed. A future proposal that reimports anything from R-series needs
new evidence; reusing S-series is encouraged and costs nothing.
