@echo off
setlocal EnableExtensions DisableDelayedExpansion

if "%~1"=="" (
    echo USAGE: call "%~f0" "FULL_PATH_TO_ALREADY_APPLIED_REPOSITORY_ROOT"
    exit /b 2
)

set "delivery_root=%~dp0"
set "repo_root=%~f1"
set "runner_source=%delivery_root%full_files\build_1C_v1.bat"
set "runner_destination=%repo_root%\build_1C_v1.bat"

if not exist "%repo_root%\.git" (
    echo ERROR: repository root does not contain .git: "%repo_root%"
    exit /b 1
)
if not exist "%runner_source%" (
    echo ERROR: v1.5 runner missing: "%runner_source%"
    exit /b 1
)

cd /d "%repo_root%" || exit /b 1

set "branch="
for /f "delims=" %%B in ('git branch --show-current') do set "branch=%%B"
if /I not "%branch%"=="main" (
    echo ERROR: expected branch main, found "%branch%".
    exit /b 1
)

rem Confirm this is the already-applied Phase 3b state, not the clean Phase 3a base.
if not exist "build.zig" (echo ERROR: applied Phase 3b build graph missing. & exit /b 1)
if not exist "src\deblock4_selftest.zig" (echo ERROR: applied Phase 3b selftest missing. & exit /b 1)
if not exist "tests\stage_1c_classic_passthrough.vpy" (echo ERROR: applied Phase 3b Classic harness missing. & exit /b 1)
if not exist "tests\stage_1c_deblock4_passthrough.vpy" (echo ERROR: applied Phase 3b Deblock4 harness missing. & exit /b 1)
if exist "build_1B1_v7_3.bat" (echo ERROR: Phase 3b deletion set is not applied; use the fresh apply helper from a clean base. & exit /b 1)
if exist "build_1B2_v5_REDEVELOPED.bat" (echo ERROR: Phase 3b deletion set is not applied; use the fresh apply helper from a clean base. & exit /b 1)
if exist "build_1B3_v5.bat" (echo ERROR: Phase 3b deletion set is not applied; use the fresh apply helper from a clean base. & exit /b 1)
if exist "src\backend_probe_avx2.zig" (echo ERROR: Phase 3b scaffolding retirement is incomplete. & exit /b 1)

copy /Y "%runner_source%" "%runner_destination%" >nul
if errorlevel 1 (
    echo ERROR: failed to install the v1.5 production runner.
    exit /b 1
)
fc /B "%runner_source%" "%runner_destination%" >nul
if errorlevel 1 (
    echo ERROR: installed production runner does not match the v1.5 delivery bytes.
    exit /b 1
)

git -c core.whitespace=cr-at-eol diff --check
if errorlevel 1 exit /b 1

echo ================================================================
echo RESUME STAGE 1C FULL PROOF MATRIX WITH V1.5 RUNNER
echo ================================================================
call "build_1C_v1.bat"
set "proof_code=%ERRORLEVEL%"
if not "%proof_code%"=="0" exit /b %proof_code%

git -c core.whitespace=cr-at-eol diff --check
if errorlevel 1 exit /b 1

echo ================================================================
echo POST-VALIDATION STATUS
echo ================================================================
git status --short
if errorlevel 1 exit /b 1

echo ================================================================
echo PHASE 3B V1.5 RESUMED VALIDATION COMPLETED SUCCESSFULLY
echo ================================================================
exit /b 0
