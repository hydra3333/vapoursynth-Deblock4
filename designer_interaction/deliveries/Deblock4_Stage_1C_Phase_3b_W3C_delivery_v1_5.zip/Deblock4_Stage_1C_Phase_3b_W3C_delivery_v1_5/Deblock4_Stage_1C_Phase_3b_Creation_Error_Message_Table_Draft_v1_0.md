# Deblock4 Stage 1C Phase 3b - Creation-Error Message Table Draft

**Version:** 1.0
**Date:** 2026-08-02
**Author:** W3C
**Status:** P4 delivery-review draft. W3D review and W3X ratification required.
**Encoding:** US-ASCII; CRLF.

## 1. Purpose and authority

This table records the user-visible creation failures implemented by the Stage
1C Classic and Deblock4 creation modules. It is the P4 draft required by Scope
v1.5 section 6 and is not controlling until W3X ratifies it after W3D review.

The strings in sections 2 and 3 are exact plugin-owned messages passed to
`mapSetError`. They are stable source obligations once ratified.

One boundary is intentionally explicit: VapourSynth validates the registered
function signature before invoking a creation callback. A standard Python call
with a wrong argument type can therefore be rejected by VapourSynth before the
plugin-owned defensive `WrongType` path runs. The Phase 3b `.vpy` proof accepts
only a diagnostic containing the filter name, argument name `strength`, and
expected type `int`, and preserves the complete observed host diagnostic in the
evidence. W3D/W3X should ratify that observed pinned VapourSynth R78 host diagnostic separately
from the plugin-owned fallback string.

## 2. Classic exact plugin-owned messages

| Condition | Exact message |
|---|---|
| Missing/non-node clip | `Classic: clip is required and must be a video node` |
| Video information unavailable | `Classic: source video information is unavailable` |
| Variable format or dimensions | `Classic: input clip must have constant format and dimensions` |
| Wrong type reaching callback defence | `Classic: one or more arguments have the wrong type` |
| Strength outside 0..60 | `Classic: strength must be between 0 and 60` |
| Boundary offset invalid for strength | `Classic: boundary_strength_offset is out of range for strength` |
| Side offset invalid for strength | `Classic: side_activity_offset is out of range for strength` |
| Unknown backend token | `Classic: backend is not a recognised token` |
| Empty planes array | `Classic: planes must not be empty` |
| Too many plane indices | `Classic: planes contains too many indices` |
| Negative plane index | `Classic: plane indices must be non-negative` |
| Plane index exceeds parser bound | `Classic: a plane index is too large` |
| Duplicate plane index | `Classic: planes must not contain duplicates` |
| Validation error not applicable to Classic | `Classic: an argument is not valid for this filter` |
| Invalid force-down value | `Classic: DEBLOCK4_FORCE_DOWN has an invalid value` |
| Requested backend above EFFECTIVE tier | `Classic: requested backend is above the EFFECTIVE CPU tier` |
| Unsupported input colour family | `Classic: input color family is unsupported` |
| Invalid input video metadata | `Classic: input video metadata is invalid` |
| Plane outside source format | `Classic: a plane index is outside the source format` |
| Instance allocation failure | `Classic: instance allocation failed` |
| Writable pass-through copy failure | `Classic: failed to copy the source frame` |
| Audit-property write failure | `Classic: failed to write audit frame properties` |

## 3. Deblock4 exact plugin-owned messages

| Condition | Exact message |
|---|---|
| Missing/non-node clip | `Deblock4: clip is required and must be a video node` |
| Video information unavailable | `Deblock4: source video information is unavailable` |
| Variable format or dimensions | `Deblock4: input clip must have constant format and dimensions` |
| Wrong type reaching callback defence | `Deblock4: one or more arguments have the wrong type` |
| Strength outside 0..60 | `Deblock4: strength must be between 0 and 60` |
| Boundary offset invalid for strength | `Deblock4: boundary_strength_offset is out of range for strength` |
| Side offset invalid for strength | `Deblock4: side_activity_offset is out of range for strength` |
| Unknown backend token | `Deblock4: backend is not a recognised token` |
| Empty planes array | `Deblock4: planes must not be empty` |
| Too many plane indices | `Deblock4: planes contains too many indices` |
| Negative plane index | `Deblock4: plane indices must be non-negative` |
| Plane index exceeds parser bound | `Deblock4: a plane index is too large` |
| Duplicate plane index | `Deblock4: planes must not contain duplicates` |
| Missing grid mode | `Deblock4: grid_mode is required` |
| Unknown grid mode | `Deblock4: grid_mode is not recognised` |
| Reserved auto grid mode | `Deblock4: grid_mode=auto is reserved and not implemented` |
| Missing custom-grid parameter | `Deblock4: custom mode requires all custom grid parameters` |
| Custom parameter supplied with preset | `Deblock4: custom grid parameters require grid_mode=custom` |
| Custom step below 1 | `Deblock4: custom grid steps must be at least 1` |
| Invalid midpoint-enabled integer | `Deblock4: luma_midpoint_enabled must be 0 or 1` |
| Midpoint scale outside 0.0..1.0 | `Deblock4: midpoint_threshold_scale must be between 0.0 and 1.0` |
| Midpoint scale inapplicable to grid | `Deblock4: midpoint_threshold_scale is not applicable to this grid policy` |
| Invalid force-down value | `Deblock4: DEBLOCK4_FORCE_DOWN has an invalid value` |
| Requested backend above EFFECTIVE tier | `Deblock4: requested backend is above the EFFECTIVE CPU tier` |
| Unsupported input colour family | `Deblock4: input color family is unsupported` |
| Invalid input video metadata | `Deblock4: input video metadata is invalid` |
| Plane outside source format | `Deblock4: a plane index is outside the source format` |
| Custom step above relevant plane dimension | `Deblock4: a custom grid step exceeds its relevant plane dimension` |
| Instance allocation failure | `Deblock4: instance allocation failed` |
| Writable pass-through copy failure | `Deblock4: failed to copy the source frame` |
| Audit-property write failure | `Deblock4: failed to write audit frame properties` |

## 4. Phase 3b e2e subset

The two Stage 1C `.vpy` harnesses exercise these refusal classes in every
normal mode unless the proof matrix assigns the case to Debug only:

- both filters: strength range, wrong type at the registered-signature boundary,
  duplicate planes, empty planes, unknown backend, and variable format;
- Deblock4: custom step below one and above the relevant plane dimension;
- Debug only: invalid force-down value and requested backend above the forced
  EFFECTIVE tier.

Every plugin-owned case checks the exact string above. The host-owned wrong-type
case checks the stable semantic fields and records the complete observed text so
the delivery review can ratify the pinned VapourSynth R78 wording without pretending the callback
owns it.
