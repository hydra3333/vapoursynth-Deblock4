# Phase 3b v1.5 W3C Static and Integration Validation

## Passed

- replaced generic cache/build/inspection variables with Deblock4-specific names and assigned them only after `VsDevCmd.bat` returns;
- changed the initial cleanup calls to delayed-expansion paths and added explicit path, cleanup and static-audit boundary output;
- added a fail-closed PowerShell availability check and normalized the failure exit code before printing the failure banner;

- rebuilt v1.5 from the complete v1.3 delivery, changing only the apply/resume helpers and delivery metadata;
- removed the recovery helper's invalid precondition that `build_1C_v1.bat` already exist before the helper installs it;
- strengthened recovery-state confirmation with explicit `build.zig` and `src/deblock4_selftest.zig` checks while retaining both permanent `.vpy` harness checks and the complete deletion-state checks;
- corrected the worker relaunch to `"%ComSpec%" /D /V:OFF /C call "%~f0" --worker`;
- retained separate project-root and path-prefix variables, and changed both initial and post-`VsDevCmd` `cd` operations to the quote-safe `%~dp0.` root;
- retained the proven VS2026 `-arch=amd64 -host_arch=amd64` handoff;
- confirmed the obsolete parent relaunch form and both directory changes through the trailing-backslash prefix are absent;
- reconstructed the accepted Phase 3a source base and integrated Phase 3b worktree;
- deletion patch `git apply --check`;
- deletion patch `git apply --check --whitespace=error-all`;
- deletion patch application in an isolated clean tree;
- complete-file overlay reproduces the integrated final bytes;
- `git -c core.whitespace=cr-at-eol diff --check`;
- all repository text in the reconstructed final tree is US-ASCII with zero bare LF;
- no missing relative Zig imports;
- zero first-class references to retired filenames outside the proof runner's explicit sweep catalogue;
- both `.vpy` files pass Python `py_compile`;
- `build_1C_v1.bat`, fresh-apply helper and resume helper have unique labels, no missing call/goto target, US-ASCII and CRLF;
- all package SHA-256 entries verified after final assembly.

## Not executed by W3C

The container does not provide the pinned Windows VS2026, Zig 0.16.0, `dumpbin` or portable VapourSynth runtime. W3C therefore makes no project-PASS claim. W3X must run the delivered v1.5 proof batch; W3D then reviews the produced artifacts and W3C concurs or identifies a defect.
