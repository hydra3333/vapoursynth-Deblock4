@echo off
setlocal EnableExtensions EnableDelayedExpansion

if "%~1"=="" (
    echo USAGE: call "%~f0" "FULL_PATH_TO_REPOSITORY_ROOT"
    exit /b 2
)

set "delivery_root=%~dp0"
set "repo_root=%~f1"
set "patch_name=Deblock4_Stage_1C_Phase_3b_scaffolding_deletions_v1_0.patch"
set "patch_source=%delivery_root%%patch_name%"

if not exist "%repo_root%\.git" (
    echo ERROR: repository root does not contain .git: "%repo_root%"
    exit /b 1
)
if not exist "%patch_source%" (
    echo ERROR: deletion patch missing: "%patch_source%"
    exit /b 1
)

cd /d "%repo_root%" || exit /b 1
set "branch="
for /f "delims=" %%B in ('git branch --show-current') do set "branch=%%B"
if /I not "!branch!"=="main" (
    echo ERROR: expected branch main, found "!branch!".
    exit /b 1
)

set "dirty="
for /f "delims=" %%S in ('git status --porcelain') do set "dirty=1"
if defined dirty (
    echo ERROR: working tree must be clean before Phase 3b application.
    git status --short
    exit /b 1
)

if not exist "src\deblock4_plugin.zig" (echo ERROR: Phase 3a base file missing: src/deblock4_plugin.zig & exit /b 1)
if not exist "src\lifecycle_trace_debug.zig" (echo ERROR: Phase 3a base file missing: src/lifecycle_trace_debug.zig & exit /b 1)
if not exist "build_1B1_v7_3.bat" (echo ERROR: Phase 3a base file missing: build_1B1_v7_3.bat & exit /b 1)
if not exist "build_1B2_v5_REDEVELOPED.bat" (echo ERROR: Phase 3a base file missing: build_1B2_v5_REDEVELOPED.bat & exit /b 1)
if not exist "build_1B3_v5.bat" (echo ERROR: Phase 3a base file missing: build_1B3_v5.bat & exit /b 1)
if not exist "src\backend_isolation_smoke_test.zig" (echo ERROR: Phase 3a base file missing: src/backend_isolation_smoke_test.zig & exit /b 1)
if not exist "src\backend_probe_avx2.zig" (echo ERROR: Phase 3a base file missing: src/backend_probe_avx2.zig & exit /b 1)
if not exist "src\backend_probe_generic.zig" (echo ERROR: Phase 3a base file missing: src/backend_probe_generic.zig & exit /b 1)
if not exist "src\backend_probe_scalar.zig" (echo ERROR: Phase 3a base file missing: src/backend_probe_scalar.zig & exit /b 1)
if not exist "src\backend_probe_sse41.zig" (echo ERROR: Phase 3a base file missing: src/backend_probe_sse41.zig & exit /b 1)
if not exist "src\backend_retention_anchor.zig" (echo ERROR: Phase 3a base file missing: src/backend_retention_anchor.zig & exit /b 1)
if not exist "src\build_probe.zig" (echo ERROR: Phase 3a base file missing: src/build_probe.zig & exit /b 1)
if not exist "src\dll_probe.zig" (echo ERROR: Phase 3a base file missing: src/dll_probe.zig & exit /b 1)
if not exist "src\dll_smoke_test.zig" (echo ERROR: Phase 3a base file missing: src/dll_smoke_test.zig & exit /b 1)
if not exist "src\vapoursynth_header_probe.zig" (echo ERROR: Phase 3a base file missing: src/vapoursynth_header_probe.zig & exit /b 1)
if exist "build_1C_v1.bat" (echo ERROR: expected new file already exists: build_1C_v1.bat & exit /b 1)
if exist "tests\stage_1c_classic_passthrough.vpy" (echo ERROR: expected new file already exists: tests/stage_1c_classic_passthrough.vpy & exit /b 1)
if exist "tests\stage_1c_deblock4_passthrough.vpy" (echo ERROR: expected new file already exists: tests/stage_1c_deblock4_passthrough.vpy & exit /b 1)
if exist "tools\stage_1c_proof_helpers.ps1" (echo ERROR: superseded proof helper already exists: tools/stage_1c_proof_helpers.ps1 & exit /b 1)
if exist "tools\audit_stage_1c_s1_structure.ps1" (echo ERROR: expected new file already exists: tools/audit_stage_1c_s1_structure.ps1 & exit /b 1)
if exist "tools\audit_stage_1c_g10_imports.ps1" (echo ERROR: expected new file already exists: tools/audit_stage_1c_g10_imports.ps1 & exit /b 1)
if exist "tools\audit_stage_1c_s2_sweep.ps1" (echo ERROR: expected new file already exists: tools/audit_stage_1c_s2_sweep.ps1 & exit /b 1)
if exist "tools\audit_stage_1c_s3_eol.ps1" (echo ERROR: expected new file already exists: tools/audit_stage_1c_s3_eol.ps1 & exit /b 1)

echo ================================================================
echo PHASE 3B DELETION PATCH CHECKS
echo ================================================================
git apply --check "%patch_source%"
if errorlevel 1 exit /b 1
git apply --check --whitespace=error-all "%patch_source%"
if errorlevel 1 exit /b 1
git apply "%patch_source%"
if errorlevel 1 exit /b 1

if not exist "tests" (
    md "tests"
    if errorlevel 1 exit /b 1
)

call :copy_file "build.zig"
if errorlevel 1 exit /b 1
call :copy_file "build.zig.zon"
if errorlevel 1 exit /b 1
call :copy_file "build_1C_v1.bat"
if errorlevel 1 exit /b 1
call :copy_file "src/deblock4_selftest.zig"
if errorlevel 1 exit /b 1
call :copy_file "tests/stage_1c_classic_passthrough.vpy"
if errorlevel 1 exit /b 1
call :copy_file "tests/stage_1c_deblock4_passthrough.vpy"
if errorlevel 1 exit /b 1
call :copy_file "third_party/vapoursynth/include/VSConstants4.h"
if errorlevel 1 exit /b 1
call :copy_file "third_party/vapoursynth/include/VSHelper4.h"
if errorlevel 1 exit /b 1
call :copy_file "third_party/vapoursynth/include/VSScript4.h"
if errorlevel 1 exit /b 1
call :copy_file "third_party/vapoursynth/include/VapourSynth4.h"
if errorlevel 1 exit /b 1
call :copy_file "tools/run_vs.cmd"
if errorlevel 1 exit /b 1
call :copy_file "tools/audit_stage_1c_s1_structure.ps1"
if errorlevel 1 exit /b 1
call :copy_file "tools/audit_stage_1c_g10_imports.ps1"
if errorlevel 1 exit /b 1
call :copy_file "tools/audit_stage_1c_s2_sweep.ps1"
if errorlevel 1 exit /b 1
call :copy_file "tools/audit_stage_1c_s3_eol.ps1"
if errorlevel 1 exit /b 1

git -c core.whitespace=cr-at-eol diff --check
if errorlevel 1 exit /b 1

echo ================================================================
echo RUN STAGE 1C FULL PROOF MATRIX
echo ================================================================
call "build_1C_v1.bat"
set "proof_code=!ERRORLEVEL!"
if not "!proof_code!"=="0" exit /b !proof_code!

git -c core.whitespace=cr-at-eol diff --check
if errorlevel 1 exit /b 1

echo ================================================================
echo POST-VALIDATION STATUS
echo ================================================================
git status --short
if errorlevel 1 exit /b 1

echo ================================================================
echo PHASE 3B V1.7 APPLICATION AND VALIDATION COMPLETED SUCCESSFULLY
echo ================================================================
exit /b 0

:copy_file
set "relative=%~1"
set "source=%delivery_root%full_files\!relative:/=\!"
set "destination=%repo_root%\!relative:/=\!"
if not exist "!source!" (
    echo ERROR: delivery source missing: !relative!.
    exit /b 1
)
for %%D in ("!destination!") do (
    if not exist "%%~dpD" (
        md "%%~dpD"
        if errorlevel 1 (
            echo ERROR: failed to create destination directory for !relative!.
            exit /b 1
        )
    )
)
copy /Y "!source!" "!destination!" >nul
if errorlevel 1 (
    echo ERROR: failed to copy !relative!.
    exit /b 1
)
fc /B "!source!" "!destination!" >nul
if errorlevel 1 (
    echo ERROR: copied bytes do not match delivery source for !relative!.
    exit /b 1
)
exit /b 0
