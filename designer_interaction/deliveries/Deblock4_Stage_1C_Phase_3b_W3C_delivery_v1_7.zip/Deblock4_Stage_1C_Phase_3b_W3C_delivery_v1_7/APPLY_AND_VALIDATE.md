# Stage 1C Phase 3b v1.7 - Apply, Resume and Validate

This v1.7 package supersedes every earlier Phase 3b delivery (`v1.0` through `v1.6`). Use only v1.7.

W3D verified the confirmed CMD-quoting defect in the v1.5 inline S1/G10/S2/S3 PowerShell payloads. v1.7 permanently removes that defect class: each audit is a separate repository `.ps1` file and the batch runner invokes it through `powershell -NoProfile -ExecutionPolicy Bypass -File`.

The four permanent audit files are:

```text
tools\audit_stage_1c_s1_structure.ps1
tools\audit_stage_1c_g10_imports.ps1
tools\audit_stage_1c_s2_sweep.ps1
tools\audit_stage_1c_s3_eol.ps1
```

The runner contains no embedded `\"` sequence in any PowerShell invocation. S3 includes `.ps1` in its own scan; S2 continues to scan `tools/` while excluding only its own deliberate retired-name catalogue and the permanent runner.

## A. Fresh application from the accepted clean Phase 3a repository

Extract this delivery outside the repository. From any command prompt, run:

```bat
call "<EXTRACTED_V1_7_DELIVERY>\apply_phase3b_and_validate.bat" "<REPOSITORY_ROOT>"
```

The helper verifies branch `main` and a clean Phase 3a tree, checks and applies the deletion-only patch, copies and byte-verifies all fifteen complete repository files, runs `git -c core.whitespace=cr-at-eol diff --check`, and runs `build_1C_v1.bat`.

Do not use the fresh-application command on a repository where Phase 3b has already been applied.

## B. Current W3X repository: Phase 3b already applied

Do not reset the repository and do not rerun the apply helper. Extract v1.7 outside the repository, then run:

```bat
call "<EXTRACTED_V1_7_DELIVERY>\resume_phase3b_validation_after_applied_state.bat" "<REPOSITORY_ROOT>"
```

The resume helper verifies the already-applied Phase 3b shape, installs and byte-verifies only the v1.7 runner and four audit scripts, removes the superseded v1.6 consolidated helper if it exists, runs `git diff --check`, and starts the complete proof matrix. It does not reapply the deletion patch or overwrite the other Phase 3b files.

Before committing, delete any loose temporary fix runners accidentally placed in the repository root. Those names are not repository deliverables.

## Expected success

The runner must exit zero and print:

```text
STAGE 1C_v1 FULL PROOF MATRIX COMPLETED SUCCESSFULLY
B1 B2 G1 G2 E1 E2 E3 E4 E5 E6 V1 S1 S2 S3 N1 PASS
```

Evidence remains under `zig-out\inspection_1C`. W3D independently reviews the evidence; the batch does not self-accept Stage 1C. A Zig `failed command: ... --listen=-` line is not by itself a failure. Use exit codes, explicit assertions and the success terminus.

## Commit hygiene after acceptance

Commit the fifteen added/replaced repository paths and thirteen deletions in `EXPECTED_CHANGED_FILES.md`. Do not commit `zig-out`, `.zig-cache`, extracted delivery files, loose fix runners, or the deletion patch. The P4 table remains a delivery-review artifact unless W3X separately directs repository placement.
