@echo off
setlocal EnableExtensions DisableDelayedExpansion

if "%~1"=="" (
    echo USAGE: call "%~f0" "FULL_PATH_TO_ALREADY_APPLIED_REPOSITORY_ROOT"
    exit /b 2
)

set "delivery_root=%~dp0"
set "repo_root=%~f1"

if not exist "%repo_root%\.git" (
    echo ERROR: repository root does not contain .git: "%repo_root%"
    exit /b 1
)

cd /d "%repo_root%" || exit /b 1

set "branch="
for /f "delims=" %%B in ('git branch --show-current') do set "branch=%%B"
if /I not "%branch%"=="main" (
    echo ERROR: expected branch main, found "%branch%".
    exit /b 1
)

rem Confirm this is the already-applied Phase 3b state, not the clean Phase 3a base.
if not exist "build.zig" (echo ERROR: applied Phase 3b build graph missing. & exit /b 1)
if not exist "src\deblock4_selftest.zig" (echo ERROR: applied Phase 3b selftest missing. & exit /b 1)
if not exist "tests\stage_1c_classic_passthrough.vpy" (echo ERROR: applied Phase 3b Classic harness missing. & exit /b 1)
if not exist "tests\stage_1c_deblock4_passthrough.vpy" (echo ERROR: applied Phase 3b Deblock4 harness missing. & exit /b 1)
if exist "build_1B1_v7_3.bat" (echo ERROR: Phase 3b deletion set is not applied; use the fresh apply helper from a clean base. & exit /b 1)
if exist "build_1B2_v5_REDEVELOPED.bat" (echo ERROR: Phase 3b deletion set is not applied; use the fresh apply helper from a clean base. & exit /b 1)
if exist "build_1B3_v5.bat" (echo ERROR: Phase 3b deletion set is not applied; use the fresh apply helper from a clean base. & exit /b 1)
if exist "src\backend_probe_avx2.zig" (echo ERROR: Phase 3b scaffolding retirement is incomplete. & exit /b 1)

if not exist "tools" (
    md "tools"
    if errorlevel 1 (
        echo ERROR: failed to create repository tools directory.
        exit /b 1
    )
)

call :install_file "build_1C_v1.bat"
if errorlevel 1 exit /b 1
call :install_file "tools\audit_stage_1c_s1_structure.ps1"
if errorlevel 1 exit /b 1
call :install_file "tools\audit_stage_1c_g10_imports.ps1"
if errorlevel 1 exit /b 1
call :install_file "tools\audit_stage_1c_s2_sweep.ps1"
if errorlevel 1 exit /b 1
call :install_file "tools\audit_stage_1c_s3_eol.ps1"
if errorlevel 1 exit /b 1

rem Remove the superseded v1.6 consolidated helper if an earlier resume attempt installed it.
if exist "tools\stage_1c_proof_helpers.ps1" (
    del /F /Q "tools\stage_1c_proof_helpers.ps1"
    if exist "tools\stage_1c_proof_helpers.ps1" (
        echo ERROR: failed to remove superseded tools\stage_1c_proof_helpers.ps1.
        exit /b 1
    )
)

git -c core.whitespace=cr-at-eol diff --check
if errorlevel 1 exit /b 1

echo ================================================================
echo RESUME STAGE 1C FULL PROOF MATRIX WITH V1.7 RUNNER
echo ================================================================
call "build_1C_v1.bat"
set "proof_code=%ERRORLEVEL%"
if not "%proof_code%"=="0" exit /b %proof_code%

git -c core.whitespace=cr-at-eol diff --check
if errorlevel 1 exit /b 1

echo ================================================================
echo POST-VALIDATION STATUS
echo ================================================================
git status --short
if errorlevel 1 exit /b 1

echo ================================================================
echo PHASE 3B V1.7 RESUMED VALIDATION COMPLETED SUCCESSFULLY
echo ================================================================
exit /b 0

:install_file
set "relative=%~1"
set "source=%delivery_root%full_files\%relative%"
set "destination=%repo_root%\%relative%"
if not exist "%source%" (
    echo ERROR: v1.7 delivery file missing: %relative%.
    exit /b 1
)
for %%D in ("%destination%") do (
    if not exist "%%~dpD" (
        md "%%~dpD"
        if errorlevel 1 (
            echo ERROR: failed to create destination directory for %relative%.
            exit /b 1
        )
    )
)
copy /Y "%source%" "%destination%" >nul
if errorlevel 1 (
    echo ERROR: failed to install %relative%.
    exit /b 1
)
fc /B "%source%" "%destination%" >nul
if errorlevel 1 (
    echo ERROR: installed %relative% does not match v1.7 delivery bytes.
    exit /b 1
)
exit /b 0
