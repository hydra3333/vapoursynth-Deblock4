@echo off
setlocal EnableExtensions EnableDelayedExpansion

if "%~1"=="" (
    echo USAGE: call "%~f0" "FULL_PATH_TO_V1.11_APPLIED_REPOSITORY_ROOT"
    exit /b 2
)

set "delivery_root=%~dp0"
set "repo_root=%~f1"

if not exist "%repo_root%\.git" (
    echo ERROR: repository root does not contain .git: "%repo_root%"
    exit /b 1
)

for %%F in (
    "full_files\build_1C_v1.bat"
    "full_files\tests\stage_1c_classic_passthrough.vpy"
    "full_files\tests\stage_1c_deblock4_passthrough.vpy"
) do if not exist "%delivery_root%%%~F" (
    echo ERROR: v1.12 delivery file missing: "%delivery_root%%%~F"
    exit /b 1
)

cd /d "%repo_root%" || exit /b 1

set "branch="
for /f "delims=" %%B in ('git branch --show-current') do set "branch=%%B"
if /I not "!branch!"=="main" (
    echo ERROR: expected branch main, found "!branch!".
    exit /b 1
)

rem Confirm the previously applied Phase 3b validation surface is present.
if not exist "tools\audit_stage_1c_s1_structure.ps1" (echo ERROR: S1 audit missing & exit /b 1)
if not exist "tools\audit_stage_1c_g10_imports.ps1" (echo ERROR: G10 audit missing & exit /b 1)
if not exist "tools\audit_stage_1c_s2_sweep.ps1" (echo ERROR: S2 audit missing & exit /b 1)
if not exist "tools\audit_stage_1c_s3_eol.ps1" (echo ERROR: S3 audit missing & exit /b 1)
if not exist "src\deblock4_selftest.zig" (echo ERROR: v1.10 selftest correction missing & exit /b 1)

rem Preserve the valid v1.11 partial proof transcript before build_1C_v1.bat
rem removes zig-out\inspection_1C for the new run. Do not overwrite a prior copy.
set "prior_log=zig-out\inspection_1C\build_1C_v1_full_output.log"
set "evidence_dir=zig-out\inspection_1C_v1_11_partial_evidence"
set "evidence_log=!evidence_dir!\build_1C_v1_full_output.log"
if exist "!prior_log!" if not exist "!evidence_log!" (
    if not exist "!evidence_dir!" md "!evidence_dir!"
    if errorlevel 1 (
        echo ERROR: failed to create v1.11 evidence directory.
        exit /b 1
    )
    copy /Y "!prior_log!" "!evidence_log!" >nul
    if errorlevel 1 (
        echo ERROR: failed to preserve v1.11 partial proof transcript.
        exit /b 1
    )
    if exist "zig-out\inspection_1C\build_1C_v1_diagnostic_index.txt" (
        copy /Y "zig-out\inspection_1C\build_1C_v1_diagnostic_index.txt" "!evidence_dir!\build_1C_v1_diagnostic_index.txt" >nul
        if errorlevel 1 (
            echo ERROR: failed to preserve v1.11 diagnostic index.
            exit /b 1
        )
    )
    echo === Preserved v1.11 partial evidence under !evidence_dir!
)

if not exist "tests" md "tests"
if errorlevel 1 exit /b 1

call :install_and_verify "full_files\build_1C_v1.bat" "build_1C_v1.bat"
if errorlevel 1 exit /b 1
call :install_and_verify "full_files\tests\stage_1c_classic_passthrough.vpy" "tests\stage_1c_classic_passthrough.vpy"
if errorlevel 1 exit /b 1
call :install_and_verify "full_files\tests\stage_1c_deblock4_passthrough.vpy" "tests\stage_1c_deblock4_passthrough.vpy"
if errorlevel 1 exit /b 1

findstr /I /C:"error_empty_planes" "build_1C_v1.bat" "tests\stage_1c_classic_passthrough.vpy" "tests\stage_1c_deblock4_passthrough.vpy" >nul
if not errorlevel 1 (
    echo ERROR: retired error_empty_planes case remains after v1.12 installation.
    exit /b 1
)
findstr /C:"Toolchain finding F6" "tests\stage_1c_classic_passthrough.vpy" >nul || (echo ERROR: Classic F6 comment missing & exit /b 1)
findstr /C:"Toolchain finding F6" "tests\stage_1c_deblock4_passthrough.vpy" >nul || (echo ERROR: Deblock4 F6 comment missing & exit /b 1)
findstr /C:"low-level-API defence" "tests\stage_1c_classic_passthrough.vpy" >nul || (echo ERROR: Classic empty-plane defence comment missing & exit /b 1)
findstr /C:"low-level-API defence" "tests\stage_1c_deblock4_passthrough.vpy" >nul || (echo ERROR: Deblock4 empty-plane defence comment missing & exit /b 1)
findstr /C:"plane arrays reject empty and duplicate and ignore order" "tests\stage_1c_classic_passthrough.vpy" >nul || (echo ERROR: Classic empty-plane unit-test reference missing & exit /b 1)
findstr /C:"plane arrays reject empty and duplicate and ignore order" "tests\stage_1c_deblock4_passthrough.vpy" >nul || (echo ERROR: Deblock4 empty-plane unit-test reference missing & exit /b 1)

for %%C in (error_strength error_duplicate_planes error_unknown_backend error_variable_format) do (
    findstr /C:"%%C" "build_1C_v1.bat" >nul || (echo ERROR: Classic retained case %%C missing from runner & exit /b 1)
)
for %%C in (error_step_low error_step_high) do (
    findstr /C:"%%C" "build_1C_v1.bat" >nul || (echo ERROR: Deblock4 retained case %%C missing from runner & exit /b 1)
)

echo ================================================================
echo PHASE 3B V1.12 CONSOLIDATED VALIDATION CORRECTION INSTALLED
echo Changed repository files:
echo   build_1C_v1.bat
echo   tests\stage_1c_classic_passthrough.vpy
echo   tests\stage_1c_deblock4_passthrough.vpy
echo Retired integration case: error_empty_planes
echo Production empty-array defence remains byte-unchanged.
echo Production code and W3X-owned files were not copied or normalised.
echo Stage 1C.1 mitigation work was not begun.
echo ================================================================

git -c core.whitespace=cr-at-eol diff --check
if errorlevel 1 exit /b 1

call "build_1C_v1.bat"
set "proof_code=!ERRORLEVEL!"
if not "!proof_code!"=="0" exit /b !proof_code!

git -c core.whitespace=cr-at-eol diff --check
if errorlevel 1 exit /b 1

echo ================================================================
echo POST-VALIDATION STATUS
echo ================================================================
git status --short
if errorlevel 1 exit /b 1

echo ================================================================
echo PHASE 3B V1.12 VALIDATION COMPLETED SUCCESSFULLY
echo ================================================================
exit /b 0

:install_and_verify
set "source=%delivery_root%%~1"
set "destination=%repo_root%\%~2"
copy /Y "!source!" "!destination!" >nul
if errorlevel 1 (
    echo ERROR: failed to install %~2.
    exit /b 1
)
fc /B "!source!" "!destination!" >nul
if errorlevel 1 (
    echo ERROR: installed %~2 does not match v1.12 delivery bytes.
    exit /b 1
)
exit /b 0
