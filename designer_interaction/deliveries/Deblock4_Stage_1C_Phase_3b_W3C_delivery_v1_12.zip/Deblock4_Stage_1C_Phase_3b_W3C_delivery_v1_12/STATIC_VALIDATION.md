# Phase 3b v1.12 W3C Static Validation

## Passed

- repository change set contains exactly the permanent runner and the two `.vpy` validation harnesses;
- `error_empty_planes` is absent from both runner case lists and both harnesses;
- both harnesses distinguish the empty-array boundary-rejection class from F6 coercion;
- both comments state that production validation remains low-level-API defence and is not dead code;
- both comments name Zig test `plane arrays reject empty and duplicate and ignore order`;
- the existing F6 comments remain present and byte-unchanged;
- every other runner case token and harness branch is unchanged from v1.11;
- the full remaining error-case sweep is recorded in the manifest;
- retained cases were source-traced from registration type through map reader and plugin-owned validation/error mapping;
- production source, the v1.10 selftest correction, all audit scripts, and Stage 1C.1 surfaces are untouched;
- both `.vpy` files compile as Python syntax;
- runner labels and internal `call`/`goto` targets resolve;
- the resume helper has exactly three repository copy/byte-verification targets;
- no W3X-owned file is included under `full_files`;
- all delivery text is US-ASCII/CRLF;
- package SHA-256 entries verify;
- ZIP integrity test passes.

## Evidence treatment

The v1.11 transcript remains valid partial evidence through Classic `error_duplicate_planes`. The resume helper preserves the current local log and diagnostic index under `zig-out/inspection_1C_v1_11_partial_evidence/` when available.

## Not executed by W3C

The container does not provide the W3X Windows/Visual Studio/VapourSynth environment. W3X must run the complete delivered proof matrix. W3D then reviews the artifacts and W3C concurs or identifies a defect.
