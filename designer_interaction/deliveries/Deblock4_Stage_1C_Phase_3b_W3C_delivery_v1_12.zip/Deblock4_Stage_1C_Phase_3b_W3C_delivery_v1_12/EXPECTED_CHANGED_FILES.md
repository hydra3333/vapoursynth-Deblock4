# Phase 3b v1.12 Expected Repository Changes

Exactly three validation files:

```text
build_1C_v1.bat
tests/stage_1c_classic_passthrough.vpy
tests/stage_1c_deblock4_passthrough.vpy
```

No production or W3X-owned file is part of this delivery.
