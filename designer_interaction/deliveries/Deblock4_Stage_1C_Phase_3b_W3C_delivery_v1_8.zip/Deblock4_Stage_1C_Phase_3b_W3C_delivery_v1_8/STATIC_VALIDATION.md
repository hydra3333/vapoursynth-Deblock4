# Phase 3b v1.8 W3C Static and Integration Validation

## Passed

- reconstructed the accepted Phase 3a source base from the recorded source archive and accepted Phase 3a delivery;
- deletion patch `git apply --check`;
- deletion patch `git apply --check --whitespace=error-all`;
- deletion patch application in an isolated clean tree;
- complete-file overlay reproduces the integrated v1.8 tree;
- `git -c core.whitespace=cr-at-eol diff --check` on the reconstructed tree;
- four separate permanent audit scripts created for S1, G10, S2 and S3;
- audit payload logic compared with the v1.5 inline payloads, including required batch `%%` to PowerShell `%` conversion;
- S2 still scans `tools/` and excludes its own deliberate retired-name catalogue;
- S3 includes `.ps1` and therefore audits all four new scripts;
- zero `\"` sequences occur in runner PowerShell invocation lines;
- repair/resume helper installs and byte-verifies all fifteen complete repository files, including both `.vpy` harnesses, before validation;
- repair/resume helper accepts only an all-present or all-absent thirteen-file retirement set and fails closed on a mixed state;
- repair/resume helper removes only exact superseded recovery artifacts;
- fresh apply helper copies and byte-verifies all fifteen added/replaced repository files;
- runner and both delivery helpers have unique labels and no missing `call`/`goto` targets;
- both `.vpy` files pass Python `py_compile`;
- all relative Zig imports resolve in the reconstructed tree;
- all repository text in the reconstructed final tree is US-ASCII with zero bare LF;
- no retired file remains after the deletion patch;
- no first-class retired-name reference remains outside the permanent S2 catalogue;
- all package SHA-256 entries verify after final assembly;
- ZIP integrity test passes.

## Not executed by W3C

The container does not provide Windows `cmd.exe`, PowerShell 5.1, Visual Studio 2026, Zig 0.16.0, `dumpbin` or the portable VapourSynth runtime. W3C therefore makes no project-PASS claim. W3X must run the delivered v1.8 proof matrix; W3D then reviews the produced artifacts and W3C concurs or identifies a defect.
