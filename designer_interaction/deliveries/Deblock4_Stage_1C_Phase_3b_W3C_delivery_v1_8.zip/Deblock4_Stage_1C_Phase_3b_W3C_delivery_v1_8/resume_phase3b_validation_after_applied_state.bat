@echo off
setlocal EnableExtensions EnableDelayedExpansion

if "%~1"=="" (
    echo USAGE: call "%~f0" "FULL_PATH_TO_PARTIALLY_OR_ALREADY_APPLIED_REPOSITORY_ROOT"
    exit /b 2
)

set "delivery_root=%~dp0"
set "repo_root=%~f1"
set "patch_source=%delivery_root%Deblock4_Stage_1C_Phase_3b_scaffolding_deletions_v1_0.patch"

if not exist "%repo_root%\.git" (
    echo ERROR: repository root does not contain .git: "%repo_root%"
    exit /b 1
)
if not exist "%patch_source%" (
    echo ERROR: deletion patch missing: "%patch_source%"
    exit /b 1
)

cd /d "%repo_root%" || exit /b 1

set "branch="
for /f "delims=" %%B in ('git branch --show-current') do set "branch=%%B"
if /I not "!branch!"=="main" (
    echo ERROR: expected branch main, found "!branch!".
    exit /b 1
)

rem Confirm this is the Deblock4 Phase 3a/3b repository, not an unrelated tree.
if not exist "src\deblock4_plugin.zig" (echo ERROR: Phase 3a base file missing: src\deblock4_plugin.zig & exit /b 1)
if not exist "src\lifecycle_trace_debug.zig" (echo ERROR: Phase 3a base file missing: src\lifecycle_trace_debug.zig & exit /b 1)

rem Accept either a complete pre-deletion Phase 3a set or a complete already-deleted Phase 3b set.
rem A mixed retirement state is ambiguous and therefore fails closed.
set /a retired_present=0
set /a retired_absent=0
call :count_retired "build_1B1_v7_3.bat"
call :count_retired "build_1B2_v5_REDEVELOPED.bat"
call :count_retired "build_1B3_v5.bat"
call :count_retired "src\backend_isolation_smoke_test.zig"
call :count_retired "src\backend_probe_avx2.zig"
call :count_retired "src\backend_probe_generic.zig"
call :count_retired "src\backend_probe_scalar.zig"
call :count_retired "src\backend_probe_sse41.zig"
call :count_retired "src\backend_retention_anchor.zig"
call :count_retired "src\build_probe.zig"
call :count_retired "src\dll_probe.zig"
call :count_retired "src\dll_smoke_test.zig"
call :count_retired "src\vapoursynth_header_probe.zig"

if !retired_present! EQU 13 (
    echo ================================================================
    echo APPLY COMPLETE PHASE 3B RETIREMENT SET
    echo ================================================================
    git apply --check "%patch_source%"
    if errorlevel 1 exit /b 1
    git apply --check --whitespace=error-all "%patch_source%"
    if errorlevel 1 exit /b 1
    git apply "%patch_source%"
    if errorlevel 1 exit /b 1
) else if !retired_absent! EQU 13 (
    echo === Complete Phase 3b retirement set is already applied.
) else (
    echo ERROR: partial Phase 3b retirement state: !retired_present! retired files present, !retired_absent! absent.
    echo ERROR: stop and inspect the repository rather than guessing which deletion state is authoritative.
    exit /b 1
)

rem Install and byte-verify the complete v1.8 repository overlay.
call :install_file "build.zig"
if errorlevel 1 exit /b 1
call :install_file "build.zig.zon"
if errorlevel 1 exit /b 1
call :install_file "build_1C_v1.bat"
if errorlevel 1 exit /b 1
call :install_file "src\deblock4_selftest.zig"
if errorlevel 1 exit /b 1
call :install_file "tests\stage_1c_classic_passthrough.vpy"
if errorlevel 1 exit /b 1
call :install_file "tests\stage_1c_deblock4_passthrough.vpy"
if errorlevel 1 exit /b 1
call :install_file "third_party\vapoursynth\include\VSConstants4.h"
if errorlevel 1 exit /b 1
call :install_file "third_party\vapoursynth\include\VSHelper4.h"
if errorlevel 1 exit /b 1
call :install_file "third_party\vapoursynth\include\VSScript4.h"
if errorlevel 1 exit /b 1
call :install_file "third_party\vapoursynth\include\VapourSynth4.h"
if errorlevel 1 exit /b 1
call :install_file "tools\run_vs.cmd"
if errorlevel 1 exit /b 1
call :install_file "tools\audit_stage_1c_s1_structure.ps1"
if errorlevel 1 exit /b 1
call :install_file "tools\audit_stage_1c_g10_imports.ps1"
if errorlevel 1 exit /b 1
call :install_file "tools\audit_stage_1c_s2_sweep.ps1"
if errorlevel 1 exit /b 1
call :install_file "tools\audit_stage_1c_s3_eol.ps1"
if errorlevel 1 exit /b 1

rem Remove only exact superseded recovery artifacts from earlier failed deliveries.
call :remove_if_present "tools\stage_1c_proof_helpers.ps1"
if errorlevel 1 exit /b 1
call :remove_if_present "build_1C_v1_PHASE3B_VSDEVCMD_FIX.bat"
if errorlevel 1 exit /b 1
call :remove_if_present "build_1C_v1_PHASE3B_VSDEVCMD_PROJECTDIR_FIX.bat"
if errorlevel 1 exit /b 1

git -c core.whitespace=cr-at-eol diff --check
if errorlevel 1 exit /b 1

echo ================================================================
echo REPAIR OR RESUME STAGE 1C FULL PROOF MATRIX WITH V1.8
echo ================================================================
call "build_1C_v1.bat"
set "proof_code=!ERRORLEVEL!"
if not "!proof_code!"=="0" exit /b !proof_code!

git -c core.whitespace=cr-at-eol diff --check
if errorlevel 1 exit /b 1

echo ================================================================
echo POST-VALIDATION STATUS
echo ================================================================
git status --short
if errorlevel 1 exit /b 1

echo ================================================================
echo PHASE 3B V1.8 REPAIR/RESUME VALIDATION COMPLETED SUCCESSFULLY
echo ================================================================
exit /b 0

:count_retired
if exist "%~1" (
    set /a retired_present+=1
) else (
    set /a retired_absent+=1
)
exit /b 0

:install_file
set "relative=%~1"
set "source=%delivery_root%full_files\!relative!"
set "destination=%repo_root%\!relative!"
if not exist "!source!" (
    echo ERROR: v1.8 delivery file missing: !relative!.
    exit /b 1
)
for %%D in ("!destination!") do (
    if not exist "%%~dpD" (
        md "%%~dpD"
        if errorlevel 1 (
            echo ERROR: failed to create destination directory for !relative!.
            exit /b 1
        )
    )
)
copy /Y "!source!" "!destination!" >nul
if errorlevel 1 (
    echo ERROR: failed to install !relative!.
    exit /b 1
)
fc /B "!source!" "!destination!" >nul
if errorlevel 1 (
    echo ERROR: installed !relative! does not match v1.8 delivery bytes.
    exit /b 1
)
exit /b 0

:remove_if_present
if not exist "%~1" exit /b 0
del /F /Q "%~1"
if exist "%~1" (
    echo ERROR: failed to remove superseded recovery artifact %~1.
    exit /b 1
)
exit /b 0
