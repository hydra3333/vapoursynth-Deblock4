# Deblock4 Stage 1C Phase 3b - W3C Delivery Manifest

**Version:** 1.8
**Date:** 2026-08-02
**Author:** W3C
**Status:** Complete replacement Phase 3b delivery candidate for W3D review and W3X validation/acceptance.
**Repository:** `hydra3333/vapoursynth-Deblock4`
**Branch:** `main`
**Encoding:** US-ASCII. Repository text files are CRLF; the delivery-only deletion patch retains its generated transport form.

**v1.8 correction:** supersedes Phase 3b deliveries v1.0 through v1.7. The v1.7 ZIP contained every required repository file, but its resume helper was not self-contained: it required the two `.vpy` harnesses to exist before copying anything and then installed only the runner plus four audit scripts. That was too brittle after interrupted validation and manual cleanup. v1.8 replaces the resume path with a repair/resume helper that installs and byte-verifies all fifteen complete repository files. It accepts either the complete pre-deletion Phase 3a retirement set or the complete already-deleted Phase 3b state, fails closed on a mixed deletion state, removes only exact superseded recovery artifacts, and then runs the unchanged proof matrix. No algorithm, frame path, tier-selection logic, repository file content, deletion set, `.vpy` harness or proof obligation is changed from v1.7.

## 1. Exact base and scope

**Scope:** Stage 1C Phase 3b - retire the verified scaffolding, install the permanent production build/proof surface, execute the complete Scope v1.5 proof matrix, and close Stage 1C without activating pixel/deblocking algorithms.

**Exact source base alternative:** the accepted and committed Phase 3a source state reconstructed byte-for-byte from:

- `src(42).zip`, SHA-256 `ac2aa4c494e7a2312cea2af2e85ffae9fa7c0049e9ea15942dc9a6730955c29f`;
- `Deblock4_Stage_1C_Phase_3a_W3C_delivery_v1_0.zip`, SHA-256 `45c73f42e6034c6c5178e8a4d11ded17c577570d79c8a6979398cd4c2f022d0e`;
- W3X recorded Phase 3a acceptance, commit and push.

No commit hash is inferred. The charter exact attached-source-tree alternative is used.

## 2. Adds or changes

- replaces the probe-era `build.zig` with the permanent Stage 1C DLL/selftest/test/inspection graph;
- adds `build_1C_v1.bat`, implementing B1/B2/G1/G2/E1-E6/V1/S1-S3/N1 and retained detector-drift evidence;
- adds four permanent, individually testable audit scripts under `tools/` for S1, G10, S2 and S3;
- extends the first-class selftest with Stage 1C pure tier/parameter contracts;
- adds both binding BlankClip `.vpy` e2e harnesses;
- converts the remaining retained LF text files to repository-standard CRLF;
- retires the exact Scope v1.5 scaffolding list;
- includes the P4 creation-error message-table draft for W3D review and W3X ratification.

## 3. Defers or does not change

- no Classic or Deblock4 pixel/deblocking algorithm is implemented;
- no real v2/v3 algorithm backend executes;
- the accepted Phase 3a frame path, ownership, registration, configuration, tier selection and lifecycle behaviour are not redesigned;
- no Stage 2C/2D oracle work begins;
- P4 remains a review draft until W3X ratifies it.

## 4. Delivery form by file

The charter one-form-per-file rule is observed.

### Complete new/replacement repository files

- `build.zig`
- `build.zig.zon`
- `build_1C_v1.bat`
- `src/deblock4_selftest.zig`
- `tests/stage_1c_classic_passthrough.vpy`
- `tests/stage_1c_deblock4_passthrough.vpy`
- `third_party/vapoursynth/include/VSConstants4.h`
- `third_party/vapoursynth/include/VSHelper4.h`
- `third_party/vapoursynth/include/VSScript4.h`
- `third_party/vapoursynth/include/VapourSynth4.h`
- `tools/run_vs.cmd`
- `tools/audit_stage_1c_s1_structure.ps1`
- `tools/audit_stage_1c_g10_imports.ps1`
- `tools/audit_stage_1c_s2_sweep.ps1`
- `tools/audit_stage_1c_s3_eol.ps1`

All are complete whole files in US-ASCII/CRLF.

### Deletions

`Deblock4_Stage_1C_Phase_3b_scaffolding_deletions_v1_0.patch` is a deletion-only unified diff prepared against the exact Phase 3a base. It deletes the thirteen paths listed in `EXPECTED_CHANGED_FILES.md`. No modified or new repository file is also present in the patch.

### Delivery-only helpers

- `apply_phase3b_and_validate.bat` - fresh clean Phase 3a application only.
- `resume_phase3b_validation_after_applied_state.bat` - self-contained W3X repair/resume path for a complete Phase 3a retirement set or a complete already-deleted Phase 3b state; it overlays all fifteen repository files before validation.

Neither helper is a repository file.

## 5. Apply or resume sequence

Fresh clean Phase 3a application:

```bat
call "<EXTRACTED_V1_8_DELIVERY>\apply_phase3b_and_validate.bat" "<REPOSITORY_ROOT>"
```

Already-applied current W3X repository:

```bat
call "<EXTRACTED_V1_8_DELIVERY>\resume_phase3b_validation_after_applied_state.bat" "<REPOSITORY_ROOT>"
```

Do not edit a failed patch, full-file copy or runner in place. Stop and report the first actual nonzero step.

## 6. Required validation and expected result

The permanent repository runner is `call build_1C_v1.bat`. The authoritative success terminus is:

```text
STAGE 1C_v1 FULL PROOF MATRIX COMPLETED SUCCESSFULLY
B1 B2 G1 G2 E1 E2 E3 E4 E5 E6 V1 S1 S2 S3 N1 PASS
```

The batch covers Debug, ReleaseSafe and ReleaseFast builds/tests/selftests/e2e; all three G10 seams; export/raw/disassembly gates; properties and checksums; force-down and explicit-backend cases; full-signature refusals; lifecycle trace; version single-home; structural/symbol/runtime no-per-frame-selection; exact sweep; zero-LF repository text; target/CPU rejection; and 9/9 non-Debug debug-option rejection.

Zig known `--listen` `failed command:` context can appear when a passing test writes expected stderr. Exit codes, Zig summaries, explicit assertions and the final success terminus are authoritative.

## 7. Review notes

- the runner invokes S1, G10, S2 and S3 only through four named `powershell -File` scripts;
- the runner has zero `\"` sequences in PowerShell invocation lines;
- S3 includes `.ps1` files and therefore self-polices all four audit scripts for US-ASCII/CRLF;
- S2 still scans `tools/` and excludes only its own retired-name catalogue plus the permanent batch runner;
- Debug positive controls use seam-unique raw strings and machine-code immediates;
- S1 symbol evidence uses stable router/ar_* object files, where `dumpbin /SYMBOLS` is authoritative;
- the v1.8 repair/resume helper copies and byte-verifies all fifteen repository files before validation and no longer requires the harnesses to pre-exist;
- W3C performed static/integration validation only. W3X Windows VS2026/Zig 0.16/VapourSynth run, W3D artifact review, W3C concurrence and W3X acceptance remain mandatory.

## 8. Expected repository status after application and validation

Exactly the fifteen added/replaced paths and thirteen deleted paths in `EXPECTED_CHANGED_FILES.md` should appear. `zig-out` and `.zig-cache` evidence remain ignored. Delivery helpers and patches remain outside the repository. Any loose temporary fix runner downloaded into the repository root must be removed before commit.
