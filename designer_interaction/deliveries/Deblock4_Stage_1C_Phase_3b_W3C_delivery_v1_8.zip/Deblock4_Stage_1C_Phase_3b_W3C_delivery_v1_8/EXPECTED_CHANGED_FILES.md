# Expected changed files

## Added or replaced
- build.zig
- build.zig.zon
- build_1C_v1.bat
- src/deblock4_selftest.zig
- tests/stage_1c_classic_passthrough.vpy
- tests/stage_1c_deblock4_passthrough.vpy
- third_party/vapoursynth/include/VSConstants4.h
- third_party/vapoursynth/include/VSHelper4.h
- third_party/vapoursynth/include/VSScript4.h
- third_party/vapoursynth/include/VapourSynth4.h
- tools/run_vs.cmd
- tools/audit_stage_1c_s1_structure.ps1
- tools/audit_stage_1c_g10_imports.ps1
- tools/audit_stage_1c_s2_sweep.ps1
- tools/audit_stage_1c_s3_eol.ps1

## Deleted
- build_1B1_v7_3.bat
- build_1B2_v5_REDEVELOPED.bat
- build_1B3_v5.bat
- src/backend_isolation_smoke_test.zig
- src/backend_probe_avx2.zig
- src/backend_probe_generic.zig
- src/backend_probe_scalar.zig
- src/backend_probe_sse41.zig
- src/backend_retention_anchor.zig
- src/build_probe.zig
- src/dll_probe.zig
- src/dll_smoke_test.zig
- src/vapoursynth_header_probe.zig
