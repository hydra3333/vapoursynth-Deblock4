# Deblock4 Stage 1C Phase 3b - W3C Delivery Manifest

**Version:** 1.13  
**Date:** 2026-08-02  
**Author:** W3C  
**Status:** Three-file production-source corrective delivery candidate for W3D review and W3X validation/acceptance.  
**Repository:** `hydra3333/vapoursynth-Deblock4`  
**Branch:** `main`  
**Encoding:** US-ASCII and CRLF.  
**Governance:** Issued under charter C-DELIV-01 through C-DELIV-09. W3X's real Windows/VS2026/Zig/VapourSynth run is authoritative.

## 1. Adds or changes

This delivery corrects the one remaining Stage 1C Phase 3b finding: the three G10 Debug marker functions are PE-exported from the Debug production DLL because they are declared `pub export fn` inside the DLL compilation graph.

v1.13 removes only the `export` keyword from those three declarations:

```text
src/force_down_debug.zig
    pub export fn deblock4_force_down_marker_FD00D001()
    ->
    pub fn deblock4_force_down_marker_FD00D001()

src/print_diag_helper_functions.zig
    pub export fn deblock4_verbose_detection_marker_DD00D001()
    ->
    pub fn deblock4_verbose_detection_marker_DD00D001()

src/lifecycle_trace_debug.zig
    pub export fn deblock4_lifecycle_trace_marker_1C71FE01()
    ->
    pub fn deblock4_lifecycle_trace_marker_1C71FE01()
```

This removes DLL-root dllexport candidacy while preserving each marker's name, return value, raw marker string, code immediate, existing address-taken expression, and the existing enabled-path raw-string uses. The lifecycle marker's direct Debug selftest call remains unchanged.

## 2. Defers or does not change

This delivery does not:

- relax, suppress, rename around, or extend any standing runner check;
- change `build_1C_v1.bat` or either `.vpy` harness;
- add a new symbol-surface acceptance dependency;
- change any G10 conditional import or Debug-only build option;
- change capability detection, ACTUAL/EFFECTIVE selection, tier dispatch, frame mechanics, properties, lifecycle ordering, or pass-through output;
- change the settled object-mode `export fn` mechanism used by Stage 1B.1 and the retained detection inspection object;
- modify any W3X-owned file;
- begin rider Stage 1C.1, Stage 2C/2D, documentation reconciliation, cleanup, or algorithm work.

If W3X's Debug proof shows that de-exporting causes a marker code immediate to disappear, W3C will issue a later evidence-driven correction using the narrowest explicit call or address-taken anchor on that marker's already enabled path. This delivery does not add such an anchor pre-emptively and never restores `export` in the DLL compilation.

## 3. Exact base

The base is the W3X-supplied repository-main source at the Phase 3b v1_12-applied state:

```text
src(43).zip
Deblock4_Stage_1C_Phase_3b_W3C_delivery_v1_12.zip
```

The separately supplied `build_1C_v1.bat` and two Stage 1C `.vpy` harnesses were byte-compared with delivery v1.12 and are identical.

Base SHA-256 values for the three replaced source files:

```text
35d9512b6527cd5fb12cdf946f35812abb8f3abaf34c615168ac0e249285d65a  src/force_down_debug.zig
358c160df6ca9d5071a48811989efdbbd9ed0e3adca8ace0fee0f565d8b89266  src/print_diag_helper_functions.zig
40c8edc12585c7c58727455ca35c5a11ba023ac37d9a649130dea31e8fb8ed2d  src/lifecycle_trace_debug.zig
```

No commit ID is asserted; the project uses the prevailing branch-main source supplied by W3X as its base anchor.

## 4. Files and delivery form

| Repository path | State | Delivery form | Purpose |
|---|---|---|---|
| `src/force_down_debug.zig` | existing | complete replacement file | remove DLL-root PE-export candidacy from force-down marker |
| `src/print_diag_helper_functions.zig` | existing | complete replacement file | remove DLL-root PE-export candidacy from verbose marker |
| `src/lifecycle_trace_debug.zig` | existing | complete replacement file | remove DLL-root PE-export candidacy from lifecycle marker |

The replacements are complete US-ASCII/CRLF files. Apart from the one token removal in each declaration, their bytes are unchanged from the stated base.

## 5. Apply sequence

Extract the ZIP outside the repository to the `TEMP` path shown below, then run:

```bat
call "E:\SOFTWARE-Win11\MULTIMEDIA\vapoursynth-Deblock4\TEMP\Deblock4_Stage_1C_Phase_3b_W3C_delivery_v1_13\resume_phase3b_v1_13_after_v1_12_applied_state.bat" "E:\SOFTWARE-Win11\MULTIMEDIA\vapoursynth-Deblock4\github\vapoursynth-Deblock4"
```

The helper:

1. requires `.git` and branch `main`;
2. verifies exact v1.12 SHA-256 preconditions for the standing runner, both `.vpy` harnesses, and all three source files being replaced;
3. confirms the v1.12 retirement/comment state;
4. preserves the existing `zig-out\inspection_1C` tree as `zig-out\inspection_1C_v1_12_partial_evidence` when not already preserved;
5. installs and `fc /B` verifies exactly the three changed source files;
6. verifies the three old exported declarations are gone and the three internal declarations, marker constants, address expressions, lifecycle direct call, and object-mode export control remain present;
7. runs the CR-at-EOL `git diff --check` gate;
8. invokes the unchanged permanent `build_1C_v1.bat` full matrix;
9. reruns `git diff --check` and prints `git status --short`.

The helper intentionally fails if the target files are not the exact supplied v1.12 base. Do not hand-edit around a precondition failure.

## 6. Required W3X validation

W3X runs the helper in the supplied Windows environment. The unchanged runner must prove:

```text
ReleaseSafe:
    build, 40/40 unit tests, selftest, all vspipe cases,
    G10 raw-string/symbol/disassembly absence, export exclusions

ReleaseFast:
    same complete proof

Debug with all three G10 seams enabled:
    build, 40/40 unit tests, selftest and vspipe positive controls
    raw binary contains each marker string
    DLL and selftest disassembly contain FD00D001, DD00D001 and 1C71FE01
    DLL export table excludes all three marker function names
```

The required Debug DLL PE export set is exactly:

```text
VapourSynthPluginInit2
_DllMainCRTStartup
```

The required matrix terminus is:

```text
STAGE 1C_v1 FULL PROOF MATRIX COMPLETED SUCCESSFULLY
B1 B2 G1 G2 E1 E2 E3 E4 E5 E6 V1 S1 S2 S3 N1 PASS
```

W3X must preserve the complete v1.13 transcript and `zig-out\inspection_1C`, and report the exact command, exit code, first failure if any, concise result, and final `git status --short`.

## 7. Review notes and invariant enforcement

- G6 is corrected at the source layer. The export-table gate is unchanged and remains loud-failing.
- Emission, linkage, and PE export remain distinct. Object-mode `export fn` is preserved; DLL-root `export fn` is removed only from these three G10 markers.
- G10 release omission and Debug positive controls are unchanged.
- Debug symbol capture remains available for review, but no new runner symbol-presence gate was added, matching W3D's approving note.
- The object-mode-versus-DLL-mode `export fn` result is a candidate for W3D's later `Deblock4_Toolchain_Findings` update; that documentation change is deferred.

## 8. W3C validation boundary

W3C performed source-delta, line-ending, manifest, helper, hash, diff, and package-integrity validation. W3C did not execute the Windows/VS2026/VapourSynth proof matrix. W3X's run alone establishes project PASS; W3D review, W3C concurrence, and W3X acceptance remain required.
