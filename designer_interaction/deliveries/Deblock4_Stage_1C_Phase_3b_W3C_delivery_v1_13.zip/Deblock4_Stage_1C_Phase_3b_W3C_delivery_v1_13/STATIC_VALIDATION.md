# Phase 3b v1.13 W3C Static Validation

## Passed

- exact base hashes recorded for all three replaced source files;
- repository delta contains exactly three files and one token removal per file;
- all three `pub export fn` marker declarations are absent from delivered files;
- all three corresponding `pub fn` declarations are present exactly once;
- marker strings, `CODE_MARKER` values and existing address-taken expressions are byte-unchanged;
- the lifecycle marker's direct call in `deblock4_selftest.zig` is unchanged in the supplied base;
- the Stage 1B.1/detection object-mode `pub export fn` control is unchanged in the supplied base;
- `build_1C_v1.bat` and both `.vpy` harnesses are excluded and retain the exact v1.12 hashes;
- the unchanged runner already gates Debug raw marker strings, Debug disassembly immediates and DLL export-table exclusion for all three names;
- unified diff applies cleanly to an isolated copy of the supplied base;
- `git apply --check` passes;
- `git apply --check --whitespace=error` passes under `core.whitespace=cr-at-eol`;
- `git diff --check` passes under `core.whitespace=cr-at-eol`;
- resume helper copy targets are exactly the three changed source files;
- resume helper source hashes and installed-file hashes match the package;
- helper labels and internal `call`/`goto` targets resolve statically;
- all delivery text and replacement source are US-ASCII/CRLF;
- package SHA-256 entries verify;
- ZIP integrity test passes.

## Per-marker static basis

```text
force-down:
    raw marker string retained in the module and enabled announce/error paths;
    code marker and existing address expression retained.

verbose detection:
    raw marker string retained in the module and enabled dump path;
    code marker and existing address expression retained.

lifecycle:
    raw marker string retained in the module and lifecycle paths;
    code marker and existing address expression retained;
    direct Debug selftest call remains present.
```

The unchanged W3X runner supplies the authoritative post-link proof for each
marker. No new symbol-presence runner check was added.

## Not executed by W3C

The sandbox does not provide W3X's Windows/Visual Studio/VapourSynth execution
environment or its installed Zig executable. W3C therefore does not claim a
Debug DLL build, PE export result, disassembly result, runtime matrix, or PASS.
W3X must run the complete delivered helper and preserve its evidence.
