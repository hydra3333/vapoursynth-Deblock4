@echo off
setlocal EnableExtensions EnableDelayedExpansion

if "%~1"=="" (
    echo USAGE: call "%~f0" "FULL_PATH_TO_V1.12_APPLIED_REPOSITORY_ROOT"
    exit /b 2
)

set "delivery_root=%~dp0"
set "repo_root=%~f1"

if not exist "%repo_root%\.git" (
    echo ERROR: repository root does not contain .git: "%repo_root%"
    exit /b 1
)

for %%F in (
    "full_files\src\force_down_debug.zig"
    "full_files\src\print_diag_helper_functions.zig"
    "full_files\src\lifecycle_trace_debug.zig"
) do if not exist "%delivery_root%%%~F" (
    echo ERROR: v1.13 delivery file missing: "%delivery_root%%%~F"
    exit /b 1
)

cd /d "%repo_root%" || exit /b 1

set "branch="
for /f "delims=" %%B in ('git branch --show-current') do set "branch=%%B"
if /I not "!branch!"=="main" (
    echo ERROR: expected branch main, found "!branch!".
    exit /b 1
)

rem Fail closed on the exact supplied v1.12-applied files that this correction
rem consumes. Unrelated repository changes are not erased or normalised.
call :require_sha256 "build_1C_v1.bat" "6220356fbe842e1b86372779fb6a4c455b63f24b1920502fe5961abc753b8332"
if errorlevel 1 exit /b 1
call :require_sha256 "tests\stage_1c_classic_passthrough.vpy" "7b3aed83b0ca65b8b77a0a021c0be3abfb7091725b800a7fdb96c1ea7733a33a"
if errorlevel 1 exit /b 1
call :require_sha256 "tests\stage_1c_deblock4_passthrough.vpy" "3bdbf2934035659587dc2a6c85b45c2d5077ca5883263e19bb074fff17b6a5fb"
if errorlevel 1 exit /b 1
call :require_sha256 "src\force_down_debug.zig" "35d9512b6527cd5fb12cdf946f35812abb8f3abaf34c615168ac0e249285d65a"
if errorlevel 1 exit /b 1
call :require_sha256 "src\print_diag_helper_functions.zig" "358c160df6ca9d5071a48811989efdbbd9ed0e3adca8ace0fee0f565d8b89266"
if errorlevel 1 exit /b 1
call :require_sha256 "src\lifecycle_trace_debug.zig" "40c8edc12585c7c58727455ca35c5a11ba023ac37d9a649130dea31e8fb8ed2d"
if errorlevel 1 exit /b 1

findstr /I /C:"error_empty_planes" "build_1C_v1.bat" "tests\stage_1c_classic_passthrough.vpy" "tests\stage_1c_deblock4_passthrough.vpy" >nul
if not errorlevel 1 (
    echo ERROR: v1.12-applied error_empty_planes retirement is missing.
    exit /b 1
)
findstr /C:"low-level-API defence" "tests\stage_1c_classic_passthrough.vpy" >nul || (echo ERROR: Classic v1.12 defence comment missing & exit /b 1)
findstr /C:"low-level-API defence" "tests\stage_1c_deblock4_passthrough.vpy" >nul || (echo ERROR: Deblock4 v1.12 defence comment missing & exit /b 1)
findstr /C:"plane arrays reject empty and duplicate and ignore order" "tests\stage_1c_classic_passthrough.vpy" >nul || (echo ERROR: Classic v1.12 unit-test reference missing & exit /b 1)
findstr /C:"plane arrays reject empty and duplicate and ignore order" "tests\stage_1c_deblock4_passthrough.vpy" >nul || (echo ERROR: Deblock4 v1.12 unit-test reference missing & exit /b 1)

rem Preserve the complete local v1.12 inspection tree before the permanent
rem runner replaces zig-out\inspection_1C. Do not overwrite a prior copy.
set "prior_evidence=zig-out\inspection_1C"
set "evidence_dir=zig-out\inspection_1C_v1_12_partial_evidence"
if exist "!prior_evidence!" if not exist "!evidence_dir!" (
    xcopy "!prior_evidence!\*" "!evidence_dir!\" /E /I /H /K /Y >nul
    if errorlevel 1 (
        echo ERROR: failed to preserve v1.12 partial evidence tree.
        exit /b 1
    )
    echo === Preserved v1.12 partial evidence under !evidence_dir!
)

call :install_and_verify "full_files\src\force_down_debug.zig" "src\force_down_debug.zig"
if errorlevel 1 exit /b 1
call :install_and_verify "full_files\src\print_diag_helper_functions.zig" "src\print_diag_helper_functions.zig"
if errorlevel 1 exit /b 1
call :install_and_verify "full_files\src\lifecycle_trace_debug.zig" "src\lifecycle_trace_debug.zig"
if errorlevel 1 exit /b 1

call :require_sha256 "src\force_down_debug.zig" "93a3d4d84273b7698028d55f1dc56b87aec615d0b09c572a548b061eda3db581"
if errorlevel 1 exit /b 1
call :require_sha256 "src\print_diag_helper_functions.zig" "41f620c74ed1ef7fba93549f4de0e98d5595212346cebc606ad870df319e50ed"
if errorlevel 1 exit /b 1
call :require_sha256 "src\lifecycle_trace_debug.zig" "5df285e4eeec29fbb2faa2f5c96b5ef158196492448c6d61c6058ed2a2a3e13e"
if errorlevel 1 exit /b 1

for %%S in (
    deblock4_force_down_marker_FD00D001
    deblock4_verbose_detection_marker_DD00D001
    deblock4_lifecycle_trace_marker_1C71FE01
) do (
    findstr /C:"pub export fn %%S" "src\force_down_debug.zig" "src\print_diag_helper_functions.zig" "src\lifecycle_trace_debug.zig" >nul
    if not errorlevel 1 (
        echo ERROR: exported Debug marker declaration remains for %%S.
        exit /b 1
    )
)
findstr /C:"pub fn deblock4_force_down_marker_FD00D001" "src\force_down_debug.zig" >nul || (echo ERROR: internal force-down marker declaration missing & exit /b 1)
findstr /C:"pub fn deblock4_verbose_detection_marker_DD00D001" "src\print_diag_helper_functions.zig" >nul || (echo ERROR: internal verbose marker declaration missing & exit /b 1)
findstr /C:"pub fn deblock4_lifecycle_trace_marker_1C71FE01" "src\lifecycle_trace_debug.zig" >nul || (echo ERROR: internal lifecycle marker declaration missing & exit /b 1)

findstr /C:"DEBLOCK4_FORCE_DOWN_DEBUG_MARKER_FD00D001" "src\force_down_debug.zig" >nul || (echo ERROR: force-down raw marker missing & exit /b 1)
findstr /C:"0xFD00_D001" "src\force_down_debug.zig" >nul || (echo ERROR: force-down code marker missing & exit /b 1)
findstr /C:"&deblock4_force_down_marker_FD00D001" "src\force_down_debug.zig" >nul || (echo ERROR: force-down address expression missing & exit /b 1)
findstr /C:"DEBLOCK4_VERBOSE_DETECTION_MARKER_DD00D001" "src\print_diag_helper_functions.zig" >nul || (echo ERROR: verbose raw marker missing & exit /b 1)
findstr /C:"0xDD00_D001" "src\print_diag_helper_functions.zig" >nul || (echo ERROR: verbose code marker missing & exit /b 1)
findstr /C:"&deblock4_verbose_detection_marker_DD00D001" "src\print_diag_helper_functions.zig" >nul || (echo ERROR: verbose address expression missing & exit /b 1)
findstr /C:"DEBLOCK4_LIFECYCLE_TRACE_DEBUG_MARKER_1C71FE01" "src\lifecycle_trace_debug.zig" >nul || (echo ERROR: lifecycle raw marker missing & exit /b 1)
findstr /C:"0x1C71_FE01" "src\lifecycle_trace_debug.zig" >nul || (echo ERROR: lifecycle code marker missing & exit /b 1)
findstr /C:"&deblock4_lifecycle_trace_marker_1C71FE01" "src\lifecycle_trace_debug.zig" >nul || (echo ERROR: lifecycle address expression missing & exit /b 1)
findstr /C:".deblock4_lifecycle_trace_marker_1C71FE01();" "src\deblock4_selftest.zig" >nul || (echo ERROR: lifecycle direct selftest call missing & exit /b 1)
findstr /C:"pub export fn deblock4_cpu_capability_detection_entry_C001" "src\cpu_capability_detection.zig" >nul || (echo ERROR: object-mode export control missing & exit /b 1)

call :require_sha256 "build_1C_v1.bat" "6220356fbe842e1b86372779fb6a4c455b63f24b1920502fe5961abc753b8332"
if errorlevel 1 exit /b 1
call :require_sha256 "tests\stage_1c_classic_passthrough.vpy" "7b3aed83b0ca65b8b77a0a021c0be3abfb7091725b800a7fdb96c1ea7733a33a"
if errorlevel 1 exit /b 1
call :require_sha256 "tests\stage_1c_deblock4_passthrough.vpy" "3bdbf2934035659587dc2a6c85b45c2d5077ca5883263e19bb074fff17b6a5fb"
if errorlevel 1 exit /b 1

echo ================================================================
echo PHASE 3B V1.13 G6 SOURCE CORRECTION INSTALLED
echo Changed repository files:
echo   src\force_down_debug.zig
echo   src\print_diag_helper_functions.zig
echo   src\lifecycle_trace_debug.zig
echo Removed only DLL-root export candidacy from the three G10 markers.
echo Runner and vspipe harness bytes remain at the v1.12 state.
echo Stage 1C.1 and all other work remain unstarted.
echo ================================================================

git -c core.whitespace=cr-at-eol diff --check
if errorlevel 1 exit /b 1

call "build_1C_v1.bat"
set "proof_code=!ERRORLEVEL!"
if not "!proof_code!"=="0" exit /b !proof_code!

git -c core.whitespace=cr-at-eol diff --check
if errorlevel 1 exit /b 1

echo ================================================================
echo POST-VALIDATION STATUS
echo ================================================================
git status --short
if errorlevel 1 exit /b 1

echo ================================================================
echo PHASE 3B V1.13 VALIDATION COMPLETED SUCCESSFULLY
echo ================================================================
exit /b 0

:install_and_verify
set "source=%delivery_root%%~1"
set "destination=%repo_root%\%~2"
copy /Y "!source!" "!destination!" >nul
if errorlevel 1 (
    echo ERROR: failed to install %~2.
    exit /b 1
)
fc /B "!source!" "!destination!" >nul
if errorlevel 1 (
    echo ERROR: installed %~2 does not match v1.13 delivery bytes.
    exit /b 1
)
exit /b 0

:require_sha256
set "hash_file=%~1"
set "expected_hash=%~2"
if not exist "!hash_file!" (
    echo ERROR: required v1.12-applied file missing: "!hash_file!"
    exit /b 1
)
set "observed_hash="
for /f "usebackq delims=" %%H in (`powershell -NoProfile -Command "(Get-FileHash -Algorithm SHA256 -LiteralPath '%~1').Hash"`) do set "observed_hash=%%H"
if /I not "!observed_hash!"=="!expected_hash!" (
    echo ERROR: v1.12-applied SHA-256 precondition failed for "!hash_file!".
    echo Expected: !expected_hash!
    echo Observed: !observed_hash!
    exit /b 1
)
exit /b 0
