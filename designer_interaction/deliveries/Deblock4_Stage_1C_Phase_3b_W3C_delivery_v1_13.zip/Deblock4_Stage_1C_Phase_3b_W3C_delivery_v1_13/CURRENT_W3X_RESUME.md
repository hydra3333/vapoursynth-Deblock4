# W3X Current-State Resume - Phase 3b v1.13

## Current repository assumption

Phase 3b delivery v1.12 is already applied. The v1.12 matrix passed every gate
except the correct Debug DLL export-table exclusion for
`deblock4_force_down_marker_FD00D001`; inspection then confirmed that all three
G10 marker names are genuine PE exports.

Do not reset the repository and do not rerun an earlier Phase 3b helper.

## Command

```bat
call "E:\SOFTWARE-Win11\MULTIMEDIA\vapoursynth-Deblock4\TEMP\Deblock4_Stage_1C_Phase_3b_W3C_delivery_v1_13\resume_phase3b_v1_13_after_v1_12_applied_state.bat" "E:\SOFTWARE-Win11\MULTIMEDIA\vapoursynth-Deblock4\github\vapoursynth-Deblock4"
```

## Files changed by the helper

Exactly three production source files:

```text
src\force_down_debug.zig
src\print_diag_helper_functions.zig
src\lifecycle_trace_debug.zig
```

The helper removes only the DLL-root `export` keyword from each G10 marker
function. The permanent runner and both `.vpy` harnesses remain byte-identical
to v1.12. No Stage 1C.1 or other work is included.

Before the new proof run, the helper preserves the current
`zig-out\inspection_1C` tree under:

```text
zig-out\inspection_1C_v1_12_partial_evidence
```

when evidence is present and has not already been preserved.

## Required final success text

```text
STAGE 1C_v1 FULL PROOF MATRIX COMPLETED SUCCESSFULLY
B1 B2 G1 G2 E1 E2 E3 E4 E5 E6 V1 S1 S2 S3 N1 PASS
```

The Debug DLL export table must contain only:

```text
VapourSynthPluginInit2
_DllMainCRTStartup
```

Preserve the complete v1.13 transcript and `zig-out\inspection_1C` for review.
Report the exact helper command, process exit code, first failure if any, the
matrix terminus, and final `git status --short`.
