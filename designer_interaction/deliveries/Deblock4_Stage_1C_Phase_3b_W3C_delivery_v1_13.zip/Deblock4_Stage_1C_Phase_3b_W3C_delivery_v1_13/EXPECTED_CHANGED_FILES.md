# Phase 3b v1.13 Expected Repository Changes

Exactly three production source files:

```text
src/force_down_debug.zig
src/print_diag_helper_functions.zig
src/lifecycle_trace_debug.zig
```

Each file differs from the supplied v1.12-applied base only by removal of the
`export` keyword from its G10 marker function declaration.

No runner, harness, build manifest, audit script, vendored header, W3X-owned
file, Stage 1C.1 surface, or documentation file is part of this delivery.
