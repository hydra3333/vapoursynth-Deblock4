# Deblock4 - Stage 1C.1 Rider Using Echo W3C Delivery Manifest

**Version:** 1.1  
**Date:** 2026-08-02  
**Author:** W3C  
**Scope:** `Deblock4_Scope_Stage_1C1_Rider_Using_Echo_v1_1.md`  
**Repository / branch:** `vapoursynth-Deblock4` / `main`  
**Status:** Replacement for delivery v1.0; use v1.1 only.  
**Encoding:** US-ASCII; CRLF.

## 1. Objective

Implement the ratified Stage 1C.1 effective-invocation echo: build one immutable
resolved call string at successful instance creation, emit it once as the
release-visible `deblock4: using ...` line, and attach the identical bytes to
every output frame as `Deblock4Using`.

## 2. Exact base and application model

This delivery targets the accepted Stage 1C branch-main source after Phase 3b
v1.13 was accepted, committed, and pushed.

The delivery contract is intentionally limited to its twelve target paths:

```text
nine existing source/build files: exact accepted-base SHA-256 preconditions
three delivery-owned new files: destination paths must be absent
```

Unrelated W3X cleanup or working-tree choices outside those twelve paths are not
preconditions and are not inspected or changed by this package.

Accepted-base SHA-256 values for the nine existing files:

- `build.zig`: `616bcae1a330b3b076754fedf570c78bb40f921c0f9f7775978115b547a3201f`
- `build_1C_v1.bat`: `6220356fbe842e1b86372779fb6a4c455b63f24b1920502fe5961abc753b8332`
- `src/classic_frame_properties.zig`: `5a03db0f7ef82244a80c77c29d2912036538a9a1f8b880b7bc490658d044e5ad`
- `src/classic_instance_creation.zig`: `cee6d3ab37dd27be2959ea278ea93184e04deb0309f40a6634760b46a2649af5`
- `src/classic_instance_data.zig`: `382a4c87b85bbc71acbeb7bb7f1741c777ecfc7b56caf0a8cf8bf6e4b602f56e`
- `src/deblock4_frame_properties.zig`: `a72ed0189839a0b46a8c200325cd43a2da73d0ce3c7247e45760e22233e81999`
- `src/deblock4_instance_creation.zig`: `733919e0c8778ec4456983bfced80d5feb5bebb1d49a20bd514d0c1a3608db70`
- `src/deblock4_instance_data.zig`: `6b33ce7c83bdb790ced16ec560686af26e7cd7c4429d9ef58b18a11c84a15897`
- `src/print_helper_functions.zig`: `a30ab4a0912c0a7891662bdfed5d0b424c8641b91a1cf76cfad787d4ee84a77d`

## 3. Adds or changes

- Adds a pure fixed-capacity `effective_invocation_text` value and formatter.
- Expands default planes to the validated source plane count and preserves
  canonical explicit plane ordering.
- Stores one completed value by copy in each immutable instance.
- Emits `deblock4: using {stored bytes}` after validation, tier selection and
  allocation, immediately before `createVideoFilter`.
- Writes `Deblock4Using` from the same stored bytes on every output frame.
- Adds an explicit pure test target covering all binding rider literals,
  default-plane expansion and the fixed-capacity bound.
- Authors both Stage 1C `.vpy` harnesses as complete new delivery-owned files at
  their active `tests/` destinations.
- Adds the adopted Classic `valid_coercion` runtime case.
- Adds only the authorised runner checks: one using line per successful case
  and no using line in every captured failed-creation transcript.

## 4. Defers or does not change

- Existing version-summary bytes and assertions.
- Parameter registration, extraction, validation and exact creation errors.
- ACTUAL/EFFECTIVE detection, tier selection and backend dispatch.
- Callback-router structure and C5 frame ordering.
- Frame pixels and all Stage 2C/2D algorithm work.
- G10 imports, markers, gates and export checks.
- Existing error-case set other than the adopted using-line absence assertion.
- Documentation generation and the deferred Toolchain Findings update.
- Any repository path outside the twelve paths listed in section 5.

## 5. Files and delivery forms

| Path | State | Delivery form |
|---|---|---|
| `build.zig` | existing | unified diff `Deblock4_Stage_1C1_Rider_Using_Echo_existing_files_v1_1.patch` |
| `build_1C_v1.bat` | existing | unified diff `Deblock4_Stage_1C1_Rider_Using_Echo_existing_files_v1_1.patch` |
| `src/classic_frame_properties.zig` | existing | unified diff `Deblock4_Stage_1C1_Rider_Using_Echo_existing_files_v1_1.patch` |
| `src/classic_instance_creation.zig` | existing | unified diff `Deblock4_Stage_1C1_Rider_Using_Echo_existing_files_v1_1.patch` |
| `src/classic_instance_data.zig` | existing | unified diff `Deblock4_Stage_1C1_Rider_Using_Echo_existing_files_v1_1.patch` |
| `src/deblock4_frame_properties.zig` | existing | unified diff `Deblock4_Stage_1C1_Rider_Using_Echo_existing_files_v1_1.patch` |
| `src/deblock4_instance_creation.zig` | existing | unified diff `Deblock4_Stage_1C1_Rider_Using_Echo_existing_files_v1_1.patch` |
| `src/deblock4_instance_data.zig` | existing | unified diff `Deblock4_Stage_1C1_Rider_Using_Echo_existing_files_v1_1.patch` |
| `src/print_helper_functions.zig` | existing | unified diff `Deblock4_Stage_1C1_Rider_Using_Echo_existing_files_v1_1.patch` |
| `src/effective_invocation_text.zig` | new | complete file under `new_files/src/effective_invocation_text.zig` |
| `tests/stage_1c_classic_passthrough.vpy` | new | complete file under `new_files/tests/stage_1c_classic_passthrough.vpy` |
| `tests/stage_1c_deblock4_passthrough.vpy` | new | complete file under `new_files/tests/stage_1c_deblock4_passthrough.vpy` |

No file is supplied simultaneously as both a patch and replacement.

## 6. Principal invariant points

1. `Value` owns a `[512]u8` buffer plus explicit length; there is no secondary
   allocation or free-path change.
2. The formatter consumes validated post-coercion/post-defaulting parameters.
3. Both public surfaces consume `instance.using_text.slice()`; line/property
   identity is structural, not duplicated formatting.
4. Emission occurs only after instance allocation and immediately before the
   existing wrapper call. Earlier error returns cannot emit a using line.
5. The existing one-line summary implementation is byte-untouched.
6. Preset-grid raw custom members are `absent`; custom members retain their
   resolved values; backend remains the request token.

## 7. Apply and validation

First restore only the twelve rider target paths to the accepted Stage 1C base
state if an earlier trial changed them. Other repository cleanup is W3X-owned
and does not need to match any delivery assumption.

Extract this replacement delivery and run:

```bat
call "FULL_PATH\Deblock4_Stage_1C1_Rider_Using_Echo_W3C_delivery_v1_1\apply_and_validate_stage_1c1_using_echo_v1_1.bat" "E:\SOFTWARE-Win11\MULTIMEDIA\vapoursynth-Deblock4\github\vapoursynth-Deblock4"
```

The helper:

1. verifies branch `main`, exact hashes for the nine existing target files, and
   absence of the three new target paths;
2. runs both required `git apply --check` gates;
3. applies the nine-file patch;
4. creates/copies and byte-verifies the formatter and both complete harnesses;
5. verifies every final target hash and key rider anchors;
6. runs `git diff --check`;
7. runs the standing `build_1C_v1.bat` full matrix;
8. copies matrix artifacts into `W3X_validation_artifacts` when present;
9. reports final `git status --short`.

## 8. Expected authoritative results

- Debug, ReleaseSafe and ReleaseFast production builds: PASS.
- Complete unit-test suite: 17/17 steps and 53/53 tests PASS in each mode,
  matching the already observed rider implementation run.
- Classic `valid_auto`, `valid_full`, and `valid_coercion`: PASS.
- All four Deblock4 valid cases: PASS.
- Every valid case: exact `Deblock4Using` property equality and exactly one
  `deblock4: using ` line.
- Every captured error case: exact existing error and no using line.
- Existing version-summary assertions: unchanged PASS.
- All fifteen standing gates and final process result:

```text
STAGE 1C_v1 FULL PROOF MATRIX COMPLETED SUCCESSFULLY
OUTER_BATCH_EXIT_CODE=0
```

Only the new v1.1 application/run establishes that replacement delivery v1.1
applies mechanically to the authoritative base.

## 9. Prior behavior evidence and W3C static validation

The implementation already completed the full matrix after the two complete
harness files were manually made available at their active destinations:

```text
ReleaseSafe: 17/17 steps, 53/53 tests PASS
ReleaseFast: 17/17 steps, 53/53 tests PASS
Debug: 17/17 steps, 53/53 tests PASS
valid_coercion stderr: Classic(strength=1, ...)
all valid using-line exact-count checks: PASS
all captured failure using-line absence checks: PASS
full matrix: PASS
OUTER_BATCH_EXIT_CODE=0
```

That run proves behavior but does not replace the required mechanical v1.1
application/run.

W3C package validation:

- exact twelve-path set: PASS;
- both harnesses delivered whole at `tests/`: PASS;
- all seven binding literals exact: PASS;
- Python syntax for both harnesses: PASS;
- US-ASCII and CRLF: PASS;
- patch `git apply --check`: PASS;
- patch `git apply --check --whitespace=error`: PASS;
- integrated `git diff --check`: PASS;
- clean-base application and final target hashes: PASS;
- package SHA-256 and ZIP integrity: PASS.

## 10. Final integrated SHA-256 values

- `build.zig`: `d25e1920ff3664bcf3156e353fd3da1c51ea141bfa8391f957143ceee13978ca`
- `build_1C_v1.bat`: `d37ec0e0755574d7f5f023ad4656cf637b34108854c23d24a3e9e47e8f90ee39`
- `src/classic_frame_properties.zig`: `d6ca49b3a74f1488d96412ade8f6dbc5526004c62f564bd0bbbbf2b929a207e5`
- `src/classic_instance_creation.zig`: `8baf6922bee9aa151d36d41b4bd5d595dac226133a6861baa06a8e84f84307ca`
- `src/classic_instance_data.zig`: `aface41404d2b7ea7a0b767f09b10069bcc80f17fc3ccb52d7614423da0d93fd`
- `src/deblock4_frame_properties.zig`: `e27c1d019fb21a9de756dcc9b391b6b2992007b3f1d37af5cb48909a5bdfd114`
- `src/deblock4_instance_creation.zig`: `d4aa6e0c4c9295a7955d90e4ce0ad1e1a83f5758efad231f5bf64c8672f925fb`
- `src/deblock4_instance_data.zig`: `8db168f00708ccdf04ce12f757a94202ed27219f84a24016f3f2f793e07de34c`
- `src/print_helper_functions.zig`: `2db78f6c6d91c419da7e16e6928e385978e481ec4efced3ee64e8e0203ae57c9`
- `src/effective_invocation_text.zig`: `4cb12f1e0386c7d1039ac1ac23d152592f98b2d17d880c3d1ffa07743aee7bde`
- `tests/stage_1c_classic_passthrough.vpy`: `4559a62fc0f20f9affc43835f783cdc604ab65b2653f5278b57fdb18f5d33ddd`
- `tests/stage_1c_deblock4_passthrough.vpy`: `aca4b20f1a7d3b68052994d748915c54168282ccdf8e4781470eaea6d8900c7e`
