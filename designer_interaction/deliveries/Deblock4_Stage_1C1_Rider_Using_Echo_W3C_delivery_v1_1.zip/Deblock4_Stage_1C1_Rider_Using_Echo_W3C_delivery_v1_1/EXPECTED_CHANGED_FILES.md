# Expected Changed Files - Stage 1C.1 Using Echo v1.1

After application from the accepted target-path base, these are the twelve
rider paths. Unrelated pre-existing W3X changes elsewhere may also appear and
are outside this delivery contract.

```text
 M build.zig
 M build_1C_v1.bat
 M src/classic_frame_properties.zig
 M src/classic_instance_creation.zig
 M src/classic_instance_data.zig
 M src/deblock4_frame_properties.zig
 M src/deblock4_instance_creation.zig
 M src/deblock4_instance_data.zig
 M src/print_helper_functions.zig
?? src/effective_invocation_text.zig
?? tests/stage_1c_classic_passthrough.vpy
?? tests/stage_1c_deblock4_passthrough.vpy
```

The three new files may appear as `A` after staging. With Git's default
untracked-directory collapsing, the two harnesses may instead be represented by
a single `?? tests/` status row. No other path belongs to this delivery.
