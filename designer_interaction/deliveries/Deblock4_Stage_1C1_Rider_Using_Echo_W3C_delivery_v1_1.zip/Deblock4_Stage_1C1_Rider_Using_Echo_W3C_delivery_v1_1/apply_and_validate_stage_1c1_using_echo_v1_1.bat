@echo off
setlocal EnableExtensions EnableDelayedExpansion

if "%~1"=="" (
    echo USAGE: call "%~f0" "FULL_PATH_TO_ACCEPTED_STAGE_1C_REPOSITORY_ROOT"
    exit /b 2
)

set "delivery_root=%~dp0"
set "repo_root=%~f1"
set "patch_file=%delivery_root%Deblock4_Stage_1C1_Rider_Using_Echo_existing_files_v1_1.patch"

if not exist "%repo_root%\.git" (
    echo ERROR: repository root does not contain .git: "%repo_root%"
    exit /b 1
)
if not exist "%patch_file%" (
    echo ERROR: delivery patch missing: "%patch_file%"
    exit /b 1
)

cd /d "%repo_root%" || exit /b 1
set "branch="
for /f "delims=" %%B in ('git branch --show-current') do set "branch=%%B"
if /I not "!branch!"=="main" (
    echo ERROR: expected branch main, found "!branch!".
    exit /b 1
)

rem Fail closed only on the twelve rider target paths. Unrelated W3X cleanup or
rem working-tree choices elsewhere are outside this delivery contract.
call :require_sha256 "build.zig" "616bcae1a330b3b076754fedf570c78bb40f921c0f9f7775978115b547a3201f" "accepted Stage 1C base"
if errorlevel 1 exit /b 1
call :require_sha256 "build_1C_v1.bat" "6220356fbe842e1b86372779fb6a4c455b63f24b1920502fe5961abc753b8332" "accepted Stage 1C base"
if errorlevel 1 exit /b 1
call :require_sha256 "src\classic_frame_properties.zig" "5a03db0f7ef82244a80c77c29d2912036538a9a1f8b880b7bc490658d044e5ad" "accepted Stage 1C base"
if errorlevel 1 exit /b 1
call :require_sha256 "src\classic_instance_creation.zig" "cee6d3ab37dd27be2959ea278ea93184e04deb0309f40a6634760b46a2649af5" "accepted Stage 1C base"
if errorlevel 1 exit /b 1
call :require_sha256 "src\classic_instance_data.zig" "382a4c87b85bbc71acbeb7bb7f1741c777ecfc7b56caf0a8cf8bf6e4b602f56e" "accepted Stage 1C base"
if errorlevel 1 exit /b 1
call :require_sha256 "src\deblock4_frame_properties.zig" "a72ed0189839a0b46a8c200325cd43a2da73d0ce3c7247e45760e22233e81999" "accepted Stage 1C base"
if errorlevel 1 exit /b 1
call :require_sha256 "src\deblock4_instance_creation.zig" "733919e0c8778ec4456983bfced80d5feb5bebb1d49a20bd514d0c1a3608db70" "accepted Stage 1C base"
if errorlevel 1 exit /b 1
call :require_sha256 "src\deblock4_instance_data.zig" "6b33ce7c83bdb790ced16ec560686af26e7cd7c4429d9ef58b18a11c84a15897" "accepted Stage 1C base"
if errorlevel 1 exit /b 1
call :require_sha256 "src\print_helper_functions.zig" "a30ab4a0912c0a7891662bdfed5d0b424c8641b91a1cf76cfad787d4ee84a77d" "accepted Stage 1C base"
if errorlevel 1 exit /b 1
if exist "src\effective_invocation_text.zig" (echo ERROR: delivery-owned new path already exists: "src\effective_invocation_text.zig" & exit /b 1)
if exist "tests\stage_1c_classic_passthrough.vpy" (echo ERROR: delivery-owned new path already exists: "tests\stage_1c_classic_passthrough.vpy" & exit /b 1)
if exist "tests\stage_1c_deblock4_passthrough.vpy" (echo ERROR: delivery-owned new path already exists: "tests\stage_1c_deblock4_passthrough.vpy" & exit /b 1)

for %%F in (
    "new_files\src\effective_invocation_text.zig"
    "new_files\tests\stage_1c_classic_passthrough.vpy"
    "new_files\tests\stage_1c_deblock4_passthrough.vpy"
) do if not exist "%delivery_root%%%~F" (
    echo ERROR: complete delivery file missing: "%delivery_root%%%~F"
    exit /b 1
)

echo === Pre-apply working tree status
git status --short
if errorlevel 1 exit /b 1

echo === Check existing-file patch
git -c core.whitespace=cr-at-eol apply --check "!patch_file!"
if errorlevel 1 exit /b 1

echo === Check existing-file patch with whitespace errors enabled
git -c core.whitespace=cr-at-eol apply --check --whitespace=error "!patch_file!"
if errorlevel 1 exit /b 1

echo === Apply existing-file patch
git -c core.whitespace=cr-at-eol apply "!patch_file!"
if errorlevel 1 exit /b 1

echo === Install three complete delivery-owned new files
if not exist "%delivery_root%new_files\src\effective_invocation_text.zig" (echo ERROR: complete delivery file missing: "%delivery_root%new_files\src\effective_invocation_text.zig" & exit /b 1)
for %%D in ("src\effective_invocation_text.zig") do if not exist "%%~dpD" mkdir "%%~dpD"
copy /Y "%delivery_root%new_files\src\effective_invocation_text.zig" "src\effective_invocation_text.zig" >nul
if errorlevel 1 exit /b 1
fc /B "%delivery_root%new_files\src\effective_invocation_text.zig" "src\effective_invocation_text.zig" >nul
if errorlevel 1 (echo ERROR: installed bytes do not match delivery for "src\effective_invocation_text.zig" & exit /b 1)

if not exist "%delivery_root%new_files\tests\stage_1c_classic_passthrough.vpy" (echo ERROR: complete delivery file missing: "%delivery_root%new_files\tests\stage_1c_classic_passthrough.vpy" & exit /b 1)
for %%D in ("tests\stage_1c_classic_passthrough.vpy") do if not exist "%%~dpD" mkdir "%%~dpD"
copy /Y "%delivery_root%new_files\tests\stage_1c_classic_passthrough.vpy" "tests\stage_1c_classic_passthrough.vpy" >nul
if errorlevel 1 exit /b 1
fc /B "%delivery_root%new_files\tests\stage_1c_classic_passthrough.vpy" "tests\stage_1c_classic_passthrough.vpy" >nul
if errorlevel 1 (echo ERROR: installed bytes do not match delivery for "tests\stage_1c_classic_passthrough.vpy" & exit /b 1)

if not exist "%delivery_root%new_files\tests\stage_1c_deblock4_passthrough.vpy" (echo ERROR: complete delivery file missing: "%delivery_root%new_files\tests\stage_1c_deblock4_passthrough.vpy" & exit /b 1)
for %%D in ("tests\stage_1c_deblock4_passthrough.vpy") do if not exist "%%~dpD" mkdir "%%~dpD"
copy /Y "%delivery_root%new_files\tests\stage_1c_deblock4_passthrough.vpy" "tests\stage_1c_deblock4_passthrough.vpy" >nul
if errorlevel 1 exit /b 1
fc /B "%delivery_root%new_files\tests\stage_1c_deblock4_passthrough.vpy" "tests\stage_1c_deblock4_passthrough.vpy" >nul
if errorlevel 1 (echo ERROR: installed bytes do not match delivery for "tests\stage_1c_deblock4_passthrough.vpy" & exit /b 1)

rem Byte-verify the complete integrated result.
call :require_sha256 "build.zig" "d25e1920ff3664bcf3156e353fd3da1c51ea141bfa8391f957143ceee13978ca" "Stage 1C.1 v1.1 result"
if errorlevel 1 exit /b 1
call :require_sha256 "build_1C_v1.bat" "d37ec0e0755574d7f5f023ad4656cf637b34108854c23d24a3e9e47e8f90ee39" "Stage 1C.1 v1.1 result"
if errorlevel 1 exit /b 1
call :require_sha256 "src\classic_frame_properties.zig" "d6ca49b3a74f1488d96412ade8f6dbc5526004c62f564bd0bbbbf2b929a207e5" "Stage 1C.1 v1.1 result"
if errorlevel 1 exit /b 1
call :require_sha256 "src\classic_instance_creation.zig" "8baf6922bee9aa151d36d41b4bd5d595dac226133a6861baa06a8e84f84307ca" "Stage 1C.1 v1.1 result"
if errorlevel 1 exit /b 1
call :require_sha256 "src\classic_instance_data.zig" "aface41404d2b7ea7a0b767f09b10069bcc80f17fc3ccb52d7614423da0d93fd" "Stage 1C.1 v1.1 result"
if errorlevel 1 exit /b 1
call :require_sha256 "src\deblock4_frame_properties.zig" "e27c1d019fb21a9de756dcc9b391b6b2992007b3f1d37af5cb48909a5bdfd114" "Stage 1C.1 v1.1 result"
if errorlevel 1 exit /b 1
call :require_sha256 "src\deblock4_instance_creation.zig" "d4aa6e0c4c9295a7955d90e4ce0ad1e1a83f5758efad231f5bf64c8672f925fb" "Stage 1C.1 v1.1 result"
if errorlevel 1 exit /b 1
call :require_sha256 "src\deblock4_instance_data.zig" "8db168f00708ccdf04ce12f757a94202ed27219f84a24016f3f2f793e07de34c" "Stage 1C.1 v1.1 result"
if errorlevel 1 exit /b 1
call :require_sha256 "src\print_helper_functions.zig" "2db78f6c6d91c419da7e16e6928e385978e481ec4efced3ee64e8e0203ae57c9" "Stage 1C.1 v1.1 result"
if errorlevel 1 exit /b 1
call :require_sha256 "src\effective_invocation_text.zig" "4cb12f1e0386c7d1039ac1ac23d152592f98b2d17d880c3d1ffa07743aee7bde" "Stage 1C.1 v1.1 result"
if errorlevel 1 exit /b 1
call :require_sha256 "tests\stage_1c_classic_passthrough.vpy" "4559a62fc0f20f9affc43835f783cdc604ab65b2653f5278b57fdb18f5d33ddd" "Stage 1C.1 v1.1 result"
if errorlevel 1 exit /b 1
call :require_sha256 "tests\stage_1c_deblock4_passthrough.vpy" "aca4b20f1a7d3b68052994d748915c54168282ccdf8e4781470eaea6d8900c7e" "Stage 1C.1 v1.1 result"
if errorlevel 1 exit /b 1

findstr /C:"pub const capacity: usize = 512;" "src\effective_invocation_text.zig" >nul || (echo ERROR: fixed-capacity using value missing & exit /b 1)
findstr /C:"Deblock4Using" "src\classic_frame_properties.zig" >nul || (echo ERROR: Classic Deblock4Using property missing & exit /b 1)
findstr /C:"Deblock4Using" "src\deblock4_frame_properties.zig" >nul || (echo ERROR: Deblock4 Deblock4Using property missing & exit /b 1)
findstr /C:"valid_coercion" "tests\stage_1c_classic_passthrough.vpy" >nul || (echo ERROR: valid_coercion harness case missing & exit /b 1)
findstr /C:"using line occurs once" "build_1C_v1.bat" >nul || (echo ERROR: success-line count assertion missing & exit /b 1)
findstr /C:"emits no using line" "build_1C_v1.bat" >nul || (echo ERROR: failure-absence assertion missing & exit /b 1)

git -c core.whitespace=cr-at-eol diff --check
if errorlevel 1 exit /b 1

echo ================================================================
echo STAGE 1C.1 USING-ECHO DELIVERY V1.1 INSTALLED
echo Existing files changed by reviewed patch:
echo   build.zig
echo   build_1C_v1.bat
echo   src\classic_frame_properties.zig
echo   src\classic_instance_creation.zig
echo   src\classic_instance_data.zig
echo   src\deblock4_frame_properties.zig
echo   src\deblock4_instance_creation.zig
echo   src\deblock4_instance_data.zig
echo   src\print_helper_functions.zig
echo Complete new delivery-owned files installed:
echo   src\effective_invocation_text.zig
echo   tests\stage_1c_classic_passthrough.vpy
echo   tests\stage_1c_deblock4_passthrough.vpy
echo No Stage 2C/2D, pixel, dispatch, registration, validation, or G10 change.
echo ================================================================

call "build_1C_v1.bat"
set "proof_code=!ERRORLEVEL!"
if not "!proof_code!"=="0" exit /b !proof_code!

git -c core.whitespace=cr-at-eol diff --check
if errorlevel 1 exit /b 1

if exist "zig-out\inspection_1C\build_1C_v1_full_output.log" (
    copy /Y "zig-out\inspection_1C\build_1C_v1_full_output.log" "%delivery_root%W3X_validation_artifacts\build_1C_v1_full_output.log" >nul
)
if exist "zig-out\inspection_1C\proof_matrix_summary.txt" (
    copy /Y "zig-out\inspection_1C\proof_matrix_summary.txt" "%delivery_root%W3X_validation_artifacts\proof_matrix_summary.txt" >nul
)

echo ================================================================
echo POST-VALIDATION STATUS
echo ================================================================
git status --short
if errorlevel 1 exit /b 1

echo ================================================================
echo STAGE 1C.1 V1.1 VALIDATION COMPLETED SUCCESSFULLY
echo W3D ARTIFACT REVIEW AND W3X ACCEPTANCE ARE STILL REQUIRED
echo ================================================================
exit /b 0

:require_sha256
set "hash_file=%~1"
set "expected_hash=%~2"
set "state_label=%~3"
if not exist "!hash_file!" (
    echo ERROR: required !state_label! file missing: "!hash_file!"
    exit /b 1
)
set "observed_hash="
for /f "usebackq delims=" %%H in (`powershell -NoProfile -Command "(Get-FileHash -Algorithm SHA256 -LiteralPath '%~1').Hash"`) do set "observed_hash=%%H"
if /I not "!observed_hash!"=="!expected_hash!" (
    echo ERROR: SHA-256 precondition failed for "!hash_file!".
    echo State: !state_label!
    echo Expected: !expected_hash!
    echo Observed: !observed_hash!
    exit /b 1
)
exit /b 0
