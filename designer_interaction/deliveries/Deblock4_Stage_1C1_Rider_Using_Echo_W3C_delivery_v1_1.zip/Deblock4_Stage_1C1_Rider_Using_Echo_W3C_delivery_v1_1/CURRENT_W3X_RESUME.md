# CURRENT W3X RESUME - Stage 1C.1 Using Echo delivery v1.1

1. Delivery v1.1 replaces v1.0. Do not use v1.0.
2. Restore only the twelve rider target paths to the accepted Stage 1C base
   before running if an earlier trial changed them.
3. Unrelated W3X cleanup elsewhere is not part of the delivery precondition.
4. Run `apply_and_validate_stage_1c1_using_echo_v1_1.bat` with the repository root as its only argument.
5. Do not hand-edit a failed patch or bypass a hash/apply/whitespace gate.
6. Return the complete console output, final exit code, final `git status
   --short`, and populated validation artifacts to W3C/W3D.
7. Stage 2C/2D and all other work remain unstarted.
