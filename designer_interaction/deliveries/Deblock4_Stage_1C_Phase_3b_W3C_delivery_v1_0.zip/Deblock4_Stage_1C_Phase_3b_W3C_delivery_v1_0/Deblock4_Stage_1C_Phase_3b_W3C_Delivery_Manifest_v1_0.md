# Deblock4 Stage 1C Phase 3b - W3C Delivery Manifest

**Version:** 1.0
**Date:** 2026-08-02
**Author:** W3C
**Status:** Final integrated Phase 3b delivery candidate for W3D review and W3X validation/acceptance.
**Repository:** `hydra3333/vapoursynth-Deblock4`
**Branch:** `main`
**Encoding:** US-ASCII. Repository text files are CRLF; delivery-only patch transport may use its generated mixed/LF header form.

## 1. Exact base and scope

**Scope:** Stage 1C Phase 3b - retire the verified scaffolding, install the permanent production build/proof surface, execute the complete Scope v1.5 proof matrix, and close Stage 1C without activating pixel/deblocking algorithms.

**Exact source base alternative:** the accepted and committed Phase 3a source state reconstructed byte-for-byte from:

- `src(42).zip`, SHA-256 `ac2aa4c494e7a2312cea2af2e85ffae9fa7c0049e9ea15942dc9a6730955c29f`;
- `Deblock4_Stage_1C_Phase_3a_W3C_delivery_v1_0.zip`, SHA-256 `45c73f42e6034c6c5178e8a4d11ded17c577570d79c8a6979398cd4c2f022d0e`;
- W3X's recorded Phase 3a acceptance, commit and push.

No commit hash is inferred. The charter's exact attached-source-tree alternative is used.

## 2. Adds or changes

- replaces the probe-era `build.zig` with the permanent Stage 1C DLL/selftest/test/inspection graph;
- adds `build_1C_v1.bat`, implementing B1/B2/G1/G2/E1-E6/V1/S1-S3/N1 and retained detector-drift evidence;
- extends the first-class selftest with Stage 1C pure tier/parameter contracts;
- adds both binding BlankClip `.vpy` e2e harnesses;
- converts the remaining retained LF text files to repository-standard CRLF;
- retires the exact Scope v1.5 scaffolding list;
- includes the P4 creation-error message-table draft for W3D review and W3X ratification.

## 3. Defers or does not change

- no Classic or Deblock4 pixel/deblocking algorithm is implemented;
- no real v2/v3 algorithm backend executes;
- the accepted Phase 3a frame path, ownership, registration, configuration, tier selection and lifecycle behaviour are not redesigned;
- no Stage 2C/2D oracle work begins;
- P4 remains a review draft until W3X ratifies it.

## 4. Delivery form by file

The charter's one-form-per-file rule is observed.

### Complete new/replacement files

- `build.zig` - complete whole file; US-ASCII/CRLF.
- `build.zig.zon` - complete whole file; US-ASCII/CRLF.
- `build_1C_v1.bat` - complete whole file; US-ASCII/CRLF.
- `src/deblock4_selftest.zig` - complete whole file; US-ASCII/CRLF.
- `tests/stage_1c_classic_passthrough.vpy` - complete whole file; US-ASCII/CRLF.
- `tests/stage_1c_deblock4_passthrough.vpy` - complete whole file; US-ASCII/CRLF.
- `third_party/vapoursynth/include/VSConstants4.h` - complete whole file; US-ASCII/CRLF.
- `third_party/vapoursynth/include/VSHelper4.h` - complete whole file; US-ASCII/CRLF.
- `third_party/vapoursynth/include/VSScript4.h` - complete whole file; US-ASCII/CRLF.
- `third_party/vapoursynth/include/VapourSynth4.h` - complete whole file; US-ASCII/CRLF.
- `tools/run_vs.cmd` - complete whole file; US-ASCII/CRLF.

### Deletions

`Deblock4_Stage_1C_Phase_3b_scaffolding_deletions_v1_0.patch` is a deletion-only unified diff prepared against the exact Phase 3a base. It deletes:

- `build_1B1_v7_3.bat`
- `build_1B2_v5_REDEVELOPED.bat`
- `build_1B3_v5.bat`
- `src/backend_isolation_smoke_test.zig`
- `src/backend_probe_avx2.zig`
- `src/backend_probe_generic.zig`
- `src/backend_probe_scalar.zig`
- `src/backend_probe_sse41.zig`
- `src/backend_retention_anchor.zig`
- `src/build_probe.zig`
- `src/dll_probe.zig`
- `src/dll_smoke_test.zig`
- `src/vapoursynth_header_probe.zig`

No modified or new file is also present in the patch.

## 5. Apply sequence

Preferred mechanical application:

```bat
call "<EXTRACTED_DELIVERY>\apply_phase3b_and_validate.bat" "<REPOSITORY_ROOT>"
```

The helper requires branch `main` and a clean working tree, applies the deletion-only patch directly from the extracted delivery, copies the complete files, runs the CRLF-aware diff gate, and calls the permanent `build_1C_v1.bat` proof runner.

Do not edit a failed patch or failed full-file copy in place. Stop and report the first failure.

## 6. Required validation and expected result

W3X runs:

```bat
call build_1C_v1.bat
```

The authoritative success terminus is:

```text
STAGE 1C_v1 FULL PROOF MATRIX COMPLETED SUCCESSFULLY
```

Expected proof summary:

```text
B1 B2 G1 G2 E1 E2 E3 E4 E5 E6 V1 S1 S2 S3 N1 PASS
```

The batch covers Debug, ReleaseSafe and ReleaseFast builds/tests/selftests/e2e; all three G10 seams; export/raw/disassembly gates; properties and checksums; force-down and explicit-backend cases; full-signature refusals; lifecycle trace; version single-home; structural/symbol/runtime no-per-frame-selection; exact sweep; zero-LF repository text; target/CPU rejection; and 9/9 non-Debug debug-option rejection.

Zig's known `--listen` `failed command:` context can appear when a passing test writes expected stderr. Exit codes, Zig summaries, explicit assertions and the final success terminus are authoritative.

## 7. Review notes

- Debug positive controls use seam-unique raw strings and machine-code immediates. G2 separately requires every gated marker function name to remain absent from the linked DLL export table; linked-PE COFF symbol retention is not an acceptance dependency.
- S1 symbol evidence uses stable router/ar_* object files, where `dumpbin /SYMBOLS` is authoritative.
- The wrong-type `.vpy` case is normally rejected by VapourSynth's registered signature before callback entry. The harness requires the filter name, argument name and expected type and records the full host diagnostic; the P4 draft makes this ownership boundary explicit.
- W3C performed static/integration validation only. W3X's Windows VS2026/Zig 0.16/VapourSynth run, W3D artifact review, W3C concurrence and W3X acceptance remain mandatory.

## 8. Expected repository status after application and validation

Exactly the eleven added/replaced paths and thirteen deleted paths listed above should appear. `zig-out` and `.zig-cache` evidence must remain ignored. The delivery patch and delivery directory remain outside the repository and must not appear in `git status`.
