# Stage 1C Phase 3b - Apply and Validate

Extract this delivery outside the repository. From any command prompt, run:

```bat
call "<EXTRACTED_DELIVERY>\apply_phase3b_and_validate.bat" "<REPOSITORY_ROOT>"
```

The helper is fail-closed. It verifies branch `main` and a clean working tree, checks and applies the deletion-only patch, copies every complete file, runs `git -c core.whitespace=cr-at-eol diff --check`, and then runs `build_1C_v1.bat`.

The deletion patch is never copied into the repository, so the S3 zero-LF audit cannot be contaminated by a delivery transport artifact.

## Expected success

The proof runner must exit zero and print:

```text
STAGE 1C_v1 FULL PROOF MATRIX COMPLETED SUCCESSFULLY
B1 B2 G1 G2 E1 E2 E3 E4 E5 E6 V1 S1 S2 S3 N1 PASS
```

Evidence is retained under `zig-out\inspection_1C`. W3D must independently review the raw binaries, exports, disassembly, e2e output/properties, lifecycle traces, sweep and S1 evidence. The batch does not self-accept Stage 1C.

A `failed command: ... --listen=-` line is not by itself a failure. Use the child/outer exit codes, Zig summary assertions, the diagnostic index and the explicit success terminus.

## Commit hygiene after acceptance

Commit the source/build/test changes and deletions only. Do not commit `zig-out`, `.zig-cache`, extracted delivery files, or the deletion patch. The P4 table is a delivery-review artifact unless W3X separately directs its repository placement.
