# W3C Static Validation - Stage 1C.1 Using Echo v1.0

The package was reconstructed and checked in a clean local Git clone of the
accepted attached-source base.

```text
expected changed paths: PASS
all binding v1.1 literals exact: PASS
Python .vpy syntax: PASS
US-ASCII repository files: PASS
CRLF repository files: PASS
git apply --check: PASS
git apply --check --whitespace=error: PASS
git diff --check: PASS
new-file byte equality: PASS
final changed-file SHA-256 equality: PASS
import-cycle scan: PASS
```

The sandbox does not contain the pinned Windows Zig/Visual Studio/VapourSynth
toolchain. No build, runtime, dumpbin or full-matrix PASS is claimed here.
