# W3X validation artifacts

The apply helper copies `build_1C_v1_full_output.log` and
`proof_matrix_summary.txt` here after a successful authoritative run. These
files are intentionally absent from the pre-run delivery ZIP.
