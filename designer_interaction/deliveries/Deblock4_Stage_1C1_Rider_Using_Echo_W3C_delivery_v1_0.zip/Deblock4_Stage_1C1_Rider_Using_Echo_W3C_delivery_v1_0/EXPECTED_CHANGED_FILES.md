# Expected Changed Files - Stage 1C.1 Using Echo v1.0

After application, `git status --short` should include exactly these rider
paths, plus any unrelated pre-existing W3X changes that were already present:

```text
 M build.zig
```
```text
 M build_1C_v1.bat
```
```text
 M src/classic_frame_properties.zig
```
```text
 M src/classic_instance_creation.zig
```
```text
 M src/classic_instance_data.zig
```
```text
 M src/deblock4_frame_properties.zig
```
```text
 M src/deblock4_instance_creation.zig
```
```text
 M src/deblock4_instance_data.zig
```
```text
 M src/print_helper_functions.zig
```
```text
 M tests/stage_1c_classic_passthrough.vpy
```
```text
 M tests/stage_1c_deblock4_passthrough.vpy
```
```text
?? src/effective_invocation_text.zig
```

The new file may appear as `A` instead of `??` after W3X stages it. No Stage
2C/2D, G10, registration, validation, router, or version file belongs to this
delivery.
