# Deblock4 Stage 1C Phase 3a W3C Delivery Manifest

Version: v1.0
Date: 2026-08-01
Status: W3C DELIVERY FOR W3D REVIEW AND W3X BUILD/TEST
Encoding: US-ASCII
Repository file EOL: CRLF

## Authority and base

```text
Repository: hydra3333/vapoursynth-Deblock4
Branch: main
Scope: Deblock4_Scope_Stage_1C_Filter_Creation_v1_5.md
Delivery order: Deblock4_Stage_1C_Delivery_Plan_Addendum_v1_1.md
W3X ruling: Phase 3 split into 3a and 3b; Phase 3a released.
Prevailing source: src(42).zip
src(42).zip SHA-256:
ac2aa4c494e7a2312cea2af2e85ffae9fa7c0049e9ea15942dc9a6730955c29f
```

## Objective

Deliver the working Stage 1C frame path and real plugin registration while
preserving the permanent Phase 2 activation switch. The settled C5 sequence is:

```text
obtain requested source frame
-> switch on immutable selected tier
-> produce final writable pass-through frame
-> annotate that final frame
-> return it
```

Lifecycle tracing is authored in Phase 3a with the lifecycle and C5 paths. Its
release-absence proof remains Phase 3b.

## Adds or changes

```text
P3A-01  Add per-filter arInitial handlers.
P3A-02  Add per-filter arAllFramesReady handlers in binding C5 order.
P3A-03  Fill the existing router branch bodies without restructuring either
         activation-reason switch.
P3A-04  Add filter-neutral frame mechanics and common arError handling.
P3A-05  Add filter-neutral property write helpers and per-filter property
         policies.
P3A-06  Add the real thin deblock4_plugin registration root.
P3A-07  Add the lifecycle trace seam, including one-line full resolved
         creation configuration, getFrame enter/exit, and free events.
P3A-08  Extend the existing C bridge for copyFrame, frame properties, filter
         errors, configPlugin, and registerFunction.
P3A-09  Correct each create callback to the exact VSPublicFunction C-ABI
         boundary, then immediately rebind to idiomatic locals. The existing
         map-read, validation, selection, allocation, and createVideoFilter
         body remains unchanged; only trace calls are inserted around it.
P3A-10  Route the existing always-on summary version through the single-homed
         deblock4_version identity.
```

## Defers or does not change

```text
- No scaffolding sweep or file retirement.
- No build.zig or build.zig.zon transformation.
- No build_1C_v1.bat.
- No permanent .vpy harnesses.
- No full B/G/E/S/V/N proof matrix.
- No ReleaseSafe/ReleaseFast lifecycle absence proof.
- No real Classic or Deblock4 pixel algorithm.
- No Phase 2 tier-selection, parameter-validation, or immutable-instance
  redesign.
- No activation-switch restructuring.
```

## Files and delivery form

### New complete repository files

```text
src/classic_ar_initial.zig
src/deblock4_ar_initial.zig
src/classic_ar_all_frames_ready.zig
src/deblock4_ar_all_frames_ready.zig
src/common_ar_error.zig
src/common_frame_mechanics.zig
src/common_frame_property_helpers.zig
src/classic_frame_properties.zig
src/deblock4_frame_properties.zig
src/deblock4_plugin.zig
src/lifecycle_trace_debug.zig
```

They are supplied as complete files under `full_files/src`.

### Existing repository files changed by patch

```text
src/classic_callback_router.zig
src/deblock4_callback_router.zig
src/classic_instance_creation.zig
src/deblock4_instance_creation.zig
src/deblock4_config.zig
src/vapoursynth_api4.h
src/vapoursynth_helper_bridge.c
```

Patch:

```text
Deblock4_Stage_1C_Phase_3a_existing_edits_v1_0.patch
```

### Validation-only files

```text
validation_support_3a/build_1c3a_phase3a_validation.bat
validation_support_3a/build_phase3a_validation.zig
validation_support_3a/phase3a_plugin_graph_root.zig
validation_support_3a/phase3a_smoke.c
```

The temporary root is copied to
`src/__phase3a_validation_plugin_root.zig` only during validation and is removed
on both success and failure.

## Principal review points

### Permanent router switch

Each router retains exactly one case for:

```text
arInitial
arAllFramesReady
arError
```

Phase 3a changes only the branch targets and surrounding lifecycle trace calls.
The switch itself is not redesigned.

### Frame ownership

```text
arInitial requests source frame n.
arAllFramesReady obtains that requested source frame.
The source frame is released on every path after acquisition.
copyFrame creates the writable final output.
Property failure releases the writable output and returns an error.
Successful return transfers the writable output frame to VapourSynth.
```

### No per-frame tier selection

The frame path reads only
`instance.common.backend_selection.selected_tier`. Router and activation
modules contain no imports or references to CPU detection, backend selection,
force-down, or the environment.

### Create boundary-only correction

The two `create` callbacks now match translated `VSPublicFunction` C-ABI pointer
forms. Each callback performs null checks and local rebinding at the top. The
existing parsing, validation, selection, allocation, and filter-construction
logic is unchanged. Lifecycle enter/exit calls are the only additions within
the creation flow. The creation-exit trace occurs before ownership of the
instance is passed to `createVideoFilter`.

### Lifecycle trace

The trace module is reachable only through source-visible conditional imports.
It hard-rejects non-Debug compilation when enabled and contains a loud string
and code marker. Creation exit records the complete immutable configuration on
one physical line, including source format/dimensions, plane request, strength,
offsets, backend request, selected tier, provenance, grid, steps, and midpoint
state where applicable.

## Apply sequence

Use `APPLY_AND_VALIDATE.md` or call:

```bat
call "<EXTRACTED_DELIVERY>\apply_phase3a_and_validate.bat" "<REPOSITORY_ROOT>"
```

The helper performs the patch checks, patch application, complete-file copies,
whitespace checks, validation-support installation, validation run, temporary-
root cleanup check, and final status report. It is fail-closed and does not use
`xcopy /C`.

## Validation commands

The delivered batch runs:

```bat
zig build --build-file validation_support_3a\build_phase3a_validation.zig phase3a-test -Doptimize=Debug -Denable_trace_lifecycle=true
zig build --build-file validation_support_3a\build_phase3a_validation.zig phase3a-test -Doptimize=ReleaseSafe -Denable_trace_lifecycle=false
zig build --build-file validation_support_3a\build_phase3a_validation.zig phase3a-test -Doptimize=ReleaseFast -Denable_trace_lifecycle=false
zig build selftest -Doptimize=Debug
zig build selftest -Doptimize=ReleaseSafe
zig build selftest -Doptimize=ReleaseFast
git -c core.whitespace=cr-at-eol diff --check
git status --short
```

For each mode the validation graph compiles the actual `deblock4_plugin.zig`
root as a Windows DLL. The single-root smoke separately verifies:

```text
configPlugin identity, namespace, display name, packed version, API version
exact Classic and Deblock4 registration signatures
real create callback C-ABI compatibility
fmParallel and rpStrictSpatial creation wiring
arInitial request
arAllFramesReady C5 pass-through copy
common and per-filter frame properties
arError null return
source-frame and node teardown
```

## W3C sandbox validation

```text
PASS  patch applies to src(42).zip source
PASS  git apply --check
PASS  git apply --check --whitespace=error-all
PASS  git diff --check
PASS  patched existing files equal reviewed files byte-for-byte
PASS  all repository source files in this delivery are US-ASCII and CRLF
PASS  C bridge syntax check with clang -std=c11
PASS  C smoke syntax check with clang -std=c11
PASS  permanent three-case router structure scan
PASS  C5 obtain/switch/property/return ordering scan
PASS  no frame-path detection/selection/environment references
PASS  no Phase 3b production artifacts or deletions
SKIP  Zig 0.16.0 compile/run in W3C sandbox; W3X is authoritative
```

## Expected W3X result

```text
Debug       Phase 3a DLL compile and smoke PASS with lifecycle trace
ReleaseSafe Phase 3a DLL compile and smoke PASS without lifecycle trace
ReleaseFast Phase 3a DLL compile and smoke PASS without lifecycle trace
All three existing selftest regression builds PASS
No temporary src/__phase3a_validation_plugin_root.zig remains
git diff --check PASS
batch exit code 0
PHASE 3A VALIDATION COMPLETED SUCCESSFULLY
```

Stop after Phase 3a reporting. W3X alone accepts Phase 3a and releases Phase 3b.
