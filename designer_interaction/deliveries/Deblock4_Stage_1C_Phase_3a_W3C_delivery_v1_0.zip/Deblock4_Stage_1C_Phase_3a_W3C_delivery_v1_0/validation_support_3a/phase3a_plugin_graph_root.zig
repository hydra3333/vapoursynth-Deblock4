// Validation-only Stage 1C Phase 3a single-root graph.
const std = @import("std");
const plugin = @import("deblock4_plugin.zig");

comptime {
    _ = &plugin.VapourSynthPluginInit2;
}

extern fn phase3a_run_smoke() callconv(.c) c_int;

test "Phase 3a plugin registration, C5 pass-through, properties, and teardown" {
    try std.testing.expectEqual(@as(c_int, 0), phase3a_run_smoke());
}
