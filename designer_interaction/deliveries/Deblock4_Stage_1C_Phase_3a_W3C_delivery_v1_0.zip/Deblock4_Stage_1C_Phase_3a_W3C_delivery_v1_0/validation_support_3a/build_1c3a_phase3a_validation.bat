@echo off
setlocal EnableExtensions EnableDelayedExpansion
for %%I in ("%~dp0..") do set "repo_root=%%~fI"
set "temporary_root=%repo_root%\src\__phase3a_validation_plugin_root.zig"
cd /d "%repo_root%" || exit /b 1
if exist "%temporary_root%" (
    echo ERROR: temporary Phase 3a validation root already exists.
    exit /b 1
)
copy /Y "%repo_root%\validation_support_3a\phase3a_plugin_graph_root.zig" "%temporary_root%" >nul
if errorlevel 1 goto :failure
call :remove_tree "%repo_root%\.zig-cache"
if errorlevel 1 goto :failure
call :remove_tree "%repo_root%\zig-out"
if errorlevel 1 goto :failure
call :remove_tree "%repo_root%\validation_support_3a\.zig-cache"
if errorlevel 1 goto :failure
call :remove_tree "%repo_root%\validation_support_3a\zig-out"
if errorlevel 1 goto :failure

echo ================================================================
echo Phase 3a Debug compile + smoke with lifecycle trace
echo ================================================================
zig build --build-file validation_support_3a\build_phase3a_validation.zig phase3a-test -Doptimize=Debug -Denable_trace_lifecycle=true
if errorlevel 1 goto :failure

for %%O in (ReleaseSafe ReleaseFast) do (
    echo ================================================================
    echo Phase 3a compile + smoke: %%O
    echo ================================================================
    zig build --build-file validation_support_3a\build_phase3a_validation.zig phase3a-test -Doptimize=%%O -Denable_trace_lifecycle=false
    if errorlevel 1 goto :failure
)

for %%O in (Debug ReleaseSafe ReleaseFast) do (
    echo ================================================================
    echo Existing selftest regression: %%O
    echo ================================================================
    zig build selftest -Doptimize=%%O
    if errorlevel 1 goto :failure
)
call :remove_temporary_root
if errorlevel 1 exit /b 1
git -c core.whitespace=cr-at-eol diff --check
if errorlevel 1 exit /b 1
git status --short
if errorlevel 1 exit /b 1
echo ================================================================
echo PHASE 3A VALIDATION COMPLETED SUCCESSFULLY
echo ================================================================
exit /b 0

:failure
set "validation_error=%errorlevel%"
if "%validation_error%"=="0" set "validation_error=1"
call :remove_temporary_root >nul 2>&1
exit /b %validation_error%

:remove_temporary_root
if not exist "%temporary_root%" exit /b 0
del /f /q "%temporary_root%"
if exist "%temporary_root%" exit /b 1
exit /b 0

:remove_tree
if not exist "%~1" exit /b 0
rmdir /s /q "%~1"
if exist "%~1" exit /b 1
exit /b 0
