const std = @import("std");

pub fn build(b: *std.Build) void {
    const target = b.resolveTargetQuery(.{
        .cpu_arch = .x86_64,
        .cpu_model = .{ .explicit = &std.Target.x86.cpu.x86_64 },
        .os_tag = .windows,
        .abi = .msvc,
    });
    const optimize = b.standardOptimizeOption(.{});
    const trace = b.option(
        bool,
        "enable_trace_lifecycle",
        "Enable Debug lifecycle trace",
    ) orelse false;

    const runtime_options = b.addOptions();
    runtime_options.addOption(bool, "enable_force_down", false);
    runtime_options.addOption(bool, "enable_verbose_detection", false);
    runtime_options.addOption(bool, "enable_trace_lifecycle", trace);

    const translate = b.addTranslateC(.{
        .root_source_file = b.path("../src/vapoursynth_api4.h"),
        .target = target,
        .optimize = optimize,
    });
    translate.addIncludePath(b.path("../third_party/vapoursynth/include"));
    const vs_module = translate.createModule();

    // Compile the actual plugin root as a Windows DLL. This is a validation-
    // only build graph; Phase 3b owns the permanent repository build.zig.
    const dll_module = b.createModule(.{
        .root_source_file = b.path("../src/deblock4_plugin.zig"),
        .target = target,
        .optimize = optimize,
        .link_libc = true,
    });
    dll_module.addOptions("deblock4_build_options", runtime_options);
    dll_module.addImport("vapoursynth_api4", vs_module);
    dll_module.addIncludePath(b.path("../third_party/vapoursynth/include"));
    dll_module.addIncludePath(b.path("../src"));
    dll_module.addCSourceFile(.{
        .file = b.path("../src/vapoursynth_helper_bridge.c"),
        .flags = &.{"-std=c11"},
    });

    const dll = b.addLibrary(.{
        .name = "Deblock4_phase3a_validation",
        .linkage = .dynamic,
        .root_module = dll_module,
    });

    // The smoke uses a temporary source-tree root so both filter paths and
    // every shared relative import belong to one Zig module, matching the
    // topology of deblock4_plugin.zig.
    const smoke_module = b.createModule(.{
        .root_source_file = b.path("../src/__phase3a_validation_plugin_root.zig"),
        .target = target,
        .optimize = optimize,
        .link_libc = true,
    });
    smoke_module.addOptions("deblock4_build_options", runtime_options);
    smoke_module.addImport("vapoursynth_api4", vs_module);

    const tests = b.addTest(.{
        .name = "phase3a-single-root-smoke",
        .root_module = smoke_module,
    });
    tests.root_module.addIncludePath(b.path("../third_party/vapoursynth/include"));
    tests.root_module.addIncludePath(b.path("../src"));
    tests.root_module.addCSourceFile(.{
        .file = b.path("../src/vapoursynth_helper_bridge.c"),
        .flags = &.{"-std=c11"},
    });
    tests.root_module.addCSourceFile(.{
        .file = b.path("phase3a_smoke.c"),
        .flags = &.{"-std=c11"},
    });

    const check = b.step(
        "phase3a-check",
        "Compile the Stage 1C Phase 3a plugin DLL and smoke graph",
    );
    check.dependOn(&dll.step);
    check.dependOn(&tests.step);

    const run = b.addRunArtifact(tests);
    run.step.dependOn(&dll.step);
    const test_step = b.step(
        "phase3a-test",
        "Compile and run the Stage 1C Phase 3a smoke",
    );
    test_step.dependOn(&run.step);
}
