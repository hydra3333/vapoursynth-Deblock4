#include <stdint.h>
#include <string.h>
#include "vapoursynth_api4.h"

extern void VapourSynthPluginInit2(VSPlugin *, const VSPLUGINAPI *);

static unsigned char plugin_storage, input_map_storage, output_map_storage;
static unsigned char property_map_storage, node_storage, source_frame_storage;
static unsigned char output_frame_storage, frame_context_storage, core_storage;
static VSVideoInfo video_info;
static VSAPI api;
static VSPLUGINAPI plugin_api;
static VSPublicFunction classic_create;
static VSPublicFunction deblock4_create;
static int current_deblock4;
static int failure;
static int requested, obtained, copied, source_freed, node_freed;
static int common_filter, common_tier, common_version;
static int grid_mode, luma_x, luma_y, chroma_x, chroma_y, midpoint_seen;

static int same_bytes(const char *value, int size, const char *expected) {
    return size == (int)strlen(expected) && memcmp(value, expected, (size_t)size) == 0;
}

static int fake_config_plugin(const char *id, const char *ns, const char *name,
                              int version, int api_version, int flags,
                              VSPlugin *plugin) {
    if (strcmp(id, "com.hydra3333.deblock4") || strcmp(ns, "deblock4") ||
        strcmp(name, "Deblock4") || version != VS_MAKE_VERSION(0, 1) ||
        api_version != VAPOURSYNTH_API_VERSION || flags != 0 ||
        plugin != (VSPlugin *)&plugin_storage) failure = 1;
    return 1;
}

static int fake_register_function(const char *name, const char *args,
                                  const char *return_type,
                                  VSPublicFunction function, void *data,
                                  VSPlugin *plugin) {
    const char *classic_args =
        "clip:vnode;strength:int:opt;boundary_strength_offset:int:opt;"
        "side_activity_offset:int:opt;planes:int[]:opt;backend:data:opt;";
    const char *deblock4_args =
        "clip:vnode;grid_mode:data;strength:int:opt;"
        "boundary_strength_offset:int:opt;side_activity_offset:int:opt;"
        "planes:int[]:opt;midpoint_threshold_scale:float:opt;"
        "backend:data:opt;luma_step_x:int:opt;luma_step_y:int:opt;"
        "chroma_step_x:int:opt;chroma_step_y:int:opt;"
        "luma_midpoint_enabled:int:opt;";
    if (!function || !args || data != 0 || strcmp(return_type, "clip:vnode;") ||
        plugin != (VSPlugin *)&plugin_storage) failure = 1;
    if (!strcmp(name, "Classic")) {
        if (strcmp(args, classic_args)) failure = 1;
        classic_create = function;
    } else if (!strcmp(name, "Deblock4")) {
        if (strcmp(args, deblock4_args)) failure = 1;
        deblock4_create = function;
    }
    else failure = 1;
    return 1;
}

static int fake_map_num_elements(const VSMap *map, const char *key) {
    (void)map;
    if (current_deblock4 && !strcmp(key, "grid_mode")) return 1;
    return -1;
}
static int64_t fake_map_get_int(const VSMap *m,const char*k,int i,int*e){(void)m;(void)k;(void)i;*e=peType;return 0;}
static const int64_t *fake_map_get_int_array(const VSMap*m,const char*k,int*e){(void)m;(void)k;*e=peType;return 0;}
static double fake_map_get_float(const VSMap*m,const char*k,int i,int*e){(void)m;(void)k;(void)i;*e=peType;return 0;}
static const char *fake_map_get_data(const VSMap *m,const char *key,int i,int *e){
    (void)m;(void)i;
    if (current_deblock4 && !strcmp(key,"grid_mode")){*e=peSuccess;return "mpeg2_progressive";}
    *e=peType;return 0;
}
static int fake_map_get_data_size(const VSMap*m,const char*k,int i,int*e){const char*v=fake_map_get_data(m,k,i,e);return v?(int)strlen(v):0;}
static VSNode *fake_map_get_node(const VSMap*m,const char*k,int i,int*e){(void)m;if(!strcmp(k,"clip")&&i==0){*e=peSuccess;return(VSNode*)&node_storage;}*e=peUnset;return 0;}
static const VSVideoInfo *fake_get_video_info(VSNode*n){if(n!=(VSNode*)&node_storage)failure=1;return &video_info;}
static void fake_map_set_error(VSMap*m,const char*s){(void)m;(void)s;failure=1;}
static void fake_request_frame_filter(int n,VSNode*node,VSFrameContext*ctx){if(n!=7||node!=(VSNode*)&node_storage||ctx!=(VSFrameContext*)&frame_context_storage)failure=1;requested=1;}
static const VSFrame *fake_get_frame_filter(int n,VSNode*node,VSFrameContext*ctx){if(n!=7||node!=(VSNode*)&node_storage||ctx!=(VSFrameContext*)&frame_context_storage)failure=1;obtained=1;return(const VSFrame*)&source_frame_storage;}
static VSFrame *fake_copy_frame(const VSFrame*f,VSCore*c){if(f!=(const VSFrame*)&source_frame_storage||c!=(VSCore*)&core_storage)failure=1;copied=1;return(VSFrame*)&output_frame_storage;}
static void fake_free_frame(const VSFrame*f){if(f!=(const VSFrame*)&source_frame_storage)failure=1;source_freed++;}
static VSMap *fake_get_props_rw(VSFrame*f){if(f!=(VSFrame*)&output_frame_storage)failure=1;return(VSMap*)&property_map_storage;}
static void fake_set_filter_error(const char*m,VSFrameContext*c){(void)m;(void)c;failure=1;}
static void fake_free_node(VSNode*n){if(n!=(VSNode*)&node_storage)failure=1;node_freed=1;}

static int fake_map_set_data(VSMap*m,const char*key,const char*value,int size,int type,int append){
    if(m!=(VSMap*)&property_map_storage||type!=dtUtf8||append!=maReplace)failure=1;
    if(!strcmp(key,"Deblock4Filter")){if(!same_bytes(value,size,current_deblock4?"Deblock4":"Classic"))failure=1;common_filter=1;}
    else if(!strcmp(key,"Deblock4Tier")){if(!same_bytes(value,size,"x86_64_v3_with_avx2"))failure=1;common_tier=1;}
    else if(!strcmp(key,"Deblock4Version")){if(!same_bytes(value,size,"0.1.0-dev+1C"))failure=1;common_version=1;}
    else if(!strcmp(key,"Deblock4GridMode")){if(!current_deblock4||!same_bytes(value,size,"mpeg2_progressive"))failure=1;grid_mode=1;}
    else failure=1;
    return 0;
}
static int fake_map_set_int(VSMap*m,const char*key,int64_t v,int append){
    if(m!=(VSMap*)&property_map_storage||append!=maReplace||v!=8)failure=1;
    if(!strcmp(key,"Deblock4LumaStepX"))luma_x=1;
    else if(!strcmp(key,"Deblock4LumaStepY"))luma_y=1;
    else if(!strcmp(key,"Deblock4ChromaStepX"))chroma_x=1;
    else if(!strcmp(key,"Deblock4ChromaStepY"))chroma_y=1;
    else failure=1;
    return 0;
}
static int fake_map_set_float(VSMap*m,const char*k,double v,int a){(void)m;(void)k;(void)v;(void)a;midpoint_seen=1;return 0;}

static void run_callbacks(VSFilterGetFrame gf,VSFilterFree ff,void *instance){
    void *frame_data=0; const VSFrame *f;
    f=gf(7,arInitial,instance,&frame_data,(VSFrameContext*)&frame_context_storage,(VSCore*)&core_storage,&api); if(f)failure=1;
    f=gf(7,arAllFramesReady,instance,&frame_data,(VSFrameContext*)&frame_context_storage,(VSCore*)&core_storage,&api); if(f!=(const VSFrame*)&output_frame_storage)failure=1;
    f=gf(7,arError,instance,&frame_data,(VSFrameContext*)&frame_context_storage,(VSCore*)&core_storage,&api); if(f)failure=1;
    ff(instance,(VSCore*)&core_storage,&api);
}
static void fake_create_filter(VSMap*out,const char*name,const VSVideoInfo*vi,VSFilterGetFrame gf,VSFilterFree ff,int mode,const VSFilterDependency*d,int nd,void*instance,VSCore*core){
    (void)out;
    if(strcmp(name,current_deblock4?"Deblock4":"Classic")||vi!=&video_info||mode!=fmParallel||nd!=1||!d||d[0].source!=(VSNode*)&node_storage||d[0].requestPattern!=rpStrictSpatial||!instance||core!=(VSCore*)&core_storage)failure=1;
    run_callbacks(gf,ff,instance);
}
static void reset(int d){
    current_deblock4=d; failure=0; requested=obtained=copied=source_freed=node_freed=0;
    common_filter=common_tier=common_version=0;grid_mode=luma_x=luma_y=chroma_x=chroma_y=midpoint_seen=0;
    memset(&video_info,0,sizeof(video_info));video_info.format.colorFamily=cfGray;video_info.format.sampleType=stInteger;video_info.format.bitsPerSample=8;video_info.format.bytesPerSample=1;video_info.format.numPlanes=1;video_info.width=16;video_info.height=16;video_info.numFrames=8;video_info.fpsNum=25;video_info.fpsDen=1;
}
static int run_one(int d){
    reset(d);
    (d?deblock4_create:classic_create)((const VSMap*)&input_map_storage,(VSMap*)&output_map_storage,0,(VSCore*)&core_storage,&api);
    if(failure||!requested||!obtained||!copied||source_freed!=1||!node_freed||!common_filter||!common_tier||!common_version)return d?20:10;
    if(d){if(!grid_mode||!luma_x||!luma_y||!chroma_x||!chroma_y||midpoint_seen)return 21;}
    else if(grid_mode||luma_x||luma_y||chroma_x||chroma_y||midpoint_seen)return 11;
    return 0;
}
int phase3a_run_smoke(void){
    int r; memset(&api,0,sizeof(api));memset(&plugin_api,0,sizeof(plugin_api));
    plugin_api.configPlugin=fake_config_plugin;plugin_api.registerFunction=fake_register_function;
    api.createVideoFilter=fake_create_filter;api.freeNode=fake_free_node;api.getVideoInfo=fake_get_video_info;api.getFrameFilter=fake_get_frame_filter;api.requestFrameFilter=fake_request_frame_filter;api.copyFrame=fake_copy_frame;api.freeFrame=fake_free_frame;api.getFramePropertiesRW=fake_get_props_rw;api.setFilterError=fake_set_filter_error;api.mapSetError=fake_map_set_error;api.mapNumElements=fake_map_num_elements;api.mapGetInt=fake_map_get_int;api.mapGetIntArray=fake_map_get_int_array;api.mapGetFloat=fake_map_get_float;api.mapGetData=fake_map_get_data;api.mapGetDataSize=fake_map_get_data_size;api.mapGetNode=fake_map_get_node;api.mapSetData=fake_map_set_data;api.mapSetInt=fake_map_set_int;api.mapSetFloat=fake_map_set_float;
    VapourSynthPluginInit2((VSPlugin*)&plugin_storage,&plugin_api);
    if(failure||!classic_create||!deblock4_create)return 1;
    r=run_one(0);if(r)return r;return run_one(1);
}
