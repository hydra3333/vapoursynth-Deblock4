# Stage 1C Phase 3a - Apply and Validate

This delivery is prepared against the prevailing committed Phase 2 source in
`src(42).zip` (SHA-256
`ac2aa4c494e7a2312cea2af2e85ffae9fa7c0049e9ea15942dc9a6730955c29f`).
It delivers Phase 3a only. It does not perform the Phase 3b sweep or modify the
permanent repository build graph.

## Recommended fail-closed sequence

Extract this delivery OUTSIDE the repository. Then run:

```bat
call "<EXTRACTED_DELIVERY>\apply_phase3a_and_validate.bat" "<REPOSITORY_ROOT>"
```

Example:

```bat
call "E:\deliveries\Deblock4_Stage_1C_Phase_3a_W3C_delivery_v1_0\apply_phase3a_and_validate.bat" "E:\SOFTWARE-Win11\MULTIMEDIA\vapoursynth-Deblock4\github\vapoursynth-Deblock4"
```

The helper stops on the first failure. It:

1. Confirms the repository is on branch `main`.
2. Prints `git status --short`.
3. Refuses to overwrite any of the eleven new Phase 3a source files.
4. Copies the existing-file patch to the repository root.
5. Runs both patch checks and stops if either fails.
6. Applies the patch.
7. Copies the eleven complete new files into `src`.
8. Runs `git diff --check`.
9. Replaces `validation_support_3a` with the delivered validation support.
10. Builds the real plugin root as a Windows DLL and runs the single-root smoke
    in Debug, ReleaseSafe, and ReleaseFast.
11. Rebuilds the existing selftest in all three modes.
12. Verifies that the temporary validation root was removed.
13. Runs the final whitespace check and prints `git status --short`.

## Fully explicit manual sequence

From the repository root:

```bat
git status --short

git branch --show-current
REM Expected: main

copy /Y "<EXTRACTED_DELIVERY>\Deblock4_Stage_1C_Phase_3a_existing_edits_v1_0.patch" ".\"

git apply --check Deblock4_Stage_1C_Phase_3a_existing_edits_v1_0.patch
if errorlevel 1 exit /b 1

git apply --check --whitespace=error-all Deblock4_Stage_1C_Phase_3a_existing_edits_v1_0.patch
if errorlevel 1 exit /b 1

git apply Deblock4_Stage_1C_Phase_3a_existing_edits_v1_0.patch
if errorlevel 1 exit /b 1
```

Before copying, confirm that none of these destinations already exists:

```text
src/classic_ar_initial.zig
src/deblock4_ar_initial.zig
src/classic_ar_all_frames_ready.zig
src/deblock4_ar_all_frames_ready.zig
src/common_ar_error.zig
src/common_frame_mechanics.zig
src/common_frame_property_helpers.zig
src/classic_frame_properties.zig
src/deblock4_frame_properties.zig
src/deblock4_plugin.zig
src/lifecycle_trace_debug.zig
```

Then copy the complete files:

```bat
copy /Y "<EXTRACTED_DELIVERY>\full_files\src\classic_ar_initial.zig" "src\classic_ar_initial.zig"
copy /Y "<EXTRACTED_DELIVERY>\full_files\src\deblock4_ar_initial.zig" "src\deblock4_ar_initial.zig"
copy /Y "<EXTRACTED_DELIVERY>\full_files\src\classic_ar_all_frames_ready.zig" "src\classic_ar_all_frames_ready.zig"
copy /Y "<EXTRACTED_DELIVERY>\full_files\src\deblock4_ar_all_frames_ready.zig" "src\deblock4_ar_all_frames_ready.zig"
copy /Y "<EXTRACTED_DELIVERY>\full_files\src\common_ar_error.zig" "src\common_ar_error.zig"
copy /Y "<EXTRACTED_DELIVERY>\full_files\src\common_frame_mechanics.zig" "src\common_frame_mechanics.zig"
copy /Y "<EXTRACTED_DELIVERY>\full_files\src\common_frame_property_helpers.zig" "src\common_frame_property_helpers.zig"
copy /Y "<EXTRACTED_DELIVERY>\full_files\src\classic_frame_properties.zig" "src\classic_frame_properties.zig"
copy /Y "<EXTRACTED_DELIVERY>\full_files\src\deblock4_frame_properties.zig" "src\deblock4_frame_properties.zig"
copy /Y "<EXTRACTED_DELIVERY>\full_files\src\deblock4_plugin.zig" "src\deblock4_plugin.zig"
copy /Y "<EXTRACTED_DELIVERY>\full_files\src\lifecycle_trace_debug.zig" "src\lifecycle_trace_debug.zig"

git -c core.whitespace=cr-at-eol diff --check
if errorlevel 1 exit /b 1

if exist validation_support_3a rmdir /s /q validation_support_3a
if exist validation_support_3a exit /b 1
xcopy "<EXTRACTED_DELIVERY>\validation_support_3a" "validation_support_3a\" /E /H /I /Y
if errorlevel 1 exit /b 1

call validation_support_3a\build_1c3a_phase3a_validation.bat
if errorlevel 1 exit /b 1

if exist src\__phase3a_validation_plugin_root.zig exit /b 1

git -c core.whitespace=cr-at-eol diff --check
if errorlevel 1 exit /b 1

git status --short
```

Do not edit a failed patch by hand. Stop and report the first failure.

## Expected validation result

The Phase 3a validation batch should complete all of the following:

```text
Debug       plugin DLL compile + single-root smoke, lifecycle trace enabled
ReleaseSafe plugin DLL compile + single-root smoke, lifecycle trace disabled
ReleaseFast plugin DLL compile + single-root smoke, lifecycle trace disabled
Debug       existing selftest regression build
ReleaseSafe existing selftest regression build
ReleaseFast existing selftest regression build
git diff --check PASS
no src/__phase3a_validation_plugin_root.zig remains
PHASE 3A VALIDATION COMPLETED SUCCESSFULLY
```

The Debug lifecycle trace writes to stderr. Zig may therefore print a benign
`failed command: ... --listen=-` runner diagnostic even when the test exits
successfully. Treat the batch exit code, absence of a real `error:` diagnostic,
and the explicit success terminus as the authoritative result.

Stop after reporting the Phase 3a results. Do not begin Phase 3b until W3X
accepts Phase 3a and releases Phase 3b.
