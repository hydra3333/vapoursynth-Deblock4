@echo off
setlocal EnableExtensions EnableDelayedExpansion

if "%~1"=="" (
    echo USAGE: call "%~f0" "FULL_PATH_TO_REPOSITORY_ROOT"
    exit /b 2
)

set "delivery_root=%~dp0"
set "repo_root=%~f1"
set "patch_name=Deblock4_Stage_1C_Phase_3a_existing_edits_v1_0.patch"
set "patch_source=%delivery_root%%patch_name%"
set "patch_repo=%repo_root%\%patch_name%"

if not exist "%repo_root%\.git" (
    echo ERROR: repository root does not contain .git: "%repo_root%"
    exit /b 1
)
if not exist "%patch_source%" (
    echo ERROR: delivery patch is missing: "%patch_source%"
    exit /b 1
)

cd /d "%repo_root%" || exit /b 1
for /f "delims=" %%B in ('git branch --show-current') do set "branch=%%B"
if /I not "!branch!"=="main" (
    echo ERROR: expected branch main, found "!branch!".
    exit /b 1
)

echo ================================================================
echo PRE-APPLY STATUS
echo ================================================================
git status --short
if errorlevel 1 exit /b 1

for %%F in (
    classic_ar_initial.zig
    deblock4_ar_initial.zig
    classic_ar_all_frames_ready.zig
    deblock4_ar_all_frames_ready.zig
    common_ar_error.zig
    common_frame_mechanics.zig
    common_frame_property_helpers.zig
    classic_frame_properties.zig
    deblock4_frame_properties.zig
    deblock4_plugin.zig
    lifecycle_trace_debug.zig
) do (
    if exist "src\%%F" (
        echo ERROR: expected new file already exists: src\%%F
        exit /b 1
    )
)

copy /Y "%patch_source%" "%patch_repo%" >nul
if errorlevel 1 exit /b 1

git apply --check "%patch_name%"
if errorlevel 1 exit /b 1
git apply --check --whitespace=error-all "%patch_name%"
if errorlevel 1 exit /b 1
git apply "%patch_name%"
if errorlevel 1 exit /b 1

for %%F in (
    classic_ar_initial.zig
    deblock4_ar_initial.zig
    classic_ar_all_frames_ready.zig
    deblock4_ar_all_frames_ready.zig
    common_ar_error.zig
    common_frame_mechanics.zig
    common_frame_property_helpers.zig
    classic_frame_properties.zig
    deblock4_frame_properties.zig
    deblock4_plugin.zig
    lifecycle_trace_debug.zig
) do (
    copy /Y "%delivery_root%full_files\src\%%F" "src\%%F" >nul
    if errorlevel 1 exit /b 1
)

git -c core.whitespace=cr-at-eol diff --check
if errorlevel 1 exit /b 1

if exist "validation_support_3a" rmdir /s /q "validation_support_3a"
if exist "validation_support_3a" exit /b 1
xcopy "%delivery_root%validation_support_3a" "validation_support_3a\" /E /H /I /Y >nul
if errorlevel 1 exit /b 1

call "validation_support_3a\build_1c3a_phase3a_validation.bat"
if errorlevel 1 exit /b 1

if exist "src\__phase3a_validation_plugin_root.zig" (
    echo ERROR: temporary Phase 3a validation root was not removed.
    exit /b 1
)

git -c core.whitespace=cr-at-eol diff --check
if errorlevel 1 exit /b 1

echo ================================================================
echo POST-VALIDATION STATUS
echo ================================================================
git status --short
if errorlevel 1 exit /b 1

exit /b 0
