# Expected repository change from v1.10 to v1.11

## Replaced

- `build_1C_v1.bat`
- `tests/stage_1c_classic_passthrough.vpy`
- `tests/stage_1c_deblock4_passthrough.vpy`

## Added

- none

## Deleted

- none

No production code or W3X-owned file is modified by v1.11. Stage 1C.1 work is not included.
