# Phase 3b v1.11 W3C Static Validation

## Passed

- repository change set contains exactly the runner and the two `.vpy` validation harnesses;
- `error_wrong_type` is absent from both runner case lists and from both harnesses;
- the approved Toolchain finding F6 comment appears beside the retained strength range case in each harness;
- every other runner case token and harness branch is byte-identical to the v1.10 basis;
- production source and the v1.10 selftest correction are untouched;
- the bounded S3 correction from v1.9 is untouched;
- no Stage 1C.1 invocation-echo or frame-property mitigation is present;
- both `.vpy` files compile as Python syntax;
- runner labels and internal `call`/`goto` targets resolve;
- the resume helper has exactly three repository copy/byte-verification targets;
- no W3X-owned file is included under `full_files`;
- all delivery text is US-ASCII/CRLF;
- package SHA-256 entries verify;
- ZIP integrity test passes.

## Evidence treatment

The v1.10 transcript remains valid partial evidence through the midpoint cases. The resume helper preserves the existing local `build_1C_v1_full_output.log` and diagnostic index under `zig-out/inspection_1C_v1_10_partial_evidence/` when available before rerunning the matrix.

## Not executed by W3C

The container does not provide the W3X Windows/Visual Studio/VapourSynth environment. W3X must run the complete delivered proof matrix. W3D then reviews the artifacts and W3C concurs or identifies a defect.
