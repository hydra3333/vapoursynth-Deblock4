# Phase 3b v1.9 W3C Static and Mutation Validation

## Passed

- repository change set contains exactly `tools/audit_stage_1c_s3_eol.ps1`;
- S3 root-file domain is exactly `build.zig`, `build.zig.zon` and `build_1C_v1.bat`;
- S3 directory domain is exactly `src/`, `tests/`, `tools/` and `third_party/`;
- excluded repository areas are not selected by the bounded filter;
- the existing text-extension list and byte-level non-ASCII/bare-LF checks are retained;
- all four permanent `tools/audit_stage_1c_*.ps1` files remain in-domain;
- current v1.8 deliverable-tree simulation passes the bounded audit;
- injected bare LF in an in-domain `.zig` file is detected;
- injected non-ASCII in an in-domain `.ps1` file is detected;
- injected bare LF and non-ASCII outside the bounded domain do not affect S3;
- delivery helper has one copy operation and one byte-for-byte verification target;
- no W3X-owned file is included under `full_files`;
- all delivery text is US-ASCII/CRLF;
- package SHA-256 entries verify;
- ZIP integrity test passes.

## Not executed by W3C

The container does not provide Windows `cmd.exe`, PowerShell 5.1, Visual Studio 2026, Zig 0.16.0, `dumpbin` or the portable VapourSynth runtime. W3X must run the complete delivered proof matrix. W3D then reviews the artifacts and W3C concurs or identifies a defect.
