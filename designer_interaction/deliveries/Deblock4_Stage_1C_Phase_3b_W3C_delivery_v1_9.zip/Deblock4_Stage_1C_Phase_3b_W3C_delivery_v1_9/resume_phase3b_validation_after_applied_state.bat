@echo off
setlocal EnableExtensions EnableDelayedExpansion

if "%~1"=="" (
    echo USAGE: call "%~f0" "FULL_PATH_TO_V1.8_APPLIED_REPOSITORY_ROOT"
    exit /b 2
)

set "delivery_root=%~dp0"
set "repo_root=%~f1"
set "source=%delivery_root%full_files\tools\audit_stage_1c_s3_eol.ps1"
set "destination=%repo_root%\tools\audit_stage_1c_s3_eol.ps1"

if not exist "%repo_root%\.git" (
    echo ERROR: repository root does not contain .git: "%repo_root%"
    exit /b 1
)
if not exist "%source%" (
    echo ERROR: v1.9 S3 audit file missing: "%source%"
    exit /b 1
)

cd /d "%repo_root%" || exit /b 1

set "branch="
for /f "delims=" %%B in ('git branch --show-current') do set "branch=%%B"
if /I not "!branch!"=="main" (
    echo ERROR: expected branch main, found "!branch!".
    exit /b 1
)

rem Confirm the current Phase 3b validation surface is present. This helper changes only S3.
if not exist "build_1C_v1.bat" (echo ERROR: Phase 3b runner missing: build_1C_v1.bat & exit /b 1)
if not exist "tools\audit_stage_1c_s1_structure.ps1" (echo ERROR: S1 audit missing & exit /b 1)
if not exist "tools\audit_stage_1c_g10_imports.ps1" (echo ERROR: G10 audit missing & exit /b 1)
if not exist "tools\audit_stage_1c_s2_sweep.ps1" (echo ERROR: S2 audit missing & exit /b 1)
if not exist "tests\stage_1c_classic_passthrough.vpy" (echo ERROR: Classic harness missing & exit /b 1)
if not exist "tests\stage_1c_deblock4_passthrough.vpy" (echo ERROR: Deblock4 harness missing & exit /b 1)

if not exist "tools" md "tools"
if errorlevel 1 exit /b 1
copy /Y "%source%" "%destination%" >nul
if errorlevel 1 (
    echo ERROR: failed to install tools\audit_stage_1c_s3_eol.ps1.
    exit /b 1
)
fc /B "%source%" "%destination%" >nul
if errorlevel 1 (
    echo ERROR: installed S3 audit does not match v1.9 delivery bytes.
    exit /b 1
)

echo ================================================================
echo PHASE 3B V1.9 SINGLE-FILE S3 CORRECTION INSTALLED
echo Changed repository file: tools\audit_stage_1c_s3_eol.ps1
echo No other repository file was copied, deleted or normalised.
echo ================================================================

git -c core.whitespace=cr-at-eol diff --check
if errorlevel 1 exit /b 1

call "build_1C_v1.bat"
set "proof_code=!ERRORLEVEL!"
if not "!proof_code!"=="0" exit /b !proof_code!

git -c core.whitespace=cr-at-eol diff --check
if errorlevel 1 exit /b 1

echo ================================================================
echo POST-VALIDATION STATUS
echo ================================================================
git status --short
if errorlevel 1 exit /b 1

echo ================================================================
echo PHASE 3B V1.9 S3-CORRECTED VALIDATION COMPLETED SUCCESSFULLY
echo ================================================================
exit /b 0
