# Expected repository change from v1.8 to v1.9

## Replaced

- `tools/audit_stage_1c_s3_eol.ps1`

## Added

- none

## Deleted

- none

No W3X-owned file is modified by v1.9.
