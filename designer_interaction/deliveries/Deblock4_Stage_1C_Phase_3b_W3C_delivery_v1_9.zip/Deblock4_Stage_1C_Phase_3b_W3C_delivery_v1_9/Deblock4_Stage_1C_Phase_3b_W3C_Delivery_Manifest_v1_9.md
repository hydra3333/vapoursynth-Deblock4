# Deblock4 Stage 1C Phase 3b - W3C Delivery Manifest

**Version:** 1.9
**Date:** 2026-08-02
**Author:** W3C
**Status:** Single-file corrective delivery candidate for W3D review and W3X validation/acceptance.
**Repository:** `hydra3333/vapoursynth-Deblock4`
**Branch:** `main`
**Encoding:** US-ASCII and CRLF.

## 1. Controlling W3D ruling

W3D assessed materiality under Charter section 2.3b and ruled that S3's proof domain is the Stage 1C deliverable tree, not the whole repository. W3X is to record that ruling.

The bounded domain is:

- `build.zig`
- `build.zig.zon`
- `build_1C_v1.bat`
- everything under `src/`
- everything under `tests/`
- everything under `tools/`
- everything under `third_party/`

The following are outside S3's code-deliverable domain and are not scanned:

- `dev_documentation/**`
- `superseded/**`
- `designer_interaction/**`
- `.claude/**`
- `.vscode/**`
- `CLAUDE.md`
- `.gitignore`
- `README.md`

The four permanent audit scripts remain under `tools/` and therefore self-audit.

## 2. Exact repository change

v1.9 changes exactly one repository file:

- `tools/audit_stage_1c_s3_eol.ps1`

No other repository file is supplied, copied, deleted, reformatted or normalised by this delivery. In particular, no W3X-owned header or `tools/run_vs.cmd` is modified. Those files remain read-only members of the bounded S3 audit domain.

## 3. Logic change

The byte-level ASCII and bare-LF tests are unchanged. The script still obtains tracked and unignored files from `git ls-files -co --exclude-standard`, but filters that list to the W3D-ruled deliverable roots before applying the existing text-extension and byte checks.

The success marker is:

```text
S3_STAGE_1C_DELIVERABLE_TREE_PASS
```

## 4. Base and use

This is a corrective delta for the currently applied Phase 3b v1.8 repository state. It is not a fresh Phase 3a application package.

Run:

```bat
call "<EXTRACTED_V1_9_DELIVERY>\resume_phase3b_validation_after_applied_state.bat" "<REPOSITORY_ROOT>"
```

The helper byte-verifies the one copied S3 script, runs `git diff --check`, and reruns the complete permanent `build_1C_v1.bat` proof matrix.

## 5. Authoritative success terminus

```text
STAGE 1C_v1 FULL PROOF MATRIX COMPLETED SUCCESSFULLY
B1 B2 G1 G2 E1 E2 E3 E4 E5 E6 V1 S1 S2 S3 N1 PASS
```

W3C performed static and mutation validation only. W3X's Windows/VS2026/Zig/VapourSynth run remains authoritative; W3D review, W3C concurrence and W3X acceptance remain required.
