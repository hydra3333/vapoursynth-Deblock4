# stage_4c_scalar_v2_diff.py - Deblock4 Stage 4C W3D differential harness
# W3D-owned (scope v1_2 sections 7/8; delivery join contract, manifest s4).
# Run under the portable VapourSynth python (tools\run_vs.cmd --python-script).
#
# EXIT CODES (contract with run_stage_4c_differential.cmd):
#   0 = ALL PASS (positive acceptance)
#   2 = DIFFERENCES DETECTED (scalar vs v2 mismatch - the tail-mutant run
#       kind EXPECTS this code)
#   3 = SELECTION/COVERAGE FAILURE (T4 assertions)
#   4 = ENVIRONMENT/CONTRACT FAILURE (env vars, load, policy, hardware)
#
# US-ASCII; CRLF.

import hashlib
import json
import os
import sys

MARK_PASS = "STAGE_4C_SCALAR_V2_DIFFERENTIAL_ALL_PASS"
MARK_DIFF = "STAGE_4C_DIFFERENTIAL_DETECTED_DIFFERENCES"
MARK_SELECT = "STAGE_4C_SELECTION_COVERAGE_FAIL"
MARK_ENV = "STAGE_4C_ENVIRONMENT_FAIL"


def env_fail(message):
    print(MARK_ENV + " " + message)
    sys.exit(4)


def require_env(name):
    value = os.environ.get(name, "")
    if not value:
        env_fail("missing environment variable " + name)
    return value


PLUGIN_PATH = require_env("DEBLOCK4_PLUGIN_PATH")
INSPECT_DIR = require_env("DEBLOCK4_STAGE4C_INSPECTION_DIR")
EXPECTED_VERSION = require_env("DEBLOCK4_STAGE4C_EXPECTED_VERSION")
EXPECTED_V1 = require_env("DEBLOCK4_STAGE4C_EXPECTED_V1")
EXPECTED_V2 = require_env("DEBLOCK4_STAGE4C_EXPECTED_V2")
RUN_KIND = os.environ.get("DEBLOCK4_STAGE4C_RUN_KIND", "positive")

if not os.path.isfile(PLUGIN_PATH):
    env_fail("plugin not found: " + PLUGIN_PATH)
os.makedirs(INSPECT_DIR, exist_ok=True)

with open(PLUGIN_PATH, "rb") as handle:
    DLL_SHA256 = hashlib.sha256(handle.read()).hexdigest()

# ---------------------------------------------------------------- policy ---
import vapoursynth as vs

if vs.core is None:
    pass  # touch nothing before the policy exists


class IsolationPolicy:
    def __init__(self):
        self.api = None

    def on_policy_registered(self, api):
        self.api = api

    def on_policy_cleared(self):
        self.api = None

    def is_alive(self, environment):
        return True


try:
    policy = IsolationPolicy()
    vs.register_policy(policy)
except vs.Error as error:
    env_fail("policy registration failed (pre-existing policy?): " + str(error))

environment = policy.api.create_environment()
with vs.EnvironmentContext(environment):
    core = vs.core.core
    core.disable_library_unloading = True
    if hasattr(core, "flags"):
        pass
    # Autoload must be off: the environment was created by our policy with
    # the default core creation flags of the embedding python; enforce
    # hermetically by asserting our namespace is absent before manual load.
    if hasattr(core, "deblock4"):
        env_fail("deblock4 namespace present before manual load (autoload?)")
    core.std.LoadPlugin(path=os.path.abspath(PLUGIN_PATH))
    if not hasattr(core, "deblock4"):
        env_fail("manual plugin load did not expose namespace deblock4")

    # ------------------------------------------------------ generators ---
    def lcg_bytes(count, seed):
        state = (seed * 2654435761 + 12345) & 0xFFFFFFFF
        out = bytearray(count)
        for index in range(count):
            state = (state * 1664525 + 1013904223) & 0xFFFFFFFF
            out[index] = (state >> 24) & 0xFF
        return out

    def fill_plane(frame, plane, width, height, kind, seed, bits):
        peak = (1 << bits) - 1
        view = frame[plane]
        noise = lcg_bytes(width, seed + plane * 7919)
        for y in range(height):
            row = view[y]
            for x in range(width):
                if kind == "flat":
                    value = 128 if bits == 8 else (1 << (bits - 1))
                elif kind == "blocks":
                    step = ((x // 8) * 23 + (y // 8) * 41 + plane * 11) % 160
                    value = (20 + step) * peak // 255
                elif kind == "blocks_noise":
                    step = ((x // 8) * 23 + (y // 8) * 41 + plane * 11) % 144
                    jitter = noise[(x + y * 3) % width] % 5
                    value = (24 + step + jitter) * peak // 255
                else:  # "extremes"
                    band = ((x // 8) + (y // 8) + plane) % 3
                    value = 0 if band == 0 else (peak if band == 1 else peak // 2)
                row[x] = value
        return frame

    def make_source(width, height, fmt, frames, kind, seed, bits):
        blank = core.std.BlankClip(
            width=width, height=height, format=fmt, length=frames, keep=True
        )

        def initialise(n, f):
            fout = f.copy()
            for plane in range(fout.format.num_planes):
                pw = fout.width >> (fout.format.subsampling_w if plane else 0)
                ph = fout.height >> (fout.format.subsampling_h if plane else 0)
                fill_plane(fout, plane, pw, ph, kind, seed + n * 101, bits)
            return fout

        return core.std.ModifyFrame(blank, blank, initialise)

    # ----------------------------------------------------------- corpus ---
    # (name, width, height, format_name, bits, kind, frames, params, expect_changes)
    CASES = [
        ("C4C-01_gray8_711x480_r7", 711, 480, "GRAY8", 8, "blocks", 3, {}, True),
        ("C4C-02_gray8_719x479_r15_h3", 719, 479, "GRAY8", 8, "blocks_noise", 3, {}, True),
        ("C4C-03_gray8_353x289_r1_h1", 353, 289, "GRAY8", 8, "blocks", 3, {}, True),
        ("C4C-04_444p8_711x480", 711, 480, "YUV444P8", 8, "blocks_noise", 3, {}, True),
        ("C4C-05_420p8_718x478_r14_h2", 718, 478, "YUV420P8", 8, "blocks", 3, {}, True),
        ("C4C-06_420p8_354x290_r2", 354, 290, "YUV420P8", 8, "blocks_noise", 3, {}, True),
        ("C4C-07_422p8_718x479", 718, 479, "YUV422P8", 8, "blocks", 3, {}, True),
        ("C4C-08_gray16_719x479_r7u16", 719, 479, "GRAY16", 16, "blocks", 3, {}, True),
        ("C4C-09_444p16_711x480", 711, 480, "YUV444P16", 16, "blocks_noise", 3, {}, True),
        ("C4C-10_420p10_354x290", 354, 290, "YUV420P10", 10, "blocks", 3, {}, True),
        ("C4C-11_gray8_smallest_12x9", 12, 9, "GRAY8", 8, "blocks", 2, {}, True),
        ("C4C-12_gray8_flat_noop", 96, 64, "GRAY8", 8, "flat", 2, {}, False),
        ("C4C-13_gray8_extremes_clamp", 160, 96, "GRAY8", 8, "extremes", 2,
         {"strength": 60}, True),
        ("C4C-14_444p8_planes_luma_only", 240, 160, "YUV444P8", 8, "blocks", 2,
         {"planes": [0]}, True),
        ("C4C-15_420p8_planes_chroma_only", 240, 160, "YUV420P8", 8, "blocks", 2,
         {"planes": [1, 2]}, True),
        ("C4C-16_gray8_corner_offsets_low", 160, 96, "GRAY8", 8, "blocks", 2,
         {"strength": 25, "boundary_strength_offset": -25,
          "side_activity_offset": -25}, False),
        ("C4C-17_gray8_corner_offsets_high", 160, 96, "GRAY8", 8, "blocks", 2,
         {"strength": 25, "boundary_strength_offset": 35,
          "side_activity_offset": 35}, True),
        ("C4C-18_gray16_h_underfill_9x6", 9, 6, "GRAY16", 16, "blocks", 2, {}, False),
    ]

    def get_format(name):
        return getattr(vs, name)

    def props_of(clip):
        frame = clip.get_frame(0)
        return {
            "tier": bytes(frame.props["Deblock4Tier"]).decode("ascii")
            if isinstance(frame.props["Deblock4Tier"], (bytes, bytearray))
            else str(frame.props["Deblock4Tier"]),
            "version": bytes(frame.props["Deblock4Version"]).decode("ascii")
            if isinstance(frame.props["Deblock4Version"], (bytes, bytearray))
            else str(frame.props["Deblock4Version"]),
        }

    # ---------------------------------------------- T4 selection coverage ---
    selection_report = {}
    probe = make_source(96, 64, get_format("GRAY8"), 1, "blocks", 424243, 8)
    try:
        auto_clip = core.deblock4.Classic(clip=probe)
        v1_clip = core.deblock4.Classic(clip=probe, backend=EXPECTED_V1)
        v2_clip = core.deblock4.Classic(clip=probe, backend=EXPECTED_V2)
    except vs.Error as error:
        print(MARK_ENV + " creation failed during selection coverage: " + str(error))
        sys.exit(4)
    auto_props = props_of(auto_clip)
    v1_props = props_of(v1_clip)
    v2_props = props_of(v2_clip)
    selection_report = {"auto": auto_props, "v1": v1_props, "v2": v2_props}
    selection_ok = (
        auto_props["tier"] == EXPECTED_V2
        and v1_props["tier"] == EXPECTED_V1
        and v2_props["tier"] == EXPECTED_V2
        and auto_props["version"] == EXPECTED_VERSION
        and v1_props["version"] == EXPECTED_VERSION
        and v2_props["version"] == EXPECTED_VERSION
    )
    if not selection_ok:
        print(MARK_SELECT + " " + json.dumps(selection_report))
        summary_path = os.path.join(INSPECT_DIR, "stage_4c_diff_summary.json")
        with open(summary_path, "w") as handle:
            json.dump({"run_kind": RUN_KIND, "dll_sha256": DLL_SHA256,
                       "selection": selection_report,
                       "verdict": "SELECTION_FAIL"}, handle, indent=2)
        sys.exit(3)

    # ----------------------------------------------------- differential ---
    case_reports = []
    first_difference = None
    total_diff_samples = 0

    for (name, width, height, fmt_name, bits, kind, frames, params,
         expect_changes) in CASES:
        fmt = get_format(fmt_name)
        source = make_source(width, height, fmt, frames, kind,
                             seed=hash(name) & 0xFFFF, bits=bits)
        leg_v1 = core.deblock4.Classic(clip=source, backend=EXPECTED_V1, **params)
        leg_v2 = core.deblock4.Classic(clip=source, backend=EXPECTED_V2, **params)
        case_diffs = 0
        case_changed_vs_source = 0
        for n in range(frames):
            f_src = source.get_frame(n)
            f_v1 = leg_v1.get_frame(n)
            f_v2 = leg_v2.get_frame(n)
            for plane in range(f_v1.format.num_planes):
                a = bytes(f_v1[plane])
                b = bytes(f_v2[plane])
                s = bytes(f_src[plane])
                if a != s:
                    case_changed_vs_source += 1
                if a != b:
                    limit = min(len(a), len(b))
                    for index in range(limit):
                        if a[index] != b[index]:
                            case_diffs += 1
                            if first_difference is None:
                                first_difference = {
                                    "case": name, "frame": n, "plane": plane,
                                    "byte_index": index,
                                    "v1": a[index], "v2": b[index],
                                }
        total_diff_samples += case_diffs
        vacuity_ok = (case_changed_vs_source > 0) if expect_changes else True
        case_reports.append({
            "case": name, "dims": [width, height], "format": fmt_name,
            "frames": frames, "diff_bytes": case_diffs,
            "planes_changed_vs_source": case_changed_vs_source,
            "expect_changes": expect_changes, "non_vacuity_ok": vacuity_ok,
        })

    non_vacuity_all = all(entry["non_vacuity_ok"] for entry in case_reports)

    summary = {
        "run_kind": RUN_KIND,
        "dll_path": os.path.abspath(PLUGIN_PATH),
        "dll_sha256": DLL_SHA256,
        "expected_version": EXPECTED_VERSION,
        "selection": selection_report,
        "cases": case_reports,
        "total_diff_bytes": total_diff_samples,
        "first_difference": first_difference,
        "non_vacuity_all": non_vacuity_all,
        "verdict": ("ALL_PASS" if (total_diff_samples == 0 and non_vacuity_all)
                    else "DIFFERENCES" if total_diff_samples else "VACUITY_FAIL"),
    }
    summary_path = os.path.join(INSPECT_DIR, "stage_4c_diff_summary.json")
    with open(summary_path, "w") as handle:
        json.dump(summary, handle, indent=2)

    if total_diff_samples != 0:
        print(MARK_DIFF + " total_diff_bytes=" + str(total_diff_samples)
              + " first=" + json.dumps(first_difference))
        sys.exit(2)
    if not non_vacuity_all:
        print(MARK_SELECT + " non-vacuity failed (differential proved nothing)")
        sys.exit(3)
    print(MARK_PASS + " cases=" + str(len(CASES))
          + " dll_sha256=" + DLL_SHA256)
    sys.exit(0)
